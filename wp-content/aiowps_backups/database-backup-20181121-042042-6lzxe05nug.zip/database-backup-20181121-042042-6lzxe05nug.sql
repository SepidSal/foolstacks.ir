-- All In One WP Security & Firewall 4.3.7.2
-- MySQL dump
-- 2018-11-21 00:50:42

SET NAMES utf8;
SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `foolstacks`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `foolstacks` AS select `st_links`.`link_id` AS `link_id`,`st_links`.`link_url` AS `link_url`,`st_links`.`link_name` AS `link_name`,`st_links`.`link_image` AS `link_image`,`st_links`.`link_target` AS `link_target`,`st_links`.`link_description` AS `link_description`,`st_links`.`link_visible` AS `link_visible`,`st_links`.`link_owner` AS `link_owner`,`st_links`.`link_rating` AS `link_rating`,`st_links`.`link_updated` AS `link_updated`,`st_links`.`link_rel` AS `link_rel`,`st_links`.`link_notes` AS `link_notes`,`st_links`.`link_rss` AS `link_rss` from `st_links`;



DROP TABLE IF EXISTS `st_aiowps_events`;

CREATE TABLE `st_aiowps_events` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `event_type` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `username` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `event_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ip_or_host` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referer_info` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_data` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `st_aiowps_failed_logins`;

CREATE TABLE `st_aiowps_failed_logins` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_login_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `login_attempt_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `st_aiowps_global_meta`;

CREATE TABLE `st_aiowps_global_meta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `meta_key1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key2` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key3` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key4` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key5` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value3` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value4` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value5` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`meta_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `st_aiowps_login_activity`;

CREATE TABLE `st_aiowps_login_activity` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `login_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `logout_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `login_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `login_country` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `browser_type` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `st_aiowps_login_activity` VALUES("1","1","foolstacks","2018-11-13 13:48:00","0000-00-00 00:00:00","5.112.106.225","","");
INSERT INTO `st_aiowps_login_activity` VALUES("2","1","foolstacks","2018-11-13 13:49:18","0000-00-00 00:00:00","185.239.173.205","","");
INSERT INTO `st_aiowps_login_activity` VALUES("3","1","foolstacks","2018-11-13 09:36:08","0000-00-00 00:00:00","5.112.106.225","","");
INSERT INTO `st_aiowps_login_activity` VALUES("4","1","foolstacks","2018-11-13 12:39:16","0000-00-00 00:00:00","5.112.106.225","","");
INSERT INTO `st_aiowps_login_activity` VALUES("5","1","foolstacks","2018-11-13 21:42:26","2018-11-14 03:27:56","91.251.46.50","","");
INSERT INTO `st_aiowps_login_activity` VALUES("6","1","foolstacks","2018-11-13 22:22:19","2018-11-14 03:27:56","91.251.46.50","","");
INSERT INTO `st_aiowps_login_activity` VALUES("7","1","foolstacks","2018-11-14 02:57:52","2018-11-14 03:27:56","91.251.46.50","","");
INSERT INTO `st_aiowps_login_activity` VALUES("8","1","foolstacks","2018-11-14 03:28:04","0000-00-00 00:00:00","91.251.46.50","","");
INSERT INTO `st_aiowps_login_activity` VALUES("9","1","foolstacks","2018-11-14 10:34:15","2018-11-14 10:39:07","185.239.173.206","","");
INSERT INTO `st_aiowps_login_activity` VALUES("10","1","foolstacks","2018-11-14 10:53:00","2018-11-14 10:54:29","5.112.250.213","","");
INSERT INTO `st_aiowps_login_activity` VALUES("11","1","foolstacks","2018-11-14 10:55:58","2018-11-14 11:26:39","5.112.250.213","","");
INSERT INTO `st_aiowps_login_activity` VALUES("12","1","foolstacks","2018-11-14 11:27:45","2018-11-14 11:57:46","5.112.250.213","","");
INSERT INTO `st_aiowps_login_activity` VALUES("13","1","foolstacks","2018-11-14 11:59:04","2018-11-14 12:29:05","5.112.250.213","","");
INSERT INTO `st_aiowps_login_activity` VALUES("14","1","foolstacks","2018-11-14 12:30:25","2018-11-14 13:00:37","5.112.250.213","","");
INSERT INTO `st_aiowps_login_activity` VALUES("15","1","foolstacks","2018-11-14 13:44:49","2018-11-14 13:48:02","5.112.250.213","","");
INSERT INTO `st_aiowps_login_activity` VALUES("16","1","foolstacks","2018-11-14 13:48:12","2018-11-14 13:51:02","5.112.250.213","","");
INSERT INTO `st_aiowps_login_activity` VALUES("17","1","foolstacks","2018-11-14 13:52:49","0000-00-00 00:00:00","5.113.56.201","","");
INSERT INTO `st_aiowps_login_activity` VALUES("18","1","foolstacks","2018-11-14 13:58:42","2018-11-15 20:22:42","109.202.101.49","","");
INSERT INTO `st_aiowps_login_activity` VALUES("19","1","foolstacks","2018-11-15 19:50:20","0000-00-00 00:00:00","5.113.225.207","","");
INSERT INTO `st_aiowps_login_activity` VALUES("20","1","foolstacks","2018-11-15 20:24:45","0000-00-00 00:00:00","5.113.225.207","","");
INSERT INTO `st_aiowps_login_activity` VALUES("21","1","foolstacks","2018-11-16 09:12:30","0000-00-00 00:00:00","86.55.170.217","","");
INSERT INTO `st_aiowps_login_activity` VALUES("22","1","foolstacks","2018-11-16 10:17:18","0000-00-00 00:00:00","86.55.170.217","","");
INSERT INTO `st_aiowps_login_activity` VALUES("23","1","foolstacks","2018-11-16 10:45:35","0000-00-00 00:00:00","86.55.170.217","","");
INSERT INTO `st_aiowps_login_activity` VALUES("24","1","foolstacks","2018-11-17 13:49:22","0000-00-00 00:00:00","5.112.217.133","","");


DROP TABLE IF EXISTS `st_aiowps_login_lockdown`;

CREATE TABLE `st_aiowps_login_lockdown` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lockdown_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `release_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `failed_login_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `lock_reason` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `unlock_key` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `st_aiowps_permanent_block`;

CREATE TABLE `st_aiowps_permanent_block` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `blocked_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `block_reason` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `country_origin` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `blocked_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `unblock` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `st_commentmeta`;

CREATE TABLE `st_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `st_commentmeta` VALUES("1","3","akismet_error","1542139649");
INSERT INTO `st_commentmeta` VALUES("2","3","akismet_history","a:4:{s:4:\"time\";d:1542139649.0091609954833984375;s:5:\"event\";s:11:\"check-error\";s:4:\"user\";s:10:\"foolstacks\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}");
INSERT INTO `st_commentmeta` VALUES("3","3","akismet_as_submitted","a:13:{s:14:\"comment_author\";s:10:\"foolstacks\";s:20:\"comment_author_email\";s:26:\"fullstackdiaries@gmail.com\";s:18:\"comment_author_url\";s:0:\"\";s:15:\"comment_content\";s:21:\"دیدگاه تازه\";s:12:\"comment_type\";s:0:\"\";s:7:\"user_ID\";i:1;s:7:\"user_id\";i:1;s:7:\"user_ip\";s:14:\"109.202.101.49\";s:10:\"user_agent\";s:114:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.77 Safari/537.36\";s:4:\"blog\";s:20:\"http://foolstacks.ir\";s:9:\"blog_lang\";s:5:\"fa_IR\";s:12:\"blog_charset\";s:5:\"UTF-8\";s:9:\"permalink\";s:25:\"http://foolstacks.ir/?p=1\";}");
INSERT INTO `st_commentmeta` VALUES("4","3","akismet_history","a:3:{s:4:\"time\";d:1542181085.3651959896087646484375;s:5:\"event\";s:12:\"status-trash\";s:4:\"user\";s:10:\"foolstacks\";}");
INSERT INTO `st_commentmeta` VALUES("5","3","_wp_trash_meta_status","1");
INSERT INTO `st_commentmeta` VALUES("6","3","_wp_trash_meta_time","1542181085");


DROP TABLE IF EXISTS `st_comments`;

CREATE TABLE `st_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10)),
  KEY `woo_idx_comment_type` (`comment_type`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `st_comments` VALUES("1","1","یک نویسنده‌ی دیدگاه در وردپرس","wapuu@wordpress.example","https://wordpress.org/","","2018-11-10 04:58:36","2018-11-10 01:28:36","سلام, این یک دیدگاه است.
برای شروع مدیریت، ویرایش و پاک کردن دیدگاه‌ها، لطفا بخش دیدگاه‌ها در پیشخوان را ببینید.
تصاویر نویسندگان دیدگاه از <a href=\"https://gravatar.com\">Gravatar</a> گرفته می‌شود.","0","1","","","0","0");
INSERT INTO `st_comments` VALUES("2","105","Mr WordPress","","https://wordpress.org/","","2015-03-10 13:08:25","2015-03-10 13:08:25","Hi, this is a comment.
To delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.","0","post-trashed","","","0","0");
INSERT INTO `st_comments` VALUES("3","1","foolstacks","fullstackdiaries@gmail.com","","109.202.101.49","2018-11-13 19:07:28","2018-11-13 20:07:28","دیدگاه تازه","0","trash","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.77 Safari/537.36","","0","1");


DROP TABLE IF EXISTS `st_layerslider`;

CREATE TABLE `st_layerslider` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `author` int(10) NOT NULL DEFAULT '0',
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_c` int(10) NOT NULL,
  `date_m` int(11) NOT NULL,
  `flag_hidden` tinyint(1) NOT NULL DEFAULT '0',
  `flag_deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `st_links`;

CREATE TABLE `st_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `st_ngg_album`;

CREATE TABLE `st_ngg_album` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `previewpic` bigint(20) NOT NULL DEFAULT '0',
  `albumdesc` mediumtext COLLATE utf8mb4_unicode_ci,
  `sortorder` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `pageid` bigint(20) NOT NULL DEFAULT '0',
  `extras_post_id` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `extras_post_id_key` (`extras_post_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `st_ngg_gallery`;

CREATE TABLE `st_ngg_gallery` (
  `gid` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `path` mediumtext COLLATE utf8mb4_unicode_ci,
  `title` mediumtext COLLATE utf8mb4_unicode_ci,
  `galdesc` mediumtext COLLATE utf8mb4_unicode_ci,
  `pageid` bigint(20) NOT NULL DEFAULT '0',
  `previewpic` bigint(20) NOT NULL DEFAULT '0',
  `author` bigint(20) NOT NULL DEFAULT '0',
  `extras_post_id` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`gid`),
  KEY `extras_post_id_key` (`extras_post_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `st_ngg_gallery` VALUES("1","gallery","Gallery","/wp-content/gallery/gallery/","Gallery","","0","1","1","2356");
INSERT INTO `st_ngg_gallery` VALUES("2","gallery","Gallery-1","/wp-content/gallery/gallery-1/","Gallery","","0","12","1","2368");


DROP TABLE IF EXISTS `st_ngg_pictures`;

CREATE TABLE `st_ngg_pictures` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT,
  `image_slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_id` bigint(20) NOT NULL DEFAULT '0',
  `galleryid` bigint(20) NOT NULL DEFAULT '0',
  `filename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` mediumtext COLLATE utf8mb4_unicode_ci,
  `alttext` mediumtext COLLATE utf8mb4_unicode_ci,
  `imagedate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `exclude` tinyint(4) DEFAULT '0',
  `sortorder` bigint(20) NOT NULL DEFAULT '0',
  `meta_data` longtext COLLATE utf8mb4_unicode_ci,
  `extras_post_id` bigint(20) NOT NULL DEFAULT '0',
  `updated_at` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`pid`),
  KEY `extras_post_id_key` (`extras_post_id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `st_ngg_pictures` VALUES("1","foolstacksgalery-1","0","1","foolstacksgalery-1.gif","","foolstacksgalery (1)","2018-11-14 09:02:18","0","0","eyJiYWNrdXAiOnsiZmlsZW5hbWUiOiJmb29sc3RhY2tzZ2FsZXJ5LTEuZ2lmIiwid2lkdGgiOjgwNCwiaGVpZ2h0Ijo3MTcsImdlbmVyYXRlZCI6IjAuNjAzMjU1MDAgMTU0MjE4NjEzOCJ9LCJhcGVydHVyZSI6ZmFsc2UsImNyZWRpdCI6ZmFsc2UsImNhbWVyYSI6ZmFsc2UsImNhcHRpb24iOmZhbHNlLCJjcmVhdGVkX3RpbWVzdGFtcCI6ZmFsc2UsImNvcHlyaWdodCI6ZmFsc2UsImZvY2FsX2xlbmd0aCI6ZmFsc2UsImlzbyI6ZmFsc2UsInNodXR0ZXJfc3BlZWQiOmZhbHNlLCJmbGFzaCI6ZmFsc2UsInRpdGxlIjpmYWxzZSwia2V5d29yZHMiOmZhbHNlLCJ3aWR0aCI6ODA0LCJoZWlnaHQiOjcxNywic2F2ZWQiOnRydWUsIm1kNSI6IjNiMDM1ZGYwMTZhYzRlOGQ2NzJlNWE4MDY1NzJmZTdlIiwiZnVsbCI6eyJ3aWR0aCI6ODA0LCJoZWlnaHQiOjcxNywibWQ1IjoiM2IwMzVkZjAxNmFjNGU4ZDY3MmU1YTgwNjU3MmZlN2UifSwidGh1bWJuYWlsIjp7IndpZHRoIjoyNDAsImhlaWdodCI6MTYwLCJmaWxlbmFtZSI6InRodW1ic19mb29sc3RhY2tzZ2FsZXJ5LTEuZ2lmIiwiZ2VuZXJhdGVkIjoiMC44OTYyNzEwMCAxNTQyMTg2MTM4In19","2357","1542186138");
INSERT INTO `st_ngg_pictures` VALUES("2","foolstacksgalery-1-1","0","1","foolstacksgalery-1.jpeg","","foolstacksgalery (1)","2018-11-14 09:02:20","0","0","eyJiYWNrdXAiOnsiZmlsZW5hbWUiOiJmb29sc3RhY2tzZ2FsZXJ5LTEuanBlZyIsIndpZHRoIjo4MjIsImhlaWdodCI6NDYyLCJnZW5lcmF0ZWQiOiIwLjM1MTEwNTAwIDE1NDIxODYxNDAifSwiYXBlcnR1cmUiOmZhbHNlLCJjcmVkaXQiOmZhbHNlLCJjYW1lcmEiOmZhbHNlLCJjYXB0aW9uIjpmYWxzZSwiY3JlYXRlZF90aW1lc3RhbXAiOmZhbHNlLCJjb3B5cmlnaHQiOmZhbHNlLCJmb2NhbF9sZW5ndGgiOmZhbHNlLCJpc28iOmZhbHNlLCJzaHV0dGVyX3NwZWVkIjpmYWxzZSwiZmxhc2giOmZhbHNlLCJ0aXRsZSI6ZmFsc2UsImtleXdvcmRzIjpmYWxzZSwid2lkdGgiOjgyMiwiaGVpZ2h0Ijo0NjIsInNhdmVkIjp0cnVlLCJtZDUiOiIwMmQxNGJlMzkwMTA5ZTQ0MmYzZDI0ZmUxNmY2NTk1OSIsImZ1bGwiOnsid2lkdGgiOjgyMiwiaGVpZ2h0Ijo0NjIsIm1kNSI6IjAyZDE0YmUzOTAxMDllNDQyZjNkMjRmZTE2ZjY1OTU5In0sInRodW1ibmFpbCI6eyJ3aWR0aCI6MjQwLCJoZWlnaHQiOjE2MCwiZmlsZW5hbWUiOiJ0aHVtYnNfZm9vbHN0YWNrc2dhbGVyeS0xLmpwZWciLCJnZW5lcmF0ZWQiOiIwLjUxOTM2OTAwIDE1NDIxODYxNDAifX0=","2358","1542186140");
INSERT INTO `st_ngg_pictures` VALUES("3","foolstacksgalery-1-2","0","1","foolstacksgalery-1.jpg","","foolstacksgalery (1)","2018-11-14 09:02:21","0","0","eyJiYWNrdXAiOnsiZmlsZW5hbWUiOiJmb29sc3RhY2tzZ2FsZXJ5LTEuanBnIiwid2lkdGgiOjYyMCwiaGVpZ2h0IjozMDAsImdlbmVyYXRlZCI6IjAuNzg2MzgyMDAgMTU0MjE4NjE0MSJ9LCJhcGVydHVyZSI6ZmFsc2UsImNyZWRpdCI6ZmFsc2UsImNhbWVyYSI6ZmFsc2UsImNhcHRpb24iOmZhbHNlLCJjcmVhdGVkX3RpbWVzdGFtcCI6ZmFsc2UsImNvcHlyaWdodCI6ZmFsc2UsImZvY2FsX2xlbmd0aCI6ZmFsc2UsImlzbyI6ZmFsc2UsInNodXR0ZXJfc3BlZWQiOmZhbHNlLCJmbGFzaCI6ZmFsc2UsInRpdGxlIjpmYWxzZSwia2V5d29yZHMiOmZhbHNlLCJ3aWR0aCI6NjIwLCJoZWlnaHQiOjMwMCwic2F2ZWQiOnRydWUsIm1kNSI6Ijk3YzA2MmE5YzQ4Y2UxZmQwYTM5NGYwOTJkMTQzNzlmIiwiZnVsbCI6eyJ3aWR0aCI6NjIwLCJoZWlnaHQiOjMwMCwibWQ1IjoiOTdjMDYyYTljNDhjZTFmZDBhMzk0ZjA5MmQxNDM3OWYifSwidGh1bWJuYWlsIjp7IndpZHRoIjoyNDAsImhlaWdodCI6MTYwLCJmaWxlbmFtZSI6InRodW1ic19mb29sc3RhY2tzZ2FsZXJ5LTEuanBnIiwiZ2VuZXJhdGVkIjoiMC45MjU4MTcwMCAxNTQyMTg2MTQxIn19","2359","1542186141");
INSERT INTO `st_ngg_pictures` VALUES("4","foolstacksgalery-1-3","0","1","foolstacksgalery-1.png","","foolstacksgalery (1)","2018-11-14 09:02:23","0","0","eyJiYWNrdXAiOnsiZmlsZW5hbWUiOiJmb29sc3RhY2tzZ2FsZXJ5LTEucG5nIiwid2lkdGgiOjQxMSwiaGVpZ2h0IjozNDksImdlbmVyYXRlZCI6IjAuMTQyNjc3MDAgMTU0MjE4NjE0MyJ9LCJhcGVydHVyZSI6ZmFsc2UsImNyZWRpdCI6ZmFsc2UsImNhbWVyYSI6ZmFsc2UsImNhcHRpb24iOmZhbHNlLCJjcmVhdGVkX3RpbWVzdGFtcCI6ZmFsc2UsImNvcHlyaWdodCI6ZmFsc2UsImZvY2FsX2xlbmd0aCI6ZmFsc2UsImlzbyI6ZmFsc2UsInNodXR0ZXJfc3BlZWQiOmZhbHNlLCJmbGFzaCI6ZmFsc2UsInRpdGxlIjpmYWxzZSwia2V5d29yZHMiOmZhbHNlLCJ3aWR0aCI6NDExLCJoZWlnaHQiOjM0OSwic2F2ZWQiOnRydWUsIm1kNSI6IjBkZGQ1M2JjYjFmMGM1ZmYxOTliZTIwZTc2OTkyZjA4IiwiZnVsbCI6eyJ3aWR0aCI6NDExLCJoZWlnaHQiOjM0OSwibWQ1IjoiMGRkZDUzYmNiMWYwYzVmZjE5OWJlMjBlNzY5OTJmMDgifSwidGh1bWJuYWlsIjp7IndpZHRoIjoyNDAsImhlaWdodCI6MTYwLCJmaWxlbmFtZSI6InRodW1ic19mb29sc3RhY2tzZ2FsZXJ5LTEucG5nIiwiZ2VuZXJhdGVkIjoiMC4zMTczMDcwMCAxNTQyMTg2MTQzIn19","2360","1542186143");
INSERT INTO `st_ngg_pictures` VALUES("5","foolstacksgalery-2","0","1","foolstacksgalery-2.jpg","","foolstacksgalery (2)","2018-11-14 09:02:24","0","0","eyJiYWNrdXAiOnsiZmlsZW5hbWUiOiJmb29sc3RhY2tzZ2FsZXJ5LTIuanBnIiwid2lkdGgiOjc3MCwiaGVpZ2h0Ijo0NzcsImdlbmVyYXRlZCI6IjAuNDUwMDAyMDAgMTU0MjE4NjE0NCJ9LCJhcGVydHVyZSI6ZmFsc2UsImNyZWRpdCI6ZmFsc2UsImNhbWVyYSI6ZmFsc2UsImNhcHRpb24iOmZhbHNlLCJjcmVhdGVkX3RpbWVzdGFtcCI6ZmFsc2UsImNvcHlyaWdodCI6ZmFsc2UsImZvY2FsX2xlbmd0aCI6ZmFsc2UsImlzbyI6ZmFsc2UsInNodXR0ZXJfc3BlZWQiOmZhbHNlLCJmbGFzaCI6ZmFsc2UsInRpdGxlIjpmYWxzZSwia2V5d29yZHMiOmZhbHNlLCJ3aWR0aCI6NzcwLCJoZWlnaHQiOjQ3Nywic2F2ZWQiOnRydWUsIm1kNSI6IjYxM2U5NDI2Y2YyYTE4MTY5OTQyNmIxYmMwZmI5Nzk4IiwiZnVsbCI6eyJ3aWR0aCI6NzcwLCJoZWlnaHQiOjQ3NywibWQ1IjoiNjEzZTk0MjZjZjJhMTgxNjk5NDI2YjFiYzBmYjk3OTgifSwidGh1bWJuYWlsIjp7IndpZHRoIjoyNDAsImhlaWdodCI6MTYwLCJmaWxlbmFtZSI6InRodW1ic19mb29sc3RhY2tzZ2FsZXJ5LTIuanBnIiwiZ2VuZXJhdGVkIjoiMC42NDQ3NzUwMCAxNTQyMTg2MTQ0In19","2361","1542186144");
INSERT INTO `st_ngg_pictures` VALUES("6","foolstacksgalery-2-1","0","1","foolstacksgalery-2.png","","foolstacksgalery (2)","2018-11-14 09:02:26","0","0","eyJiYWNrdXAiOnsiZmlsZW5hbWUiOiJmb29sc3RhY2tzZ2FsZXJ5LTIucG5nIiwid2lkdGgiOjM1MCwiaGVpZ2h0IjozOTQsImdlbmVyYXRlZCI6IjAuMzQwMzU4MDAgMTU0MjE4NjE0NiJ9LCJhcGVydHVyZSI6ZmFsc2UsImNyZWRpdCI6ZmFsc2UsImNhbWVyYSI6ZmFsc2UsImNhcHRpb24iOmZhbHNlLCJjcmVhdGVkX3RpbWVzdGFtcCI6ZmFsc2UsImNvcHlyaWdodCI6ZmFsc2UsImZvY2FsX2xlbmd0aCI6ZmFsc2UsImlzbyI6ZmFsc2UsInNodXR0ZXJfc3BlZWQiOmZhbHNlLCJmbGFzaCI6ZmFsc2UsInRpdGxlIjpmYWxzZSwia2V5d29yZHMiOmZhbHNlLCJ3aWR0aCI6MzUwLCJoZWlnaHQiOjM5NCwic2F2ZWQiOnRydWUsIm1kNSI6IjdhMWE3NTQ2ZGU2YTYwODhkMmVkYTEyNWFmNmJkM2JhIiwiZnVsbCI6eyJ3aWR0aCI6MzUwLCJoZWlnaHQiOjM5NCwibWQ1IjoiN2ExYTc1NDZkZTZhNjA4OGQyZWRhMTI1YWY2YmQzYmEifSwidGh1bWJuYWlsIjp7IndpZHRoIjoyNDAsImhlaWdodCI6MTYwLCJmaWxlbmFtZSI6InRodW1ic19mb29sc3RhY2tzZ2FsZXJ5LTIucG5nIiwiZ2VuZXJhdGVkIjoiMC43MjM4MjMwMCAxNTQyMTg2MTQ2In19","2362","1542186146");
INSERT INTO `st_ngg_pictures` VALUES("7","foolstacksgalery-3","0","1","foolstacksgalery-3.jpg","","foolstacksgalery (3)","2018-11-14 09:02:28","0","0","eyJiYWNrdXAiOnsiZmlsZW5hbWUiOiJmb29sc3RhY2tzZ2FsZXJ5LTMuanBnIiwid2lkdGgiOjc5NiwiaGVpZ2h0Ijo0MDAsImdlbmVyYXRlZCI6IjAuMDk4MDU3MDAgMTU0MjE4NjE0OCJ9LCJhcGVydHVyZSI6ZmFsc2UsImNyZWRpdCI6ZmFsc2UsImNhbWVyYSI6ZmFsc2UsImNhcHRpb24iOmZhbHNlLCJjcmVhdGVkX3RpbWVzdGFtcCI6ZmFsc2UsImNvcHlyaWdodCI6ZmFsc2UsImZvY2FsX2xlbmd0aCI6ZmFsc2UsImlzbyI6ZmFsc2UsInNodXR0ZXJfc3BlZWQiOmZhbHNlLCJmbGFzaCI6ZmFsc2UsInRpdGxlIjpmYWxzZSwia2V5d29yZHMiOmZhbHNlLCJ3aWR0aCI6Nzk2LCJoZWlnaHQiOjQwMCwic2F2ZWQiOnRydWUsIm1kNSI6IjMwYjI5YWY1OTlkOGI1ZGNkY2EzZGE0OTY3ZjY0YjExIiwiZnVsbCI6eyJ3aWR0aCI6Nzk2LCJoZWlnaHQiOjQwMCwibWQ1IjoiMzBiMjlhZjU5OWQ4YjVkY2RjYTNkYTQ5NjdmNjRiMTEifSwidGh1bWJuYWlsIjp7IndpZHRoIjoyNDAsImhlaWdodCI6MTYwLCJmaWxlbmFtZSI6InRodW1ic19mb29sc3RhY2tzZ2FsZXJ5LTMuanBnIiwiZ2VuZXJhdGVkIjoiMC4yNjM0NzQwMCAxNTQyMTg2MTQ4In19","2363","1542186148");
INSERT INTO `st_ngg_pictures` VALUES("8","foolstacksgalery-3-1","0","1","foolstacksgalery-3.png","","foolstacksgalery (3)","2018-11-14 09:02:29","0","0","eyJiYWNrdXAiOnsiZmlsZW5hbWUiOiJmb29sc3RhY2tzZ2FsZXJ5LTMucG5nIiwid2lkdGgiOjQwMCwiaGVpZ2h0IjozMzAsImdlbmVyYXRlZCI6IjAuNzg4Njk1MDAgMTU0MjE4NjE0OSJ9LCJhcGVydHVyZSI6ZmFsc2UsImNyZWRpdCI6ZmFsc2UsImNhbWVyYSI6ZmFsc2UsImNhcHRpb24iOmZhbHNlLCJjcmVhdGVkX3RpbWVzdGFtcCI6ZmFsc2UsImNvcHlyaWdodCI6ZmFsc2UsImZvY2FsX2xlbmd0aCI6ZmFsc2UsImlzbyI6ZmFsc2UsInNodXR0ZXJfc3BlZWQiOmZhbHNlLCJmbGFzaCI6ZmFsc2UsInRpdGxlIjpmYWxzZSwia2V5d29yZHMiOmZhbHNlLCJ3aWR0aCI6NDAwLCJoZWlnaHQiOjMzMCwic2F2ZWQiOnRydWUsIm1kNSI6ImQxZDQ5MGIxZmU0MmIzOGY5YWVkODg4NDlkYWEyNWU4IiwiZnVsbCI6eyJ3aWR0aCI6NDAwLCJoZWlnaHQiOjMzMCwibWQ1IjoiZDFkNDkwYjFmZTQyYjM4ZjlhZWQ4ODg0OWRhYTI1ZTgifSwidGh1bWJuYWlsIjp7IndpZHRoIjoyNDAsImhlaWdodCI6MTYwLCJmaWxlbmFtZSI6InRodW1ic19mb29sc3RhY2tzZ2FsZXJ5LTMucG5nIiwiZ2VuZXJhdGVkIjoiMC45NzI3NjEwMCAxNTQyMTg2MTQ5In19","2364","1542186149");
INSERT INTO `st_ngg_pictures` VALUES("9","foolstacksgalery-4","0","1","foolstacksgalery-4.png","","foolstacksgalery (4)","2018-11-14 09:02:31","0","0","eyJiYWNrdXAiOnsiZmlsZW5hbWUiOiJmb29sc3RhY2tzZ2FsZXJ5LTQucG5nIiwid2lkdGgiOjQ4MCwiaGVpZ2h0Ijo0MjQsImdlbmVyYXRlZCI6IjAuMzM0NTc3MDAgMTU0MjE4NjE1MSJ9LCJhcGVydHVyZSI6ZmFsc2UsImNyZWRpdCI6ZmFsc2UsImNhbWVyYSI6ZmFsc2UsImNhcHRpb24iOmZhbHNlLCJjcmVhdGVkX3RpbWVzdGFtcCI6ZmFsc2UsImNvcHlyaWdodCI6ZmFsc2UsImZvY2FsX2xlbmd0aCI6ZmFsc2UsImlzbyI6ZmFsc2UsInNodXR0ZXJfc3BlZWQiOmZhbHNlLCJmbGFzaCI6ZmFsc2UsInRpdGxlIjpmYWxzZSwia2V5d29yZHMiOmZhbHNlLCJ3aWR0aCI6NDgwLCJoZWlnaHQiOjQyNCwic2F2ZWQiOnRydWUsIm1kNSI6IjU4MGY5NTk0YTY3YzEwYzFhMjFjN2YyMmJkNmI2M2M2IiwiZnVsbCI6eyJ3aWR0aCI6NDgwLCJoZWlnaHQiOjQyNCwibWQ1IjoiNTgwZjk1OTRhNjdjMTBjMWEyMWM3ZjIyYmQ2YjYzYzYifSwidGh1bWJuYWlsIjp7IndpZHRoIjoyNDAsImhlaWdodCI6MTYwLCJmaWxlbmFtZSI6InRodW1ic19mb29sc3RhY2tzZ2FsZXJ5LTQucG5nIiwiZ2VuZXJhdGVkIjoiMC41NTAyNjYwMCAxNTQyMTg2MTUxIn19","2365","1542186151");
INSERT INTO `st_ngg_pictures` VALUES("10","foolstacksgalery-5","0","1","foolstacksgalery-5.png","","foolstacksgalery (5)","2018-11-14 09:02:32","0","0","eyJiYWNrdXAiOnsiZmlsZW5hbWUiOiJmb29sc3RhY2tzZ2FsZXJ5LTUucG5nIiwid2lkdGgiOjIyNiwiaGVpZ2h0IjoyMjMsImdlbmVyYXRlZCI6IjAuNzM4MjYzMDAgMTU0MjE4NjE1MiJ9LCJhcGVydHVyZSI6ZmFsc2UsImNyZWRpdCI6ZmFsc2UsImNhbWVyYSI6ZmFsc2UsImNhcHRpb24iOmZhbHNlLCJjcmVhdGVkX3RpbWVzdGFtcCI6ZmFsc2UsImNvcHlyaWdodCI6ZmFsc2UsImZvY2FsX2xlbmd0aCI6ZmFsc2UsImlzbyI6ZmFsc2UsInNodXR0ZXJfc3BlZWQiOmZhbHNlLCJmbGFzaCI6ZmFsc2UsInRpdGxlIjpmYWxzZSwia2V5d29yZHMiOmZhbHNlLCJ3aWR0aCI6MjI2LCJoZWlnaHQiOjIyMywic2F2ZWQiOnRydWUsIm1kNSI6ImI5NGMzMTFiMjNjOGVkNTM0MzU3ZDNlMjc3NWU1OGI3IiwiZnVsbCI6eyJ3aWR0aCI6MjI2LCJoZWlnaHQiOjIyMywibWQ1IjoiYjk0YzMxMWIyM2M4ZWQ1MzQzNTdkM2UyNzc1ZTU4YjcifSwidGh1bWJuYWlsIjp7IndpZHRoIjoyMjYsImhlaWdodCI6MTYwLCJmaWxlbmFtZSI6InRodW1ic19mb29sc3RhY2tzZ2FsZXJ5LTUucG5nIiwiZ2VuZXJhdGVkIjoiMC44Njk0ODAwMCAxNTQyMTg2MTUyIn19","2366","1542186152");
INSERT INTO `st_ngg_pictures` VALUES("11","foolstacksgalery-6","0","1","foolstacksgalery-6.png","","foolstacksgalery (6)","2018-11-14 09:02:33","0","0","eyJiYWNrdXAiOnsiZmlsZW5hbWUiOiJmb29sc3RhY2tzZ2FsZXJ5LTYucG5nIiwid2lkdGgiOjI3NSwiaGVpZ2h0IjoxODMsImdlbmVyYXRlZCI6IjAuODEzOTU1MDAgMTU0MjE4NjE1MyJ9LCJhcGVydHVyZSI6ZmFsc2UsImNyZWRpdCI6ZmFsc2UsImNhbWVyYSI6ZmFsc2UsImNhcHRpb24iOmZhbHNlLCJjcmVhdGVkX3RpbWVzdGFtcCI6ZmFsc2UsImNvcHlyaWdodCI6ZmFsc2UsImZvY2FsX2xlbmd0aCI6ZmFsc2UsImlzbyI6ZmFsc2UsInNodXR0ZXJfc3BlZWQiOmZhbHNlLCJmbGFzaCI6ZmFsc2UsInRpdGxlIjpmYWxzZSwia2V5d29yZHMiOmZhbHNlLCJ3aWR0aCI6Mjc1LCJoZWlnaHQiOjE4Mywic2F2ZWQiOnRydWUsIm1kNSI6IjA1MWU0ZmI5ODY2YmYzZTAxZTY5YTI2Zjc0OWEyODY2IiwiZnVsbCI6eyJ3aWR0aCI6Mjc1LCJoZWlnaHQiOjE4MywibWQ1IjoiMDUxZTRmYjk4NjZiZjNlMDFlNjlhMjZmNzQ5YTI4NjYifSwidGh1bWJuYWlsIjp7IndpZHRoIjoyNDAsImhlaWdodCI6MTYwLCJmaWxlbmFtZSI6InRodW1ic19mb29sc3RhY2tzZ2FsZXJ5LTYucG5nIiwiZ2VuZXJhdGVkIjoiMC45MDg1MzYwMCAxNTQyMTg2MTUzIn19","2367","1542186153");
INSERT INTO `st_ngg_pictures` VALUES("12","foolstacksgalery-1-4","0","2","foolstacksgalery-1.gif","","foolstacksgalery (1)","2018-11-14 09:04:39","0","0","eyJiYWNrdXAiOnsiZmlsZW5hbWUiOiJmb29sc3RhY2tzZ2FsZXJ5LTEuZ2lmIiwid2lkdGgiOjgwNCwiaGVpZ2h0Ijo3MTcsImdlbmVyYXRlZCI6IjAuOTI2Njg0MDAgMTU0MjE4NjI3OSJ9LCJhcGVydHVyZSI6ZmFsc2UsImNyZWRpdCI6ZmFsc2UsImNhbWVyYSI6ZmFsc2UsImNhcHRpb24iOmZhbHNlLCJjcmVhdGVkX3RpbWVzdGFtcCI6ZmFsc2UsImNvcHlyaWdodCI6ZmFsc2UsImZvY2FsX2xlbmd0aCI6ZmFsc2UsImlzbyI6ZmFsc2UsInNodXR0ZXJfc3BlZWQiOmZhbHNlLCJmbGFzaCI6ZmFsc2UsInRpdGxlIjpmYWxzZSwia2V5d29yZHMiOmZhbHNlLCJ3aWR0aCI6ODA0LCJoZWlnaHQiOjcxNywic2F2ZWQiOnRydWUsIm1kNSI6IjNiMDM1ZGYwMTZhYzRlOGQ2NzJlNWE4MDY1NzJmZTdlIiwiZnVsbCI6eyJ3aWR0aCI6ODA0LCJoZWlnaHQiOjcxNywibWQ1IjoiM2IwMzVkZjAxNmFjNGU4ZDY3MmU1YTgwNjU3MmZlN2UifSwidGh1bWJuYWlsIjp7IndpZHRoIjoyNDAsImhlaWdodCI6MTYwLCJmaWxlbmFtZSI6InRodW1ic19mb29sc3RhY2tzZ2FsZXJ5LTEuZ2lmIiwiZ2VuZXJhdGVkIjoiMC4yNjY4ODYwMCAxNTQyMTg2MjgwIn19","2369","1542186280");
INSERT INTO `st_ngg_pictures` VALUES("13","foolstacksgalery-1-5","0","2","foolstacksgalery-1.jpeg","","foolstacksgalery (1)","2018-11-14 09:04:41","0","0","eyJiYWNrdXAiOnsiZmlsZW5hbWUiOiJmb29sc3RhY2tzZ2FsZXJ5LTEuanBlZyIsIndpZHRoIjo4MjIsImhlaWdodCI6NDYyLCJnZW5lcmF0ZWQiOiIwLjc1ODAxODAwIDE1NDIxODYyODEifSwiYXBlcnR1cmUiOmZhbHNlLCJjcmVkaXQiOmZhbHNlLCJjYW1lcmEiOmZhbHNlLCJjYXB0aW9uIjpmYWxzZSwiY3JlYXRlZF90aW1lc3RhbXAiOmZhbHNlLCJjb3B5cmlnaHQiOmZhbHNlLCJmb2NhbF9sZW5ndGgiOmZhbHNlLCJpc28iOmZhbHNlLCJzaHV0dGVyX3NwZWVkIjpmYWxzZSwiZmxhc2giOmZhbHNlLCJ0aXRsZSI6ZmFsc2UsImtleXdvcmRzIjpmYWxzZSwid2lkdGgiOjgyMiwiaGVpZ2h0Ijo0NjIsInNhdmVkIjp0cnVlLCJtZDUiOiIwMmQxNGJlMzkwMTA5ZTQ0MmYzZDI0ZmUxNmY2NTk1OSIsImZ1bGwiOnsid2lkdGgiOjgyMiwiaGVpZ2h0Ijo0NjIsIm1kNSI6IjAyZDE0YmUzOTAxMDllNDQyZjNkMjRmZTE2ZjY1OTU5In0sInRodW1ibmFpbCI6eyJ3aWR0aCI6MjQwLCJoZWlnaHQiOjE2MCwiZmlsZW5hbWUiOiJ0aHVtYnNfZm9vbHN0YWNrc2dhbGVyeS0xLmpwZWciLCJnZW5lcmF0ZWQiOiIwLjk5NDQ3MzAwIDE1NDIxODYyODEifX0=","2370","1542186281");
INSERT INTO `st_ngg_pictures` VALUES("14","foolstacksgalery-1-6","0","2","foolstacksgalery-1.jpg","","foolstacksgalery (1)","2018-11-14 09:04:43","0","0","eyJiYWNrdXAiOnsiZmlsZW5hbWUiOiJmb29sc3RhY2tzZ2FsZXJ5LTEuanBnIiwid2lkdGgiOjYyMCwiaGVpZ2h0IjozMDAsImdlbmVyYXRlZCI6IjAuNzE1MzMwMDAgMTU0MjE4NjI4MyJ9LCJhcGVydHVyZSI6ZmFsc2UsImNyZWRpdCI6ZmFsc2UsImNhbWVyYSI6ZmFsc2UsImNhcHRpb24iOmZhbHNlLCJjcmVhdGVkX3RpbWVzdGFtcCI6ZmFsc2UsImNvcHlyaWdodCI6ZmFsc2UsImZvY2FsX2xlbmd0aCI6ZmFsc2UsImlzbyI6ZmFsc2UsInNodXR0ZXJfc3BlZWQiOmZhbHNlLCJmbGFzaCI6ZmFsc2UsInRpdGxlIjpmYWxzZSwia2V5d29yZHMiOmZhbHNlLCJ3aWR0aCI6NjIwLCJoZWlnaHQiOjMwMCwic2F2ZWQiOnRydWUsIm1kNSI6Ijk3YzA2MmE5YzQ4Y2UxZmQwYTM5NGYwOTJkMTQzNzlmIiwiZnVsbCI6eyJ3aWR0aCI6NjIwLCJoZWlnaHQiOjMwMCwibWQ1IjoiOTdjMDYyYTljNDhjZTFmZDBhMzk0ZjA5MmQxNDM3OWYifSwidGh1bWJuYWlsIjp7IndpZHRoIjoyNDAsImhlaWdodCI6MTYwLCJmaWxlbmFtZSI6InRodW1ic19mb29sc3RhY2tzZ2FsZXJ5LTEuanBnIiwiZ2VuZXJhdGVkIjoiMC44Mzk1NjIwMCAxNTQyMTg2MjgzIn19","2371","1542186283");
INSERT INTO `st_ngg_pictures` VALUES("15","foolstacksgalery-1-7","0","2","foolstacksgalery-1.png","","foolstacksgalery (1)","2018-11-14 09:04:45","0","0","eyJiYWNrdXAiOnsiZmlsZW5hbWUiOiJmb29sc3RhY2tzZ2FsZXJ5LTEucG5nIiwid2lkdGgiOjQxMSwiaGVpZ2h0IjozNDksImdlbmVyYXRlZCI6IjAuMjkxNjYxMDAgMTU0MjE4NjI4NSJ9LCJhcGVydHVyZSI6ZmFsc2UsImNyZWRpdCI6ZmFsc2UsImNhbWVyYSI6ZmFsc2UsImNhcHRpb24iOmZhbHNlLCJjcmVhdGVkX3RpbWVzdGFtcCI6ZmFsc2UsImNvcHlyaWdodCI6ZmFsc2UsImZvY2FsX2xlbmd0aCI6ZmFsc2UsImlzbyI6ZmFsc2UsInNodXR0ZXJfc3BlZWQiOmZhbHNlLCJmbGFzaCI6ZmFsc2UsInRpdGxlIjpmYWxzZSwia2V5d29yZHMiOmZhbHNlLCJ3aWR0aCI6NDExLCJoZWlnaHQiOjM0OSwic2F2ZWQiOnRydWUsIm1kNSI6IjBkZGQ1M2JjYjFmMGM1ZmYxOTliZTIwZTc2OTkyZjA4IiwiZnVsbCI6eyJ3aWR0aCI6NDExLCJoZWlnaHQiOjM0OSwibWQ1IjoiMGRkZDUzYmNiMWYwYzVmZjE5OWJlMjBlNzY5OTJmMDgifSwidGh1bWJuYWlsIjp7IndpZHRoIjoyNDAsImhlaWdodCI6MTYwLCJmaWxlbmFtZSI6InRodW1ic19mb29sc3RhY2tzZ2FsZXJ5LTEucG5nIiwiZ2VuZXJhdGVkIjoiMC41NTQ1MjYwMCAxNTQyMTg2Mjg1In19","2372","1542186285");
INSERT INTO `st_ngg_pictures` VALUES("16","foolstacksgalery-2-2","0","2","foolstacksgalery-2.jpg","","foolstacksgalery (2)","2018-11-14 09:04:46","0","0","eyJiYWNrdXAiOnsiZmlsZW5hbWUiOiJmb29sc3RhY2tzZ2FsZXJ5LTIuanBnIiwid2lkdGgiOjc3MCwiaGVpZ2h0Ijo0NzcsImdlbmVyYXRlZCI6IjAuNzk0MTMyMDAgMTU0MjE4NjI4NiJ9LCJhcGVydHVyZSI6ZmFsc2UsImNyZWRpdCI6ZmFsc2UsImNhbWVyYSI6ZmFsc2UsImNhcHRpb24iOmZhbHNlLCJjcmVhdGVkX3RpbWVzdGFtcCI6ZmFsc2UsImNvcHlyaWdodCI6ZmFsc2UsImZvY2FsX2xlbmd0aCI6ZmFsc2UsImlzbyI6ZmFsc2UsInNodXR0ZXJfc3BlZWQiOmZhbHNlLCJmbGFzaCI6ZmFsc2UsInRpdGxlIjpmYWxzZSwia2V5d29yZHMiOmZhbHNlLCJ3aWR0aCI6NzcwLCJoZWlnaHQiOjQ3Nywic2F2ZWQiOnRydWUsIm1kNSI6IjYxM2U5NDI2Y2YyYTE4MTY5OTQyNmIxYmMwZmI5Nzk4IiwiZnVsbCI6eyJ3aWR0aCI6NzcwLCJoZWlnaHQiOjQ3NywibWQ1IjoiNjEzZTk0MjZjZjJhMTgxNjk5NDI2YjFiYzBmYjk3OTgifSwidGh1bWJuYWlsIjp7IndpZHRoIjoyNDAsImhlaWdodCI6MTYwLCJmaWxlbmFtZSI6InRodW1ic19mb29sc3RhY2tzZ2FsZXJ5LTIuanBnIiwiZ2VuZXJhdGVkIjoiMC4wMTE5NTgwMCAxNTQyMTg2Mjg3In19","2373","1542186287");
INSERT INTO `st_ngg_pictures` VALUES("17","foolstacksgalery-2-3","0","2","foolstacksgalery-2.png","","foolstacksgalery (2)","2018-11-14 09:04:48","0","0","eyJiYWNrdXAiOnsiZmlsZW5hbWUiOiJmb29sc3RhY2tzZ2FsZXJ5LTIucG5nIiwid2lkdGgiOjM1MCwiaGVpZ2h0IjozOTQsImdlbmVyYXRlZCI6IjAuNzY3ODM2MDAgMTU0MjE4NjI4OCJ9LCJhcGVydHVyZSI6ZmFsc2UsImNyZWRpdCI6ZmFsc2UsImNhbWVyYSI6ZmFsc2UsImNhcHRpb24iOmZhbHNlLCJjcmVhdGVkX3RpbWVzdGFtcCI6ZmFsc2UsImNvcHlyaWdodCI6ZmFsc2UsImZvY2FsX2xlbmd0aCI6ZmFsc2UsImlzbyI6ZmFsc2UsInNodXR0ZXJfc3BlZWQiOmZhbHNlLCJmbGFzaCI6ZmFsc2UsInRpdGxlIjpmYWxzZSwia2V5d29yZHMiOmZhbHNlLCJ3aWR0aCI6MzUwLCJoZWlnaHQiOjM5NCwic2F2ZWQiOnRydWUsIm1kNSI6IjdhMWE3NTQ2ZGU2YTYwODhkMmVkYTEyNWFmNmJkM2JhIiwiZnVsbCI6eyJ3aWR0aCI6MzUwLCJoZWlnaHQiOjM5NCwibWQ1IjoiN2ExYTc1NDZkZTZhNjA4OGQyZWRhMTI1YWY2YmQzYmEifSwidGh1bWJuYWlsIjp7IndpZHRoIjoyNDAsImhlaWdodCI6MTYwLCJmaWxlbmFtZSI6InRodW1ic19mb29sc3RhY2tzZ2FsZXJ5LTIucG5nIiwiZ2VuZXJhdGVkIjoiMC45NTc0NjgwMCAxNTQyMTg2Mjg4In19","2374","1542186288");
INSERT INTO `st_ngg_pictures` VALUES("18","foolstacksgalery-3-2","0","2","foolstacksgalery-3.jpg","","foolstacksgalery (3)","2018-11-14 09:04:50","0","0","eyJiYWNrdXAiOnsiZmlsZW5hbWUiOiJmb29sc3RhY2tzZ2FsZXJ5LTMuanBnIiwid2lkdGgiOjc5NiwiaGVpZ2h0Ijo0MDAsImdlbmVyYXRlZCI6IjAuMzkyOTIxMDAgMTU0MjE4NjI5MCJ9LCJhcGVydHVyZSI6ZmFsc2UsImNyZWRpdCI6ZmFsc2UsImNhbWVyYSI6ZmFsc2UsImNhcHRpb24iOmZhbHNlLCJjcmVhdGVkX3RpbWVzdGFtcCI6ZmFsc2UsImNvcHlyaWdodCI6ZmFsc2UsImZvY2FsX2xlbmd0aCI6ZmFsc2UsImlzbyI6ZmFsc2UsInNodXR0ZXJfc3BlZWQiOmZhbHNlLCJmbGFzaCI6ZmFsc2UsInRpdGxlIjpmYWxzZSwia2V5d29yZHMiOmZhbHNlLCJ3aWR0aCI6Nzk2LCJoZWlnaHQiOjQwMCwic2F2ZWQiOnRydWUsIm1kNSI6IjMwYjI5YWY1OTlkOGI1ZGNkY2EzZGE0OTY3ZjY0YjExIiwiZnVsbCI6eyJ3aWR0aCI6Nzk2LCJoZWlnaHQiOjQwMCwibWQ1IjoiMzBiMjlhZjU5OWQ4YjVkY2RjYTNkYTQ5NjdmNjRiMTEifSwidGh1bWJuYWlsIjp7IndpZHRoIjoyNDAsImhlaWdodCI6MTYwLCJmaWxlbmFtZSI6InRodW1ic19mb29sc3RhY2tzZ2FsZXJ5LTMuanBnIiwiZ2VuZXJhdGVkIjoiMC42NjYzNTMwMCAxNTQyMTg2MjkwIn19","2375","1542186290");
INSERT INTO `st_ngg_pictures` VALUES("19","foolstacksgalery-3-3","0","2","foolstacksgalery-3.png","","foolstacksgalery (3)","2018-11-14 09:04:52","0","0","eyJiYWNrdXAiOnsiZmlsZW5hbWUiOiJmb29sc3RhY2tzZ2FsZXJ5LTMucG5nIiwid2lkdGgiOjQwMCwiaGVpZ2h0IjozMzAsImdlbmVyYXRlZCI6IjAuMzQxNzczMDAgMTU0MjE4NjI5MiJ9LCJhcGVydHVyZSI6ZmFsc2UsImNyZWRpdCI6ZmFsc2UsImNhbWVyYSI6ZmFsc2UsImNhcHRpb24iOmZhbHNlLCJjcmVhdGVkX3RpbWVzdGFtcCI6ZmFsc2UsImNvcHlyaWdodCI6ZmFsc2UsImZvY2FsX2xlbmd0aCI6ZmFsc2UsImlzbyI6ZmFsc2UsInNodXR0ZXJfc3BlZWQiOmZhbHNlLCJmbGFzaCI6ZmFsc2UsInRpdGxlIjpmYWxzZSwia2V5d29yZHMiOmZhbHNlLCJ3aWR0aCI6NDAwLCJoZWlnaHQiOjMzMCwic2F2ZWQiOnRydWUsIm1kNSI6ImQxZDQ5MGIxZmU0MmIzOGY5YWVkODg4NDlkYWEyNWU4IiwiZnVsbCI6eyJ3aWR0aCI6NDAwLCJoZWlnaHQiOjMzMCwibWQ1IjoiZDFkNDkwYjFmZTQyYjM4ZjlhZWQ4ODg0OWRhYTI1ZTgifSwidGh1bWJuYWlsIjp7IndpZHRoIjoyNDAsImhlaWdodCI6MTYwLCJmaWxlbmFtZSI6InRodW1ic19mb29sc3RhY2tzZ2FsZXJ5LTMucG5nIiwiZ2VuZXJhdGVkIjoiMC43MDQ1ODkwMCAxNTQyMTg2MjkyIn19","2376","1542186292");
INSERT INTO `st_ngg_pictures` VALUES("20","foolstacksgalery-4-1","0","2","foolstacksgalery-4.png","","foolstacksgalery (4)","2018-11-14 09:04:55","0","0","eyJiYWNrdXAiOnsiZmlsZW5hbWUiOiJmb29sc3RhY2tzZ2FsZXJ5LTQucG5nIiwid2lkdGgiOjQ4MCwiaGVpZ2h0Ijo0MjQsImdlbmVyYXRlZCI6IjAuNDE1NDY1MDAgMTU0MjE4NjI5NSJ9LCJhcGVydHVyZSI6ZmFsc2UsImNyZWRpdCI6ZmFsc2UsImNhbWVyYSI6ZmFsc2UsImNhcHRpb24iOmZhbHNlLCJjcmVhdGVkX3RpbWVzdGFtcCI6ZmFsc2UsImNvcHlyaWdodCI6ZmFsc2UsImZvY2FsX2xlbmd0aCI6ZmFsc2UsImlzbyI6ZmFsc2UsInNodXR0ZXJfc3BlZWQiOmZhbHNlLCJmbGFzaCI6ZmFsc2UsInRpdGxlIjpmYWxzZSwia2V5d29yZHMiOmZhbHNlLCJ3aWR0aCI6NDgwLCJoZWlnaHQiOjQyNCwic2F2ZWQiOnRydWUsIm1kNSI6IjU4MGY5NTk0YTY3YzEwYzFhMjFjN2YyMmJkNmI2M2M2IiwiZnVsbCI6eyJ3aWR0aCI6NDgwLCJoZWlnaHQiOjQyNCwibWQ1IjoiNTgwZjk1OTRhNjdjMTBjMWEyMWM3ZjIyYmQ2YjYzYzYifSwidGh1bWJuYWlsIjp7IndpZHRoIjoyNDAsImhlaWdodCI6MTYwLCJmaWxlbmFtZSI6InRodW1ic19mb29sc3RhY2tzZ2FsZXJ5LTQucG5nIiwiZ2VuZXJhdGVkIjoiMC42MjM2NDcwMCAxNTQyMTg2Mjk1In19","2377","1542186295");
INSERT INTO `st_ngg_pictures` VALUES("21","foolstacksgalery-5-1","0","2","foolstacksgalery-5.png","","foolstacksgalery (5)","2018-11-14 09:04:56","0","0","eyJiYWNrdXAiOnsiZmlsZW5hbWUiOiJmb29sc3RhY2tzZ2FsZXJ5LTUucG5nIiwid2lkdGgiOjIyNiwiaGVpZ2h0IjoyMjMsImdlbmVyYXRlZCI6IjAuNzE2Nzg2MDAgMTU0MjE4NjI5NiJ9LCJhcGVydHVyZSI6ZmFsc2UsImNyZWRpdCI6ZmFsc2UsImNhbWVyYSI6ZmFsc2UsImNhcHRpb24iOmZhbHNlLCJjcmVhdGVkX3RpbWVzdGFtcCI6ZmFsc2UsImNvcHlyaWdodCI6ZmFsc2UsImZvY2FsX2xlbmd0aCI6ZmFsc2UsImlzbyI6ZmFsc2UsInNodXR0ZXJfc3BlZWQiOmZhbHNlLCJmbGFzaCI6ZmFsc2UsInRpdGxlIjpmYWxzZSwia2V5d29yZHMiOmZhbHNlLCJ3aWR0aCI6MjI2LCJoZWlnaHQiOjIyMywic2F2ZWQiOnRydWUsIm1kNSI6ImI5NGMzMTFiMjNjOGVkNTM0MzU3ZDNlMjc3NWU1OGI3IiwiZnVsbCI6eyJ3aWR0aCI6MjI2LCJoZWlnaHQiOjIyMywibWQ1IjoiYjk0YzMxMWIyM2M4ZWQ1MzQzNTdkM2UyNzc1ZTU4YjcifSwidGh1bWJuYWlsIjp7IndpZHRoIjoyMjYsImhlaWdodCI6MTYwLCJmaWxlbmFtZSI6InRodW1ic19mb29sc3RhY2tzZ2FsZXJ5LTUucG5nIiwiZ2VuZXJhdGVkIjoiMC44Njg5OTgwMCAxNTQyMTg2Mjk2In19","2378","1542186296");
INSERT INTO `st_ngg_pictures` VALUES("22","foolstacksgalery-6-1","0","2","foolstacksgalery-6.png","","foolstacksgalery (6)","2018-11-14 09:04:59","0","0","eyJiYWNrdXAiOnsiZmlsZW5hbWUiOiJmb29sc3RhY2tzZ2FsZXJ5LTYucG5nIiwid2lkdGgiOjI3NSwiaGVpZ2h0IjoxODMsImdlbmVyYXRlZCI6IjAuNzE4MTM5MDAgMTU0MjE4NjI5OSJ9LCJhcGVydHVyZSI6ZmFsc2UsImNyZWRpdCI6ZmFsc2UsImNhbWVyYSI6ZmFsc2UsImNhcHRpb24iOmZhbHNlLCJjcmVhdGVkX3RpbWVzdGFtcCI6ZmFsc2UsImNvcHlyaWdodCI6ZmFsc2UsImZvY2FsX2xlbmd0aCI6ZmFsc2UsImlzbyI6ZmFsc2UsInNodXR0ZXJfc3BlZWQiOmZhbHNlLCJmbGFzaCI6ZmFsc2UsInRpdGxlIjpmYWxzZSwia2V5d29yZHMiOmZhbHNlLCJ3aWR0aCI6Mjc1LCJoZWlnaHQiOjE4Mywic2F2ZWQiOnRydWUsIm1kNSI6IjA1MWU0ZmI5ODY2YmYzZTAxZTY5YTI2Zjc0OWEyODY2IiwiZnVsbCI6eyJ3aWR0aCI6Mjc1LCJoZWlnaHQiOjE4MywibWQ1IjoiMDUxZTRmYjk4NjZiZjNlMDFlNjlhMjZmNzQ5YTI4NjYifSwidGh1bWJuYWlsIjp7IndpZHRoIjoyNDAsImhlaWdodCI6MTYwLCJmaWxlbmFtZSI6InRodW1ic19mb29sc3RhY2tzZ2FsZXJ5LTYucG5nIiwiZ2VuZXJhdGVkIjoiMC4wMzEyOTQwMCAxNTQyMTg2MzAwIn19","2379","1542186300");


DROP TABLE IF EXISTS `st_options`;

CREATE TABLE `st_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=MyISAM AUTO_INCREMENT=3146 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `st_options` VALUES("1","siteurl","http://foolstacks.ir","yes");
INSERT INTO `st_options` VALUES("2","home","http://foolstacks.ir","yes");
INSERT INTO `st_options` VALUES("3","blogname","روزمره ها","yes");
INSERT INTO `st_options` VALUES("4","blogdescription","","yes");
INSERT INTO `st_options` VALUES("5","users_can_register","0","yes");
INSERT INTO `st_options` VALUES("6","admin_email","fullstackdiaries@gmail.com","yes");
INSERT INTO `st_options` VALUES("7","start_of_week","6","yes");
INSERT INTO `st_options` VALUES("8","use_balanceTags","0","yes");
INSERT INTO `st_options` VALUES("9","use_smilies","1","yes");
INSERT INTO `st_options` VALUES("10","require_name_email","1","yes");
INSERT INTO `st_options` VALUES("11","comments_notify","1","yes");
INSERT INTO `st_options` VALUES("12","posts_per_rss","10","yes");
INSERT INTO `st_options` VALUES("13","rss_use_excerpt","0","yes");
INSERT INTO `st_options` VALUES("14","mailserver_url","mail.example.com","yes");
INSERT INTO `st_options` VALUES("15","mailserver_login","login@example.com","yes");
INSERT INTO `st_options` VALUES("16","mailserver_pass","password","yes");
INSERT INTO `st_options` VALUES("17","mailserver_port","110","yes");
INSERT INTO `st_options` VALUES("18","default_category","1","yes");
INSERT INTO `st_options` VALUES("19","default_comment_status","open","yes");
INSERT INTO `st_options` VALUES("20","default_ping_status","open","yes");
INSERT INTO `st_options` VALUES("21","default_pingback_flag","1","yes");
INSERT INTO `st_options` VALUES("22","posts_per_page","10","yes");
INSERT INTO `st_options` VALUES("23","date_format","F j, Y","yes");
INSERT INTO `st_options` VALUES("24","time_format","g:i a","yes");
INSERT INTO `st_options` VALUES("25","links_updated_date_format","F j, Y g:i a","yes");
INSERT INTO `st_options` VALUES("26","comment_moderation","0","yes");
INSERT INTO `st_options` VALUES("27","moderation_notify","1","yes");
INSERT INTO `st_options` VALUES("28","permalink_structure","/%postname%/","yes");
INSERT INTO `st_options` VALUES("30","hack_file","0","yes");
INSERT INTO `st_options` VALUES("31","blog_charset","UTF-8","yes");
INSERT INTO `st_options` VALUES("32","moderation_keys","","no");
INSERT INTO `st_options` VALUES("33","active_plugins","a:19:{i:0;s:27:\"LayerSlider/layerslider.php\";i:1;s:19:\"akismet/akismet.php\";i:2;s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";i:3;s:36:\"contact-form-7/wp-contact-form-7.php\";i:4;s:33:\"duplicate-post/duplicate-post.php\";i:5;s:43:\"google-analytics-dashboard-for-wp/gadwp.php\";i:6;s:9:\"hello.php\";i:7;s:19:\"jetpack/jetpack.php\";i:8;s:27:\"js_composer/js_composer.php\";i:9;s:38:\"recent-tweets-widget/recent-tweets.php\";i:10;s:47:\"regenerate-thumbnails/regenerate-thumbnails.php\";i:11;s:23:\"revslider/revslider.php\";i:12;s:27:\"updraftplus/updraftplus.php\";i:13;s:53:\"velvet-blues-update-urls/velvet-blues-update-urls.php\";i:14;s:27:\"woocommerce/woocommerce.php\";i:15;s:24:\"wordpress-seo/wp-seo.php\";i:16;s:31:\"wp-statistics/wp-statistics.php\";i:17;s:21:\"wpglobus/wpglobus.php\";i:18;s:29:\"nextgen-gallery/nggallery.php\";}","yes");
INSERT INTO `st_options` VALUES("34","category_base","","yes");
INSERT INTO `st_options` VALUES("35","ping_sites","http://rpc.pingomatic.com/","yes");
INSERT INTO `st_options` VALUES("36","comment_max_links","2","yes");
INSERT INTO `st_options` VALUES("37","gmt_offset","","yes");
INSERT INTO `st_options` VALUES("38","default_email_category","1","yes");
INSERT INTO `st_options` VALUES("39","recently_edited","","no");
INSERT INTO `st_options` VALUES("40","template","betheme","yes");
INSERT INTO `st_options` VALUES("41","stylesheet","betheme","yes");
INSERT INTO `st_options` VALUES("42","comment_whitelist","1","yes");
INSERT INTO `st_options` VALUES("43","blacklist_keys","","no");
INSERT INTO `st_options` VALUES("44","comment_registration","0","yes");
INSERT INTO `st_options` VALUES("45","html_type","text/html","yes");
INSERT INTO `st_options` VALUES("46","use_trackback","0","yes");
INSERT INTO `st_options` VALUES("47","default_role","subscriber","yes");
INSERT INTO `st_options` VALUES("48","db_version","38590","yes");
INSERT INTO `st_options` VALUES("49","uploads_use_yearmonth_folders","1","yes");
INSERT INTO `st_options` VALUES("50","upload_path","","yes");
INSERT INTO `st_options` VALUES("51","blog_public","1","yes");
INSERT INTO `st_options` VALUES("52","default_link_category","2","yes");
INSERT INTO `st_options` VALUES("53","show_on_front","page","yes");
INSERT INTO `st_options` VALUES("54","tag_base","","yes");
INSERT INTO `st_options` VALUES("55","show_avatars","1","yes");
INSERT INTO `st_options` VALUES("56","avatar_rating","G","yes");
INSERT INTO `st_options` VALUES("57","upload_url_path","","yes");
INSERT INTO `st_options` VALUES("58","thumbnail_size_w","150","yes");
INSERT INTO `st_options` VALUES("59","thumbnail_size_h","150","yes");
INSERT INTO `st_options` VALUES("60","thumbnail_crop","1","yes");
INSERT INTO `st_options` VALUES("61","medium_size_w","300","yes");
INSERT INTO `st_options` VALUES("62","medium_size_h","300","yes");
INSERT INTO `st_options` VALUES("63","avatar_default","mystery","yes");
INSERT INTO `st_options` VALUES("64","large_size_w","1024","yes");
INSERT INTO `st_options` VALUES("65","large_size_h","1024","yes");
INSERT INTO `st_options` VALUES("66","image_default_link_type","none","yes");
INSERT INTO `st_options` VALUES("67","image_default_size","","yes");
INSERT INTO `st_options` VALUES("68","image_default_align","","yes");
INSERT INTO `st_options` VALUES("69","close_comments_for_old_posts","0","yes");
INSERT INTO `st_options` VALUES("70","close_comments_days_old","14","yes");
INSERT INTO `st_options` VALUES("71","thread_comments","1","yes");
INSERT INTO `st_options` VALUES("72","thread_comments_depth","5","yes");
INSERT INTO `st_options` VALUES("73","page_comments","0","yes");
INSERT INTO `st_options` VALUES("74","comments_per_page","50","yes");
INSERT INTO `st_options` VALUES("75","default_comments_page","newest","yes");
INSERT INTO `st_options` VALUES("76","comment_order","asc","yes");
INSERT INTO `st_options` VALUES("77","sticky_posts","a:0:{}","yes");
INSERT INTO `st_options` VALUES("78","widget_categories","a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `st_options` VALUES("79","widget_text","a:10:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:4:\"text\";s:125:\"[image src=\"http://themes.muffingroup.com/be/webdesign/wp-content/uploads/2015/03/home_webdesign_footer_logo.png\" border=\"0\"]\";s:6:\"filter\";b:0;}i:3;a:4:{s:5:\"title\";s:28:\"درباره این سایت\";s:4:\"text\";s:88:\"اینجا مکان مناسبی است برای معرفی شما و سایت‌تان.\";s:6:\"filter\";b:1;s:6:\"visual\";b:1;}i:4;a:4:{s:5:\"title\";s:22:\"ما را بیابید\";s:4:\"text\";s:262:\"<strong>نشانی</strong>
خیابان ۱۲۳
نیویورک، نیویورک ۱۰۰۰۱

<strong>ساعت کاری</strong>
شنبه تا چهارشنبه: ۹ صبح تا ۵ بعد از ظهر
پنجشنبه و جمعه: ۱۱ صبح تا ۳ بعد از ظهر\";s:6:\"filter\";b:1;s:6:\"visual\";b:1;}i:5;a:4:{s:5:\"title\";s:28:\"درباره این سایت\";s:4:\"text\";s:88:\"اینجا مکان مناسبی است برای معرفی شما و سایت‌تان.\";s:6:\"filter\";b:1;s:6:\"visual\";b:1;}i:6;a:4:{s:5:\"title\";s:22:\"ما را بیابید\";s:4:\"text\";s:262:\"<strong>نشانی</strong>
خیابان ۱۲۳
نیویورک، نیویورک ۱۰۰۰۱

<strong>ساعت کاری</strong>
شنبه تا چهارشنبه: ۹ صبح تا ۵ بعد از ظهر
پنجشنبه و جمعه: ۱۱ صبح تا ۳ بعد از ظهر\";s:6:\"filter\";b:1;s:6:\"visual\";b:1;}i:7;a:4:{s:5:\"title\";s:28:\"درباره این سایت\";s:4:\"text\";s:88:\"اینجا مکان مناسبی است برای معرفی شما و سایت‌تان.\";s:6:\"filter\";b:1;s:6:\"visual\";b:1;}i:8;a:4:{s:5:\"title\";s:0:\"\";s:4:\"text\";s:52:\"<strong>نشانی</strong>
ایران - تهران\";s:6:\"filter\";b:1;s:6:\"visual\";b:1;}i:9;a:4:{s:5:\"title\";s:28:\"درباره این سایت\";s:4:\"text\";s:55:\"از گوشه و کنارهای زندگی روزمره\";s:6:\"filter\";b:1;s:6:\"visual\";b:1;}i:10;a:3:{s:5:\"title\";s:0:\"\";s:4:\"text\";s:473:\"<p class=\"contact_icons\" style=\"text-align: right; margin-top: 10px;\">
	<a style=\"color: #3a589b;\" href=\"#\"><i class=\"icon-facebook-circled\"></i></a>
	<a style=\"color: #d6492f;\" href=\"#\"><i class=\"icon-gplus-circled\"></i></a>
	<a style=\"color: #32ccfe;\" href=\"#\"><i class=\"icon-twitter-circled\"></i></a>
	<a style=\"color: #cb2027;\" href=\"#\"><i class=\"icon-pinterest-circled\"></i></a>
	<a style=\"color: #007bb6;\" href=\"#\"><i class=\"icon-linkedin-circled\"></i></a>
</p>\";s:6:\"filter\";b:0;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `st_options` VALUES("80","widget_rss","a:4:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;i:3;a:0:{}i:5;a:0:{}}","yes");
INSERT INTO `st_options` VALUES("81","uninstall_plugins","a:2:{s:27:\"LayerSlider/layerslider.php\";s:29:\"layerslider_uninstall_scripts\";s:43:\"google-analytics-dashboard-for-wp/gadwp.php\";a:2:{i:0;s:15:\"GADWP_Uninstall\";i:1;s:9:\"uninstall\";}}","no");
INSERT INTO `st_options` VALUES("82","timezone_string","Asia/Tehran","yes");
INSERT INTO `st_options` VALUES("83","page_for_posts","29","yes");
INSERT INTO `st_options` VALUES("84","page_on_front","106","yes");
INSERT INTO `st_options` VALUES("85","default_post_format","0","yes");
INSERT INTO `st_options` VALUES("86","link_manager_enabled","0","yes");
INSERT INTO `st_options` VALUES("87","finished_splitting_shared_terms","1","yes");
INSERT INTO `st_options` VALUES("88","site_icon","52","yes");
INSERT INTO `st_options` VALUES("89","medium_large_size_w","768","yes");
INSERT INTO `st_options` VALUES("90","medium_large_size_h","0","yes");
INSERT INTO `st_options` VALUES("91","wp_page_for_privacy_policy","3","yes");
INSERT INTO `st_options` VALUES("92","initial_db_version","38590","yes");
INSERT INTO `st_options` VALUES("93","st_user_roles","a:9:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:126:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:10:\"copy_posts\";b:1;s:20:\"wpseo_manage_options\";b:1;s:18:\"manage_woocommerce\";b:1;s:24:\"view_woocommerce_reports\";b:1;s:12:\"edit_product\";b:1;s:12:\"read_product\";b:1;s:14:\"delete_product\";b:1;s:13:\"edit_products\";b:1;s:20:\"edit_others_products\";b:1;s:16:\"publish_products\";b:1;s:21:\"read_private_products\";b:1;s:15:\"delete_products\";b:1;s:23:\"delete_private_products\";b:1;s:25:\"delete_published_products\";b:1;s:22:\"delete_others_products\";b:1;s:21:\"edit_private_products\";b:1;s:23:\"edit_published_products\";b:1;s:20:\"manage_product_terms\";b:1;s:18:\"edit_product_terms\";b:1;s:20:\"delete_product_terms\";b:1;s:20:\"assign_product_terms\";b:1;s:15:\"edit_shop_order\";b:1;s:15:\"read_shop_order\";b:1;s:17:\"delete_shop_order\";b:1;s:16:\"edit_shop_orders\";b:1;s:23:\"edit_others_shop_orders\";b:1;s:19:\"publish_shop_orders\";b:1;s:24:\"read_private_shop_orders\";b:1;s:18:\"delete_shop_orders\";b:1;s:26:\"delete_private_shop_orders\";b:1;s:28:\"delete_published_shop_orders\";b:1;s:25:\"delete_others_shop_orders\";b:1;s:24:\"edit_private_shop_orders\";b:1;s:26:\"edit_published_shop_orders\";b:1;s:23:\"manage_shop_order_terms\";b:1;s:21:\"edit_shop_order_terms\";b:1;s:23:\"delete_shop_order_terms\";b:1;s:23:\"assign_shop_order_terms\";b:1;s:16:\"edit_shop_coupon\";b:1;s:16:\"read_shop_coupon\";b:1;s:18:\"delete_shop_coupon\";b:1;s:17:\"edit_shop_coupons\";b:1;s:24:\"edit_others_shop_coupons\";b:1;s:20:\"publish_shop_coupons\";b:1;s:25:\"read_private_shop_coupons\";b:1;s:19:\"delete_shop_coupons\";b:1;s:27:\"delete_private_shop_coupons\";b:1;s:29:\"delete_published_shop_coupons\";b:1;s:26:\"delete_others_shop_coupons\";b:1;s:25:\"edit_private_shop_coupons\";b:1;s:27:\"edit_published_shop_coupons\";b:1;s:24:\"manage_shop_coupon_terms\";b:1;s:22:\"edit_shop_coupon_terms\";b:1;s:24:\"delete_shop_coupon_terms\";b:1;s:24:\"assign_shop_coupon_terms\";b:1;s:24:\"NextGEN Gallery overview\";b:1;s:19:\"NextGEN Use TinyMCE\";b:1;s:21:\"NextGEN Upload images\";b:1;s:22:\"NextGEN Manage gallery\";b:1;s:19:\"NextGEN Manage tags\";b:1;s:29:\"NextGEN Manage others gallery\";b:1;s:18:\"NextGEN Edit album\";b:1;s:20:\"NextGEN Change style\";b:1;s:22:\"NextGEN Change options\";b:1;s:24:\"NextGEN Attach Interface\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:36:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:10:\"copy_posts\";b:1;s:15:\"wpseo_bulk_edit\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}s:13:\"wpseo_manager\";a:2:{s:4:\"name\";s:11:\"SEO Manager\";s:12:\"capabilities\";a:38:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:10:\"copy_posts\";b:1;s:15:\"wpseo_bulk_edit\";b:1;s:28:\"wpseo_edit_advanced_metadata\";b:1;s:20:\"wpseo_manage_options\";b:1;}}s:12:\"wpseo_editor\";a:2:{s:4:\"name\";s:10:\"SEO Editor\";s:12:\"capabilities\";a:37:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:10:\"copy_posts\";b:1;s:15:\"wpseo_bulk_edit\";b:1;s:28:\"wpseo_edit_advanced_metadata\";b:1;}}s:8:\"customer\";a:2:{s:4:\"name\";s:8:\"Customer\";s:12:\"capabilities\";a:1:{s:4:\"read\";b:1;}}s:12:\"shop_manager\";a:2:{s:4:\"name\";s:12:\"Shop manager\";s:12:\"capabilities\";a:93:{s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:4:\"read\";b:1;s:18:\"read_private_pages\";b:1;s:18:\"read_private_posts\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_posts\";b:1;s:10:\"edit_pages\";b:1;s:20:\"edit_published_posts\";b:1;s:20:\"edit_published_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"edit_private_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:17:\"edit_others_pages\";b:1;s:13:\"publish_posts\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_posts\";b:1;s:12:\"delete_pages\";b:1;s:20:\"delete_private_pages\";b:1;s:20:\"delete_private_posts\";b:1;s:22:\"delete_published_pages\";b:1;s:22:\"delete_published_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:19:\"delete_others_pages\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:17:\"moderate_comments\";b:1;s:12:\"upload_files\";b:1;s:6:\"export\";b:1;s:6:\"import\";b:1;s:10:\"list_users\";b:1;s:18:\"edit_theme_options\";b:1;s:18:\"manage_woocommerce\";b:1;s:24:\"view_woocommerce_reports\";b:1;s:12:\"edit_product\";b:1;s:12:\"read_product\";b:1;s:14:\"delete_product\";b:1;s:13:\"edit_products\";b:1;s:20:\"edit_others_products\";b:1;s:16:\"publish_products\";b:1;s:21:\"read_private_products\";b:1;s:15:\"delete_products\";b:1;s:23:\"delete_private_products\";b:1;s:25:\"delete_published_products\";b:1;s:22:\"delete_others_products\";b:1;s:21:\"edit_private_products\";b:1;s:23:\"edit_published_products\";b:1;s:20:\"manage_product_terms\";b:1;s:18:\"edit_product_terms\";b:1;s:20:\"delete_product_terms\";b:1;s:20:\"assign_product_terms\";b:1;s:15:\"edit_shop_order\";b:1;s:15:\"read_shop_order\";b:1;s:17:\"delete_shop_order\";b:1;s:16:\"edit_shop_orders\";b:1;s:23:\"edit_others_shop_orders\";b:1;s:19:\"publish_shop_orders\";b:1;s:24:\"read_private_shop_orders\";b:1;s:18:\"delete_shop_orders\";b:1;s:26:\"delete_private_shop_orders\";b:1;s:28:\"delete_published_shop_orders\";b:1;s:25:\"delete_others_shop_orders\";b:1;s:24:\"edit_private_shop_orders\";b:1;s:26:\"edit_published_shop_orders\";b:1;s:23:\"manage_shop_order_terms\";b:1;s:21:\"edit_shop_order_terms\";b:1;s:23:\"delete_shop_order_terms\";b:1;s:23:\"assign_shop_order_terms\";b:1;s:16:\"edit_shop_coupon\";b:1;s:16:\"read_shop_coupon\";b:1;s:18:\"delete_shop_coupon\";b:1;s:17:\"edit_shop_coupons\";b:1;s:24:\"edit_others_shop_coupons\";b:1;s:20:\"publish_shop_coupons\";b:1;s:25:\"read_private_shop_coupons\";b:1;s:19:\"delete_shop_coupons\";b:1;s:27:\"delete_private_shop_coupons\";b:1;s:29:\"delete_published_shop_coupons\";b:1;s:26:\"delete_others_shop_coupons\";b:1;s:25:\"edit_private_shop_coupons\";b:1;s:27:\"edit_published_shop_coupons\";b:1;s:24:\"manage_shop_coupon_terms\";b:1;s:22:\"edit_shop_coupon_terms\";b:1;s:24:\"delete_shop_coupon_terms\";b:1;s:24:\"assign_shop_coupon_terms\";b:1;}}}","yes");
INSERT INTO `st_options` VALUES("94","fresh_site","0","yes");
INSERT INTO `st_options` VALUES("95","WPLANG","fa_IR","yes");
INSERT INTO `st_options` VALUES("96","widget_search","a:4:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;i:3;a:1:{s:5:\"title\";s:10:\"جستجو\";}i:4;a:1:{s:5:\"title\";s:10:\"جستجو\";}}","yes");
INSERT INTO `st_options` VALUES("97","widget_recent-posts","a:4:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;i:4;a:3:{s:5:\"title\";s:26:\"نوشته های تازه\";s:6:\"number\";i:4;s:9:\"show_date\";b:1;}i:6;a:3:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:4;s:9:\"show_date\";b:0;}}","yes");
INSERT INTO `st_options` VALUES("98","widget_recent-comments","a:4:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;i:4;a:0:{}i:6;a:0:{}}","yes");
INSERT INTO `st_options` VALUES("99","widget_archives","a:5:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;i:4;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:1;}i:6;a:0:{}i:8;a:3:{s:5:\"title\";s:28:\"نوشته های پیشین\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}}","yes");
INSERT INTO `st_options` VALUES("100","widget_meta","a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `st_options` VALUES("101","sidebars_widgets","a:23:{s:19:\"wp_inactive_widgets\";a:24:{i:0;s:14:\"recent-posts-4\";i:1;s:10:\"archives-4\";i:2;s:7:\"text-10\";i:3;s:5:\"rss-5\";i:4;s:22:\"wp_statistics_widget-3\";i:5;s:10:\"archives-2\";i:6;s:6:\"meta-2\";i:7;s:8:\"search-2\";i:8;s:6:\"text-2\";i:9;s:6:\"text-3\";i:10;s:6:\"text-4\";i:11;s:6:\"text-5\";i:12;s:6:\"text-6\";i:13;s:6:\"text-7\";i:14;s:12:\"categories-2\";i:15;s:14:\"recent-posts-2\";i:16;s:17:\"recent-comments-2\";i:17;s:8:\"search-3\";i:18;s:6:\"text-9\";i:19;s:8:\"search-4\";i:20;s:5:\"rss-3\";i:21;s:6:\"text-8\";i:22;s:10:\"archives-6\";i:23;s:17:\"recent-comments-4\";}s:13:\"footer-area-1\";a:2:{i:0;s:22:\"wp_statistics_widget-5\";i:1;s:25:\"woocommerce_widget_cart-2\";}s:13:\"footer-area-2\";a:1:{i:0;s:10:\"archives-8\";}s:13:\"footer-area-3\";a:1:{i:0;s:17:\"recent-comments-6\";}s:13:\"footer-area-4\";a:1:{i:0;s:14:\"recent-posts-6\";}s:10:\"top-area-1\";a:1:{i:0;s:18:\"widget_mfn_login-2\";}s:10:\"top-area-2\";a:1:{i:0;s:10:\"calendar-2\";}s:10:\"top-area-3\";a:0:{}s:10:\"top-area-4\";a:0:{}s:5:\"forum\";a:0:{}s:5:\"buddy\";a:0:{}s:6:\"events\";a:1:{i:0;s:10:\"calendar-3\";}s:4:\"shop\";a:0:{}s:22:\"blog-cat-uncategorized\";a:0:{}s:45:\"blog-cat-%d8%aa%d8%a7%d8%b1%db%8c%d8%ae%db%8c\";a:0:{}s:91:\"blog-cat-%d8%af%d8%b3%d8%aa%d9%87%e2%80%8c%d8%a8%d9%86%d8%af%db%8c-%d9%86%d8%b4%d8%af%d9%87\";a:0:{}s:39:\"blog-cat-%d8%b9%d9%85%d9%88%d9%85%db%8c\";a:0:{}s:45:\"blog-cat-%d9%81%d8%b1%d9%87%d9%86%da%af%db%8c\";a:0:{}s:39:\"blog-cat-%d9%88%d8%b1%d8%b2%d8%b4%db%8c\";a:0:{}s:20:\"portfolio-cat-photos\";a:0:{}s:19:\"portfolio-cat-video\";a:0:{}s:23:\"portfolio-cat-webdesign\";a:0:{}s:13:\"array_version\";i:3;}","yes");
INSERT INTO `st_options` VALUES("3116","_site_transient_timeout_theme_roots","1542725227","no");
INSERT INTO `st_options` VALUES("3117","_site_transient_theme_roots","a:4:{s:7:\"betheme\";s:7:\"/themes\";s:13:\"twentyfifteen\";s:7:\"/themes\";s:15:\"twentyseventeen\";s:7:\"/themes\";s:13:\"twentysixteen\";s:7:\"/themes\";}","no");
INSERT INTO `st_options` VALUES("3118","_site_transient_update_plugins","O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1542723429;s:7:\"checked\";a:19:{s:19:\"akismet/akismet.php\";s:3:\"4.1\";s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";s:7:\"4.3.7.2\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:5:\"5.0.5\";s:33:\"duplicate-post/duplicate-post.php\";s:5:\"3.2.2\";s:43:\"google-analytics-dashboard-for-wp/gadwp.php\";s:5:\"5.3.5\";s:9:\"hello.php\";s:3:\"1.7\";s:19:\"jetpack/jetpack.php\";s:3:\"6.7\";s:27:\"LayerSlider/layerslider.php\";s:5:\"5.4.0\";s:29:\"nextgen-gallery/nggallery.php\";s:6:\"3.0.16\";s:38:\"recent-tweets-widget/recent-tweets.php\";s:5:\"1.6.8\";s:47:\"regenerate-thumbnails/regenerate-thumbnails.php\";s:5:\"3.0.2\";s:23:\"revslider/revslider.php\";s:6:\"4.6.93\";s:27:\"updraftplus/updraftplus.php\";s:6:\"1.15.3\";s:53:\"velvet-blues-update-urls/velvet-blues-update-urls.php\";s:5:\"3.2.8\";s:27:\"woocommerce/woocommerce.php\";s:5:\"3.5.1\";s:27:\"js_composer/js_composer.php\";s:5:\"4.6.1\";s:21:\"wpglobus/wpglobus.php\";s:6:\"1.9.27\";s:31:\"wp-statistics/wp-statistics.php\";s:6:\"12.5.2\";s:24:\"wordpress-seo/wp-seo.php\";s:3:\"9.1\";}s:8:\"response\";a:2:{s:21:\"wpglobus/wpglobus.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:22:\"w.org/plugins/wpglobus\";s:4:\"slug\";s:8:\"wpglobus\";s:6:\"plugin\";s:21:\"wpglobus/wpglobus.php\";s:11:\"new_version\";s:6:\"1.9.30\";s:3:\"url\";s:39:\"https://wordpress.org/plugins/wpglobus/\";s:7:\"package\";s:51:\"https://downloads.wordpress.org/plugin/wpglobus.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:61:\"https://ps.w.org/wpglobus/assets/icon-256x256.png?rev=1069705\";s:2:\"1x\";s:61:\"https://ps.w.org/wpglobus/assets/icon-128x128.png?rev=1069705\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:62:\"https://ps.w.org/wpglobus/assets/banner-772x250.png?rev=956934\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"4.9.8\";s:12:\"requires_php\";s:3:\"5.4\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:24:\"wordpress-seo/wp-seo.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:27:\"w.org/plugins/wordpress-seo\";s:4:\"slug\";s:13:\"wordpress-seo\";s:6:\"plugin\";s:24:\"wordpress-seo/wp-seo.php\";s:11:\"new_version\";s:3:\"9.2\";s:3:\"url\";s:44:\"https://wordpress.org/plugins/wordpress-seo/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/wordpress-seo.9.2.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:66:\"https://ps.w.org/wordpress-seo/assets/icon-256x256.png?rev=1834347\";s:2:\"1x\";s:58:\"https://ps.w.org/wordpress-seo/assets/icon.svg?rev=1946641\";s:3:\"svg\";s:58:\"https://ps.w.org/wordpress-seo/assets/icon.svg?rev=1946641\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/wordpress-seo/assets/banner-1544x500.png?rev=1843435\";s:2:\"1x\";s:68:\"https://ps.w.org/wordpress-seo/assets/banner-772x250.png?rev=1843435\";}s:11:\"banners_rtl\";a:2:{s:2:\"2x\";s:73:\"https://ps.w.org/wordpress-seo/assets/banner-1544x500-rtl.png?rev=1843435\";s:2:\"1x\";s:72:\"https://ps.w.org/wordpress-seo/assets/banner-772x250-rtl.png?rev=1843435\";}s:6:\"tested\";s:3:\"5.0\";s:12:\"requires_php\";s:5:\"5.2.4\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:14:{s:19:\"akismet/akismet.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:21:\"w.org/plugins/akismet\";s:4:\"slug\";s:7:\"akismet\";s:6:\"plugin\";s:19:\"akismet/akismet.php\";s:11:\"new_version\";s:3:\"4.1\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/akismet/\";s:7:\"package\";s:54:\"https://downloads.wordpress.org/plugin/akismet.4.1.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:59:\"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272\";s:2:\"1x\";s:59:\"https://ps.w.org/akismet/assets/icon-128x128.png?rev=969272\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:61:\"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904\";}s:11:\"banners_rtl\";a:0:{}}s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:49:\"w.org/plugins/all-in-one-wp-security-and-firewall\";s:4:\"slug\";s:35:\"all-in-one-wp-security-and-firewall\";s:6:\"plugin\";s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";s:11:\"new_version\";s:7:\"4.3.7.2\";s:3:\"url\";s:66:\"https://wordpress.org/plugins/all-in-one-wp-security-and-firewall/\";s:7:\"package\";s:78:\"https://downloads.wordpress.org/plugin/all-in-one-wp-security-and-firewall.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:88:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/icon-128x128.png?rev=1232826\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:91:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/banner-1544x500.png?rev=1914011\";s:2:\"1x\";s:90:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/banner-772x250.png?rev=1914013\";}s:11:\"banners_rtl\";a:0:{}}s:36:\"contact-form-7/wp-contact-form-7.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:28:\"w.org/plugins/contact-form-7\";s:4:\"slug\";s:14:\"contact-form-7\";s:6:\"plugin\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:11:\"new_version\";s:5:\"5.0.5\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/contact-form-7/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/contact-form-7.5.0.5.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:66:\"https://ps.w.org/contact-form-7/assets/icon-256x256.png?rev=984007\";s:2:\"1x\";s:66:\"https://ps.w.org/contact-form-7/assets/icon-128x128.png?rev=984007\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/contact-form-7/assets/banner-1544x500.png?rev=860901\";s:2:\"1x\";s:68:\"https://ps.w.org/contact-form-7/assets/banner-772x250.png?rev=880427\";}s:11:\"banners_rtl\";a:0:{}}s:33:\"duplicate-post/duplicate-post.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:28:\"w.org/plugins/duplicate-post\";s:4:\"slug\";s:14:\"duplicate-post\";s:6:\"plugin\";s:33:\"duplicate-post/duplicate-post.php\";s:11:\"new_version\";s:5:\"3.2.2\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/duplicate-post/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/duplicate-post.3.2.2.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/duplicate-post/assets/icon-256x256.png?rev=1612753\";s:2:\"1x\";s:67:\"https://ps.w.org/duplicate-post/assets/icon-128x128.png?rev=1612753\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:69:\"https://ps.w.org/duplicate-post/assets/banner-772x250.png?rev=1612986\";}s:11:\"banners_rtl\";a:0:{}}s:43:\"google-analytics-dashboard-for-wp/gadwp.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:47:\"w.org/plugins/google-analytics-dashboard-for-wp\";s:4:\"slug\";s:33:\"google-analytics-dashboard-for-wp\";s:6:\"plugin\";s:43:\"google-analytics-dashboard-for-wp/gadwp.php\";s:11:\"new_version\";s:5:\"5.3.5\";s:3:\"url\";s:64:\"https://wordpress.org/plugins/google-analytics-dashboard-for-wp/\";s:7:\"package\";s:82:\"https://downloads.wordpress.org/plugin/google-analytics-dashboard-for-wp.5.3.5.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:85:\"https://ps.w.org/google-analytics-dashboard-for-wp/assets/icon-256x256.png?rev=970326\";s:2:\"1x\";s:85:\"https://ps.w.org/google-analytics-dashboard-for-wp/assets/icon-128x128.png?rev=970326\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:88:\"https://ps.w.org/google-analytics-dashboard-for-wp/assets/banner-772x250.png?rev=1064664\";}s:11:\"banners_rtl\";a:0:{}}s:9:\"hello.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:25:\"w.org/plugins/hello-dolly\";s:4:\"slug\";s:11:\"hello-dolly\";s:6:\"plugin\";s:9:\"hello.php\";s:11:\"new_version\";s:3:\"1.6\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/hello-dolly/\";s:7:\"package\";s:58:\"https://downloads.wordpress.org/plugin/hello-dolly.1.6.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:63:\"https://ps.w.org/hello-dolly/assets/icon-256x256.jpg?rev=969907\";s:2:\"1x\";s:63:\"https://ps.w.org/hello-dolly/assets/icon-128x128.jpg?rev=969907\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:65:\"https://ps.w.org/hello-dolly/assets/banner-772x250.png?rev=478342\";}s:11:\"banners_rtl\";a:0:{}}s:19:\"jetpack/jetpack.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:21:\"w.org/plugins/jetpack\";s:4:\"slug\";s:7:\"jetpack\";s:6:\"plugin\";s:19:\"jetpack/jetpack.php\";s:11:\"new_version\";s:3:\"6.7\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/jetpack/\";s:7:\"package\";s:54:\"https://downloads.wordpress.org/plugin/jetpack.6.7.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:60:\"https://ps.w.org/jetpack/assets/icon-256x256.png?rev=1791404\";s:2:\"1x\";s:52:\"https://ps.w.org/jetpack/assets/icon.svg?rev=1791404\";s:3:\"svg\";s:52:\"https://ps.w.org/jetpack/assets/icon.svg?rev=1791404\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:63:\"https://ps.w.org/jetpack/assets/banner-1544x500.png?rev=1791404\";s:2:\"1x\";s:62:\"https://ps.w.org/jetpack/assets/banner-772x250.png?rev=1791404\";}s:11:\"banners_rtl\";a:0:{}}s:29:\"nextgen-gallery/nggallery.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:29:\"w.org/plugins/nextgen-gallery\";s:4:\"slug\";s:15:\"nextgen-gallery\";s:6:\"plugin\";s:29:\"nextgen-gallery/nggallery.php\";s:11:\"new_version\";s:6:\"3.0.16\";s:3:\"url\";s:46:\"https://wordpress.org/plugins/nextgen-gallery/\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/plugin/nextgen-gallery.3.0.16.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:68:\"https://ps.w.org/nextgen-gallery/assets/icon-256x256.png?rev=1875408\";s:2:\"1x\";s:68:\"https://ps.w.org/nextgen-gallery/assets/icon-128x128.png?rev=1875408\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:71:\"https://ps.w.org/nextgen-gallery/assets/banner-1544x500.png?rev=1962188\";s:2:\"1x\";s:70:\"https://ps.w.org/nextgen-gallery/assets/banner-772x250.png?rev=1962188\";}s:11:\"banners_rtl\";a:0:{}}s:38:\"recent-tweets-widget/recent-tweets.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:34:\"w.org/plugins/recent-tweets-widget\";s:4:\"slug\";s:20:\"recent-tweets-widget\";s:6:\"plugin\";s:38:\"recent-tweets-widget/recent-tweets.php\";s:11:\"new_version\";s:5:\"1.6.8\";s:3:\"url\";s:51:\"https://wordpress.org/plugins/recent-tweets-widget/\";s:7:\"package\";s:69:\"https://downloads.wordpress.org/plugin/recent-tweets-widget.1.6.8.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:73:\"https://ps.w.org/recent-tweets-widget/assets/icon-256x256.png?rev=1849418\";s:2:\"1x\";s:73:\"https://ps.w.org/recent-tweets-widget/assets/icon-128x128.png?rev=1849418\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:75:\"https://ps.w.org/recent-tweets-widget/assets/banner-772x250.png?rev=1849422\";}s:11:\"banners_rtl\";a:0:{}}s:47:\"regenerate-thumbnails/regenerate-thumbnails.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:35:\"w.org/plugins/regenerate-thumbnails\";s:4:\"slug\";s:21:\"regenerate-thumbnails\";s:6:\"plugin\";s:47:\"regenerate-thumbnails/regenerate-thumbnails.php\";s:11:\"new_version\";s:5:\"3.0.2\";s:3:\"url\";s:52:\"https://wordpress.org/plugins/regenerate-thumbnails/\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/plugin/regenerate-thumbnails.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:74:\"https://ps.w.org/regenerate-thumbnails/assets/icon-128x128.png?rev=1753390\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:77:\"https://ps.w.org/regenerate-thumbnails/assets/banner-1544x500.jpg?rev=1753390\";s:2:\"1x\";s:76:\"https://ps.w.org/regenerate-thumbnails/assets/banner-772x250.jpg?rev=1753390\";}s:11:\"banners_rtl\";a:0:{}}s:27:\"updraftplus/updraftplus.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:25:\"w.org/plugins/updraftplus\";s:4:\"slug\";s:11:\"updraftplus\";s:6:\"plugin\";s:27:\"updraftplus/updraftplus.php\";s:11:\"new_version\";s:6:\"1.15.3\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/updraftplus/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/plugin/updraftplus.1.15.3.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:64:\"https://ps.w.org/updraftplus/assets/icon-256x256.jpg?rev=1686200\";s:2:\"1x\";s:64:\"https://ps.w.org/updraftplus/assets/icon-128x128.jpg?rev=1686200\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/updraftplus/assets/banner-1544x500.png?rev=1686200\";s:2:\"1x\";s:66:\"https://ps.w.org/updraftplus/assets/banner-772x250.png?rev=1686200\";}s:11:\"banners_rtl\";a:0:{}}s:53:\"velvet-blues-update-urls/velvet-blues-update-urls.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:38:\"w.org/plugins/velvet-blues-update-urls\";s:4:\"slug\";s:24:\"velvet-blues-update-urls\";s:6:\"plugin\";s:53:\"velvet-blues-update-urls/velvet-blues-update-urls.php\";s:11:\"new_version\";s:5:\"3.2.8\";s:3:\"url\";s:55:\"https://wordpress.org/plugins/velvet-blues-update-urls/\";s:7:\"package\";s:73:\"https://downloads.wordpress.org/plugin/velvet-blues-update-urls.3.2.8.zip\";s:5:\"icons\";a:1:{s:7:\"default\";s:75:\"https://s.w.org/plugins/geopattern-icon/velvet-blues-update-urls_727172.svg\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:78:\"https://ps.w.org/velvet-blues-update-urls/assets/banner-772x250.jpg?rev=486343\";}s:11:\"banners_rtl\";a:0:{}}s:27:\"woocommerce/woocommerce.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:25:\"w.org/plugins/woocommerce\";s:4:\"slug\";s:11:\"woocommerce\";s:6:\"plugin\";s:27:\"woocommerce/woocommerce.php\";s:11:\"new_version\";s:5:\"3.5.1\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/woocommerce/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/woocommerce.3.5.1.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:64:\"https://ps.w.org/woocommerce/assets/icon-256x256.png?rev=1440831\";s:2:\"1x\";s:64:\"https://ps.w.org/woocommerce/assets/icon-128x128.png?rev=1440831\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/woocommerce/assets/banner-1544x500.png?rev=1629184\";s:2:\"1x\";s:66:\"https://ps.w.org/woocommerce/assets/banner-772x250.png?rev=1629184\";}s:11:\"banners_rtl\";a:0:{}}s:31:\"wp-statistics/wp-statistics.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:27:\"w.org/plugins/wp-statistics\";s:4:\"slug\";s:13:\"wp-statistics\";s:6:\"plugin\";s:31:\"wp-statistics/wp-statistics.php\";s:11:\"new_version\";s:6:\"12.5.2\";s:3:\"url\";s:44:\"https://wordpress.org/plugins/wp-statistics/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/wp-statistics.12.5.2.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:66:\"https://ps.w.org/wp-statistics/assets/icon-256x256.png?rev=1673578\";s:2:\"1x\";s:58:\"https://ps.w.org/wp-statistics/assets/icon.svg?rev=1860682\";s:3:\"svg\";s:58:\"https://ps.w.org/wp-statistics/assets/icon.svg?rev=1860682\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:68:\"https://ps.w.org/wp-statistics/assets/banner-772x250.png?rev=1673578\";}s:11:\"banners_rtl\";a:0:{}}}}","no");
INSERT INTO `st_options` VALUES("139","auto_core_update_notified","a:4:{s:4:\"type\";s:7:\"success\";s:5:\"email\";s:26:\"fullstackdiaries@gmail.com\";s:7:\"version\";s:5:\"4.9.8\";s:9:\"timestamp\";i:1541813333;}","no");
INSERT INTO `st_options` VALUES("247","widget_widget_mfn_recent_posts","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `st_options` VALUES("248","widget_widget_mfn_tag_cloud","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `st_options` VALUES("237","client-types_children","a:0:{}","yes");
INSERT INTO `st_options` VALUES("2660","category_children","a:0:{}","yes");
INSERT INTO `st_options` VALUES("328","jetpack_activated","1","yes");
INSERT INTO `st_options` VALUES("331","jetpack_activation_source","a:2:{i:0;s:7:\"unknown\";i:1;N;}","yes");
INSERT INTO `st_options` VALUES("151","nav_menu_options","a:1:{s:8:\"auto_add\";a:0:{}}","yes");
INSERT INTO `st_options` VALUES("102","widget_pages","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `st_options` VALUES("103","widget_calendar","a:3:{i:2;a:1:{s:5:\"title\";s:0:\"\";}i:3;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `st_options` VALUES("104","widget_media_audio","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `st_options` VALUES("105","widget_media_image","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `st_options` VALUES("106","widget_media_gallery","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `st_options` VALUES("107","widget_media_video","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `st_options` VALUES("108","widget_tag_cloud","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `st_options` VALUES("109","widget_nav_menu","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `st_options` VALUES("110","widget_custom_html","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `st_options` VALUES("111","cron","a:21:{i:1542761443;a:1:{s:20:\"jetpack_clean_nonces\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1542761447;a:1:{s:26:\"action_scheduler_run_queue\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:12:\"every_minute\";s:4:\"args\";a:0:{}s:8:\"interval\";i:60;}}}i:1542761967;a:1:{s:24:\"aiowps_hourly_cron_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1542762062;a:1:{s:29:\"ngg_delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"ngg_custom\";s:4:\"args\";a:0:{}s:8:\"interval\";i:900;}}}i:1542763716;a:4:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1542763720;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1542765042;a:1:{s:32:\"woocommerce_cancel_unpaid_orders\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1542765584;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1542768213;a:1:{s:29:\"akismet_schedule_cron_recheck\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1542772246;a:1:{s:28:\"woocommerce_cleanup_sessions\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1542793846;a:1:{s:33:\"woocommerce_cleanup_personal_data\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1542793847;a:1:{s:19:\"wpseo-reindex-links\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1542793856;a:1:{s:30:\"woocommerce_tracker_send_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1542794226;a:1:{s:28:\"wp_statistics_add_visit_hook\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1542794367;a:1:{s:23:\"aiowps_daily_cron_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1542804646;a:1:{s:24:\"woocommerce_cleanup_logs\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1542830848;a:1:{s:24:\"akismet_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1542834000;a:1:{s:27:\"woocommerce_scheduled_sales\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1543312245;a:1:{s:18:\"wpseo_onpage_fetch\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}}i:1543881600;a:1:{s:25:\"woocommerce_geoip_updater\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:7:\"monthly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:2592000;}}}s:7:\"version\";i:2;}","yes");
INSERT INTO `st_options` VALUES("112","theme_mods_twentyseventeen","a:10:{s:18:\"custom_css_post_id\";i:-1;s:18:\"nav_menu_locations\";a:2:{s:3:\"top\";i:2;s:6:\"social\";i:3;}s:7:\"panel_1\";i:30;s:7:\"panel_2\";i:27;s:7:\"panel_3\";i:29;s:7:\"panel_4\";i:28;s:11:\"custom_logo\";s:0:\"\";s:12:\"header_image\";s:66:\"http://foolstacks.ir/wp-content/uploads/2018/11/cropped-myship.jpg\";s:17:\"header_image_data\";O:8:\"stdClass\":5:{s:13:\"attachment_id\";i:72;s:3:\"url\";s:66:\"http://foolstacks.ir/wp-content/uploads/2018/11/cropped-myship.jpg\";s:13:\"thumbnail_url\";s:66:\"http://foolstacks.ir/wp-content/uploads/2018/11/cropped-myship.jpg\";s:6:\"height\";i:1250;s:5:\"width\";i:2000;}s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1541816140;s:4:\"data\";a:4:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:1:{i:0;s:8:\"search-3\";}s:9:\"sidebar-2\";a:1:{i:0;s:6:\"text-8\";}s:9:\"sidebar-3\";a:2:{i:0;s:6:\"text-9\";i:1;s:8:\"search-4\";}}}}","yes");
INSERT INTO `st_options` VALUES("126","can_compress_scripts","0","no");
INSERT INTO `st_options` VALUES("542","wp_statistics_plugin_version","12.5.2","yes");
INSERT INTO `st_options` VALUES("543","wp_statistics_db_version","12.5.2","yes");
INSERT INTO `st_options` VALUES("544","wp_statistics","a:91:{s:18:\"pending_db_updates\";a:2:{s:13:\"date_ip_agent\";b:0;s:11:\"unique_date\";b:0;}s:16:\"search_converted\";i:1;s:9:\"robotlist\";s:1715:\"007ac9
5bot
A6-Indexer
AbachoBOT
accoona
AcoiRobot
AddThis.com
ADmantX
AdsBot-Google
advbot
AhrefsBot
aiHitBot
alexa
alphabot
AltaVista
AntivirusPro
anyevent
appie
Applebot
archive.org_bot
Ask Jeeves
ASPSeek
Baiduspider
Benjojo
BeetleBot
bingbot
Blekkobot
blexbot
BOT for JCE
bubing
Butterfly
cbot
clamantivirus
cliqzbot
clumboot
coccoc
crawler
CrocCrawler
crowsnest.tv
dbot
dl2bot
dotbot
downloadbot
duckduckgo
Dumbot
EasouSpider
eStyle
EveryoneSocialBot
Exabot
ezooms
facebook.com
facebookexternalhit
FAST
Feedfetcher-Google
feedzirra
findxbot
Firfly
FriendFeedBot
froogle
GeonaBot
Gigabot
girafabot
gimme60bot
glbot
Googlebot
GroupHigh
ia_archiver
IDBot
InfoSeek
inktomi
IstellaBot
jetmon
Kraken
Leikibot
linkapediabot
linkdexbot
LinkpadBot
LoadTimeBot
looksmart
ltx71
Lycos
Mail.RU_Bot
Me.dium
meanpathbot
mediabot
medialbot
Mediapartners-Google
MJ12bot
msnbot
MojeekBot
monobot
moreover
MRBOT
NationalDirectory
NerdyBot
NetcraftSurveyAgent
niki-bot
nutch
Openbot
OrangeBot
owler
p4Bot
PaperLiBot
pageanalyzer
PagesInventory
Pimonster
porkbun
pr-cy
proximic
pwbot
r4bot
rabaz
Rambler
Rankivabot
revip
riddler
rogerbot
Scooter
Scrubby
scrapy.org
SearchmetricsBot
sees.co
SemanticBot
SemrushBot
SeznamBot
sfFeedReader
shareaholic-bot
sistrix
SiteExplorer
Slurp
Socialradarbot
SocialSearch
Sogou web spider
Spade
spbot
SpiderLing
SputnikBot
Superfeedr
SurveyBot
TechnoratiSnoop
TECNOSEEK
Teoma
trendictionbot
TweetmemeBot
Twiceler
Twitterbot
Twitturls
u2bot
uMBot-LN
uni5download
unrulymedia
UptimeRobot
URL_Spider_SQL
Vagabondo
vBSEO
WASALive-Bot
WebAlta Crawler
WebBug
WebFindBot
WebMasterAid
WeSEE
Wotbox
wsowner
wsr-agent
www.galaxy.com
x100bot
XoviBot
xzybot
yandex
Yahoo
Yammybot
YoudaoBot
ZyBorg
ZemlyaCrawl\";s:13:\"anonymize_ips\";s:0:\"\";s:5:\"geoip\";s:2:\"on\";s:8:\"browscap\";s:0:\"\";s:10:\"useronline\";s:1:\"1\";s:6:\"visits\";s:1:\"1\";s:8:\"visitors\";s:1:\"1\";s:5:\"pages\";s:1:\"1\";s:12:\"check_online\";s:1:\"5\";s:8:\"menu_bar\";s:1:\"0\";s:11:\"coefficient\";s:1:\"1\";s:12:\"stats_report\";s:0:\"\";s:11:\"time_report\";s:5:\"daily\";s:11:\"send_report\";s:4:\"mail\";s:14:\"content_report\";s:0:\"\";s:12:\"update_geoip\";s:0:\"\";s:8:\"store_ua\";s:0:\"\";s:21:\"exclude_administrator\";s:1:\"1\";s:18:\"disable_se_clearch\";s:1:\"1\";s:14:\"disable_se_ask\";s:1:\"1\";s:8:\"map_type\";s:6:\"jqvmap\";s:18:\"force_robot_update\";s:1:\"1\";s:17:\"show_welcome_page\";b:0;s:23:\"first_show_welcome_page\";b:1;s:15:\"update_browscap\";b:1;s:16:\"disable_se_baidu\";s:0:\"\";s:15:\"disable_se_bing\";s:0:\"\";s:21:\"disable_se_duckduckgo\";s:0:\"\";s:17:\"disable_se_google\";s:0:\"\";s:16:\"disable_se_yahoo\";s:0:\"\";s:17:\"disable_se_yandex\";s:0:\"\";s:15:\"track_all_pages\";s:0:\"\";s:14:\"disable_column\";s:0:\"\";s:9:\"show_hits\";s:0:\"\";s:21:\"display_hits_position\";s:1:\"0\";s:12:\"chart_totals\";s:0:\"\";s:12:\"hide_notices\";s:0:\"\";s:10:\"all_online\";s:0:\"\";s:20:\"strip_uri_parameters\";s:0:\"\";s:14:\"addsearchwords\";s:0:\"\";s:8:\"hash_ips\";s:0:\"\";s:10:\"email_list\";s:26:\"fullstackdiaries@gmail.com\";s:15:\"browscap_report\";s:0:\"\";s:12:\"geoip_report\";s:0:\"\";s:12:\"prune_report\";s:0:\"\";s:14:\"upgrade_report\";s:0:\"\";s:13:\"admin_notices\";s:0:\"\";s:11:\"disable_map\";s:0:\"\";s:17:\"disable_dashboard\";s:0:\"\";s:14:\"disable_editor\";s:0:\"\";s:15:\"read_capability\";s:14:\"manage_options\";s:17:\"manage_capability\";s:14:\"manage_options\";s:14:\"exclude_editor\";s:0:\"\";s:14:\"exclude_author\";s:0:\"\";s:19:\"exclude_contributor\";s:0:\"\";s:18:\"exclude_subscriber\";s:0:\"\";s:19:\"exclude_seo_manager\";s:0:\"\";s:18:\"exclude_seo_editor\";s:0:\"\";s:16:\"exclude_customer\";s:0:\"\";s:20:\"exclude_shop_manager\";s:0:\"\";s:17:\"record_exclusions\";s:0:\"\";s:10:\"exclude_ip\";s:0:\"\";s:17:\"exclude_loginpage\";s:0:\"\";s:18:\"excluded_countries\";s:0:\"\";s:18:\"included_countries\";s:0:\"\";s:14:\"excluded_hosts\";s:0:\"\";s:15:\"robot_threshold\";s:0:\"\";s:12:\"use_honeypot\";s:0:\"\";s:15:\"honeypot_postid\";s:0:\"\";s:13:\"exclude_feeds\";s:0:\"\";s:13:\"excluded_urls\";s:0:\"\";s:12:\"exclude_404s\";s:0:\"\";s:20:\"corrupt_browser_info\";s:0:\"\";s:12:\"exclude_ajax\";s:0:\"\";s:14:\"schedule_geoip\";s:0:\"\";s:8:\"auto_pop\";s:0:\"\";s:20:\"private_country_code\";s:3:\"000\";s:17:\"schedule_browscap\";s:0:\"\";s:12:\"referrerspam\";s:0:\"\";s:19:\"update_referrerspam\";s:0:\"\";s:21:\"schedule_referrerspam\";s:0:\"\";s:16:\"last_browscap_dl\";i:0;s:16:\"schedule_dbmaint\";s:0:\"\";s:21:\"schedule_dbmaint_days\";s:3:\"365\";s:24:\"schedule_dbmaint_visitor\";s:0:\"\";s:29:\"schedule_dbmaint_visitor_hits\";s:2:\"50\";s:13:\"last_geoip_dl\";i:1542103954;s:6:\"widget\";a:24:{s:11:\"name_widget\";s:0:\"\";s:17:\"useronline_widget\";s:2:\"on\";s:13:\"tvisit_widget\";s:2:\"on\";s:15:\"tvisitor_widget\";s:0:\"\";s:13:\"yvisit_widget\";s:0:\"\";s:15:\"yvisitor_widget\";s:0:\"\";s:13:\"wvisit_widget\";s:0:\"\";s:13:\"mvisit_widget\";s:0:\"\";s:14:\"ysvisit_widget\";s:0:\"\";s:14:\"ttvisit_widget\";s:2:\"on\";s:16:\"ttvisitor_widget\";s:0:\"\";s:14:\"tpviews_widget\";s:0:\"\";s:10:\"ser_widget\";s:0:\"\";s:9:\"select_se\";s:0:\"\";s:9:\"tp_widget\";s:0:\"\";s:10:\"tpg_widget\";s:0:\"\";s:9:\"tc_widget\";s:0:\"\";s:9:\"ts_widget\";s:0:\"\";s:9:\"tu_widget\";s:0:\"\";s:9:\"ap_widget\";s:0:\"\";s:9:\"ac_widget\";s:0:\"\";s:9:\"au_widget\";s:0:\"\";s:10:\"lpd_widget\";s:2:\"on\";s:10:\"select_lps\";s:0:\"\";}s:16:\"disable_se_qwant\";b:1;}","yes");
INSERT INTO `st_options` VALUES("545","widget_wp_statistics_widget","a:3:{i:3;a:0:{}i:5;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `st_options` VALUES("2493","_site_transient_update_core","O:8:\"stdClass\":4:{s:7:\"updates\";a:2:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:65:\"https://downloads.wordpress.org/release/fa_IR/wordpress-4.9.8.zip\";s:6:\"locale\";s:5:\"fa_IR\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:65:\"https://downloads.wordpress.org/release/fa_IR/wordpress-4.9.8.zip\";s:10:\"no_content\";b:0;s:11:\"new_bundled\";b:0;s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"4.9.8\";s:7:\"version\";s:5:\"4.9.8\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"4.7\";s:15:\"partial_version\";s:0:\"\";}i:1;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.9.8.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.9.8.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-4.9.8-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-4.9.8-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"4.9.8\";s:7:\"version\";s:5:\"4.9.8\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"4.7\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1542723420;s:15:\"version_checked\";s:5:\"4.9.8\";s:12:\"translations\";a:0:{}}","no");
INSERT INTO `st_options` VALUES("2494","_site_transient_update_themes","O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1542723428;s:7:\"checked\";a:4:{s:7:\"betheme\";s:3:\"8.8\";s:13:\"twentyfifteen\";s:3:\"2.0\";s:15:\"twentyseventeen\";s:3:\"1.7\";s:13:\"twentysixteen\";s:3:\"1.5\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}}","no");
INSERT INTO `st_options` VALUES("553","aiowpsec_db_version","1.9","yes");
INSERT INTO `st_options` VALUES("554","aio_wp_security_configs","a:94:{s:19:\"aiowps_enable_debug\";s:0:\"\";s:36:\"aiowps_remove_wp_generator_meta_info\";s:1:\"1\";s:25:\"aiowps_prevent_hotlinking\";s:1:\"1\";s:28:\"aiowps_enable_login_lockdown\";s:1:\"1\";s:28:\"aiowps_allow_unlock_requests\";s:0:\"\";s:25:\"aiowps_max_login_attempts\";i:3;s:24:\"aiowps_retry_time_period\";i:10;s:26:\"aiowps_lockout_time_length\";i:360;s:28:\"aiowps_set_generic_login_msg\";s:1:\"1\";s:26:\"aiowps_enable_email_notify\";s:1:\"1\";s:20:\"aiowps_email_address\";s:26:\"fullstackdiaries@gmail.com\";s:27:\"aiowps_enable_forced_logout\";s:1:\"1\";s:25:\"aiowps_logout_time_period\";i:30;s:39:\"aiowps_enable_invalid_username_lockdown\";s:1:\"1\";s:43:\"aiowps_instantly_lockout_specific_usernames\";a:3:{i:0;s:5:\"admin\";i:1;s:5:\"ADMIN\";i:2;s:5:\"Admin\";}s:32:\"aiowps_unlock_request_secret_key\";s:20:\"gfnewvcp6u97e3mk3lgo\";s:35:\"aiowps_lockdown_enable_whitelisting\";s:0:\"\";s:36:\"aiowps_lockdown_allowed_ip_addresses\";s:0:\"\";s:26:\"aiowps_enable_whitelisting\";s:0:\"\";s:27:\"aiowps_allowed_ip_addresses\";s:0:\"\";s:27:\"aiowps_enable_login_captcha\";s:1:\"1\";s:34:\"aiowps_enable_custom_login_captcha\";s:1:\"1\";s:31:\"aiowps_enable_woo_login_captcha\";s:1:\"1\";s:34:\"aiowps_enable_woo_register_captcha\";s:1:\"1\";s:25:\"aiowps_captcha_secret_key\";s:20:\"x6y13oguttzjyr90tjsw\";s:42:\"aiowps_enable_manual_registration_approval\";s:1:\"1\";s:39:\"aiowps_enable_registration_page_captcha\";s:1:\"1\";s:35:\"aiowps_enable_registration_honeypot\";s:1:\"1\";s:27:\"aiowps_enable_random_prefix\";s:0:\"\";s:31:\"aiowps_enable_automated_backups\";s:1:\"1\";s:26:\"aiowps_db_backup_frequency\";i:1;s:25:\"aiowps_db_backup_interval\";s:1:\"2\";s:26:\"aiowps_backup_files_stored\";i:2;s:32:\"aiowps_send_backup_email_address\";s:1:\"1\";s:27:\"aiowps_backup_email_address\";s:26:\"fullstackdiaries@gmail.com\";s:27:\"aiowps_disable_file_editing\";s:1:\"1\";s:37:\"aiowps_prevent_default_wp_file_access\";s:1:\"1\";s:22:\"aiowps_system_log_file\";s:9:\"error_log\";s:26:\"aiowps_enable_blacklisting\";s:0:\"\";s:26:\"aiowps_banned_ip_addresses\";s:0:\"\";s:28:\"aiowps_enable_basic_firewall\";s:1:\"1\";s:31:\"aiowps_enable_pingback_firewall\";s:0:\"\";s:38:\"aiowps_disable_xmlrpc_pingback_methods\";s:0:\"\";s:34:\"aiowps_block_debug_log_file_access\";s:1:\"1\";s:26:\"aiowps_disable_index_views\";s:0:\"\";s:30:\"aiowps_disable_trace_and_track\";s:0:\"\";s:28:\"aiowps_forbid_proxy_comments\";s:0:\"\";s:29:\"aiowps_deny_bad_query_strings\";s:0:\"\";s:34:\"aiowps_advanced_char_string_filter\";s:0:\"\";s:25:\"aiowps_enable_5g_firewall\";s:0:\"\";s:25:\"aiowps_enable_6g_firewall\";s:0:\"\";s:26:\"aiowps_enable_custom_rules\";s:0:\"\";s:32:\"aiowps_place_custom_rules_at_top\";s:0:\"\";s:19:\"aiowps_custom_rules\";s:0:\"\";s:25:\"aiowps_enable_404_logging\";s:0:\"\";s:28:\"aiowps_enable_404_IP_lockout\";s:0:\"\";s:30:\"aiowps_404_lockout_time_length\";s:2:\"60\";s:28:\"aiowps_404_lock_redirect_url\";s:16:\"http://127.0.0.1\";s:31:\"aiowps_enable_rename_login_page\";s:1:\"1\";s:28:\"aiowps_enable_login_honeypot\";s:0:\"\";s:43:\"aiowps_enable_brute_force_attack_prevention\";s:0:\"\";s:30:\"aiowps_brute_force_secret_word\";s:13:\"aiowps_secret\";s:24:\"aiowps_cookie_brute_test\";s:29:\"aiowps_cookie_test_0vqhaqpnfl\";s:44:\"aiowps_cookie_based_brute_force_redirect_url\";s:16:\"http://127.0.0.1\";s:59:\"aiowps_brute_force_attack_prevention_pw_protected_exception\";s:0:\"\";s:51:\"aiowps_brute_force_attack_prevention_ajax_exception\";s:0:\"\";s:19:\"aiowps_site_lockout\";s:0:\"\";s:23:\"aiowps_site_lockout_msg\";s:0:\"\";s:30:\"aiowps_enable_spambot_blocking\";s:0:\"\";s:29:\"aiowps_enable_comment_captcha\";s:1:\"1\";s:31:\"aiowps_enable_autoblock_spam_ip\";s:0:\"\";s:33:\"aiowps_spam_ip_min_comments_block\";s:0:\"\";s:33:\"aiowps_enable_bp_register_captcha\";s:0:\"\";s:35:\"aiowps_enable_bbp_new_topic_captcha\";s:0:\"\";s:32:\"aiowps_enable_automated_fcd_scan\";s:0:\"\";s:25:\"aiowps_fcd_scan_frequency\";s:1:\"4\";s:24:\"aiowps_fcd_scan_interval\";s:1:\"2\";s:28:\"aiowps_fcd_exclude_filetypes\";s:0:\"\";s:24:\"aiowps_fcd_exclude_files\";s:0:\"\";s:26:\"aiowps_send_fcd_scan_email\";s:0:\"\";s:29:\"aiowps_fcd_scan_email_address\";s:26:\"fullstackdiaries@gmail.com\";s:27:\"aiowps_fcds_change_detected\";b:0;s:22:\"aiowps_copy_protection\";s:0:\"\";s:40:\"aiowps_prevent_site_display_inside_frame\";s:0:\"\";s:32:\"aiowps_prevent_users_enumeration\";s:0:\"\";s:42:\"aiowps_disallow_unauthorized_rest_requests\";s:0:\"\";s:25:\"aiowps_ip_retrieve_method\";s:1:\"0\";s:25:\"aiowps_recaptcha_site_key\";s:0:\"\";s:27:\"aiowps_recaptcha_secret_key\";s:0:\"\";s:24:\"aiowps_default_recaptcha\";s:1:\"1\";s:22:\"aiowps_login_page_slug\";s:12:\"sepidwplogin\";s:23:\"aiowps_last_backup_time\";s:19:\"2018-11-14 03:29:51\";s:26:\"aiowps_cookie_test_success\";s:1:\"1\";s:35:\"aiowps_enable_lost_password_captcha\";s:1:\"1\";}","yes");
INSERT INTO `st_options` VALUES("567","woocommerce_maybe_regenerate_images_hash","991b1ca641921cf0f5baf7a2fe85861b","yes");
INSERT INTO `st_options` VALUES("178","current_theme","بي تم | TopTheme","yes");
INSERT INTO `st_options` VALUES("179","theme_mods_betheme","a:3:{i:0;b:0;s:18:\"nav_menu_locations\";a:5:{s:9:\"main-menu\";i:22;s:14:\"secondary-menu\";i:0;s:9:\"lang-menu\";i:0;s:11:\"social-menu\";i:0;s:18:\"social-menu-bottom\";i:0;}s:18:\"custom_css_post_id\";i:-1;}","yes");
INSERT INTO `st_options` VALUES("180","theme_switched","","yes");
INSERT INTO `st_options` VALUES("181","betheme","a:306:{s:8:\"last_tab\";s:6:\"footer\";s:5:\"style\";s:0:\"\";s:6:\"layout\";s:10:\"full-width\";s:10:\"grid-width\";s:0:\"\";s:7:\"grid960\";s:1:\"0\";s:11:\"favicon-img\";s:0:\"\";s:11:\"img-page-bg\";s:0:\"\";s:16:\"position-page-bg\";s:22:\"no-repeat;center top;;\";s:17:\"image-frame-style\";s:0:\"\";s:8:\"logo-img\";s:54:\"http://foolstacks.ir/wp-content/uploads/2018/11/s1.png\";s:15:\"retina-logo-img\";s:54:\"http://foolstacks.ir/wp-content/uploads/2018/11/s1.png\";s:15:\"sticky-logo-img\";s:54:\"http://foolstacks.ir/wp-content/uploads/2018/11/s1.png\";s:22:\"sticky-retina-logo-img\";s:54:\"http://foolstacks.ir/wp-content/uploads/2018/11/s1.png\";s:9:\"logo-text\";s:0:\"\";s:10:\"logo-width\";s:0:\"\";s:9:\"logo-link\";a:1:{s:4:\"link\";s:4:\"link\";}s:19:\"slider-blog-timeout\";s:1:\"0\";s:22:\"slider-clients-timeout\";s:1:\"0\";s:20:\"slider-offer-timeout\";s:1:\"0\";s:24:\"slider-portfolio-timeout\";s:1:\"0\";s:19:\"slider-shop-timeout\";s:1:\"0\";s:21:\"slider-slider-timeout\";s:1:\"0\";s:27:\"slider-testimonials-timeout\";s:1:\"0\";s:18:\"builder-visibility\";s:0:\"\";s:13:\"display-order\";s:1:\"0\";s:23:\"math-animations-disable\";s:1:\"0\";s:19:\"table-hover-disable\";s:1:\"0\";s:10:\"static-css\";s:1:\"0\";s:12:\"table_prefix\";s:11:\"base_prefix\";s:8:\"hook-top\";s:0:\"\";s:19:\"hook-content-before\";s:0:\"\";s:18:\"hook-content-after\";s:0:\"\";s:11:\"hook-bottom\";s:0:\"\";s:12:\"header-style\";s:6:\"modern\";s:9:\"header-fw\";a:1:{s:10:\"full-width\";s:10:\"full-width\";}s:16:\"img-subheader-bg\";s:0:\"\";s:24:\"img-subheader-attachment\";s:0:\"\";s:17:\"minimalist-header\";s:1:\"1\";s:13:\"sticky-header\";s:1:\"1\";s:19:\"sticky-header-style\";s:4:\"dark\";s:21:\"subheader-transparent\";s:3:\"100\";s:15:\"subheader-image\";s:0:\"\";s:21:\"subheader-slider-show\";s:1:\"0\";s:15:\"subheader-style\";s:0:\"\";s:19:\"header-action-title\";s:0:\"\";s:18:\"header-action-link\";s:0:\"\";s:13:\"header-banner\";s:0:\"\";s:13:\"header-search\";s:1:\"1\";s:11:\"sliding-top\";s:1:\"0\";s:16:\"sliding-top-icon\";s:19:\"icon-down-open-mini\";s:11:\"header-wpml\";s:0:\"\";s:10:\"menu-style\";s:0:\"\";s:10:\"action-bar\";s:1:\"1\";s:13:\"header-slogan\";s:0:\"\";s:12:\"header-phone\";s:0:\"\";s:14:\"header-phone-2\";s:0:\"\";s:12:\"header-email\";s:0:\"\";s:13:\"sidebar-width\";s:2:\"23\";s:13:\"sidebar-lines\";s:0:\"\";s:18:\"single-page-layout\";s:0:\"\";s:19:\"single-page-sidebar\";s:0:\"\";s:20:\"single-page-sidebar2\";s:0:\"\";s:13:\"single-layout\";s:0:\"\";s:14:\"single-sidebar\";s:0:\"\";s:15:\"single-sidebar2\";s:0:\"\";s:23:\"single-portfolio-layout\";s:0:\"\";s:24:\"single-portfolio-sidebar\";s:0:\"\";s:25:\"single-portfolio-sidebar2\";s:0:\"\";s:19:\"pagination-show-all\";s:1:\"1\";s:4:\"love\";s:1:\"0\";s:13:\"prev-next-nav\";s:1:\"1\";s:5:\"share\";s:1:\"1\";s:13:\"title-heading\";s:1:\"1\";s:10:\"blog-posts\";s:1:\"4\";s:11:\"blog-layout\";s:7:\"classic\";s:12:\"blog-columns\";s:1:\"2\";s:15:\"blog-full-width\";s:1:\"0\";s:14:\"excerpt-length\";s:2:\"26\";s:10:\"blog-title\";s:1:\"1\";s:9:\"blog-meta\";s:1:\"1\";s:14:\"blog-load-more\";s:1:\"0\";s:9:\"blog-page\";s:2:\"29\";s:11:\"blog-author\";s:1:\"1\";s:12:\"blog-related\";s:1:\"1\";s:13:\"blog-comments\";s:1:\"1\";s:16:\"blog-single-zoom\";s:1:\"1\";s:18:\"blog-single-layout\";s:0:\"\";s:15:\"portfolio-posts\";s:1:\"8\";s:16:\"portfolio-layout\";s:4:\"grid\";s:17:\"portfolio-columns\";s:0:\"\";s:20:\"portfolio-full-width\";s:1:\"0\";s:17:\"portfolio-orderby\";s:4:\"date\";s:15:\"portfolio-order\";s:4:\"DESC\";s:21:\"portfolio-hover-title\";s:1:\"0\";s:18:\"portfolio-external\";s:0:\"\";s:17:\"portfolio-isotope\";s:1:\"1\";s:19:\"portfolio-load-more\";s:1:\"0\";s:14:\"portfolio-page\";s:0:\"\";s:17:\"portfolio-related\";s:1:\"1\";s:18:\"portfolio-comments\";s:1:\"0\";s:14:\"portfolio-slug\";s:14:\"portfolio-item\";s:13:\"portfolio-tax\";s:15:\"portfolio-types\";s:14:\"shop-catalogue\";s:1:\"0\";s:11:\"shop-images\";s:0:\"\";s:11:\"shop-layout\";s:4:\"grid\";s:13:\"shop-products\";s:2:\"12\";s:12:\"shop-excerpt\";s:1:\"0\";s:11:\"shop-slider\";s:0:\"\";s:19:\"shop-product-images\";s:0:\"\";s:12:\"shop-related\";s:1:\"1\";s:18:\"shop-product-style\";s:0:\"\";s:9:\"shop-cart\";s:11:\"icon-basket\";s:13:\"page-comments\";s:1:\"0\";s:13:\"error404-icon\";s:11:\"icon-reddit\";s:13:\"error404-page\";s:0:\"\";s:12:\"construction\";s:1:\"0\";s:18:\"construction-title\";s:11:\"Coming Soon\";s:17:\"construction-text\";s:0:\"\";s:17:\"construction-date\";s:19:\"12/30/2014 12:00:00\";s:19:\"construction-offset\";s:1:\"0\";s:20:\"construction-contact\";s:0:\"\";s:17:\"construction-page\";s:0:\"\";s:13:\"footer-layout\";s:0:\"\";s:12:\"footer-style\";s:7:\"sliding\";s:13:\"footer-bg-img\";s:75:\"http://foolstacks.ir/wp-content/uploads/2018/11/home_webdesign_pattern1.png\";s:21:\"footer-call-to-action\";s:0:\"\";s:11:\"footer-copy\";s:51:\"روز مره های یک دولوپر  sepidsal ©\";s:11:\"footer-hide\";s:6:\"center\";s:12:\"back-top-top\";s:0:\"\";s:18:\"popup-contact-form\";s:0:\"\";s:23:\"popup-contact-form-icon\";s:9:\"icon-chat\";s:10:\"responsive\";s:1:\"1\";s:19:\"responsive-logo-img\";s:0:\"\";s:26:\"responsive-retina-logo-img\";s:0:\"\";s:20:\"font-size-responsive\";s:1:\"0\";s:8:\"no-hover\";s:0:\"\";s:25:\"header-menu-mobile-sticky\";s:1:\"0\";s:16:\"header-menu-text\";s:0:\"\";s:13:\"no-section-bg\";s:0:\"\";s:18:\"responsive-top-bar\";s:4:\"left\";s:16:\"google-analytics\";s:0:\"\";s:18:\"google-remarketing\";s:0:\"\";s:7:\"mfn-seo\";s:1:\"1\";s:16:\"meta-description\";s:27:\"Just another WordPress site\";s:13:\"meta-keywords\";s:0:\"\";s:13:\"social-target\";s:1:\"1\";s:12:\"social-skype\";s:17:\"Sepideh Saljooghi\";s:15:\"social-facebook\";s:33:\"https://www.facebook.com/sepidsal\";s:17:\"social-googleplus\";s:0:\"\";s:14:\"social-twitter\";s:33:\"https://www.facebook.com/sepidsal\";s:12:\"social-vimeo\";s:0:\"\";s:14:\"social-youtube\";s:0:\"\";s:13:\"social-flickr\";s:0:\"\";s:15:\"social-linkedin\";s:55:\"https://www.linkedin.com/in/sepideh-saljooghi-94a69a68/\";s:16:\"social-pinterest\";s:34:\"https://www.pinterest.com/sepidsal\";s:15:\"social-dribbble\";s:0:\"\";s:16:\"social-instagram\";s:34:\"https://www.instagram.com/sepidsal\";s:14:\"social-behance\";s:0:\"\";s:13:\"social-tumblr\";s:0:\"\";s:16:\"social-vkontakte\";s:0:\"\";s:13:\"social-viadeo\";s:0:\"\";s:11:\"social-xing\";s:0:\"\";s:10:\"social-rss\";s:1:\"1\";s:11:\"nice-scroll\";s:1:\"1\";s:17:\"nice-scroll-speed\";s:2:\"40\";s:18:\"sc-gallery-disable\";s:1:\"0\";s:11:\"prettyphoto\";s:10:\"pp_default\";s:17:\"prettyphoto-width\";s:0:\"\";s:18:\"prettyphoto-height\";s:0:\"\";s:17:\"retina-js-disable\";s:1:\"0\";s:10:\"plugin-rev\";s:0:\"\";s:12:\"plugin-layer\";s:0:\"\";s:13:\"plugin-visual\";s:0:\"\";s:4:\"skin\";s:6:\"custom\";s:15:\"background-body\";s:7:\"#FCFCFC\";s:9:\"color-one\";s:7:\"#2991D6\";s:17:\"background-header\";s:7:\"#666666\";s:19:\"background-top-left\";s:7:\"#000000\";s:21:\"background-top-middle\";s:7:\"#e3e3e3\";s:20:\"background-top-right\";s:7:\"#f5f5f5\";s:17:\"color-top-right-a\";s:7:\"#444444\";s:17:\"background-search\";s:7:\"#59a3ff\";s:20:\"background-subheader\";s:7:\"#F7F7F7\";s:15:\"color-subheader\";s:7:\"#888888\";s:12:\"color-menu-a\";s:7:\"#444444\";s:19:\"color-menu-a-active\";s:7:\"#59a3ff\";s:24:\"background-menu-a-active\";s:7:\"#59a3ff\";s:18:\"background-submenu\";s:7:\"#F2F2F2\";s:15:\"color-submenu-a\";s:7:\"#5f5f5f\";s:21:\"color-submenu-a-hover\";s:7:\"#2e2e2e\";s:21:\"background-action-bar\";s:7:\"#2C2C2C\";s:23:\"background-overlay-menu\";s:7:\"#000000\";s:25:\"background-overlay-menu-a\";s:7:\"#ffffff\";s:17:\"border-menu-plain\";s:7:\"#F2F2F2\";s:11:\"color-theme\";s:7:\"#59a3ff\";s:10:\"color-text\";s:7:\"#626262\";s:7:\"color-a\";s:7:\"#59a3ff\";s:13:\"color-a-hover\";s:7:\"#3f87e1\";s:16:\"color-fancy-link\";s:7:\"#656B6F\";s:21:\"background-fancy-link\";s:7:\"#59a3ff\";s:22:\"color-fancy-link-hover\";s:7:\"#59a3ff\";s:27:\"background-fancy-link-hover\";s:7:\"#3f87e1\";s:10:\"color-note\";s:7:\"#a8a8a8\";s:10:\"color-list\";s:7:\"#737E86\";s:20:\"background-highlight\";s:7:\"#59a3ff\";s:28:\"background-highlight-section\";s:7:\"#59a3ff\";s:8:\"color-hr\";s:7:\"#59a3ff\";s:12:\"button-style\";s:6:\"stroke\";s:17:\"background-button\";s:7:\"#f7f7f7\";s:12:\"color-button\";s:7:\"#747474\";s:18:\"color-footer-theme\";s:7:\"#ffffff\";s:17:\"background-footer\";s:7:\"#545454\";s:12:\"color-footer\";s:7:\"#acacac\";s:14:\"color-footer-a\";s:7:\"#ffffff\";s:20:\"color-footer-a-hover\";s:7:\"#cfcfcf\";s:20:\"color-footer-heading\";s:7:\"#ffffff\";s:17:\"color-footer-note\";s:7:\"#a8a8a8\";s:23:\"color-sliding-top-theme\";s:7:\"#2991d6\";s:22:\"background-sliding-top\";s:7:\"#545454\";s:17:\"color-sliding-top\";s:7:\"#cccccc\";s:19:\"color-sliding-top-a\";s:7:\"#2991d6\";s:25:\"color-sliding-top-a-hover\";s:7:\"#2275ac\";s:25:\"color-sliding-top-heading\";s:7:\"#ffffff\";s:22:\"color-sliding-top-note\";s:7:\"#a8a8a8\";s:8:\"color-h1\";s:7:\"#000000\";s:8:\"color-h2\";s:7:\"#000000\";s:8:\"color-h3\";s:7:\"#000000\";s:8:\"color-h4\";s:7:\"#000000\";s:8:\"color-h5\";s:7:\"#6f6f6f\";s:8:\"color-h6\";s:7:\"#000000\";s:15:\"color-tab-title\";s:7:\"#59a3ff\";s:16:\"color-blockquote\";s:7:\"#444444\";s:17:\"color-contentlink\";s:7:\"#59a3ff\";s:13:\"color-counter\";s:7:\"#59a3ff\";s:21:\"background-getintouch\";s:7:\"#59a3ff\";s:13:\"color-iconbar\";s:7:\"#59a3ff\";s:13:\"color-iconbox\";s:7:\"#59a3ff\";s:26:\"background-imageframe-link\";s:7:\"#59a3ff\";s:21:\"color-imageframe-link\";s:7:\"#ffffff\";s:15:\"color-list-icon\";s:7:\"#59a3ff\";s:19:\"color-pricing-price\";s:7:\"#59a3ff\";s:27:\"background-pricing-featured\";s:7:\"#59a3ff\";s:22:\"background-progressbar\";s:7:\"#59a3ff\";s:22:\"color-quickfact-number\";s:7:\"#59a3ff\";s:27:\"background-slidingbox-title\";s:7:\"#59a3ff\";s:27:\"background-trailer-subtitle\";s:7:\"#59a3ff\";s:12:\"font-content\";s:13:\"Alegreya Sans\";s:9:\"font-menu\";s:13:\"Alegreya Sans\";s:10:\"font-title\";s:13:\"Alegreya Sans\";s:13:\"font-headings\";s:13:\"Alegreya Sans\";s:19:\"font-headings-small\";s:13:\"Alegreya Sans\";s:15:\"font-blockquote\";s:13:\"Alegreya Sans\";s:11:\"font-weight\";a:7:{i:100;s:3:\"100\";i:300;s:3:\"300\";i:400;s:3:\"400\";s:9:\"400italic\";s:9:\"400italic\";i:500;s:3:\"500\";i:600;s:3:\"600\";i:700;s:3:\"700\";}s:11:\"font-subset\";s:0:\"\";s:17:\"font-size-content\";s:2:\"15\";s:14:\"font-size-menu\";s:2:\"15\";s:12:\"font-size-h1\";s:2:\"25\";s:12:\"font-size-h2\";s:2:\"50\";s:12:\"font-size-h3\";s:2:\"40\";s:12:\"font-size-h4\";s:2:\"24\";s:12:\"font-size-h5\";s:2:\"18\";s:12:\"font-size-h6\";s:2:\"15\";s:11:\"font-custom\";s:0:\"\";s:16:\"font-custom-woff\";s:0:\"\";s:15:\"font-custom-ttf\";s:0:\"\";s:15:\"font-custom-svg\";s:0:\"\";s:15:\"font-custom-eot\";s:0:\"\";s:12:\"font-custom2\";s:0:\"\";s:17:\"font-custom2-woff\";s:0:\"\";s:16:\"font-custom2-ttf\";s:0:\"\";s:16:\"font-custom2-svg\";s:0:\"\";s:16:\"font-custom2-eot\";s:0:\"\";s:9:\"translate\";s:1:\"1\";s:28:\"translate-search-placeholder\";s:17:\"فرم جستجو\";s:24:\"translate-search-results\";s:21:\"نتایج جستجو\";s:14:\"translate-home\";s:4:\"Home\";s:14:\"translate-prev\";s:17:\"صفحه قبلی\";s:14:\"translate-next\";s:15:\"صفحه بعد\";s:19:\"translate-load-more\";s:25:\"اطلاعات بیشتر\";s:17:\"translate-wpml-no\";s:72:\"هیچ ترجمه ای برای این صفحه در دسترس نیست\";s:14:\"translate-days\";s:6:\"روز\";s:15:\"translate-hours\";s:8:\"ساعت\";s:17:\"translate-minutes\";s:10:\"دقیقه\";s:17:\"translate-seconds\";s:10:\"ثانیه\";s:16:\"translate-filter\";s:26:\"فیلتر بر اساس :\";s:14:\"translate-tags\";s:15:\"برچسب ها\";s:17:\"translate-authors\";s:19:\"نویسنده ها\";s:13:\"translate-all\";s:17:\"نمایش همه\";s:18:\"translate-item-all\";s:6:\"همه\";s:19:\"translate-published\";s:26:\"منتشر شده توسط\";s:12:\"translate-at\";s:4:\"در\";s:20:\"translate-categories\";s:14:\"موضوعات\";s:18:\"translate-readmore\";s:25:\"اطلاعات بیشتر\";s:14:\"translate-like\";s:17:\"جالب بود؟\";s:17:\"translate-related\";s:24:\"عکس های مرتبط\";s:16:\"translate-client\";s:10:\"مشتری\";s:14:\"translate-date\";s:10:\"تاریخ\";s:17:\"translate-website\";s:13:\"وب سایت\";s:14:\"translate-view\";s:26:\"مشاهده وب سایت\";s:14:\"translate-task\";s:10:\"وظایف\";s:19:\"translate-404-title\";s:23:\"وای ... خطای 404\";s:22:\"translate-404-subtitle\";s:102:\"با عرض پوزش. صفحه ای که شما به دنبال آن هستید وجود ندارد...\";s:18:\"translate-404-text\";s:85:\"لطفا آدرس وارد شده را چک کنید و دوباره سعی کنید \";s:17:\"translate-404-btn\";s:29:\"برو به صفحه نخست\";s:10:\"custom-css\";s:1453:\"h5 { font-weight: 400; }

@media only screen and (min-width: 1240px) {
#Top_bar .container { margin: 0 1%; width: 99%; }
}
@media only screen and (min-width: 768px) {
.header-overlay .overlay-menu-toggle { top: 67px !important; right: 45px; padding: 7px 2px; }
.single-portfolio #Content { margin-top: 120px; }
}

.header-overlay .overlay-menu-toggle { background: rgba(0, 0, 0, 0.3); padding: 7px 2px; color: #fff; top: 32px; }

/* Shortcodes */
.zoom_box .desc .desc_txt { font-weight: 700; letter-spacing: 2px; }
.section-border-top { border-top: 1px solid rgba(0, 0, 0, 0.08); }

/* Newsletter */
.newsletter_form { margin-top: 30px; }
.newsletter_form > input[type=\"email\"] { display: inline-block; margin-right: 10px; max-width: 250px; }

/* Button */
a.button_large .button_label { font-size: 17px; padding: 20px 30px; }
a.button_large .button_icon { padding: 20px 16px; }

/* Contact icons */
.contact_icons a { font-size: 30px; line-height: 30px; }

/* Footer */
#Footer { background-repeat: repeat; }
#Footer .widgets_wrapper { padding: 40px 0 0; }
#Footer .footer_copy { border-top: 0; padding-bottom: 20px; }
#Footer .footer_copy .copyright { float: right; }
#Footer .footer_copy .social-menu { float: left; }
#Footer .footer_copy a#back_to_top { display: none; }
#Footer .footer_copy .social-menu li { border-right: 0 none; display: inline-block; font-size: 16px; margin-right: 15px; padding-right: 15px; }\";s:9:\"custom-js\";s:0:\"\";}","yes");
INSERT INTO `st_options` VALUES("298","widget_akismet_widget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `st_options` VALUES("183","revslider_checktables","1","yes");
INSERT INTO `st_options` VALUES("184","revslider-static-css",".tp-caption a {
color:#ff7302;
text-shadow:none;
-webkit-transition:all 0.2s ease-out;
-moz-transition:all 0.2s ease-out;
-o-transition:all 0.2s ease-out;
-ms-transition:all 0.2s ease-out;
}

.tp-caption a:hover {
color:#ffa902;
}","yes");
INSERT INTO `st_options` VALUES("185","revslider-update-check-short","1542537231","yes");
INSERT INTO `st_options` VALUES("186","ls-plugin-version","5.4.0","yes");
INSERT INTO `st_options` VALUES("187","ls-db-version","5.0.0","yes");
INSERT INTO `st_options` VALUES("188","ls-installed","1","yes");
INSERT INTO `st_options` VALUES("189","ls-google-fonts","a:4:{i:0;a:2:{s:5:\"param\";s:28:\"Lato:100,300,regular,700,900\";s:5:\"admin\";b:0;}i:1;a:2:{s:5:\"param\";s:13:\"Open+Sans:300\";s:5:\"admin\";b:0;}i:2;a:2:{s:5:\"param\";s:20:\"Indie+Flower:regular\";s:5:\"admin\";b:0;}i:3;a:2:{s:5:\"param\";s:22:\"Oswald:300,regular,700\";s:5:\"admin\";b:0;}}","yes");
INSERT INTO `st_options` VALUES("190","ls-date-installed","1541816182","yes");
INSERT INTO `st_options` VALUES("192","tp_twitter_global_notification","1","yes");
INSERT INTO `st_options` VALUES("200","duplicate_post_copytitle","1","yes");
INSERT INTO `st_options` VALUES("201","duplicate_post_copydate","0","yes");
INSERT INTO `st_options` VALUES("195","recently_activated","a:4:{s:27:\"redirection/redirection.php\";i:1542184571;s:59:\"force-regenerate-thumbnails/force-regenerate-thumbnails.php\";i:1542183975;s:41:\"envato-wordpress-toolkit-master/index.php\";i:1542183923;s:45:\"limit-login-attempts/limit-login-attempts.php\";i:1542183907;}","yes");
INSERT INTO `st_options` VALUES("196","widget_tp_widget_recent_tweets","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `st_options` VALUES("197","widget_layerslider_widget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `st_options` VALUES("198","widget_rev-slider-widget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `st_options` VALUES("199","vc_version","4.6.1","yes");
INSERT INTO `st_options` VALUES("202","duplicate_post_copystatus","0","yes");
INSERT INTO `st_options` VALUES("203","duplicate_post_copyslug","0","yes");
INSERT INTO `st_options` VALUES("204","duplicate_post_copyexcerpt","1","yes");
INSERT INTO `st_options` VALUES("205","duplicate_post_copycontent","1","yes");
INSERT INTO `st_options` VALUES("206","duplicate_post_copythumbnail","1","yes");
INSERT INTO `st_options` VALUES("207","duplicate_post_copytemplate","1","yes");
INSERT INTO `st_options` VALUES("208","duplicate_post_copyformat","1","yes");
INSERT INTO `st_options` VALUES("209","duplicate_post_copyauthor","0","yes");
INSERT INTO `st_options` VALUES("210","duplicate_post_copypassword","0","yes");
INSERT INTO `st_options` VALUES("211","duplicate_post_copyattachments","0","yes");
INSERT INTO `st_options` VALUES("212","duplicate_post_copychildren","0","yes");
INSERT INTO `st_options` VALUES("213","duplicate_post_copycomments","0","yes");
INSERT INTO `st_options` VALUES("214","duplicate_post_copymenuorder","1","yes");
INSERT INTO `st_options` VALUES("215","duplicate_post_taxonomies_blacklist","a:0:{}","yes");
INSERT INTO `st_options` VALUES("216","duplicate_post_blacklist","","yes");
INSERT INTO `st_options` VALUES("217","duplicate_post_types_enabled","a:2:{i:0;s:4:\"post\";i:1;s:4:\"page\";}","yes");
INSERT INTO `st_options` VALUES("218","duplicate_post_show_row","1","yes");
INSERT INTO `st_options` VALUES("219","duplicate_post_show_adminbar","1","yes");
INSERT INTO `st_options` VALUES("220","duplicate_post_show_submitbox","1","yes");
INSERT INTO `st_options` VALUES("221","duplicate_post_show_bulkactions","1","yes");
INSERT INTO `st_options` VALUES("222","duplicate_post_version","3.2.2","yes");
INSERT INTO `st_options` VALUES("223","duplicate_post_show_notice","0","no");
INSERT INTO `st_options` VALUES("239","portfolio-types_children","a:0:{}","yes");
INSERT INTO `st_options` VALUES("238","offer-types_children","a:0:{}","yes");
INSERT INTO `st_options` VALUES("240","slide-types_children","a:0:{}","yes");
INSERT INTO `st_options` VALUES("241","testimonial-types_children","a:0:{}","yes");
INSERT INTO `st_options` VALUES("246","widget_widget_mfn_recent_comments","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `st_options` VALUES("249","widget_widget_mfn_flickr","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `st_options` VALUES("250","widget_widget_mfn_login","a:3:{i:1;a:0:{}i:2;a:3:{s:5:\"title\";s:0:\"\";s:13:\"show_register\";i:1;s:23:\"show_forgotten_password\";i:1;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `st_options` VALUES("251","widget_widget_mfn_menu","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `st_options` VALUES("274","revslider-latest-version","5.3.0.2","yes");
INSERT INTO `st_options` VALUES("275","revslider-notices","a:4:{i:0;O:8:\"stdClass\":7:{s:7:\"version\";s:5:\"4.9.9\";s:4:\"text\";s:202:\"<a href=\"http://revolution.themepunch.com\" target=\"_blank\"><img src=\"http://updates.themepunch.tools/banners/updatenow_banner.jpg\" style=\"min-width: 50%; max-width:100%\" alt=\"revslider 5.0 is out\" ></a>\";s:4:\"code\";s:10:\"TPRS500-75\";s:5:\"color\";s:5:\"green\";s:7:\"disable\";b:0;s:9:\"is_global\";b:0;s:10:\"additional\";a:0:{}}i:1;O:8:\"stdClass\":7:{s:7:\"version\";s:7:\"5.0.4.1\";s:4:\"text\";s:230:\"<a href=\"http://revolution.themepunch.com/direct-customer-benefits/\" target=\"_blank\"><img src=\"http://updates.themepunch.tools/banners/updateto506_banner.jpg\" style=\"min-width: 50%; max-width:100%\" alt=\"revslider 5.0 is out\" ></a>\";s:4:\"code\";s:10:\"TPRS506-01\";s:5:\"color\";s:5:\"green\";s:7:\"disable\";b:0;s:9:\"is_global\";b:0;s:10:\"additional\";a:0:{}}i:2;O:8:\"stdClass\":7:{s:7:\"version\";s:5:\"5.1.4\";s:4:\"text\";s:260:\"<a href=\"http://revolution.themepunch.com/direct-customer-benefits/?ref=515b#productactivation\" target=\"_blank\"><img src=\"http://updates.themepunch.tools/banners/updatenow_banner515.jpg\" style=\"min-width: 50%; max-width:100%\" alt=\"revslider 5.1.5 is out\" ></a>\";s:4:\"code\";s:10:\"TPRS515-01\";s:5:\"color\";s:5:\"green\";s:7:\"disable\";b:0;s:9:\"is_global\";b:0;s:10:\"additional\";a:0:{}}i:3;O:8:\"stdClass\":7:{s:7:\"version\";s:5:\"5.1.6\";s:4:\"text\";s:235:\"<a href=\"//revolution.themepunch.com/direct-customer-benefits/?ref=52b\" target=\"_blank\"><img src=\"http://updates.themepunch.tools/banners/updatenow_banner52.jpg\" style=\"min-width: 50%; max-width:100%\" alt=\"revslider 5.1.5 is out\" ></a>\";s:4:\"code\";s:10:\"TPRS515-01\";s:5:\"color\";s:5:\"green\";s:7:\"disable\";b:0;s:9:\"is_global\";b:0;s:10:\"additional\";a:0:{}}}","yes");
INSERT INTO `st_options` VALUES("289","revslider-valid-notice","false","yes");
INSERT INTO `st_options` VALUES("290","revslider-notices-dc","a:3:{i:0;s:10:\"TPRS515-01\";i:1;s:10:\"TPRS506-01\";i:2;s:10:\"TPRS500-75\";}","yes");
INSERT INTO `st_options` VALUES("489","_transient_wpseo_meta_table_inaccessible","0","no");
INSERT INTO `st_options` VALUES("486","_transient_timeout_wpseo_link_table_inaccessible","1573638649","no");
INSERT INTO `st_options` VALUES("487","_transient_wpseo_link_table_inaccessible","0","no");
INSERT INTO `st_options` VALUES("488","_transient_timeout_wpseo_meta_table_inaccessible","1573638649","no");
INSERT INTO `st_options` VALUES("303","wpcf7","a:2:{s:7:\"version\";s:5:\"5.0.5\";s:13:\"bulk_validate\";a:4:{s:9:\"timestamp\";d:1542114696;s:7:\"version\";s:5:\"5.0.5\";s:11:\"count_valid\";i:1;s:13:\"count_invalid\";i:0;}}","yes");
INSERT INTO `st_options` VALUES("320","ngg_run_freemius","1","yes");
INSERT INTO `st_options` VALUES("321","fs_active_plugins","O:8:\"stdClass\":2:{s:7:\"plugins\";a:1:{s:24:\"nextgen-gallery/freemius\";O:8:\"stdClass\":3:{s:7:\"version\";s:7:\"1.2.1.5\";s:9:\"timestamp\";i:1542102642;s:11:\"plugin_path\";s:29:\"nextgen-gallery/nggallery.php\";}}s:6:\"newest\";O:8:\"stdClass\":5:{s:11:\"plugin_path\";s:29:\"nextgen-gallery/nggallery.php\";s:8:\"sdk_path\";s:24:\"nextgen-gallery/freemius\";s:7:\"version\";s:7:\"1.2.1.5\";s:13:\"in_activation\";b:0;s:9:\"timestamp\";i:1542102642;}}","yes");
INSERT INTO `st_options` VALUES("322","fs_debug_mode","","yes");
INSERT INTO `st_options` VALUES("323","fs_accounts","a:4:{s:11:\"plugin_data\";a:1:{s:15:\"nextgen-gallery\";a:15:{s:16:\"plugin_main_file\";O:8:\"stdClass\":1:{s:4:\"path\";s:75:\"/home/foolstac/public_html/wp-content/plugins/nextgen-gallery/nggallery.php\";}s:17:\"install_timestamp\";i:1542102642;s:16:\"sdk_last_version\";N;s:11:\"sdk_version\";s:7:\"1.2.1.5\";s:16:\"sdk_upgrade_mode\";b:1;s:18:\"sdk_downgrade_mode\";b:0;s:19:\"plugin_last_version\";N;s:14:\"plugin_version\";s:6:\"3.0.16\";s:19:\"plugin_upgrade_mode\";b:1;s:21:\"plugin_downgrade_mode\";b:0;s:21:\"is_plugin_new_install\";b:1;s:17:\"connectivity_test\";a:6:{s:12:\"is_connected\";b:1;s:4:\"host\";s:13:\"foolstacks.ir\";s:9:\"server_ip\";s:13:\"5.112.106.225\";s:9:\"is_active\";b:1;s:9:\"timestamp\";i:1542102642;s:7:\"version\";s:6:\"3.0.16\";}s:17:\"was_plugin_loaded\";b:1;s:15:\"prev_is_premium\";b:0;s:12:\"is_anonymous\";a:3:{s:2:\"is\";b:1;s:9:\"timestamp\";i:1542102678;s:7:\"version\";s:6:\"3.0.16\";}}}s:13:\"file_slug_map\";a:1:{s:29:\"nextgen-gallery/nggallery.php\";s:15:\"nextgen-gallery\";}s:7:\"plugins\";a:1:{s:15:\"nextgen-gallery\";O:9:\"FS_Plugin\":16:{s:16:\"parent_plugin_id\";N;s:5:\"title\";s:15:\"NextGEN Gallery\";s:4:\"slug\";s:15:\"nextgen-gallery\";s:4:\"type\";N;s:4:\"file\";s:29:\"nextgen-gallery/nggallery.php\";s:7:\"version\";s:6:\"3.0.16\";s:11:\"auto_update\";N;s:4:\"info\";N;s:10:\"is_premium\";b:0;s:7:\"is_live\";b:1;s:10:\"public_key\";s:32:\"pk_009356711cd548837f074e1ef60a4\";s:10:\"secret_key\";N;s:2:\"id\";s:3:\"266\";s:7:\"updated\";N;s:7:\"created\";N;s:22:\"\0FS_Entity\0_is_updated\";b:0;}}s:9:\"unique_id\";s:32:\"3de7fc3f605378a0986fe88e1bf20152\";}","yes");
INSERT INTO `st_options` VALUES("324","fs_api_cache","a:0:{}","yes");
INSERT INTO `st_options` VALUES("510","woocommerce_meta_box_errors","a:0:{}","yes");
INSERT INTO `st_options` VALUES("721","_transient_timeout_wc_low_stock_count","1544695813","no");
INSERT INTO `st_options` VALUES("722","_transient_wc_low_stock_count","0","no");
INSERT INTO `st_options` VALUES("723","_transient_timeout_wc_outofstock_count","1544695813","no");
INSERT INTO `st_options` VALUES("724","_transient_wc_outofstock_count","0","no");
INSERT INTO `st_options` VALUES("490","pope_module_list","a:36:{i:0;s:19:\"photocrati-fs|3.0.0\";i:1;s:21:\"photocrati-i18n|3.0.0\";i:2;s:27:\"photocrati-validation|3.0.0\";i:3;s:23:\"photocrati-router|3.0.0\";i:4;s:34:\"photocrati-wordpress_routing|3.0.0\";i:5;s:25:\"photocrati-security|3.0.0\";i:6;s:35:\"photocrati-nextgen_settings|3.0.0.2\";i:7;s:22:\"photocrati-mvc|3.0.0.1\";i:8;s:21:\"photocrati-ajax|3.0.0\";i:9;s:27:\"photocrati-datamapper|3.0.0\";i:10;s:33:\"photocrati-nextgen-legacy|3.0.0.1\";i:11;s:32:\"photocrati-simple_html_dom|3.0.0\";i:12;s:29:\"photocrati-nextgen-data|3.0.0\";i:13;s:35:\"photocrati-dynamic_thumbnails|3.0.0\";i:14;s:32:\"photocrati-nextgen_admin|3.0.0.1\";i:15;s:42:\"photocrati-nextgen_gallery_display|3.0.0.4\";i:16;s:36:\"photocrati-frame_communication|3.0.0\";i:17;s:33:\"photocrati-attach_to_post|3.0.0.5\";i:18;s:40:\"photocrati-nextgen_addgallery_page|3.0.0\";i:19;s:38:\"photocrati-nextgen_other_options|3.0.0\";i:20;s:37:\"photocrati-nextgen_pagination|3.0.0.2\";i:21;s:35:\"photocrati-dynamic_stylesheet|3.0.0\";i:22;s:36:\"photocrati-nextgen_pro_upgrade|3.0.0\";i:23;s:22:\"photocrati-cache|3.0.0\";i:24;s:25:\"photocrati-lightbox|3.0.0\";i:25;s:42:\"photocrati-nextgen_basic_templates|3.0.0.2\";i:26;s:39:\"photocrati-nextgen_basic_gallery|3.0.13\";i:27;s:45:\"photocrati-nextgen_basic_imagebrowser|3.0.0.4\";i:28;s:40:\"photocrati-nextgen_basic_singlepic|3.0.0\";i:29;s:41:\"photocrati-nextgen_basic_tagcloud|3.0.0.1\";i:30;s:38:\"photocrati-nextgen_basic_album|3.0.0.5\";i:31;s:23:\"photocrati-widget|3.0.0\";i:32;s:37:\"photocrati-third_party_compat|3.0.0.1\";i:33;s:31:\"photocrati-nextgen_xmlrpc|3.0.0\";i:34;s:22:\"photocrati-wpcli|3.0.0\";i:35;s:24:\"photocrati-imagify|3.0.0\";}","yes");
INSERT INTO `st_options` VALUES("495","_transient_woocommerce_webhook_ids","a:0:{}","yes");
INSERT INTO `st_options` VALUES("496","_transient_wc_attribute_taxonomies","a:0:{}","yes");
INSERT INTO `st_options` VALUES("500","do_activate","0","yes");
INSERT INTO `st_options` VALUES("513","wpseo_onpage","a:2:{s:6:\"status\";i:1;s:10:\"last_fetch\";i:1542707624;}","yes");
INSERT INTO `st_options` VALUES("514","_transient_timeout_external_ip_address_185.50.37.139","1542707454","no");
INSERT INTO `st_options` VALUES("515","_transient_external_ip_address_185.50.37.139","185.50.37.139","no");
INSERT INTO `st_options` VALUES("778","new_admin_email","fullstackdiaries@gmail.com","yes");
INSERT INTO `st_options` VALUES("525","_transient_timeout_external_ip_address_5.112.106.225","1542707508","no");
INSERT INTO `st_options` VALUES("526","_transient_external_ip_address_5.112.106.225","185.50.37.139","no");
INSERT INTO `st_options` VALUES("527","updraftplus_tour_cancelled_on","intro","yes");
INSERT INTO `st_options` VALUES("1974","gadwp_cache_errors_count","a:2:{s:5:\"value\";i:1;s:7:\"expires\";i:1542268800;}","no");
INSERT INTO `st_options` VALUES("334","jetpack_available_modules","a:1:{s:3:\"6.7\";a:44:{s:18:\"after-the-deadline\";s:3:\"1.1\";s:8:\"carousel\";s:3:\"1.5\";s:13:\"comment-likes\";s:3:\"5.1\";s:8:\"comments\";s:3:\"1.4\";s:12:\"contact-form\";s:3:\"1.3\";s:20:\"custom-content-types\";s:3:\"3.1\";s:10:\"custom-css\";s:3:\"1.7\";s:21:\"enhanced-distribution\";s:3:\"1.2\";s:16:\"google-analytics\";s:3:\"4.5\";s:19:\"gravatar-hovercards\";s:3:\"1.1\";s:15:\"infinite-scroll\";s:3:\"2.0\";s:8:\"json-api\";s:3:\"1.9\";s:5:\"latex\";s:3:\"1.1\";s:11:\"lazy-images\";s:5:\"5.6.0\";s:5:\"likes\";s:3:\"2.2\";s:6:\"manage\";s:3:\"3.4\";s:8:\"markdown\";s:3:\"2.8\";s:9:\"masterbar\";s:3:\"4.8\";s:9:\"minileven\";s:3:\"1.8\";s:7:\"monitor\";s:3:\"2.6\";s:5:\"notes\";s:3:\"1.9\";s:10:\"photon-cdn\";s:3:\"6.6\";s:6:\"photon\";s:3:\"2.0\";s:13:\"post-by-email\";s:3:\"2.0\";s:7:\"protect\";s:3:\"3.4\";s:9:\"publicize\";s:3:\"2.0\";s:3:\"pwa\";s:5:\"5.6.0\";s:13:\"related-posts\";s:3:\"2.9\";s:6:\"search\";s:3:\"5.0\";s:9:\"seo-tools\";s:3:\"4.4\";s:10:\"sharedaddy\";s:3:\"1.1\";s:10:\"shortcodes\";s:3:\"1.1\";s:10:\"shortlinks\";s:3:\"1.1\";s:8:\"sitemaps\";s:3:\"3.9\";s:3:\"sso\";s:3:\"2.6\";s:5:\"stats\";s:3:\"1.1\";s:13:\"subscriptions\";s:3:\"1.2\";s:13:\"tiled-gallery\";s:3:\"2.1\";s:10:\"vaultpress\";s:5:\"0:1.2\";s:18:\"verification-tools\";s:3:\"3.0\";s:10:\"videopress\";s:3:\"2.5\";s:17:\"widget-visibility\";s:3:\"2.4\";s:7:\"widgets\";s:3:\"1.2\";s:7:\"wordads\";s:5:\"4.5.0\";}}","yes");
INSERT INTO `st_options` VALUES("335","jetpack_options","a:2:{s:7:\"version\";s:14:\"6.7:1542102644\";s:11:\"old_version\";s:14:\"6.7:1542102644\";}","yes");
INSERT INTO `st_options` VALUES("336","wpseo","a:19:{s:15:\"ms_defaults_set\";b:0;s:7:\"version\";s:3:\"9.1\";s:20:\"disableadvanced_meta\";b:1;s:19:\"onpage_indexability\";b:1;s:11:\"baiduverify\";s:0:\"\";s:12:\"googleverify\";s:22:\"googlead64d254471a2650\";s:8:\"msverify\";s:0:\"\";s:12:\"yandexverify\";s:0:\"\";s:9:\"site_type\";s:4:\"blog\";s:20:\"has_multiple_authors\";b:0;s:16:\"environment_type\";s:10:\"production\";s:23:\"content_analysis_active\";b:1;s:23:\"keyword_analysis_active\";b:1;s:21:\"enable_admin_bar_menu\";b:1;s:26:\"enable_cornerstone_content\";b:1;s:18:\"enable_xml_sitemap\";b:1;s:24:\"enable_text_link_counter\";b:1;s:22:\"show_onboarding_notice\";b:0;s:18:\"first_activated_on\";b:0;}","yes");
INSERT INTO `st_options` VALUES("337","wpseo_titles","a:164:{s:10:\"title_test\";i:0;s:17:\"forcerewritetitle\";b:0;s:9:\"separator\";s:7:\"sc-dash\";s:16:\"title-home-wpseo\";s:42:\"%%sitename%% %%page%% %%sep%% %%sitedesc%%\";s:18:\"title-author-wpseo\";s:51:\"%%name%%, نویسنده در %%sitename%% %%page%%\";s:19:\"title-archive-wpseo\";s:38:\"%%date%% %%page%% %%sep%% %%sitename%%\";s:18:\"title-search-wpseo\";s:84:\"شما برای %%searchphrase%% جستجو کردید %%page%% %%sep%% %%sitename%%\";s:15:\"title-404-wpseo\";s:45:\"صفحه پیدا نشد %%sep%% %%sitename%%\";s:19:\"metadesc-home-wpseo\";s:0:\"\";s:21:\"metadesc-author-wpseo\";s:0:\"\";s:22:\"metadesc-archive-wpseo\";s:0:\"\";s:9:\"rssbefore\";s:0:\"\";s:8:\"rssafter\";s:79:\"نوشته %%POSTLINK%% اولین بار در %%BLOGLINK%%. پدیدار شد.\";s:20:\"noindex-author-wpseo\";b:0;s:28:\"noindex-author-noposts-wpseo\";b:1;s:21:\"noindex-archive-wpseo\";b:1;s:14:\"disable-author\";b:1;s:12:\"disable-date\";b:0;s:19:\"disable-post_format\";b:0;s:18:\"disable-attachment\";b:1;s:23:\"is-media-purge-relevant\";b:0;s:20:\"breadcrumbs-404crumb\";s:38:\"خطای 404: صفحه پیدا نشد\";s:29:\"breadcrumbs-display-blog-page\";b:1;s:20:\"breadcrumbs-boldlast\";b:0;s:25:\"breadcrumbs-archiveprefix\";s:30:\"بایگانی‌ها برای\";s:18:\"breadcrumbs-enable\";b:0;s:16:\"breadcrumbs-home\";s:8:\"خانه\";s:18:\"breadcrumbs-prefix\";s:0:\"\";s:24:\"breadcrumbs-searchprefix\";s:39:\"شما جستجو نمودید برای\";s:15:\"breadcrumbs-sep\";s:7:\"&raquo;\";s:12:\"website_name\";s:17:\"روزمره ها\";s:11:\"person_name\";s:10:\"سپیده\";s:22:\"alternate_website_name\";s:0:\"\";s:12:\"company_logo\";s:0:\"\";s:12:\"company_name\";s:0:\"\";s:17:\"company_or_person\";s:6:\"person\";s:17:\"stripcategorybase\";b:0;s:10:\"title-post\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:13:\"metadesc-post\";s:0:\"\";s:12:\"noindex-post\";b:0;s:13:\"showdate-post\";b:0;s:23:\"display-metabox-pt-post\";b:1;s:23:\"post_types-post-maintax\";i:0;s:10:\"title-page\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:13:\"metadesc-page\";s:0:\"\";s:12:\"noindex-page\";b:0;s:13:\"showdate-page\";b:0;s:23:\"display-metabox-pt-page\";b:1;s:23:\"post_types-page-maintax\";i:0;s:16:\"title-attachment\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:19:\"metadesc-attachment\";s:0:\"\";s:18:\"noindex-attachment\";b:0;s:19:\"showdate-attachment\";b:0;s:29:\"display-metabox-pt-attachment\";b:1;s:29:\"post_types-attachment-maintax\";i:0;s:18:\"title-tax-category\";s:68:\"بایگانی‌های %%term_title%% %%page%% %%sep%% %%sitename%%\";s:21:\"metadesc-tax-category\";s:0:\"\";s:28:\"display-metabox-tax-category\";b:1;s:20:\"noindex-tax-category\";b:0;s:18:\"title-tax-post_tag\";s:68:\"بایگانی‌های %%term_title%% %%page%% %%sep%% %%sitename%%\";s:21:\"metadesc-tax-post_tag\";s:0:\"\";s:28:\"display-metabox-tax-post_tag\";b:1;s:20:\"noindex-tax-post_tag\";b:0;s:21:\"title-tax-post_format\";s:68:\"بایگانی‌های %%term_title%% %%page%% %%sep%% %%sitename%%\";s:24:\"metadesc-tax-post_format\";s:0:\"\";s:31:\"display-metabox-tax-post_format\";b:1;s:23:\"noindex-tax-post_format\";b:1;s:13:\"title-product\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:16:\"metadesc-product\";s:0:\"\";s:15:\"noindex-product\";b:0;s:16:\"showdate-product\";b:0;s:26:\"display-metabox-pt-product\";b:1;s:26:\"post_types-product-maintax\";i:0;s:23:\"title-ptarchive-product\";s:58:\"بایگانی %%pt_plural%% %%page%% %%sep%% %%sitename%%\";s:26:\"metadesc-ptarchive-product\";s:0:\"\";s:25:\"bctitle-ptarchive-product\";s:0:\"\";s:25:\"noindex-ptarchive-product\";b:0;s:21:\"title-tax-product_cat\";s:68:\"بایگانی‌های %%term_title%% %%page%% %%sep%% %%sitename%%\";s:24:\"metadesc-tax-product_cat\";s:0:\"\";s:31:\"display-metabox-tax-product_cat\";b:1;s:23:\"noindex-tax-product_cat\";b:0;s:29:\"taxonomy-product_cat-ptparent\";i:0;s:21:\"title-tax-product_tag\";s:68:\"بایگانی‌های %%term_title%% %%page%% %%sep%% %%sitename%%\";s:24:\"metadesc-tax-product_tag\";s:0:\"\";s:31:\"display-metabox-tax-product_tag\";b:1;s:23:\"noindex-tax-product_tag\";b:0;s:29:\"taxonomy-product_tag-ptparent\";i:0;s:32:\"title-tax-product_shipping_class\";s:68:\"بایگانی‌های %%term_title%% %%page%% %%sep%% %%sitename%%\";s:35:\"metadesc-tax-product_shipping_class\";s:0:\"\";s:42:\"display-metabox-tax-product_shipping_class\";b:1;s:34:\"noindex-tax-product_shipping_class\";b:0;s:40:\"taxonomy-product_shipping_class-ptparent\";i:0;s:17:\"title-tax-ngg_tag\";s:68:\"بایگانی‌های %%term_title%% %%page%% %%sep%% %%sitename%%\";s:20:\"metadesc-tax-ngg_tag\";s:0:\"\";s:27:\"display-metabox-tax-ngg_tag\";b:1;s:19:\"noindex-tax-ngg_tag\";b:0;s:25:\"taxonomy-ngg_tag-ptparent\";i:0;s:12:\"title-client\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:15:\"metadesc-client\";s:0:\"\";s:14:\"noindex-client\";b:0;s:15:\"showdate-client\";b:0;s:25:\"display-metabox-pt-client\";b:1;s:25:\"post_types-client-maintax\";i:0;s:11:\"title-offer\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:14:\"metadesc-offer\";s:0:\"\";s:13:\"noindex-offer\";b:0;s:14:\"showdate-offer\";b:0;s:24:\"display-metabox-pt-offer\";b:1;s:24:\"post_types-offer-maintax\";i:0;s:15:\"title-portfolio\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:18:\"metadesc-portfolio\";s:0:\"\";s:17:\"noindex-portfolio\";b:0;s:18:\"showdate-portfolio\";b:0;s:28:\"display-metabox-pt-portfolio\";b:1;s:28:\"post_types-portfolio-maintax\";i:0;s:11:\"title-slide\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:14:\"metadesc-slide\";s:0:\"\";s:13:\"noindex-slide\";b:0;s:14:\"showdate-slide\";b:0;s:24:\"display-metabox-pt-slide\";b:1;s:24:\"post_types-slide-maintax\";i:0;s:17:\"title-testimonial\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:20:\"metadesc-testimonial\";s:0:\"\";s:19:\"noindex-testimonial\";b:0;s:20:\"showdate-testimonial\";b:0;s:30:\"display-metabox-pt-testimonial\";b:1;s:30:\"post_types-testimonial-maintax\";i:0;s:12:\"title-layout\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:15:\"metadesc-layout\";s:0:\"\";s:14:\"noindex-layout\";b:0;s:15:\"showdate-layout\";b:0;s:25:\"display-metabox-pt-layout\";b:1;s:25:\"post_types-layout-maintax\";i:0;s:14:\"title-template\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:17:\"metadesc-template\";s:0:\"\";s:16:\"noindex-template\";b:0;s:17:\"showdate-template\";b:0;s:27:\"display-metabox-pt-template\";b:1;s:27:\"post_types-template-maintax\";i:0;s:22:\"title-tax-client-types\";s:68:\"بایگانی‌های %%term_title%% %%page%% %%sep%% %%sitename%%\";s:25:\"metadesc-tax-client-types\";s:0:\"\";s:32:\"display-metabox-tax-client-types\";b:1;s:24:\"noindex-tax-client-types\";b:0;s:30:\"taxonomy-client-types-ptparent\";i:0;s:21:\"title-tax-offer-types\";s:68:\"بایگانی‌های %%term_title%% %%page%% %%sep%% %%sitename%%\";s:24:\"metadesc-tax-offer-types\";s:0:\"\";s:31:\"display-metabox-tax-offer-types\";b:1;s:23:\"noindex-tax-offer-types\";b:0;s:29:\"taxonomy-offer-types-ptparent\";i:0;s:25:\"title-tax-portfolio-types\";s:68:\"بایگانی‌های %%term_title%% %%page%% %%sep%% %%sitename%%\";s:28:\"metadesc-tax-portfolio-types\";s:0:\"\";s:35:\"display-metabox-tax-portfolio-types\";b:1;s:27:\"noindex-tax-portfolio-types\";b:0;s:33:\"taxonomy-portfolio-types-ptparent\";i:0;s:21:\"title-tax-slide-types\";s:68:\"بایگانی‌های %%term_title%% %%page%% %%sep%% %%sitename%%\";s:24:\"metadesc-tax-slide-types\";s:0:\"\";s:31:\"display-metabox-tax-slide-types\";b:1;s:23:\"noindex-tax-slide-types\";b:0;s:29:\"taxonomy-slide-types-ptparent\";i:0;s:27:\"title-tax-testimonial-types\";s:68:\"بایگانی‌های %%term_title%% %%page%% %%sep%% %%sitename%%\";s:30:\"metadesc-tax-testimonial-types\";s:0:\"\";s:37:\"display-metabox-tax-testimonial-types\";b:1;s:29:\"noindex-tax-testimonial-types\";b:0;s:35:\"taxonomy-testimonial-types-ptparent\";i:0;}","yes");
INSERT INTO `st_options` VALUES("338","wpseo_social","a:20:{s:13:\"facebook_site\";s:0:\"\";s:13:\"instagram_url\";s:0:\"\";s:12:\"linkedin_url\";s:55:\"https://www.linkedin.com/in/sepideh-saljooghi-94a69a68/\";s:11:\"myspace_url\";s:0:\"\";s:16:\"og_default_image\";s:0:\"\";s:19:\"og_default_image_id\";s:0:\"\";s:18:\"og_frontpage_title\";s:0:\"\";s:17:\"og_frontpage_desc\";s:0:\"\";s:18:\"og_frontpage_image\";s:0:\"\";s:21:\"og_frontpage_image_id\";s:0:\"\";s:9:\"opengraph\";b:1;s:13:\"pinterest_url\";s:0:\"\";s:15:\"pinterestverify\";s:0:\"\";s:14:\"plus-publisher\";s:0:\"\";s:7:\"twitter\";b:1;s:12:\"twitter_site\";s:0:\"\";s:17:\"twitter_card_type\";s:19:\"summary_large_image\";s:11:\"youtube_url\";s:0:\"\";s:15:\"google_plus_url\";s:0:\"\";s:10:\"fbadminapp\";s:0:\"\";}","yes");
INSERT INTO `st_options` VALUES("339","wpseo_flush_rewrite","1","yes");
INSERT INTO `st_options` VALUES("455","woocommerce_admin_notices","a:3:{i:0;s:7:\"install\";i:1;s:20:\"no_secure_connection\";i:2;s:14:\"template_files\";}","yes");
INSERT INTO `st_options` VALUES("342","woocommerce_store_address","","yes");
INSERT INTO `st_options` VALUES("343","woocommerce_store_address_2","","yes");
INSERT INTO `st_options` VALUES("344","woocommerce_store_city","","yes");
INSERT INTO `st_options` VALUES("345","woocommerce_default_country","GB","yes");
INSERT INTO `st_options` VALUES("346","woocommerce_store_postcode","","yes");
INSERT INTO `st_options` VALUES("347","woocommerce_allowed_countries","all","yes");
INSERT INTO `st_options` VALUES("348","woocommerce_all_except_countries","","yes");
INSERT INTO `st_options` VALUES("349","woocommerce_specific_allowed_countries","","yes");
INSERT INTO `st_options` VALUES("350","woocommerce_ship_to_countries","","yes");
INSERT INTO `st_options` VALUES("351","woocommerce_specific_ship_to_countries","","yes");
INSERT INTO `st_options` VALUES("352","woocommerce_default_customer_address","geolocation","yes");
INSERT INTO `st_options` VALUES("353","woocommerce_calc_taxes","no","yes");
INSERT INTO `st_options` VALUES("354","woocommerce_enable_coupons","yes","yes");
INSERT INTO `st_options` VALUES("355","woocommerce_calc_discounts_sequentially","no","no");
INSERT INTO `st_options` VALUES("356","woocommerce_currency","GBP","yes");
INSERT INTO `st_options` VALUES("357","woocommerce_currency_pos","left","yes");
INSERT INTO `st_options` VALUES("358","woocommerce_price_thousand_sep",",","yes");
INSERT INTO `st_options` VALUES("359","woocommerce_price_decimal_sep",".","yes");
INSERT INTO `st_options` VALUES("360","woocommerce_price_num_decimals","2","yes");
INSERT INTO `st_options` VALUES("361","woocommerce_shop_page_id","","yes");
INSERT INTO `st_options` VALUES("362","woocommerce_cart_redirect_after_add","no","yes");
INSERT INTO `st_options` VALUES("363","woocommerce_enable_ajax_add_to_cart","yes","yes");
INSERT INTO `st_options` VALUES("364","woocommerce_placeholder_image","","yes");
INSERT INTO `st_options` VALUES("365","woocommerce_weight_unit","kg","yes");
INSERT INTO `st_options` VALUES("366","woocommerce_dimension_unit","cm","yes");
INSERT INTO `st_options` VALUES("367","woocommerce_enable_reviews","yes","yes");
INSERT INTO `st_options` VALUES("368","woocommerce_review_rating_verification_label","yes","no");
INSERT INTO `st_options` VALUES("369","woocommerce_review_rating_verification_required","no","no");
INSERT INTO `st_options` VALUES("370","woocommerce_enable_review_rating","yes","yes");
INSERT INTO `st_options` VALUES("371","woocommerce_review_rating_required","yes","no");
INSERT INTO `st_options` VALUES("372","woocommerce_manage_stock","yes","yes");
INSERT INTO `st_options` VALUES("373","woocommerce_hold_stock_minutes","60","no");
INSERT INTO `st_options` VALUES("374","woocommerce_notify_low_stock","yes","no");
INSERT INTO `st_options` VALUES("375","woocommerce_notify_no_stock","yes","no");
INSERT INTO `st_options` VALUES("376","woocommerce_stock_email_recipient","fullstackdiaries@gmail.com","no");
INSERT INTO `st_options` VALUES("377","woocommerce_notify_low_stock_amount","2","no");
INSERT INTO `st_options` VALUES("378","woocommerce_notify_no_stock_amount","0","yes");
INSERT INTO `st_options` VALUES("379","woocommerce_hide_out_of_stock_items","no","yes");
INSERT INTO `st_options` VALUES("380","woocommerce_stock_format","","yes");
INSERT INTO `st_options` VALUES("381","woocommerce_file_download_method","force","no");
INSERT INTO `st_options` VALUES("382","woocommerce_downloads_require_login","no","no");
INSERT INTO `st_options` VALUES("383","woocommerce_downloads_grant_access_after_payment","yes","no");
INSERT INTO `st_options` VALUES("384","woocommerce_prices_include_tax","no","yes");
INSERT INTO `st_options` VALUES("385","woocommerce_tax_based_on","shipping","yes");
INSERT INTO `st_options` VALUES("386","woocommerce_shipping_tax_class","inherit","yes");
INSERT INTO `st_options` VALUES("387","woocommerce_tax_round_at_subtotal","no","yes");
INSERT INTO `st_options` VALUES("388","woocommerce_tax_classes","کاهش رتبه 
 رتبه صفر","yes");
INSERT INTO `st_options` VALUES("389","woocommerce_tax_display_shop","excl","yes");
INSERT INTO `st_options` VALUES("390","woocommerce_tax_display_cart","excl","yes");
INSERT INTO `st_options` VALUES("391","woocommerce_price_display_suffix","","yes");
INSERT INTO `st_options` VALUES("392","woocommerce_tax_total_display","itemized","no");
INSERT INTO `st_options` VALUES("393","woocommerce_enable_shipping_calc","yes","no");
INSERT INTO `st_options` VALUES("394","woocommerce_shipping_cost_requires_address","no","yes");
INSERT INTO `st_options` VALUES("395","woocommerce_ship_to_destination","billing","no");
INSERT INTO `st_options` VALUES("396","woocommerce_shipping_debug_mode","no","yes");
INSERT INTO `st_options` VALUES("397","woocommerce_enable_guest_checkout","yes","no");
INSERT INTO `st_options` VALUES("398","woocommerce_enable_checkout_login_reminder","no","no");
INSERT INTO `st_options` VALUES("399","woocommerce_enable_signup_and_login_from_checkout","no","no");
INSERT INTO `st_options` VALUES("400","woocommerce_enable_myaccount_registration","no","no");
INSERT INTO `st_options` VALUES("401","woocommerce_registration_generate_username","yes","no");
INSERT INTO `st_options` VALUES("402","woocommerce_registration_generate_password","yes","no");
INSERT INTO `st_options` VALUES("403","woocommerce_erasure_request_removes_order_data","no","no");
INSERT INTO `st_options` VALUES("404","woocommerce_erasure_request_removes_download_data","no","no");
INSERT INTO `st_options` VALUES("405","woocommerce_registration_privacy_policy_text","اطلاعات شخصی شما برای پردازش سفارش شما استفاده می‌شود، و پشتیبانی از تجربه شما در این وبسایت، و برای اهداف دیگری که در [privacy_policy] توضیح داده شده است.","yes");
INSERT INTO `st_options` VALUES("406","woocommerce_checkout_privacy_policy_text","Your personal data will be used to process your order, support your experience throughout this website, and for other purposes described in our [privacy_policy].","yes");
INSERT INTO `st_options` VALUES("407","woocommerce_delete_inactive_accounts","a:2:{s:6:\"number\";s:0:\"\";s:4:\"unit\";s:6:\"months\";}","no");
INSERT INTO `st_options` VALUES("408","woocommerce_trash_pending_orders","","no");
INSERT INTO `st_options` VALUES("409","woocommerce_trash_failed_orders","","no");
INSERT INTO `st_options` VALUES("410","woocommerce_trash_cancelled_orders","","no");
INSERT INTO `st_options` VALUES("411","woocommerce_anonymize_completed_orders","a:2:{s:6:\"number\";s:0:\"\";s:4:\"unit\";s:6:\"months\";}","no");
INSERT INTO `st_options` VALUES("412","woocommerce_email_from_name","روزمره ها","no");
INSERT INTO `st_options` VALUES("413","woocommerce_email_from_address","fullstackdiaries@gmail.com","no");
INSERT INTO `st_options` VALUES("414","woocommerce_email_header_image","","no");
INSERT INTO `st_options` VALUES("415","woocommerce_email_footer_text","{site_title}<br/>Powered by <a href=\"https://woocommerce.com/\">WooCommerce</a>","no");
INSERT INTO `st_options` VALUES("416","woocommerce_email_base_color","#96588a","no");
INSERT INTO `st_options` VALUES("417","woocommerce_email_background_color","#f7f7f7","no");
INSERT INTO `st_options` VALUES("418","woocommerce_email_body_background_color","#ffffff","no");
INSERT INTO `st_options` VALUES("419","woocommerce_email_text_color","#3c3c3c","no");
INSERT INTO `st_options` VALUES("420","woocommerce_cart_page_id","","yes");
INSERT INTO `st_options` VALUES("421","woocommerce_checkout_page_id","","yes");
INSERT INTO `st_options` VALUES("422","woocommerce_myaccount_page_id","","yes");
INSERT INTO `st_options` VALUES("423","woocommerce_terms_page_id","","no");
INSERT INTO `st_options` VALUES("424","woocommerce_force_ssl_checkout","no","yes");
INSERT INTO `st_options` VALUES("425","woocommerce_unforce_ssl_checkout","no","yes");
INSERT INTO `st_options` VALUES("426","woocommerce_checkout_pay_endpoint","order-pay","yes");
INSERT INTO `st_options` VALUES("427","woocommerce_checkout_order_received_endpoint","order-received","yes");
INSERT INTO `st_options` VALUES("428","woocommerce_myaccount_add_payment_method_endpoint","add-payment-method","yes");
INSERT INTO `st_options` VALUES("429","woocommerce_myaccount_delete_payment_method_endpoint","delete-payment-method","yes");
INSERT INTO `st_options` VALUES("430","woocommerce_myaccount_set_default_payment_method_endpoint","set-default-payment-method","yes");
INSERT INTO `st_options` VALUES("431","woocommerce_myaccount_orders_endpoint","orders","yes");
INSERT INTO `st_options` VALUES("432","woocommerce_myaccount_view_order_endpoint","view-order","yes");
INSERT INTO `st_options` VALUES("433","woocommerce_myaccount_downloads_endpoint","downloads","yes");
INSERT INTO `st_options` VALUES("434","woocommerce_myaccount_edit_account_endpoint","edit-account","yes");
INSERT INTO `st_options` VALUES("435","woocommerce_myaccount_edit_address_endpoint","edit-address","yes");
INSERT INTO `st_options` VALUES("436","woocommerce_myaccount_payment_methods_endpoint","payment-methods","yes");
INSERT INTO `st_options` VALUES("437","woocommerce_myaccount_lost_password_endpoint","lost-password","yes");
INSERT INTO `st_options` VALUES("438","woocommerce_logout_endpoint","customer-logout","yes");
INSERT INTO `st_options` VALUES("439","woocommerce_api_enabled","no","yes");
INSERT INTO `st_options` VALUES("440","woocommerce_single_image_width","600","yes");
INSERT INTO `st_options` VALUES("441","woocommerce_thumbnail_image_width","300","yes");
INSERT INTO `st_options` VALUES("442","woocommerce_checkout_highlight_required_fields","yes","yes");
INSERT INTO `st_options` VALUES("443","woocommerce_demo_store","no","no");
INSERT INTO `st_options` VALUES("444","woocommerce_permalinks","a:5:{s:12:\"product_base\";s:7:\"product\";s:13:\"category_base\";s:16:\"product-category\";s:8:\"tag_base\";s:11:\"product-tag\";s:14:\"attribute_base\";s:0:\"\";s:22:\"use_verbose_page_rules\";b:0;}","yes");
INSERT INTO `st_options` VALUES("445","current_theme_supports_woocommerce","yes","yes");
INSERT INTO `st_options` VALUES("446","woocommerce_queue_flush_rewrite_rules","no","yes");
INSERT INTO `st_options` VALUES("483","ngg_db_version","1.8.1","yes");
INSERT INTO `st_options` VALUES("449","product_cat_children","a:0:{}","yes");
INSERT INTO `st_options` VALUES("450","default_product_cat","36","yes");
INSERT INTO `st_options` VALUES("453","woocommerce_version","3.5.1","yes");
INSERT INTO `st_options` VALUES("454","woocommerce_db_version","3.5.1","yes");
INSERT INTO `st_options` VALUES("460","jetpack_sync_settings_disable","0","yes");
INSERT INTO `st_options` VALUES("482","photocrati_auto_update_admin_check_date","","yes");
INSERT INTO `st_options` VALUES("462","widget_ngg-images","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `st_options` VALUES("463","widget_ngg-mrssw","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `st_options` VALUES("464","widget_slideshow","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `st_options` VALUES("465","widget_woocommerce_widget_cart","a:2:{i:2;a:2:{s:5:\"title\";s:15:\"سبد خرید\";s:13:\"hide_if_empty\";i:1;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `st_options` VALUES("466","widget_woocommerce_layered_nav_filters","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `st_options` VALUES("467","widget_woocommerce_layered_nav","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `st_options` VALUES("468","widget_woocommerce_price_filter","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `st_options` VALUES("469","widget_woocommerce_product_categories","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `st_options` VALUES("470","widget_woocommerce_product_search","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `st_options` VALUES("471","widget_woocommerce_product_tag_cloud","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `st_options` VALUES("472","widget_woocommerce_products","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `st_options` VALUES("473","widget_woocommerce_recently_viewed_products","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `st_options` VALUES("474","widget_woocommerce_top_rated_products","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `st_options` VALUES("475","widget_woocommerce_recent_reviews","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `st_options` VALUES("476","widget_woocommerce_rating_filter","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `st_options` VALUES("477","ngg_transient_groups","a:7:{s:9:\"__counter\";i:7;s:3:\"MVC\";a:2:{s:2:\"id\";i:2;s:7:\"enabled\";b:1;}s:15:\"col_in_st_posts\";a:2:{s:2:\"id\";i:3;s:7:\"enabled\";b:1;}s:21:\"col_in_st_ngg_gallery\";a:2:{s:2:\"id\";i:4;s:7:\"enabled\";b:1;}s:22:\"col_in_st_ngg_pictures\";a:2:{s:2:\"id\";i:5;s:7:\"enabled\";b:1;}s:19:\"col_in_st_ngg_album\";a:2:{s:2:\"id\";i:6;s:7:\"enabled\";b:1;}s:27:\"displayed_gallery_rendering\";a:2:{s:2:\"id\";i:7;s:7:\"enabled\";b:1;}}","yes");
INSERT INTO `st_options` VALUES("481","photocrati_auto_update_admin_update_list","","yes");
INSERT INTO `st_options` VALUES("479","ngg_options","a:72:{s:11:\"gallerypath\";s:19:\"wp-content/gallery/\";s:11:\"wpmuCSSfile\";s:13:\"nggallery.css\";s:9:\"wpmuStyle\";b:0;s:9:\"wpmuRoles\";b:0;s:16:\"wpmuImportFolder\";b:0;s:13:\"wpmuZipUpload\";b:0;s:14:\"wpmuQuotaCheck\";b:0;s:17:\"datamapper_driver\";s:22:\"custom_post_datamapper\";s:21:\"gallerystorage_driver\";s:25:\"ngglegacy_gallery_storage\";s:20:\"maximum_entity_count\";i:500;s:17:\"router_param_slug\";s:9:\"nggallery\";s:22:\"router_param_separator\";s:2:\"--\";s:19:\"router_param_prefix\";s:0:\"\";s:9:\"deleteImg\";b:1;s:13:\"usePermalinks\";b:0;s:13:\"permalinkSlug\";s:9:\"nggallery\";s:14:\"graphicLibrary\";s:2:\"gd\";s:14:\"imageMagickDir\";s:15:\"/usr/local/bin/\";s:11:\"useMediaRSS\";b:0;s:18:\"galleries_in_feeds\";b:0;s:12:\"activateTags\";i:0;s:10:\"appendType\";s:4:\"tags\";s:9:\"maxImages\";i:7;s:14:\"relatedHeading\";s:24:\"<h3>Related Images:</h3>\";s:10:\"thumbwidth\";i:240;s:11:\"thumbheight\";i:160;s:8:\"thumbfix\";b:1;s:12:\"thumbquality\";i:100;s:8:\"imgWidth\";i:1800;s:9:\"imgHeight\";i:1200;s:10:\"imgQuality\";i:100;s:9:\"imgBackup\";b:1;s:13:\"imgAutoResize\";b:1;s:9:\"galImages\";s:2:\"24\";s:17:\"galPagedGalleries\";i:0;s:10:\"galColumns\";i:0;s:12:\"galShowSlide\";b:0;s:12:\"galTextSlide\";s:14:\"View Slideshow\";s:14:\"galTextGallery\";s:15:\"View Thumbnails\";s:12:\"galShowOrder\";s:7:\"gallery\";s:7:\"galSort\";s:9:\"sortorder\";s:10:\"galSortDir\";s:3:\"ASC\";s:10:\"galNoPages\";b:1;s:13:\"galImgBrowser\";i:0;s:12:\"galHiddenImg\";i:0;s:10:\"galAjaxNav\";i:1;s:11:\"thumbEffect\";s:14:\"simplelightbox\";s:9:\"thumbCode\";s:47:\"class=\"ngg-simplelightbox\" rel=\"%GALLERY_NAME%\"\";s:18:\"thumbEffectContext\";s:14:\"nextgen_images\";s:5:\"wmPos\";s:9:\"midCenter\";s:6:\"wmXpos\";i:15;s:6:\"wmYpos\";i:5;s:6:\"wmType\";s:4:\"text\";s:6:\"wmPath\";s:0:\"\";s:6:\"wmFont\";s:9:\"arial.ttf\";s:6:\"wmSize\";i:30;s:6:\"wmText\";s:17:\"روزمره ها\";s:7:\"wmColor\";s:6:\"ffffff\";s:8:\"wmOpaque\";s:2:\"33\";s:7:\"slideFX\";s:4:\"fade\";s:7:\"irWidth\";i:750;s:8:\"irHeight\";i:500;s:12:\"irRotatetime\";i:5;s:11:\"activateCSS\";i:1;s:7:\"CSSfile\";s:13:\"nggallery.css\";s:28:\"always_enable_frontend_logic\";b:0;s:22:\"dynamic_thumbnail_slug\";s:13:\"nextgen-image\";s:23:\"dynamic_stylesheet_slug\";s:12:\"nextgen-dcss\";s:11:\"installDate\";i:1542102683;s:13:\"gallery_count\";i:2;s:23:\"dismissed_notifications\";a:1:{s:48:\"ngg_wizard_nextgen.beginner.gallery_creation_igw\";a:1:{i:0;i:1;}}s:40:\"gallery_created_after_reviews_introduced\";b:1;}","yes");
INSERT INTO `st_options` VALUES("1706","_transient_wc_count_comments","O:8:\"stdClass\":7:{s:14:\"total_comments\";i:1;s:3:\"all\";i:1;s:8:\"approved\";s:1:\"1\";s:12:\"post-trashed\";s:1:\"1\";s:5:\"trash\";s:1:\"1\";s:9:\"moderated\";i:0;s:4:\"spam\";i:0;}","yes");
INSERT INTO `st_options` VALUES("1707","_transient_as_comment_count","O:8:\"stdClass\":7:{s:8:\"approved\";s:1:\"1\";s:12:\"post-trashed\";s:1:\"1\";s:5:\"trash\";s:1:\"1\";s:14:\"total_comments\";i:1;s:3:\"all\";i:1;s:9:\"moderated\";i:0;s:4:\"spam\";i:0;}","yes");
INSERT INTO `st_options` VALUES("1656","_site_transient_timeout_browser_f27a70fef65ab50236291e1635e268f3","1542783860","no");
INSERT INTO `st_options` VALUES("1657","_site_transient_browser_f27a70fef65ab50236291e1635e268f3","a:10:{s:4:\"name\";s:17:\"Internet Explorer\";s:7:\"version\";s:4:\"11.0\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:74:\"https://support.microsoft.com/en-us/help/17621/internet-explorer-downloads\";s:7:\"img_src\";s:39:\"http://s.w.org/images/browsers/ie.png?1\";s:11:\"img_src_ssl\";s:40:\"https://s.w.org/images/browsers/ie.png?1\";s:15:\"current_version\";s:2:\"11\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}","no");
INSERT INTO `st_options` VALUES("1673","_site_transient_timeout_browser_88948936c8355fa92108d4448c2520d0","1542784982","no");
INSERT INTO `st_options` VALUES("1674","_site_transient_browser_88948936c8355fa92108d4448c2520d0","a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:13:\"70.0.3538.102\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}","no");
INSERT INTO `st_options` VALUES("2145","wpseo-gsc-refresh_token","1/QDDmK72j2TT46jhl7VEw2unNLzuPSC9mVhy3lWXBQfA","yes");
INSERT INTO `st_options` VALUES("2146","wpseo-gsc-access_token","a:5:{s:13:\"refresh_token\";s:45:\"1/QDDmK72j2TT46jhl7VEw2unNLzuPSC9mVhy3lWXBQfA\";s:12:\"access_token\";s:129:\"ya29.GltVBhxNZMU_gM56QgtY4kfIR1StMOmwyFKW__iM_2m0a-6MFhhzclyUeH4E_AL_WizjaEAWuiqcZX--NpFTwuYc9YYtw3LoTBTZH012BfxThNi2n95NDZGLozGd\";s:7:\"expires\";d:1542316818;s:10:\"expires_in\";i:3600;s:7:\"created\";i:1542300618;}","yes");
INSERT INTO `st_options` VALUES("2349","wpglobus_option_en_language_names","a:34:{s:2:\"ar\";s:6:\"Arabic\";s:2:\"en\";s:7:\"English\";s:2:\"au\";s:12:\"English (AU)\";s:2:\"ca\";s:12:\"English (CA)\";s:2:\"gb\";s:12:\"English (UK)\";s:2:\"zh\";s:7:\"Chinese\";s:2:\"tw\";s:12:\"Chinese (TW)\";s:2:\"da\";s:6:\"Danish\";s:2:\"nl\";s:5:\"Dutch\";s:2:\"gl\";s:8:\"Galician\";s:2:\"de\";s:6:\"German\";s:2:\"fi\";s:7:\"Finnish\";s:2:\"fr\";s:6:\"French\";s:2:\"qc\";s:11:\"French (CA)\";s:2:\"he\";s:6:\"Hebrew\";s:2:\"hi\";s:5:\"Hindi\";s:2:\"hu\";s:9:\"Hungarian\";s:2:\"it\";s:7:\"Italian\";s:2:\"ja\";s:8:\"Japanese\";s:2:\"ko\";s:6:\"Korean\";s:2:\"no\";s:9:\"Norwegian\";s:2:\"fa\";s:7:\"Persian\";s:2:\"pl\";s:6:\"Polish\";s:2:\"pt\";s:10:\"Portuguese\";s:2:\"br\";s:15:\"Portuguese (BR)\";s:2:\"ro\";s:8:\"Romanian\";s:2:\"ru\";s:7:\"Russian\";s:2:\"es\";s:7:\"Spanish\";s:2:\"mx\";s:12:\"Spanish (MX)\";s:2:\"sv\";s:7:\"Swedish\";s:2:\"tr\";s:7:\"Turkish\";s:2:\"uk\";s:9:\"Ukrainian\";s:2:\"vi\";s:10:\"Vietnamese\";s:2:\"cy\";s:5:\"Welsh\";}","yes");
INSERT INTO `st_options` VALUES("2350","wpglobus_option_locale","a:34:{s:2:\"ar\";s:2:\"ar\";s:2:\"en\";s:5:\"en_US\";s:2:\"au\";s:5:\"en_AU\";s:2:\"ca\";s:5:\"en_CA\";s:2:\"gb\";s:5:\"en_GB\";s:2:\"zh\";s:5:\"zh_CN\";s:2:\"tw\";s:5:\"zh_CN\";s:2:\"da\";s:5:\"da_DK\";s:2:\"nl\";s:5:\"nl_NL\";s:2:\"gl\";s:5:\"gl_ES\";s:2:\"de\";s:5:\"de_DE\";s:2:\"fi\";s:2:\"fi\";s:2:\"fr\";s:5:\"fr_FR\";s:2:\"qc\";s:5:\"fr_CA\";s:2:\"he\";s:5:\"he_IL\";s:2:\"hi\";s:5:\"hi_IN\";s:2:\"hu\";s:5:\"hu_HU\";s:2:\"it\";s:5:\"it_IT\";s:2:\"ja\";s:2:\"ja\";s:2:\"ko\";s:5:\"ko_KR\";s:2:\"no\";s:5:\"nb_NO\";s:2:\"fa\";s:5:\"fa_IR\";s:2:\"pl\";s:5:\"pl_PL\";s:2:\"pt\";s:5:\"pt_PT\";s:2:\"br\";s:5:\"pt_BR\";s:2:\"ro\";s:5:\"ro_RO\";s:2:\"ru\";s:5:\"ru_RU\";s:2:\"es\";s:5:\"es_ES\";s:2:\"mx\";s:5:\"es_MX\";s:2:\"sv\";s:5:\"sv_SE\";s:2:\"tr\";s:5:\"tr_TR\";s:2:\"uk\";s:2:\"uk\";s:2:\"vi\";s:2:\"vi\";s:2:\"cy\";s:2:\"cy\";}","yes");
INSERT INTO `st_options` VALUES("2351","wpglobus_option_flags","a:34:{s:2:\"ar\";s:8:\"arle.png\";s:2:\"en\";s:6:\"us.png\";s:2:\"au\";s:6:\"au.png\";s:2:\"ca\";s:6:\"ca.png\";s:2:\"gb\";s:6:\"uk.png\";s:2:\"zh\";s:6:\"cn.png\";s:2:\"tw\";s:6:\"cn.png\";s:2:\"da\";s:6:\"dk.png\";s:2:\"nl\";s:6:\"nl.png\";s:2:\"gl\";s:10:\"galego.png\";s:2:\"de\";s:6:\"de.png\";s:2:\"fi\";s:6:\"fi.png\";s:2:\"fr\";s:6:\"fr.png\";s:2:\"qc\";s:9:\"fr_CA.png\";s:2:\"he\";s:6:\"il.png\";s:2:\"hi\";s:6:\"in.png\";s:2:\"hu\";s:6:\"hu.png\";s:2:\"it\";s:6:\"it.png\";s:2:\"ja\";s:6:\"jp.png\";s:2:\"ko\";s:6:\"kr.png\";s:2:\"no\";s:6:\"no.png\";s:2:\"fa\";s:6:\"ir.png\";s:2:\"pl\";s:6:\"pl.png\";s:2:\"pt\";s:6:\"pt.png\";s:2:\"br\";s:6:\"br.png\";s:2:\"ro\";s:6:\"ro.png\";s:2:\"ru\";s:6:\"ru.png\";s:2:\"es\";s:6:\"es.png\";s:2:\"mx\";s:6:\"mx.png\";s:2:\"sv\";s:6:\"se.png\";s:2:\"tr\";s:6:\"tr.png\";s:2:\"uk\";s:6:\"ua.png\";s:2:\"vi\";s:6:\"vn.png\";s:2:\"cy\";s:6:\"cy.png\";}","yes");
INSERT INTO `st_options` VALUES("2352","wpglobus_option_versioning","a:1:{s:15:\"current_version\";s:6:\"1.9.27\";}","yes");
INSERT INTO `st_options` VALUES("2359","wpglobus_option","a:7:{s:17:\"enabled_languages\";a:2:{s:2:\"fa\";b:1;s:2:\"en\";b:1;}s:14:\"show_flag_name\";s:5:\"empty\";s:12:\"use_nav_menu\";s:3:\"all\";s:9:\"post_type\";a:0:{}s:16:\"browser_redirect\";a:1:{s:20:\"redirect_by_language\";i:0;}s:10:\"css_editor\";s:0:\"\";s:9:\"js_editor\";s:0:\"\";}","yes");
INSERT INTO `st_options` VALUES("2355","widget_wpglobus","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `st_options` VALUES("771","_transient_shipping-transient-version","1542105106","yes");
INSERT INTO `st_options` VALUES("1484","_transient_timeout_wc_shipping_method_count_1_1542105106","1544743062","no");
INSERT INTO `st_options` VALUES("1485","_transient_wc_shipping_method_count_1_1542105106","0","no");
INSERT INTO `st_options` VALUES("2187","rewrite_rules","a:508:{s:24:\"^wc-auth/v([1]{1})/(.*)?\";s:63:\"index.php?wc-auth-version=$matches[1]&wc-auth-route=$matches[2]\";s:22:\"^wc-api/v([1-3]{1})/?$\";s:51:\"index.php?wc-api-version=$matches[1]&wc-api-route=/\";s:24:\"^wc-api/v([1-3]{1})(.*)?\";s:61:\"index.php?wc-api-version=$matches[1]&wc-api-route=$matches[2]\";s:19:\"sitemap_index\\.xml$\";s:19:\"index.php?sitemap=1\";s:31:\"([^/]+?)-sitemap([0-9]+)?\\.xml$\";s:51:\"index.php?sitemap=$matches[1]&sitemap_n=$matches[2]\";s:24:\"([a-z]+)?-?sitemap\\.xsl$\";s:25:\"index.php?xsl=$matches[1]\";s:7:\"shop/?$\";s:27:\"index.php?post_type=product\";s:37:\"shop/feed/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=product&feed=$matches[1]\";s:32:\"shop/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=product&feed=$matches[1]\";s:24:\"shop/page/([0-9]{1,})/?$\";s:45:\"index.php?post_type=product&paged=$matches[1]\";s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:32:\"category/(.+?)/wc-api(/(.*))?/?$\";s:54:\"index.php?category_name=$matches[1]&wc-api=$matches[3]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:29:\"tag/([^/]+)/wc-api(/(.*))?/?$\";s:44:\"index.php?tag=$matches[1]&wc-api=$matches[3]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:55:\"product-category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_cat=$matches[1]&feed=$matches[2]\";s:50:\"product-category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_cat=$matches[1]&feed=$matches[2]\";s:31:\"product-category/(.+?)/embed/?$\";s:44:\"index.php?product_cat=$matches[1]&embed=true\";s:43:\"product-category/(.+?)/page/?([0-9]{1,})/?$\";s:51:\"index.php?product_cat=$matches[1]&paged=$matches[2]\";s:25:\"product-category/(.+?)/?$\";s:33:\"index.php?product_cat=$matches[1]\";s:52:\"product-tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_tag=$matches[1]&feed=$matches[2]\";s:47:\"product-tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_tag=$matches[1]&feed=$matches[2]\";s:28:\"product-tag/([^/]+)/embed/?$\";s:44:\"index.php?product_tag=$matches[1]&embed=true\";s:40:\"product-tag/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?product_tag=$matches[1]&paged=$matches[2]\";s:22:\"product-tag/([^/]+)/?$\";s:33:\"index.php?product_tag=$matches[1]\";s:35:\"product/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:45:\"product/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:65:\"product/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"product/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"product/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:41:\"product/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:24:\"product/([^/]+)/embed/?$\";s:40:\"index.php?product=$matches[1]&embed=true\";s:28:\"product/([^/]+)/trackback/?$\";s:34:\"index.php?product=$matches[1]&tb=1\";s:48:\"product/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?product=$matches[1]&feed=$matches[2]\";s:43:\"product/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?product=$matches[1]&feed=$matches[2]\";s:36:\"product/([^/]+)/page/?([0-9]{1,})/?$\";s:47:\"index.php?product=$matches[1]&paged=$matches[2]\";s:43:\"product/([^/]+)/comment-page-([0-9]{1,})/?$\";s:47:\"index.php?product=$matches[1]&cpage=$matches[2]\";s:33:\"product/([^/]+)/wc-api(/(.*))?/?$\";s:48:\"index.php?product=$matches[1]&wc-api=$matches[3]\";s:39:\"product/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:50:\"product/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:32:\"product/([^/]+)(?:/([0-9]+))?/?$\";s:46:\"index.php?product=$matches[1]&page=$matches[2]\";s:24:\"product/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:34:\"product/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:54:\"product/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"product/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"product/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:30:\"product/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:48:\"ngg_tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?ngg_tag=$matches[1]&feed=$matches[2]\";s:43:\"ngg_tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?ngg_tag=$matches[1]&feed=$matches[2]\";s:24:\"ngg_tag/([^/]+)/embed/?$\";s:40:\"index.php?ngg_tag=$matches[1]&embed=true\";s:36:\"ngg_tag/([^/]+)/page/?([0-9]{1,})/?$\";s:47:\"index.php?ngg_tag=$matches[1]&paged=$matches[2]\";s:18:\"ngg_tag/([^/]+)/?$\";s:29:\"index.php?ngg_tag=$matches[1]\";s:45:\"amn_exact-metrics/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:55:\"amn_exact-metrics/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:75:\"amn_exact-metrics/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:70:\"amn_exact-metrics/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:70:\"amn_exact-metrics/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:51:\"amn_exact-metrics/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:34:\"amn_exact-metrics/([^/]+)/embed/?$\";s:50:\"index.php?amn_exact-metrics=$matches[1]&embed=true\";s:38:\"amn_exact-metrics/([^/]+)/trackback/?$\";s:44:\"index.php?amn_exact-metrics=$matches[1]&tb=1\";s:46:\"amn_exact-metrics/([^/]+)/page/?([0-9]{1,})/?$\";s:57:\"index.php?amn_exact-metrics=$matches[1]&paged=$matches[2]\";s:53:\"amn_exact-metrics/([^/]+)/comment-page-([0-9]{1,})/?$\";s:57:\"index.php?amn_exact-metrics=$matches[1]&cpage=$matches[2]\";s:43:\"amn_exact-metrics/([^/]+)/wc-api(/(.*))?/?$\";s:58:\"index.php?amn_exact-metrics=$matches[1]&wc-api=$matches[3]\";s:49:\"amn_exact-metrics/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:60:\"amn_exact-metrics/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:42:\"amn_exact-metrics/([^/]+)(?:/([0-9]+))?/?$\";s:56:\"index.php?amn_exact-metrics=$matches[1]&page=$matches[2]\";s:34:\"amn_exact-metrics/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:44:\"amn_exact-metrics/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:64:\"amn_exact-metrics/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:59:\"amn_exact-metrics/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:59:\"amn_exact-metrics/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:40:\"amn_exact-metrics/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:40:\"vc_grid_item/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:50:\"vc_grid_item/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:70:\"vc_grid_item/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:65:\"vc_grid_item/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:65:\"vc_grid_item/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:46:\"vc_grid_item/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:29:\"vc_grid_item/([^/]+)/embed/?$\";s:45:\"index.php?vc_grid_item=$matches[1]&embed=true\";s:33:\"vc_grid_item/([^/]+)/trackback/?$\";s:39:\"index.php?vc_grid_item=$matches[1]&tb=1\";s:41:\"vc_grid_item/([^/]+)/page/?([0-9]{1,})/?$\";s:52:\"index.php?vc_grid_item=$matches[1]&paged=$matches[2]\";s:48:\"vc_grid_item/([^/]+)/comment-page-([0-9]{1,})/?$\";s:52:\"index.php?vc_grid_item=$matches[1]&cpage=$matches[2]\";s:38:\"vc_grid_item/([^/]+)/wc-api(/(.*))?/?$\";s:53:\"index.php?vc_grid_item=$matches[1]&wc-api=$matches[3]\";s:44:\"vc_grid_item/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:55:\"vc_grid_item/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:37:\"vc_grid_item/([^/]+)(?:/([0-9]+))?/?$\";s:51:\"index.php?vc_grid_item=$matches[1]&page=$matches[2]\";s:29:\"vc_grid_item/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:39:\"vc_grid_item/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:59:\"vc_grid_item/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:54:\"vc_grid_item/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:54:\"vc_grid_item/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:35:\"vc_grid_item/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:37:\"ngg_album/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:47:\"ngg_album/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:67:\"ngg_album/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:62:\"ngg_album/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:62:\"ngg_album/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:43:\"ngg_album/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:26:\"ngg_album/([^/]+)/embed/?$\";s:42:\"index.php?ngg_album=$matches[1]&embed=true\";s:30:\"ngg_album/([^/]+)/trackback/?$\";s:36:\"index.php?ngg_album=$matches[1]&tb=1\";s:38:\"ngg_album/([^/]+)/page/?([0-9]{1,})/?$\";s:49:\"index.php?ngg_album=$matches[1]&paged=$matches[2]\";s:45:\"ngg_album/([^/]+)/comment-page-([0-9]{1,})/?$\";s:49:\"index.php?ngg_album=$matches[1]&cpage=$matches[2]\";s:35:\"ngg_album/([^/]+)/wc-api(/(.*))?/?$\";s:50:\"index.php?ngg_album=$matches[1]&wc-api=$matches[3]\";s:41:\"ngg_album/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:52:\"ngg_album/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:34:\"ngg_album/([^/]+)(?:/([0-9]+))?/?$\";s:48:\"index.php?ngg_album=$matches[1]&page=$matches[2]\";s:26:\"ngg_album/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:36:\"ngg_album/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:56:\"ngg_album/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:51:\"ngg_album/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:51:\"ngg_album/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:32:\"ngg_album/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:39:\"ngg_gallery/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:49:\"ngg_gallery/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:69:\"ngg_gallery/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:64:\"ngg_gallery/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:64:\"ngg_gallery/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:45:\"ngg_gallery/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:28:\"ngg_gallery/([^/]+)/embed/?$\";s:44:\"index.php?ngg_gallery=$matches[1]&embed=true\";s:32:\"ngg_gallery/([^/]+)/trackback/?$\";s:38:\"index.php?ngg_gallery=$matches[1]&tb=1\";s:40:\"ngg_gallery/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?ngg_gallery=$matches[1]&paged=$matches[2]\";s:47:\"ngg_gallery/([^/]+)/comment-page-([0-9]{1,})/?$\";s:51:\"index.php?ngg_gallery=$matches[1]&cpage=$matches[2]\";s:37:\"ngg_gallery/([^/]+)/wc-api(/(.*))?/?$\";s:52:\"index.php?ngg_gallery=$matches[1]&wc-api=$matches[3]\";s:43:\"ngg_gallery/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:54:\"ngg_gallery/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:36:\"ngg_gallery/([^/]+)(?:/([0-9]+))?/?$\";s:50:\"index.php?ngg_gallery=$matches[1]&page=$matches[2]\";s:28:\"ngg_gallery/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:38:\"ngg_gallery/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:58:\"ngg_gallery/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:53:\"ngg_gallery/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:53:\"ngg_gallery/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:34:\"ngg_gallery/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:40:\"ngg_pictures/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:50:\"ngg_pictures/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:70:\"ngg_pictures/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:65:\"ngg_pictures/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:65:\"ngg_pictures/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:46:\"ngg_pictures/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:29:\"ngg_pictures/([^/]+)/embed/?$\";s:45:\"index.php?ngg_pictures=$matches[1]&embed=true\";s:33:\"ngg_pictures/([^/]+)/trackback/?$\";s:39:\"index.php?ngg_pictures=$matches[1]&tb=1\";s:41:\"ngg_pictures/([^/]+)/page/?([0-9]{1,})/?$\";s:52:\"index.php?ngg_pictures=$matches[1]&paged=$matches[2]\";s:48:\"ngg_pictures/([^/]+)/comment-page-([0-9]{1,})/?$\";s:52:\"index.php?ngg_pictures=$matches[1]&cpage=$matches[2]\";s:38:\"ngg_pictures/([^/]+)/wc-api(/(.*))?/?$\";s:53:\"index.php?ngg_pictures=$matches[1]&wc-api=$matches[3]\";s:44:\"ngg_pictures/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:55:\"ngg_pictures/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:37:\"ngg_pictures/([^/]+)(?:/([0-9]+))?/?$\";s:51:\"index.php?ngg_pictures=$matches[1]&page=$matches[2]\";s:29:\"ngg_pictures/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:39:\"ngg_pictures/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:59:\"ngg_pictures/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:54:\"ngg_pictures/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:54:\"ngg_pictures/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:35:\"ngg_pictures/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:44:\"lightbox_library/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:54:\"lightbox_library/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:74:\"lightbox_library/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:69:\"lightbox_library/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:69:\"lightbox_library/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:50:\"lightbox_library/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:33:\"lightbox_library/([^/]+)/embed/?$\";s:49:\"index.php?lightbox_library=$matches[1]&embed=true\";s:37:\"lightbox_library/([^/]+)/trackback/?$\";s:43:\"index.php?lightbox_library=$matches[1]&tb=1\";s:45:\"lightbox_library/([^/]+)/page/?([0-9]{1,})/?$\";s:56:\"index.php?lightbox_library=$matches[1]&paged=$matches[2]\";s:52:\"lightbox_library/([^/]+)/comment-page-([0-9]{1,})/?$\";s:56:\"index.php?lightbox_library=$matches[1]&cpage=$matches[2]\";s:42:\"lightbox_library/([^/]+)/wc-api(/(.*))?/?$\";s:57:\"index.php?lightbox_library=$matches[1]&wc-api=$matches[3]\";s:48:\"lightbox_library/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:59:\"lightbox_library/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:41:\"lightbox_library/([^/]+)(?:/([0-9]+))?/?$\";s:55:\"index.php?lightbox_library=$matches[1]&page=$matches[2]\";s:33:\"lightbox_library/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:43:\"lightbox_library/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:63:\"lightbox_library/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:58:\"lightbox_library/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:58:\"lightbox_library/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:39:\"lightbox_library/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:39:\"client-item/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:49:\"client-item/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:69:\"client-item/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:64:\"client-item/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:64:\"client-item/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:45:\"client-item/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:28:\"client-item/([^/]+)/embed/?$\";s:39:\"index.php?client=$matches[1]&embed=true\";s:32:\"client-item/([^/]+)/trackback/?$\";s:33:\"index.php?client=$matches[1]&tb=1\";s:40:\"client-item/([^/]+)/page/?([0-9]{1,})/?$\";s:46:\"index.php?client=$matches[1]&paged=$matches[2]\";s:47:\"client-item/([^/]+)/comment-page-([0-9]{1,})/?$\";s:46:\"index.php?client=$matches[1]&cpage=$matches[2]\";s:37:\"client-item/([^/]+)/wc-api(/(.*))?/?$\";s:47:\"index.php?client=$matches[1]&wc-api=$matches[3]\";s:43:\"client-item/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:54:\"client-item/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:36:\"client-item/([^/]+)(?:/([0-9]+))?/?$\";s:45:\"index.php?client=$matches[1]&page=$matches[2]\";s:28:\"client-item/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:38:\"client-item/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:58:\"client-item/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:53:\"client-item/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:53:\"client-item/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:34:\"client-item/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:53:\"client-types/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:51:\"index.php?client-types=$matches[1]&feed=$matches[2]\";s:48:\"client-types/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:51:\"index.php?client-types=$matches[1]&feed=$matches[2]\";s:29:\"client-types/([^/]+)/embed/?$\";s:45:\"index.php?client-types=$matches[1]&embed=true\";s:41:\"client-types/([^/]+)/page/?([0-9]{1,})/?$\";s:52:\"index.php?client-types=$matches[1]&paged=$matches[2]\";s:23:\"client-types/([^/]+)/?$\";s:34:\"index.php?client-types=$matches[1]\";s:38:\"offer-item/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:48:\"offer-item/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:68:\"offer-item/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:63:\"offer-item/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:63:\"offer-item/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:44:\"offer-item/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:27:\"offer-item/([^/]+)/embed/?$\";s:38:\"index.php?offer=$matches[1]&embed=true\";s:31:\"offer-item/([^/]+)/trackback/?$\";s:32:\"index.php?offer=$matches[1]&tb=1\";s:39:\"offer-item/([^/]+)/page/?([0-9]{1,})/?$\";s:45:\"index.php?offer=$matches[1]&paged=$matches[2]\";s:46:\"offer-item/([^/]+)/comment-page-([0-9]{1,})/?$\";s:45:\"index.php?offer=$matches[1]&cpage=$matches[2]\";s:36:\"offer-item/([^/]+)/wc-api(/(.*))?/?$\";s:46:\"index.php?offer=$matches[1]&wc-api=$matches[3]\";s:42:\"offer-item/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:53:\"offer-item/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:35:\"offer-item/([^/]+)(?:/([0-9]+))?/?$\";s:44:\"index.php?offer=$matches[1]&page=$matches[2]\";s:27:\"offer-item/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\"offer-item/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\"offer-item/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"offer-item/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"offer-item/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\"offer-item/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:52:\"offer-types/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?offer-types=$matches[1]&feed=$matches[2]\";s:47:\"offer-types/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?offer-types=$matches[1]&feed=$matches[2]\";s:28:\"offer-types/([^/]+)/embed/?$\";s:44:\"index.php?offer-types=$matches[1]&embed=true\";s:40:\"offer-types/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?offer-types=$matches[1]&paged=$matches[2]\";s:22:\"offer-types/([^/]+)/?$\";s:33:\"index.php?offer-types=$matches[1]\";s:42:\"portfolio-item/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:52:\"portfolio-item/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:72:\"portfolio-item/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:67:\"portfolio-item/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:67:\"portfolio-item/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:48:\"portfolio-item/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:31:\"portfolio-item/([^/]+)/embed/?$\";s:42:\"index.php?portfolio=$matches[1]&embed=true\";s:35:\"portfolio-item/([^/]+)/trackback/?$\";s:36:\"index.php?portfolio=$matches[1]&tb=1\";s:43:\"portfolio-item/([^/]+)/page/?([0-9]{1,})/?$\";s:49:\"index.php?portfolio=$matches[1]&paged=$matches[2]\";s:50:\"portfolio-item/([^/]+)/comment-page-([0-9]{1,})/?$\";s:49:\"index.php?portfolio=$matches[1]&cpage=$matches[2]\";s:40:\"portfolio-item/([^/]+)/wc-api(/(.*))?/?$\";s:50:\"index.php?portfolio=$matches[1]&wc-api=$matches[3]\";s:46:\"portfolio-item/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:57:\"portfolio-item/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:39:\"portfolio-item/([^/]+)(?:/([0-9]+))?/?$\";s:48:\"index.php?portfolio=$matches[1]&page=$matches[2]\";s:31:\"portfolio-item/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:41:\"portfolio-item/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:61:\"portfolio-item/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:56:\"portfolio-item/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:56:\"portfolio-item/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:37:\"portfolio-item/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:56:\"portfolio-types/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:54:\"index.php?portfolio-types=$matches[1]&feed=$matches[2]\";s:51:\"portfolio-types/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:54:\"index.php?portfolio-types=$matches[1]&feed=$matches[2]\";s:32:\"portfolio-types/([^/]+)/embed/?$\";s:48:\"index.php?portfolio-types=$matches[1]&embed=true\";s:44:\"portfolio-types/([^/]+)/page/?([0-9]{1,})/?$\";s:55:\"index.php?portfolio-types=$matches[1]&paged=$matches[2]\";s:26:\"portfolio-types/([^/]+)/?$\";s:37:\"index.php?portfolio-types=$matches[1]\";s:38:\"slide-item/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:48:\"slide-item/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:68:\"slide-item/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:63:\"slide-item/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:63:\"slide-item/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:44:\"slide-item/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:27:\"slide-item/([^/]+)/embed/?$\";s:38:\"index.php?slide=$matches[1]&embed=true\";s:31:\"slide-item/([^/]+)/trackback/?$\";s:32:\"index.php?slide=$matches[1]&tb=1\";s:39:\"slide-item/([^/]+)/page/?([0-9]{1,})/?$\";s:45:\"index.php?slide=$matches[1]&paged=$matches[2]\";s:46:\"slide-item/([^/]+)/comment-page-([0-9]{1,})/?$\";s:45:\"index.php?slide=$matches[1]&cpage=$matches[2]\";s:36:\"slide-item/([^/]+)/wc-api(/(.*))?/?$\";s:46:\"index.php?slide=$matches[1]&wc-api=$matches[3]\";s:42:\"slide-item/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:53:\"slide-item/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:35:\"slide-item/([^/]+)(?:/([0-9]+))?/?$\";s:44:\"index.php?slide=$matches[1]&page=$matches[2]\";s:27:\"slide-item/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\"slide-item/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\"slide-item/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"slide-item/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"slide-item/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\"slide-item/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:52:\"slide-types/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?slide-types=$matches[1]&feed=$matches[2]\";s:47:\"slide-types/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?slide-types=$matches[1]&feed=$matches[2]\";s:28:\"slide-types/([^/]+)/embed/?$\";s:44:\"index.php?slide-types=$matches[1]&embed=true\";s:40:\"slide-types/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?slide-types=$matches[1]&paged=$matches[2]\";s:22:\"slide-types/([^/]+)/?$\";s:33:\"index.php?slide-types=$matches[1]\";s:44:\"testimonial-item/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:54:\"testimonial-item/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:74:\"testimonial-item/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:69:\"testimonial-item/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:69:\"testimonial-item/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:50:\"testimonial-item/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:33:\"testimonial-item/([^/]+)/embed/?$\";s:44:\"index.php?testimonial=$matches[1]&embed=true\";s:37:\"testimonial-item/([^/]+)/trackback/?$\";s:38:\"index.php?testimonial=$matches[1]&tb=1\";s:45:\"testimonial-item/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?testimonial=$matches[1]&paged=$matches[2]\";s:52:\"testimonial-item/([^/]+)/comment-page-([0-9]{1,})/?$\";s:51:\"index.php?testimonial=$matches[1]&cpage=$matches[2]\";s:42:\"testimonial-item/([^/]+)/wc-api(/(.*))?/?$\";s:52:\"index.php?testimonial=$matches[1]&wc-api=$matches[3]\";s:48:\"testimonial-item/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:59:\"testimonial-item/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:41:\"testimonial-item/([^/]+)(?:/([0-9]+))?/?$\";s:50:\"index.php?testimonial=$matches[1]&page=$matches[2]\";s:33:\"testimonial-item/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:43:\"testimonial-item/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:63:\"testimonial-item/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:58:\"testimonial-item/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:58:\"testimonial-item/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:39:\"testimonial-item/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:58:\"testimonial-types/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:56:\"index.php?testimonial-types=$matches[1]&feed=$matches[2]\";s:53:\"testimonial-types/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:56:\"index.php?testimonial-types=$matches[1]&feed=$matches[2]\";s:34:\"testimonial-types/([^/]+)/embed/?$\";s:50:\"index.php?testimonial-types=$matches[1]&embed=true\";s:46:\"testimonial-types/([^/]+)/page/?([0-9]{1,})/?$\";s:57:\"index.php?testimonial-types=$matches[1]&paged=$matches[2]\";s:28:\"testimonial-types/([^/]+)/?$\";s:39:\"index.php?testimonial-types=$matches[1]\";s:39:\"layout-item/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:49:\"layout-item/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:69:\"layout-item/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:64:\"layout-item/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:64:\"layout-item/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:45:\"layout-item/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:28:\"layout-item/([^/]+)/embed/?$\";s:39:\"index.php?layout=$matches[1]&embed=true\";s:32:\"layout-item/([^/]+)/trackback/?$\";s:33:\"index.php?layout=$matches[1]&tb=1\";s:40:\"layout-item/([^/]+)/page/?([0-9]{1,})/?$\";s:46:\"index.php?layout=$matches[1]&paged=$matches[2]\";s:47:\"layout-item/([^/]+)/comment-page-([0-9]{1,})/?$\";s:46:\"index.php?layout=$matches[1]&cpage=$matches[2]\";s:37:\"layout-item/([^/]+)/wc-api(/(.*))?/?$\";s:47:\"index.php?layout=$matches[1]&wc-api=$matches[3]\";s:43:\"layout-item/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:54:\"layout-item/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:36:\"layout-item/([^/]+)(?:/([0-9]+))?/?$\";s:45:\"index.php?layout=$matches[1]&page=$matches[2]\";s:28:\"layout-item/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:38:\"layout-item/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:58:\"layout-item/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:53:\"layout-item/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:53:\"layout-item/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:34:\"layout-item/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:41:\"template-item/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:51:\"template-item/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:71:\"template-item/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:66:\"template-item/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:66:\"template-item/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:47:\"template-item/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:30:\"template-item/([^/]+)/embed/?$\";s:41:\"index.php?template=$matches[1]&embed=true\";s:34:\"template-item/([^/]+)/trackback/?$\";s:35:\"index.php?template=$matches[1]&tb=1\";s:42:\"template-item/([^/]+)/page/?([0-9]{1,})/?$\";s:48:\"index.php?template=$matches[1]&paged=$matches[2]\";s:49:\"template-item/([^/]+)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?template=$matches[1]&cpage=$matches[2]\";s:39:\"template-item/([^/]+)/wc-api(/(.*))?/?$\";s:49:\"index.php?template=$matches[1]&wc-api=$matches[3]\";s:45:\"template-item/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:56:\"template-item/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:38:\"template-item/([^/]+)(?:/([0-9]+))?/?$\";s:47:\"index.php?template=$matches[1]&page=$matches[2]\";s:30:\"template-item/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:40:\"template-item/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:60:\"template-item/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:55:\"template-item/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:55:\"template-item/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:36:\"template-item/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:45:\"displayed_gallery/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:55:\"displayed_gallery/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:75:\"displayed_gallery/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:70:\"displayed_gallery/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:70:\"displayed_gallery/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:51:\"displayed_gallery/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:34:\"displayed_gallery/([^/]+)/embed/?$\";s:50:\"index.php?displayed_gallery=$matches[1]&embed=true\";s:38:\"displayed_gallery/([^/]+)/trackback/?$\";s:44:\"index.php?displayed_gallery=$matches[1]&tb=1\";s:46:\"displayed_gallery/([^/]+)/page/?([0-9]{1,})/?$\";s:57:\"index.php?displayed_gallery=$matches[1]&paged=$matches[2]\";s:53:\"displayed_gallery/([^/]+)/comment-page-([0-9]{1,})/?$\";s:57:\"index.php?displayed_gallery=$matches[1]&cpage=$matches[2]\";s:43:\"displayed_gallery/([^/]+)/wc-api(/(.*))?/?$\";s:58:\"index.php?displayed_gallery=$matches[1]&wc-api=$matches[3]\";s:49:\"displayed_gallery/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:60:\"displayed_gallery/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:42:\"displayed_gallery/([^/]+)(?:/([0-9]+))?/?$\";s:56:\"index.php?displayed_gallery=$matches[1]&page=$matches[2]\";s:34:\"displayed_gallery/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:44:\"displayed_gallery/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:64:\"displayed_gallery/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:59:\"displayed_gallery/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:59:\"displayed_gallery/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:40:\"displayed_gallery/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:40:\"display_type/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:50:\"display_type/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:70:\"display_type/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:65:\"display_type/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:65:\"display_type/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:46:\"display_type/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:29:\"display_type/([^/]+)/embed/?$\";s:45:\"index.php?display_type=$matches[1]&embed=true\";s:33:\"display_type/([^/]+)/trackback/?$\";s:39:\"index.php?display_type=$matches[1]&tb=1\";s:41:\"display_type/([^/]+)/page/?([0-9]{1,})/?$\";s:52:\"index.php?display_type=$matches[1]&paged=$matches[2]\";s:48:\"display_type/([^/]+)/comment-page-([0-9]{1,})/?$\";s:52:\"index.php?display_type=$matches[1]&cpage=$matches[2]\";s:38:\"display_type/([^/]+)/wc-api(/(.*))?/?$\";s:53:\"index.php?display_type=$matches[1]&wc-api=$matches[3]\";s:44:\"display_type/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:55:\"display_type/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:37:\"display_type/([^/]+)(?:/([0-9]+))?/?$\";s:51:\"index.php?display_type=$matches[1]&page=$matches[2]\";s:29:\"display_type/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:39:\"display_type/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:59:\"display_type/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:54:\"display_type/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:54:\"display_type/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:35:\"display_type/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:46:\"gal_display_source/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:56:\"gal_display_source/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:76:\"gal_display_source/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:71:\"gal_display_source/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:71:\"gal_display_source/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:52:\"gal_display_source/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:35:\"gal_display_source/([^/]+)/embed/?$\";s:51:\"index.php?gal_display_source=$matches[1]&embed=true\";s:39:\"gal_display_source/([^/]+)/trackback/?$\";s:45:\"index.php?gal_display_source=$matches[1]&tb=1\";s:47:\"gal_display_source/([^/]+)/page/?([0-9]{1,})/?$\";s:58:\"index.php?gal_display_source=$matches[1]&paged=$matches[2]\";s:54:\"gal_display_source/([^/]+)/comment-page-([0-9]{1,})/?$\";s:58:\"index.php?gal_display_source=$matches[1]&cpage=$matches[2]\";s:44:\"gal_display_source/([^/]+)/wc-api(/(.*))?/?$\";s:59:\"index.php?gal_display_source=$matches[1]&wc-api=$matches[3]\";s:50:\"gal_display_source/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:61:\"gal_display_source/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:43:\"gal_display_source/([^/]+)(?:/([0-9]+))?/?$\";s:57:\"index.php?gal_display_source=$matches[1]&page=$matches[2]\";s:35:\"gal_display_source/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:45:\"gal_display_source/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:65:\"gal_display_source/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"gal_display_source/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"gal_display_source/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:41:\"gal_display_source/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:12:\"robots\\.txt$\";s:18:\"index.php?robots=1\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:27:\"comment-page-([0-9]{1,})/?$\";s:40:\"index.php?&page_id=106&cpage=$matches[1]\";s:17:\"wc-api(/(.*))?/?$\";s:29:\"index.php?&wc-api=$matches[2]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:26:\"comments/wc-api(/(.*))?/?$\";s:29:\"index.php?&wc-api=$matches[2]\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:29:\"search/(.+)/wc-api(/(.*))?/?$\";s:42:\"index.php?s=$matches[1]&wc-api=$matches[3]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:32:\"author/([^/]+)/wc-api(/(.*))?/?$\";s:52:\"index.php?author_name=$matches[1]&wc-api=$matches[3]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:54:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/wc-api(/(.*))?/?$\";s:82:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&wc-api=$matches[5]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:41:\"([0-9]{4})/([0-9]{1,2})/wc-api(/(.*))?/?$\";s:66:\"index.php?year=$matches[1]&monthnum=$matches[2]&wc-api=$matches[4]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:28:\"([0-9]{4})/wc-api(/(.*))?/?$\";s:45:\"index.php?year=$matches[1]&wc-api=$matches[3]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:25:\"(.?.+?)/wc-api(/(.*))?/?$\";s:49:\"index.php?pagename=$matches[1]&wc-api=$matches[3]\";s:28:\"(.?.+?)/order-pay(/(.*))?/?$\";s:52:\"index.php?pagename=$matches[1]&order-pay=$matches[3]\";s:33:\"(.?.+?)/order-received(/(.*))?/?$\";s:57:\"index.php?pagename=$matches[1]&order-received=$matches[3]\";s:25:\"(.?.+?)/orders(/(.*))?/?$\";s:49:\"index.php?pagename=$matches[1]&orders=$matches[3]\";s:29:\"(.?.+?)/view-order(/(.*))?/?$\";s:53:\"index.php?pagename=$matches[1]&view-order=$matches[3]\";s:28:\"(.?.+?)/downloads(/(.*))?/?$\";s:52:\"index.php?pagename=$matches[1]&downloads=$matches[3]\";s:31:\"(.?.+?)/edit-account(/(.*))?/?$\";s:55:\"index.php?pagename=$matches[1]&edit-account=$matches[3]\";s:31:\"(.?.+?)/edit-address(/(.*))?/?$\";s:55:\"index.php?pagename=$matches[1]&edit-address=$matches[3]\";s:34:\"(.?.+?)/payment-methods(/(.*))?/?$\";s:58:\"index.php?pagename=$matches[1]&payment-methods=$matches[3]\";s:32:\"(.?.+?)/lost-password(/(.*))?/?$\";s:56:\"index.php?pagename=$matches[1]&lost-password=$matches[3]\";s:34:\"(.?.+?)/customer-logout(/(.*))?/?$\";s:58:\"index.php?pagename=$matches[1]&customer-logout=$matches[3]\";s:37:\"(.?.+?)/add-payment-method(/(.*))?/?$\";s:61:\"index.php?pagename=$matches[1]&add-payment-method=$matches[3]\";s:40:\"(.?.+?)/delete-payment-method(/(.*))?/?$\";s:64:\"index.php?pagename=$matches[1]&delete-payment-method=$matches[3]\";s:45:\"(.?.+?)/set-default-payment-method(/(.*))?/?$\";s:69:\"index.php?pagename=$matches[1]&set-default-payment-method=$matches[3]\";s:31:\".?.+?/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:42:\".?.+?/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";s:27:\"[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\"[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\"[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"([^/]+)/embed/?$\";s:37:\"index.php?name=$matches[1]&embed=true\";s:20:\"([^/]+)/trackback/?$\";s:31:\"index.php?name=$matches[1]&tb=1\";s:40:\"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:35:\"([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:28:\"([^/]+)/page/?([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&paged=$matches[2]\";s:35:\"([^/]+)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&cpage=$matches[2]\";s:25:\"([^/]+)/wc-api(/(.*))?/?$\";s:45:\"index.php?name=$matches[1]&wc-api=$matches[3]\";s:31:\"[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:42:\"[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:24:\"([^/]+)(?:/([0-9]+))?/?$\";s:43:\"index.php?name=$matches[1]&page=$matches[2]\";s:16:\"[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:26:\"[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:46:\"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:22:\"[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";}","yes");
INSERT INTO `st_options` VALUES("2163","wpseo-gsc","a:1:{s:7:\"profile\";s:0:\"\";}","yes");
INSERT INTO `st_options` VALUES("2175","_transient_timeout_external_ip_address_66.249.93.29","1542906153","no");
INSERT INTO `st_options` VALUES("2176","_transient_external_ip_address_66.249.93.29","185.50.37.139","no");
INSERT INTO `st_options` VALUES("2177","_transient_timeout_external_ip_address_66.249.93.30","1542906163","no");
INSERT INTO `st_options` VALUES("2178","_transient_external_ip_address_66.249.93.30","185.50.37.139","no");
INSERT INTO `st_options` VALUES("1953","gadwp_options","{\"client_id\":\"\",\"client_secret\":\"\",\"access_front\":[\"administrator\"],\"access_back\":[\"administrator\"],\"tableid_jail\":\"\",\"theme_color\":\"#1e73be\",\"switch_profile\":0,\"tracking_type\":\"universal\",\"ga_anonymize_ip\":0,\"user_api\":0,\"ga_event_tracking\":0,\"ga_event_downloads\":\"zip|mp3*|mpe*g|pdf|docx*|pptx*|xlsx*|rar*\",\"track_exclude\":[],\"ga_target_geomap\":\"\",\"ga_realtime_pages\":10,\"token\":\"{\\\"access_token\\\":\\\"ya29.GlxVBj3EO4lE0RIaPRRM6JZG9Spl9mRGutzV1A6nhtd3YSMAu_gMQro828VZdcSboW5JVSjsvpNNed5CyTJUxhNRZDPjDo0IK2E79IjR-wEZlOhLihACWlLb4459AA\\\",\\\"expires_in\\\":3600,\\\"refresh_token\\\":\\\"1\\\\\\/vMjGGwd46drY0hVT1Wwyv5or4LmKOk2t3NeNXdpzMgw\\\",\\\"scope\\\":\\\"https:\\\\\\/\\\\\\/www.googleapis.com\\\\\\/auth\\\\\\/analytics.readonly\\\",\\\"token_type\\\":\\\"Bearer\\\",\\\"created\\\":1542301590}\",\"ga_profiles_list\":[],\"ga_enhanced_links\":0,\"ga_remarketing\":0,\"network_mode\":0,\"ga_speed_samplerate\":1,\"ga_user_samplerate\":100,\"ga_event_bouncerate\":0,\"ga_crossdomain_tracking\":0,\"ga_crossdomain_list\":\"\",\"ga_author_dimindex\":0,\"ga_category_dimindex\":0,\"ga_tag_dimindex\":0,\"ga_user_dimindex\":0,\"ga_pubyear_dimindex\":0,\"ga_pubyearmonth_dimindex\":0,\"ga_aff_tracking\":0,\"ga_event_affiliates\":\"\\/out\\/\",\"automatic_updates_minorversion\":\"1\",\"backend_item_reports\":1,\"backend_realtime_report\":0,\"frontend_item_reports\":0,\"dashboard_widget\":1,\"api_backoff\":0,\"ga_cookiedomain\":\"\",\"ga_cookiename\":\"\",\"ga_cookieexpires\":\"\",\"pagetitle_404\":\"Page Not Found\",\"maps_api_key\":\"\",\"tm_author_var\":0,\"tm_category_var\":0,\"tm_tag_var\":0,\"tm_user_var\":0,\"tm_pubyear_var\":0,\"tm_pubyearmonth_var\":0,\"web_containerid\":\"\",\"amp_containerid\":\"\",\"amp_tracking_tagmanager\":0,\"amp_tracking_analytics\":0,\"amp_tracking_clientidapi\":0,\"trackingcode_infooter\":0,\"trackingevents_infooter\":0,\"ecommerce_mode\":\"disabled\",\"ga_formsubmit_tracking\":0,\"optimize_tracking\":0,\"optimize_containerid\":\"\",\"optimize_pagehiding\":0,\"superadmin_tracking\":0,\"ga_pagescrolldepth_tracking\":0,\"tm_pagescrolldepth_tracking\":0,\"ga_event_precision\":0,\"ga_force_ssl\":0,\"with_endpoint\":1,\"ga_optout\":0,\"ga_dnt_optout\":0,\"tm_optout\":0,\"tm_dnt_optout\":0,\"ga_with_gtag\":0,\"usage_tracking\":1,\"hide_am_notices\":0,\"network_hide_am_notices\":0,\"ga_enhanced_excludesa\":0,\"ga_hash_tracking\":0,\"gadwp_hidden\":\"Y\"}","yes");
INSERT INTO `st_options` VALUES("1954","widget_gadwp-frontwidget-report","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `st_options` VALUES("1955","_amn_exact-metrics_last_checked","1542412800","yes");
INSERT INTO `st_options` VALUES("2125","exactmetrics_usage_tracking_last_checkin","1542298872","yes");
INSERT INTO `st_options` VALUES("2126","exactmetrics_tracking_notice","1","yes");
INSERT INTO `st_options` VALUES("3094","_transient_timeout_jetpack_idc_allowed","1542711225","no");
INSERT INTO `st_options` VALUES("3095","_transient_jetpack_idc_allowed","1","no");
INSERT INTO `st_options` VALUES("3145","_transient_doing_cron","1542761441.8133978843688964843750","yes");
INSERT INTO `st_options` VALUES("1971","gadwp_redeemed_code","4/lQAVy494-LqED8WWPIDhyHGxXSh0Iy9cERR_lYjxznMReq8acTWJV90","yes");
INSERT INTO `st_options` VALUES("2348","wpglobus_option_language_names","a:34:{s:2:\"ar\";s:49:\"&#1575;&#1604;&#1593;&#1585;&#1576;&#1610;&#1577;\";s:2:\"en\";s:7:\"English\";s:2:\"au\";s:12:\"English (AU)\";s:2:\"ca\";s:12:\"English (CA)\";s:2:\"gb\";s:12:\"English (UK)\";s:2:\"zh\";s:32:\"&#31616;&#20307;&#20013;&#25991;\";s:2:\"tw\";s:32:\"&#32321;&#39636;&#20013;&#25991;\";s:2:\"da\";s:5:\"Dansk\";s:2:\"nl\";s:10:\"Nederlands\";s:2:\"gl\";s:6:\"Galego\";s:2:\"de\";s:7:\"Deutsch\";s:2:\"fi\";s:5:\"Suomi\";s:2:\"fr\";s:9:\"Français\";s:2:\"qc\";s:14:\"Français (CA)\";s:2:\"he\";s:35:\"&#1506;&#1489;&#1512;&#1497;&#1514;\";s:2:\"hi\";s:42:\"&#2361;&#2367;&#2344;&#2381;&#2342;&#2368;\";s:2:\"hu\";s:6:\"Magyar\";s:2:\"it\";s:8:\"Italiano\";s:2:\"ja\";s:24:\"&#26085;&#26412;&#35486;\";s:2:\"ko\";s:24:\"&#54620;&#44397;&#50612;\";s:2:\"no\";s:5:\"Norsk\";s:2:\"fa\";s:35:\"&#1601;&#1575;&#1585;&#1587;&#1740;\";s:2:\"pl\";s:6:\"Polski\";s:2:\"pt\";s:10:\"Português\";s:2:\"br\";s:15:\"Português (BR)\";s:2:\"ro\";s:8:\"Română\";s:2:\"ru\";s:14:\"Русский\";s:2:\"es\";s:8:\"Español\";s:2:\"mx\";s:13:\"Español (MX)\";s:2:\"sv\";s:7:\"Svenska\";s:2:\"tr\";s:8:\"Türkçe\";s:2:\"uk\";s:20:\"Українська\";s:2:\"vi\";s:14:\"Tiếng Việt\";s:2:\"cy\";s:7:\"Cymraeg\";}","yes");


DROP TABLE IF EXISTS `st_postmeta`;

CREATE TABLE `st_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM AUTO_INCREMENT=1798 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `st_postmeta` VALUES("1","2","_wp_page_template","default");
INSERT INTO `st_postmeta` VALUES("2","3","_wp_page_template","default");
INSERT INTO `st_postmeta` VALUES("1794","2383","_yoast_wpseo_primary_category","40");
INSERT INTO `st_postmeta` VALUES("1793","2383","_yoast_wpseo_content_score","90");
INSERT INTO `st_postmeta` VALUES("1791","2383","mfn-post-hide-title","0");
INSERT INTO `st_postmeta` VALUES("1792","2383","mfn-post-hide-image","0");
INSERT INTO `st_postmeta` VALUES("1790","2383","mfn-post-slider-layer","0");
INSERT INTO `st_postmeta` VALUES("1788","2383","mfn-post-hide-content","0");
INSERT INTO `st_postmeta` VALUES("1789","2383","mfn-post-slider","0");
INSERT INTO `st_postmeta` VALUES("1787","2383","slide_template","default");
INSERT INTO `st_postmeta` VALUES("1795","2383","mfn-post-love","0");
INSERT INTO `st_postmeta` VALUES("1786","2383","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("1783","2383","wpglobus_language","fa");
INSERT INTO `st_postmeta` VALUES("1782","2383","_edit_lock","1542450394:1");
INSERT INTO `st_postmeta` VALUES("201","29","_edit_lock","1542148901:1");
INSERT INTO `st_postmeta` VALUES("202","60","_wp_attached_file","2018/11/Girl-Reading-Book-Wallpaper.jpg");
INSERT INTO `st_postmeta` VALUES("203","60","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:1200;s:4:\"file\";s:39:\"2018/11/Girl-Reading-Book-Wallpaper.jpg\";s:5:\"sizes\";a:23:{s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:39:\"Girl-Reading-Book-Wallpaper-234x146.jpg\";s:5:\"width\";i:234;s:6:\"height\";i:146;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:37:\"Girl-Reading-Book-Wallpaper-50x31.jpg\";s:5:\"width\";i:50;s:6:\"height\";i:31;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"portfolio-mf\";a:4:{s:4:\"file\";s:39:\"Girl-Reading-Book-Wallpaper-960x750.jpg\";s:5:\"width\";i:960;s:6:\"height\";i:750;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:39:\"Girl-Reading-Book-Wallpaper-960x375.jpg\";s:5:\"width\";i:960;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-t\";a:4:{s:4:\"file\";s:39:\"Girl-Reading-Book-Wallpaper-480x750.jpg\";s:5:\"width\";i:480;s:6:\"height\";i:750;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-list\";a:4:{s:4:\"file\";s:40:\"Girl-Reading-Book-Wallpaper-1160x450.jpg\";s:5:\"width\";i:1160;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-single\";a:4:{s:4:\"file\";s:40:\"Girl-Reading-Book-Wallpaper-1200x480.jpg\";s:5:\"width\";i:1200;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:37:\"Girl-Reading-Book-Wallpaper-80x80.jpg\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:38:\"Girl-Reading-Book-Wallpaper-120x75.jpg\";s:5:\"width\";i:120;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"slider-content\";a:4:{s:4:\"file\";s:39:\"Girl-Reading-Book-Wallpaper-890x470.jpg\";s:5:\"width\";i:890;s:6:\"height\";i:470;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:37:\"Girl-Reading-Book-Wallpaper-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:39:\"Girl-Reading-Book-Wallpaper-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:39:\"Girl-Reading-Book-Wallpaper-600x375.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:39:\"Girl-Reading-Book-Wallpaper-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:39:\"Girl-Reading-Book-Wallpaper-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:39:\"Girl-Reading-Book-Wallpaper-300x188.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:188;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:39:\"Girl-Reading-Book-Wallpaper-768x480.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:40:\"Girl-Reading-Book-Wallpaper-1024x640.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:640;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:39:\"Girl-Reading-Book-Wallpaper-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:39:\"Girl-Reading-Book-Wallpaper-600x375.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:39:\"Girl-Reading-Book-Wallpaper-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:30:\"twentyseventeen-featured-image\";a:4:{s:4:\"file\";s:41:\"Girl-Reading-Book-Wallpaper-1920x1200.jpg\";s:5:\"width\";i:1920;s:6:\"height\";i:1200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:32:\"twentyseventeen-thumbnail-avatar\";a:4:{s:4:\"file\";s:39:\"Girl-Reading-Book-Wallpaper-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("1093","2331","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("90","38","_menu_item_type","post_type");
INSERT INTO `st_postmeta` VALUES("199","27","_edit_last","1");
INSERT INTO `st_postmeta` VALUES("197","58","_wp_attached_file","2018/11/318714-130G210391134.jpg");
INSERT INTO `st_postmeta` VALUES("198","58","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:707;s:4:\"file\";s:32:\"2018/11/318714-130G210391134.jpg\";s:5:\"sizes\";a:21:{s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:32:\"318714-130G210391134-207x146.jpg\";s:5:\"width\";i:207;s:6:\"height\";i:146;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:30:\"318714-130G210391134-50x35.jpg\";s:5:\"width\";i:50;s:6:\"height\";i:35;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"portfolio-mf\";a:4:{s:4:\"file\";s:32:\"318714-130G210391134-960x707.jpg\";s:5:\"width\";i:960;s:6:\"height\";i:707;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:32:\"318714-130G210391134-960x375.jpg\";s:5:\"width\";i:960;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-t\";a:4:{s:4:\"file\";s:32:\"318714-130G210391134-480x707.jpg\";s:5:\"width\";i:480;s:6:\"height\";i:707;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-list\";a:4:{s:4:\"file\";s:33:\"318714-130G210391134-1000x450.jpg\";s:5:\"width\";i:1000;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-single\";a:4:{s:4:\"file\";s:33:\"318714-130G210391134-1000x480.jpg\";s:5:\"width\";i:1000;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:30:\"318714-130G210391134-80x80.jpg\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:31:\"318714-130G210391134-106x75.jpg\";s:5:\"width\";i:106;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"slider-content\";a:4:{s:4:\"file\";s:32:\"318714-130G210391134-890x470.jpg\";s:5:\"width\";i:890;s:6:\"height\";i:470;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:30:\"318714-130G210391134-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:32:\"318714-130G210391134-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:32:\"318714-130G210391134-600x424.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:424;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:32:\"318714-130G210391134-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:32:\"318714-130G210391134-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:32:\"318714-130G210391134-300x212.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:212;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:32:\"318714-130G210391134-768x543.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:543;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:32:\"318714-130G210391134-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:32:\"318714-130G210391134-600x424.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:424;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:32:\"318714-130G210391134-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:32:\"twentyseventeen-thumbnail-avatar\";a:4:{s:4:\"file\";s:32:\"318714-130G210391134-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("196","27","_edit_lock","1542148901:1");
INSERT INTO `st_postmeta` VALUES("89","37","_menu_item_url","http://foolstacks.ir/");
INSERT INTO `st_postmeta` VALUES("204","29","_edit_last","1");
INSERT INTO `st_postmeta` VALUES("1081","29","_wpb_vc_js_status","false");
INSERT INTO `st_postmeta` VALUES("206","26","_edit_lock","1542138417:1");
INSERT INTO `st_postmeta` VALUES("207","61","_wp_attached_file","2018/11/wallpaper.wiki-Cute-Girl-for-Background-PIC-WPC003570.jpg");
INSERT INTO `st_postmeta` VALUES("208","61","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:1200;s:4:\"file\";s:65:\"2018/11/wallpaper.wiki-Cute-Girl-for-Background-PIC-WPC003570.jpg\";s:5:\"sizes\";a:23:{s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:65:\"wallpaper.wiki-Cute-Girl-for-Background-PIC-WPC003570-234x146.jpg\";s:5:\"width\";i:234;s:6:\"height\";i:146;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:63:\"wallpaper.wiki-Cute-Girl-for-Background-PIC-WPC003570-50x31.jpg\";s:5:\"width\";i:50;s:6:\"height\";i:31;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"portfolio-mf\";a:4:{s:4:\"file\";s:65:\"wallpaper.wiki-Cute-Girl-for-Background-PIC-WPC003570-960x750.jpg\";s:5:\"width\";i:960;s:6:\"height\";i:750;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:65:\"wallpaper.wiki-Cute-Girl-for-Background-PIC-WPC003570-960x375.jpg\";s:5:\"width\";i:960;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-t\";a:4:{s:4:\"file\";s:65:\"wallpaper.wiki-Cute-Girl-for-Background-PIC-WPC003570-480x750.jpg\";s:5:\"width\";i:480;s:6:\"height\";i:750;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-list\";a:4:{s:4:\"file\";s:66:\"wallpaper.wiki-Cute-Girl-for-Background-PIC-WPC003570-1160x450.jpg\";s:5:\"width\";i:1160;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-single\";a:4:{s:4:\"file\";s:66:\"wallpaper.wiki-Cute-Girl-for-Background-PIC-WPC003570-1200x480.jpg\";s:5:\"width\";i:1200;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:63:\"wallpaper.wiki-Cute-Girl-for-Background-PIC-WPC003570-80x80.jpg\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:64:\"wallpaper.wiki-Cute-Girl-for-Background-PIC-WPC003570-120x75.jpg\";s:5:\"width\";i:120;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"slider-content\";a:4:{s:4:\"file\";s:65:\"wallpaper.wiki-Cute-Girl-for-Background-PIC-WPC003570-890x470.jpg\";s:5:\"width\";i:890;s:6:\"height\";i:470;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:63:\"wallpaper.wiki-Cute-Girl-for-Background-PIC-WPC003570-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:65:\"wallpaper.wiki-Cute-Girl-for-Background-PIC-WPC003570-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:65:\"wallpaper.wiki-Cute-Girl-for-Background-PIC-WPC003570-600x375.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:65:\"wallpaper.wiki-Cute-Girl-for-Background-PIC-WPC003570-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:65:\"wallpaper.wiki-Cute-Girl-for-Background-PIC-WPC003570-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:65:\"wallpaper.wiki-Cute-Girl-for-Background-PIC-WPC003570-300x188.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:188;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:65:\"wallpaper.wiki-Cute-Girl-for-Background-PIC-WPC003570-768x480.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:66:\"wallpaper.wiki-Cute-Girl-for-Background-PIC-WPC003570-1024x640.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:640;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:65:\"wallpaper.wiki-Cute-Girl-for-Background-PIC-WPC003570-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:65:\"wallpaper.wiki-Cute-Girl-for-Background-PIC-WPC003570-600x375.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:65:\"wallpaper.wiki-Cute-Girl-for-Background-PIC-WPC003570-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:30:\"twentyseventeen-featured-image\";a:4:{s:4:\"file\";s:67:\"wallpaper.wiki-Cute-Girl-for-Background-PIC-WPC003570-1920x1200.jpg\";s:5:\"width\";i:1920;s:6:\"height\";i:1200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:32:\"twentyseventeen-thumbnail-avatar\";a:4:{s:4:\"file\";s:65:\"wallpaper.wiki-Cute-Girl-for-Background-PIC-WPC003570-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("88","37","_menu_item_xfn","");
INSERT INTO `st_postmeta` VALUES("68","26","_customize_changeset_uuid","07ee365d-3e3e-46c4-ab74-fa256f5cca18");
INSERT INTO `st_postmeta` VALUES("86","37","_menu_item_target","");
INSERT INTO `st_postmeta` VALUES("87","37","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `st_postmeta` VALUES("71","27","_customize_changeset_uuid","07ee365d-3e3e-46c4-ab74-fa256f5cca18");
INSERT INTO `st_postmeta` VALUES("85","37","_menu_item_object","custom");
INSERT INTO `st_postmeta` VALUES("74","28","_customize_changeset_uuid","07ee365d-3e3e-46c4-ab74-fa256f5cca18");
INSERT INTO `st_postmeta` VALUES("84","37","_menu_item_object_id","37");
INSERT INTO `st_postmeta` VALUES("77","29","_customize_changeset_uuid","07ee365d-3e3e-46c4-ab74-fa256f5cca18");
INSERT INTO `st_postmeta` VALUES("82","37","_menu_item_type","custom");
INSERT INTO `st_postmeta` VALUES("83","37","_menu_item_menu_item_parent","0");
INSERT INTO `st_postmeta` VALUES("80","30","_customize_changeset_uuid","07ee365d-3e3e-46c4-ab74-fa256f5cca18");
INSERT INTO `st_postmeta` VALUES("81","31","_edit_lock","1541814092:1");
INSERT INTO `st_postmeta` VALUES("91","38","_menu_item_menu_item_parent","0");
INSERT INTO `st_postmeta` VALUES("92","38","_menu_item_object_id","27");
INSERT INTO `st_postmeta` VALUES("93","38","_menu_item_object","page");
INSERT INTO `st_postmeta` VALUES("94","38","_menu_item_target","");
INSERT INTO `st_postmeta` VALUES("95","38","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `st_postmeta` VALUES("96","38","_menu_item_xfn","");
INSERT INTO `st_postmeta` VALUES("97","38","_menu_item_url","");
INSERT INTO `st_postmeta` VALUES("98","39","_menu_item_type","post_type");
INSERT INTO `st_postmeta` VALUES("99","39","_menu_item_menu_item_parent","0");
INSERT INTO `st_postmeta` VALUES("100","39","_menu_item_object_id","29");
INSERT INTO `st_postmeta` VALUES("101","39","_menu_item_object","page");
INSERT INTO `st_postmeta` VALUES("102","39","_menu_item_target","");
INSERT INTO `st_postmeta` VALUES("103","39","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `st_postmeta` VALUES("104","39","_menu_item_xfn","");
INSERT INTO `st_postmeta` VALUES("105","39","_menu_item_url","");
INSERT INTO `st_postmeta` VALUES("106","40","_menu_item_type","post_type");
INSERT INTO `st_postmeta` VALUES("107","40","_menu_item_menu_item_parent","0");
INSERT INTO `st_postmeta` VALUES("108","40","_menu_item_object_id","28");
INSERT INTO `st_postmeta` VALUES("109","40","_menu_item_object","page");
INSERT INTO `st_postmeta` VALUES("110","40","_menu_item_target","");
INSERT INTO `st_postmeta` VALUES("111","40","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `st_postmeta` VALUES("112","40","_menu_item_xfn","");
INSERT INTO `st_postmeta` VALUES("113","40","_menu_item_url","");
INSERT INTO `st_postmeta` VALUES("114","41","_menu_item_type","custom");
INSERT INTO `st_postmeta` VALUES("115","41","_menu_item_menu_item_parent","0");
INSERT INTO `st_postmeta` VALUES("116","41","_menu_item_object_id","41");
INSERT INTO `st_postmeta` VALUES("117","41","_menu_item_object","custom");
INSERT INTO `st_postmeta` VALUES("118","41","_menu_item_target","");
INSERT INTO `st_postmeta` VALUES("119","41","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `st_postmeta` VALUES("120","41","_menu_item_xfn","");
INSERT INTO `st_postmeta` VALUES("121","41","_menu_item_url","https://www.facebook.com/sepidsal");
INSERT INTO `st_postmeta` VALUES("122","42","_menu_item_type","custom");
INSERT INTO `st_postmeta` VALUES("123","42","_menu_item_menu_item_parent","0");
INSERT INTO `st_postmeta` VALUES("124","42","_menu_item_object_id","42");
INSERT INTO `st_postmeta` VALUES("125","42","_menu_item_object","custom");
INSERT INTO `st_postmeta` VALUES("126","42","_menu_item_target","");
INSERT INTO `st_postmeta` VALUES("127","42","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `st_postmeta` VALUES("128","42","_menu_item_xfn","");
INSERT INTO `st_postmeta` VALUES("129","42","_menu_item_url","https://twitter.com/sepidsal");
INSERT INTO `st_postmeta` VALUES("130","43","_menu_item_type","custom");
INSERT INTO `st_postmeta` VALUES("131","43","_menu_item_menu_item_parent","0");
INSERT INTO `st_postmeta` VALUES("132","43","_menu_item_object_id","43");
INSERT INTO `st_postmeta` VALUES("133","43","_menu_item_object","custom");
INSERT INTO `st_postmeta` VALUES("134","43","_menu_item_target","");
INSERT INTO `st_postmeta` VALUES("135","43","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `st_postmeta` VALUES("136","43","_menu_item_xfn","");
INSERT INTO `st_postmeta` VALUES("137","43","_menu_item_url","https://www.instagram.com/sepidsal");
INSERT INTO `st_postmeta` VALUES("138","44","_menu_item_type","custom");
INSERT INTO `st_postmeta` VALUES("139","44","_menu_item_menu_item_parent","0");
INSERT INTO `st_postmeta` VALUES("140","44","_menu_item_object_id","44");
INSERT INTO `st_postmeta` VALUES("141","44","_menu_item_object","custom");
INSERT INTO `st_postmeta` VALUES("142","44","_menu_item_target","");
INSERT INTO `st_postmeta` VALUES("143","44","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `st_postmeta` VALUES("144","44","_menu_item_xfn","");
INSERT INTO `st_postmeta` VALUES("145","44","_menu_item_url","mailto:fullstackdiaries@gmail.com");
INSERT INTO `st_postmeta` VALUES("146","45","_menu_item_type","custom");
INSERT INTO `st_postmeta` VALUES("147","45","_menu_item_menu_item_parent","0");
INSERT INTO `st_postmeta` VALUES("148","45","_menu_item_object_id","45");
INSERT INTO `st_postmeta` VALUES("149","45","_menu_item_object","custom");
INSERT INTO `st_postmeta` VALUES("150","45","_menu_item_target","");
INSERT INTO `st_postmeta` VALUES("151","45","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `st_postmeta` VALUES("152","45","_menu_item_xfn","");
INSERT INTO `st_postmeta` VALUES("153","45","_menu_item_url","https://www.pinterest.com/sepidsal");
INSERT INTO `st_postmeta` VALUES("154","31","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("155","31","_wp_trash_meta_time","1541814151");
INSERT INTO `st_postmeta` VALUES("158","46","_edit_lock","1541814333:1");
INSERT INTO `st_postmeta` VALUES("159","47","_menu_item_type","custom");
INSERT INTO `st_postmeta` VALUES("160","47","_menu_item_menu_item_parent","0");
INSERT INTO `st_postmeta` VALUES("161","47","_menu_item_object_id","47");
INSERT INTO `st_postmeta` VALUES("162","47","_menu_item_object","custom");
INSERT INTO `st_postmeta` VALUES("163","47","_menu_item_target","");
INSERT INTO `st_postmeta` VALUES("164","47","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `st_postmeta` VALUES("165","47","_menu_item_xfn","");
INSERT INTO `st_postmeta` VALUES("166","47","_menu_item_url","https://www.linkedin.com/in/sepideh-saljooghi-94a69a68/");
INSERT INTO `st_postmeta` VALUES("167","48","_menu_item_type","custom");
INSERT INTO `st_postmeta` VALUES("168","48","_menu_item_menu_item_parent","0");
INSERT INTO `st_postmeta` VALUES("169","48","_menu_item_object_id","48");
INSERT INTO `st_postmeta` VALUES("170","48","_menu_item_object","custom");
INSERT INTO `st_postmeta` VALUES("171","48","_menu_item_target","");
INSERT INTO `st_postmeta` VALUES("172","48","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `st_postmeta` VALUES("173","48","_menu_item_xfn","");
INSERT INTO `st_postmeta` VALUES("174","48","_menu_item_url","https://github.com/SepidSal");
INSERT INTO `st_postmeta` VALUES("175","46","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("176","46","_wp_trash_meta_time","1541814337");
INSERT INTO `st_postmeta` VALUES("177","49","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("178","49","_wp_trash_meta_time","1541814476");
INSERT INTO `st_postmeta` VALUES("179","50","_edit_lock","1541814513:1");
INSERT INTO `st_postmeta` VALUES("180","50","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("181","50","_wp_trash_meta_time","1541814521");
INSERT INTO `st_postmeta` VALUES("182","51","_edit_lock","1541814551:1");
INSERT INTO `st_postmeta` VALUES("183","51","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("184","51","_wp_trash_meta_time","1541814561");
INSERT INTO `st_postmeta` VALUES("185","52","_wp_attached_file","2018/11/s1.png");
INSERT INTO `st_postmeta` VALUES("186","52","_wp_attachment_metadata","a:5:{s:5:\"width\";i:230;s:6:\"height\";i:220;s:4:\"file\";s:14:\"2018/11/s1.png\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"s1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:14:\"s1-153x146.png\";s:5:\"width\";i:153;s:6:\"height\";i:146;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:12:\"s1-50x48.png\";s:5:\"width\";i:50;s:6:\"height\";i:48;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:12:\"s1-80x80.png\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:12:\"s1-78x75.png\";s:5:\"width\";i:78;s:6:\"height\";i:75;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:12:\"s1-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:14:\"s1-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:14:\"s1-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:32:\"twentyseventeen-thumbnail-avatar\";a:4:{s:4:\"file\";s:14:\"s1-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("187","53","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("188","53","_wp_trash_meta_time","1541814611");
INSERT INTO `st_postmeta` VALUES("189","54","_wp_attached_file","2018/11/images.png");
INSERT INTO `st_postmeta` VALUES("190","54","_wp_attachment_metadata","a:5:{s:5:\"width\";i:225;s:6:\"height\";i:225;s:4:\"file\";s:18:\"2018/11/images.png\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"images-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:18:\"images-146x146.png\";s:5:\"width\";i:146;s:6:\"height\";i:146;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:16:\"images-50x50.png\";s:5:\"width\";i:50;s:6:\"height\";i:50;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:16:\"images-80x80.png\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:16:\"images-75x75.png\";s:5:\"width\";i:75;s:6:\"height\";i:75;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:16:\"images-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:18:\"images-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:18:\"images-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:32:\"twentyseventeen-thumbnail-avatar\";a:4:{s:4:\"file\";s:18:\"images-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("191","55","_wp_attached_file","2018/11/cropped-images.png");
INSERT INTO `st_postmeta` VALUES("192","55","_wp_attachment_context","custom-logo");
INSERT INTO `st_postmeta` VALUES("193","55","_wp_attachment_metadata","a:5:{s:5:\"width\";i:250;s:6:\"height\";i:250;s:4:\"file\";s:26:\"2018/11/cropped-images.png\";s:5:\"sizes\";a:3:{s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:26:\"cropped-images-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:26:\"cropped-images-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:32:\"twentyseventeen-thumbnail-avatar\";a:4:{s:4:\"file\";s:26:\"cropped-images-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("194","56","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("195","56","_wp_trash_meta_time","1541814652");
INSERT INTO `st_postmeta` VALUES("209","26","_edit_last","1");
INSERT INTO `st_postmeta` VALUES("210","26","_thumbnail_id","61");
INSERT INTO `st_postmeta` VALUES("211","30","_edit_lock","1541815732:1");
INSERT INTO `st_postmeta` VALUES("212","64","_wp_attached_file","2018/11/background-alam-kartun-6.jpg");
INSERT INTO `st_postmeta` VALUES("213","64","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1842;s:6:\"height\";i:1152;s:4:\"file\";s:36:\"2018/11/background-alam-kartun-6.jpg\";s:5:\"sizes\";a:22:{s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"background-alam-kartun-6-233x146.jpg\";s:5:\"width\";i:233;s:6:\"height\";i:146;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:34:\"background-alam-kartun-6-50x31.jpg\";s:5:\"width\";i:50;s:6:\"height\";i:31;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"portfolio-mf\";a:4:{s:4:\"file\";s:36:\"background-alam-kartun-6-960x750.jpg\";s:5:\"width\";i:960;s:6:\"height\";i:750;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:36:\"background-alam-kartun-6-960x375.jpg\";s:5:\"width\";i:960;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-t\";a:4:{s:4:\"file\";s:36:\"background-alam-kartun-6-480x750.jpg\";s:5:\"width\";i:480;s:6:\"height\";i:750;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-list\";a:4:{s:4:\"file\";s:37:\"background-alam-kartun-6-1160x450.jpg\";s:5:\"width\";i:1160;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-single\";a:4:{s:4:\"file\";s:37:\"background-alam-kartun-6-1200x480.jpg\";s:5:\"width\";i:1200;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:34:\"background-alam-kartun-6-80x80.jpg\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:35:\"background-alam-kartun-6-120x75.jpg\";s:5:\"width\";i:120;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"slider-content\";a:4:{s:4:\"file\";s:36:\"background-alam-kartun-6-890x470.jpg\";s:5:\"width\";i:890;s:6:\"height\";i:470;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:34:\"background-alam-kartun-6-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"background-alam-kartun-6-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:36:\"background-alam-kartun-6-600x375.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"background-alam-kartun-6-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"background-alam-kartun-6-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"background-alam-kartun-6-300x188.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:188;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:36:\"background-alam-kartun-6-768x480.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:37:\"background-alam-kartun-6-1024x640.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:640;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"background-alam-kartun-6-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:36:\"background-alam-kartun-6-600x375.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"background-alam-kartun-6-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:32:\"twentyseventeen-thumbnail-avatar\";a:4:{s:4:\"file\";s:36:\"background-alam-kartun-6-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("214","30","_edit_last","1");
INSERT INTO `st_postmeta` VALUES("215","30","_thumbnail_id","64");
INSERT INTO `st_postmeta` VALUES("216","3","_wp_trash_meta_status","draft");
INSERT INTO `st_postmeta` VALUES("217","3","_wp_trash_meta_time","1541815101");
INSERT INTO `st_postmeta` VALUES("218","3","_wp_desired_post_slug","حفظ-حریم-خصوصی");
INSERT INTO `st_postmeta` VALUES("219","28","_edit_lock","1542183729:1");
INSERT INTO `st_postmeta` VALUES("220","67","_wp_attached_file","2018/11/d16b2da711934b95012afad351db7b509bb703614c7d7-GsBNoa-1.jpg");
INSERT INTO `st_postmeta` VALUES("221","67","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1440;s:6:\"height\";i:900;s:4:\"file\";s:66:\"2018/11/d16b2da711934b95012afad351db7b509bb703614c7d7-GsBNoa-1.jpg\";s:5:\"sizes\";a:22:{s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:66:\"d16b2da711934b95012afad351db7b509bb703614c7d7-GsBNoa-1-234x146.jpg\";s:5:\"width\";i:234;s:6:\"height\";i:146;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:64:\"d16b2da711934b95012afad351db7b509bb703614c7d7-GsBNoa-1-50x31.jpg\";s:5:\"width\";i:50;s:6:\"height\";i:31;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"portfolio-mf\";a:4:{s:4:\"file\";s:66:\"d16b2da711934b95012afad351db7b509bb703614c7d7-GsBNoa-1-960x750.jpg\";s:5:\"width\";i:960;s:6:\"height\";i:750;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:66:\"d16b2da711934b95012afad351db7b509bb703614c7d7-GsBNoa-1-960x375.jpg\";s:5:\"width\";i:960;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-t\";a:4:{s:4:\"file\";s:66:\"d16b2da711934b95012afad351db7b509bb703614c7d7-GsBNoa-1-480x750.jpg\";s:5:\"width\";i:480;s:6:\"height\";i:750;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-list\";a:4:{s:4:\"file\";s:67:\"d16b2da711934b95012afad351db7b509bb703614c7d7-GsBNoa-1-1160x450.jpg\";s:5:\"width\";i:1160;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-single\";a:4:{s:4:\"file\";s:67:\"d16b2da711934b95012afad351db7b509bb703614c7d7-GsBNoa-1-1200x480.jpg\";s:5:\"width\";i:1200;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:64:\"d16b2da711934b95012afad351db7b509bb703614c7d7-GsBNoa-1-80x80.jpg\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:65:\"d16b2da711934b95012afad351db7b509bb703614c7d7-GsBNoa-1-120x75.jpg\";s:5:\"width\";i:120;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"slider-content\";a:4:{s:4:\"file\";s:66:\"d16b2da711934b95012afad351db7b509bb703614c7d7-GsBNoa-1-890x470.jpg\";s:5:\"width\";i:890;s:6:\"height\";i:470;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:64:\"d16b2da711934b95012afad351db7b509bb703614c7d7-GsBNoa-1-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:66:\"d16b2da711934b95012afad351db7b509bb703614c7d7-GsBNoa-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:66:\"d16b2da711934b95012afad351db7b509bb703614c7d7-GsBNoa-1-600x375.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:66:\"d16b2da711934b95012afad351db7b509bb703614c7d7-GsBNoa-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:66:\"d16b2da711934b95012afad351db7b509bb703614c7d7-GsBNoa-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:66:\"d16b2da711934b95012afad351db7b509bb703614c7d7-GsBNoa-1-300x188.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:188;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:66:\"d16b2da711934b95012afad351db7b509bb703614c7d7-GsBNoa-1-768x480.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:67:\"d16b2da711934b95012afad351db7b509bb703614c7d7-GsBNoa-1-1024x640.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:640;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:66:\"d16b2da711934b95012afad351db7b509bb703614c7d7-GsBNoa-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:66:\"d16b2da711934b95012afad351db7b509bb703614c7d7-GsBNoa-1-600x375.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:66:\"d16b2da711934b95012afad351db7b509bb703614c7d7-GsBNoa-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:32:\"twentyseventeen-thumbnail-avatar\";a:4:{s:4:\"file\";s:66:\"d16b2da711934b95012afad351db7b509bb703614c7d7-GsBNoa-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("222","28","_edit_last","1");
INSERT INTO `st_postmeta` VALUES("1082","29","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("224","2","_edit_lock","1541815074:1");
INSERT INTO `st_postmeta` VALUES("225","2","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("226","2","_wp_trash_meta_time","1541815219");
INSERT INTO `st_postmeta` VALUES("227","2","_wp_desired_post_slug","برگه-نمونه");
INSERT INTO `st_postmeta` VALUES("228","71","_wp_attached_file","2018/11/myship.jpg");
INSERT INTO `st_postmeta` VALUES("229","71","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1280;s:6:\"height\";i:800;s:4:\"file\";s:18:\"2018/11/myship.jpg\";s:5:\"sizes\";a:22:{s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:18:\"myship-234x146.jpg\";s:5:\"width\";i:234;s:6:\"height\";i:146;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:16:\"myship-50x31.jpg\";s:5:\"width\";i:50;s:6:\"height\";i:31;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"portfolio-mf\";a:4:{s:4:\"file\";s:18:\"myship-960x750.jpg\";s:5:\"width\";i:960;s:6:\"height\";i:750;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:18:\"myship-960x375.jpg\";s:5:\"width\";i:960;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-t\";a:4:{s:4:\"file\";s:18:\"myship-480x750.jpg\";s:5:\"width\";i:480;s:6:\"height\";i:750;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-list\";a:4:{s:4:\"file\";s:19:\"myship-1160x450.jpg\";s:5:\"width\";i:1160;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-single\";a:4:{s:4:\"file\";s:19:\"myship-1200x480.jpg\";s:5:\"width\";i:1200;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:16:\"myship-80x80.jpg\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:17:\"myship-120x75.jpg\";s:5:\"width\";i:120;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"slider-content\";a:4:{s:4:\"file\";s:18:\"myship-890x470.jpg\";s:5:\"width\";i:890;s:6:\"height\";i:470;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:16:\"myship-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:18:\"myship-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:18:\"myship-600x375.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:18:\"myship-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"myship-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"myship-300x188.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:188;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:18:\"myship-768x480.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"myship-1024x640.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:640;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:18:\"myship-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:18:\"myship-600x375.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:18:\"myship-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:32:\"twentyseventeen-thumbnail-avatar\";a:4:{s:4:\"file\";s:18:\"myship-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("230","72","_wp_attached_file","2018/11/cropped-myship.jpg");
INSERT INTO `st_postmeta` VALUES("231","72","_wp_attachment_context","custom-header");
INSERT INTO `st_postmeta` VALUES("232","72","_wp_attachment_metadata","a:5:{s:5:\"width\";i:2000;s:6:\"height\";i:1250;s:4:\"file\";s:26:\"2018/11/cropped-myship.jpg\";s:5:\"sizes\";a:9:{s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:26:\"cropped-myship-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:26:\"cropped-myship-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:26:\"cropped-myship-600x375.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:26:\"cropped-myship-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:26:\"cropped-myship-300x188.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:188;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:26:\"cropped-myship-768x480.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:27:\"cropped-myship-1024x640.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:640;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:30:\"twentyseventeen-featured-image\";a:4:{s:4:\"file\";s:28:\"cropped-myship-2000x1200.jpg\";s:5:\"width\";i:2000;s:6:\"height\";i:1200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:32:\"twentyseventeen-thumbnail-avatar\";a:4:{s:4:\"file\";s:26:\"cropped-myship-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("233","72","_wp_attachment_custom_header_last_used_twentyseventeen","1541815409");
INSERT INTO `st_postmeta` VALUES("234","72","_wp_attachment_is_custom_header","twentyseventeen");
INSERT INTO `st_postmeta` VALUES("235","73","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("236","73","_wp_trash_meta_time","1541815409");
INSERT INTO `st_postmeta` VALUES("237","74","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("238","74","_wp_trash_meta_time","1541815559");
INSERT INTO `st_postmeta` VALUES("239","1","_edit_lock","1542139907:1");
INSERT INTO `st_postmeta` VALUES("240","1","_edit_last","1");
INSERT INTO `st_postmeta` VALUES("245","77","_wp_attached_file","2018/11/402965393-happy-wallpapers.jpg");
INSERT INTO `st_postmeta` VALUES("246","77","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:1200;s:4:\"file\";s:38:\"2018/11/402965393-happy-wallpapers.jpg\";s:5:\"sizes\";a:23:{s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:38:\"402965393-happy-wallpapers-234x146.jpg\";s:5:\"width\";i:234;s:6:\"height\";i:146;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:36:\"402965393-happy-wallpapers-50x31.jpg\";s:5:\"width\";i:50;s:6:\"height\";i:31;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"portfolio-mf\";a:4:{s:4:\"file\";s:38:\"402965393-happy-wallpapers-960x750.jpg\";s:5:\"width\";i:960;s:6:\"height\";i:750;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:38:\"402965393-happy-wallpapers-960x375.jpg\";s:5:\"width\";i:960;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-t\";a:4:{s:4:\"file\";s:38:\"402965393-happy-wallpapers-480x750.jpg\";s:5:\"width\";i:480;s:6:\"height\";i:750;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-list\";a:4:{s:4:\"file\";s:39:\"402965393-happy-wallpapers-1160x450.jpg\";s:5:\"width\";i:1160;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-single\";a:4:{s:4:\"file\";s:39:\"402965393-happy-wallpapers-1200x480.jpg\";s:5:\"width\";i:1200;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:36:\"402965393-happy-wallpapers-80x80.jpg\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:37:\"402965393-happy-wallpapers-120x75.jpg\";s:5:\"width\";i:120;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"slider-content\";a:4:{s:4:\"file\";s:38:\"402965393-happy-wallpapers-890x470.jpg\";s:5:\"width\";i:890;s:6:\"height\";i:470;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:36:\"402965393-happy-wallpapers-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:38:\"402965393-happy-wallpapers-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:38:\"402965393-happy-wallpapers-600x375.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:38:\"402965393-happy-wallpapers-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:38:\"402965393-happy-wallpapers-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:38:\"402965393-happy-wallpapers-300x188.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:188;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:38:\"402965393-happy-wallpapers-768x480.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:39:\"402965393-happy-wallpapers-1024x640.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:640;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:38:\"402965393-happy-wallpapers-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:38:\"402965393-happy-wallpapers-600x375.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:38:\"402965393-happy-wallpapers-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:30:\"twentyseventeen-featured-image\";a:4:{s:4:\"file\";s:40:\"402965393-happy-wallpapers-1920x1200.jpg\";s:5:\"width\";i:1920;s:6:\"height\";i:1200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:32:\"twentyseventeen-thumbnail-avatar\";a:4:{s:4:\"file\";s:38:\"402965393-happy-wallpapers-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("247","78","_wp_attached_file","2018/11/cute-3.jpg");
INSERT INTO `st_postmeta` VALUES("248","78","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:1200;s:4:\"file\";s:18:\"2018/11/cute-3.jpg\";s:5:\"sizes\";a:23:{s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:18:\"cute-3-234x146.jpg\";s:5:\"width\";i:234;s:6:\"height\";i:146;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:16:\"cute-3-50x31.jpg\";s:5:\"width\";i:50;s:6:\"height\";i:31;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"portfolio-mf\";a:4:{s:4:\"file\";s:18:\"cute-3-960x750.jpg\";s:5:\"width\";i:960;s:6:\"height\";i:750;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:18:\"cute-3-960x375.jpg\";s:5:\"width\";i:960;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-t\";a:4:{s:4:\"file\";s:18:\"cute-3-480x750.jpg\";s:5:\"width\";i:480;s:6:\"height\";i:750;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-list\";a:4:{s:4:\"file\";s:19:\"cute-3-1160x450.jpg\";s:5:\"width\";i:1160;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-single\";a:4:{s:4:\"file\";s:19:\"cute-3-1200x480.jpg\";s:5:\"width\";i:1200;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:16:\"cute-3-80x80.jpg\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:17:\"cute-3-120x75.jpg\";s:5:\"width\";i:120;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"slider-content\";a:4:{s:4:\"file\";s:18:\"cute-3-890x470.jpg\";s:5:\"width\";i:890;s:6:\"height\";i:470;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:16:\"cute-3-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:18:\"cute-3-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:18:\"cute-3-600x375.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:18:\"cute-3-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"cute-3-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"cute-3-300x188.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:188;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:18:\"cute-3-768x480.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"cute-3-1024x640.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:640;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:18:\"cute-3-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:18:\"cute-3-600x375.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:18:\"cute-3-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:30:\"twentyseventeen-featured-image\";a:4:{s:4:\"file\";s:20:\"cute-3-1920x1200.jpg\";s:5:\"width\";i:1920;s:6:\"height\";i:1200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:32:\"twentyseventeen-thumbnail-avatar\";a:4:{s:4:\"file\";s:18:\"cute-3-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("249","1","_thumbnail_id","78");
INSERT INTO `st_postmeta` VALUES("252","79","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("253","79","_wp_trash_meta_time","1541815978");
INSERT INTO `st_postmeta` VALUES("254","80","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("255","80","_wp_trash_meta_time","1541816014");
INSERT INTO `st_postmeta` VALUES("1648","2258","settings","eyJvdmVycmlkZV90aHVtYm5haWxfc2V0dGluZ3MiOiIwIiwidGh1bWJuYWlsX3dpZHRoIjoiMjQwIiwidGh1bWJuYWlsX2hlaWdodCI6IjE2MCIsInRodW1ibmFpbF9jcm9wIjoiMSIsImltYWdlc19wZXJfcGFnZSI6IjE2IiwibnVtYmVyX29mX2NvbHVtbnMiOiIwIiwiYWpheF9wYWdpbmF0aW9uIjoiMSIsInNob3dfYWxsX2luX2xpZ2h0Ym94IjoiMCIsInVzZV9pbWFnZWJyb3dzZXJfZWZmZWN0IjoiMCIsInNob3dfc2xpZGVzaG93X2xpbmsiOiIwIiwic2xpZGVzaG93X2xpbmtfdGV4dCI6IlZpZXcgU2xpZGVzaG93IiwiZGlzcGxheV92aWV3IjoiZGVmYXVsdC12aWV3LnBocCIsInRlbXBsYXRlIjoiIiwidXNlX2xpZ2h0Ym94X2VmZmVjdCI6dHJ1ZSwiZGlzcGxheV9ub19pbWFnZXNfZXJyb3IiOjEsImRpc2FibGVfcGFnaW5hdGlvbiI6MCwidGh1bWJuYWlsX3F1YWxpdHkiOiIxMDAiLCJ0aHVtYm5haWxfd2F0ZXJtYXJrIjowLCJuZ2dfdHJpZ2dlcnNfZGlzcGxheSI6Im5ldmVyIiwiX2Vycm9ycyI6W119");
INSERT INTO `st_postmeta` VALUES("1647","2258","id_field","ID");
INSERT INTO `st_postmeta` VALUES("1646","2258","aliases","WyJiYXNpY190aHVtYm5haWwiLCJiYXNpY190aHVtYm5haWxzIiwibmV4dGdlbl9iYXNpY190aHVtYm5haWxzIl0=");
INSERT INTO `st_postmeta` VALUES("1644","2258","__defaults_set","1");
INSERT INTO `st_postmeta` VALUES("1645","2258","entity_types","WyJpbWFnZSJd");
INSERT INTO `st_postmeta` VALUES("1643","2258","hidden_from_igw","");
INSERT INTO `st_postmeta` VALUES("1641","2258","installed_at_version","3.0.16");
INSERT INTO `st_postmeta` VALUES("1642","2258","hidden_from_ui","");
INSERT INTO `st_postmeta` VALUES("697","28","mfn-post-menu","0");
INSERT INTO `st_postmeta` VALUES("698","28","mfn-post-one-page","0");
INSERT INTO `st_postmeta` VALUES("699","28","mfn-post-hide-title","0");
INSERT INTO `st_postmeta` VALUES("700","28","mfn-post-remove-padding","0");
INSERT INTO `st_postmeta` VALUES("1640","2258","name","photocrati-nextgen_basic_thumbnails");
INSERT INTO `st_postmeta` VALUES("1639","2258","view_order","10000");
INSERT INTO `st_postmeta` VALUES("1638","2258","default_source","galleries");
INSERT INTO `st_postmeta` VALUES("1637","2258","preview_image_relpath","/nextgen-gallery/products/photocrati_nextgen/modules/nextgen_basic_gallery/static/thumb_preview.jpg");
INSERT INTO `st_postmeta` VALUES("696","28","mfn-post-slider-layer","0");
INSERT INTO `st_postmeta` VALUES("264","83","_edit_last","1");
INSERT INTO `st_postmeta` VALUES("265","83","_edit_lock","1542119541:1");
INSERT INTO `st_postmeta` VALUES("268","83","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("269","83","slide_template","default");
INSERT INTO `st_postmeta` VALUES("270","83","mfn-post-hide-content","0");
INSERT INTO `st_postmeta` VALUES("271","83","mfn-post-slider","0");
INSERT INTO `st_postmeta` VALUES("272","83","mfn-post-slider-layer","0");
INSERT INTO `st_postmeta` VALUES("273","83","mfn-post-hide-title","0");
INSERT INTO `st_postmeta` VALUES("274","83","mfn-post-hide-image","0");
INSERT INTO `st_postmeta` VALUES("277","83","mfn-post-love","0");
INSERT INTO `st_postmeta` VALUES("278","85","_edit_last","1");
INSERT INTO `st_postmeta` VALUES("279","85","_edit_lock","1542119540:1");
INSERT INTO `st_postmeta` VALUES("292","87","_edit_lock","1542119539:1");
INSERT INTO `st_postmeta` VALUES("282","85","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("283","85","slide_template","default");
INSERT INTO `st_postmeta` VALUES("284","85","mfn-post-hide-content","0");
INSERT INTO `st_postmeta` VALUES("285","85","mfn-post-slider","0");
INSERT INTO `st_postmeta` VALUES("286","85","mfn-post-slider-layer","0");
INSERT INTO `st_postmeta` VALUES("287","85","mfn-post-hide-title","0");
INSERT INTO `st_postmeta` VALUES("288","85","mfn-post-hide-image","0");
INSERT INTO `st_postmeta` VALUES("291","87","_edit_last","1");
INSERT INTO `st_postmeta` VALUES("295","87","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("296","87","slide_template","default");
INSERT INTO `st_postmeta` VALUES("297","87","mfn-post-hide-content","0");
INSERT INTO `st_postmeta` VALUES("298","87","mfn-post-slider","0");
INSERT INTO `st_postmeta` VALUES("299","87","mfn-post-slider-layer","0");
INSERT INTO `st_postmeta` VALUES("300","87","mfn-post-hide-title","0");
INSERT INTO `st_postmeta` VALUES("301","87","mfn-post-hide-image","0");
INSERT INTO `st_postmeta` VALUES("304","87","mfn-post-love","0");
INSERT INTO `st_postmeta` VALUES("305","85","mfn-post-love","0");
INSERT INTO `st_postmeta` VALUES("306","1","mfn-post-love","0");
INSERT INTO `st_postmeta` VALUES("309","89","_wp_attached_file","2015/03/home_webdesign_slide1_bg.jpg");
INSERT INTO `st_postmeta` VALUES("310","89","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:1200;s:4:\"file\";s:36:\"2015/03/home_webdesign_slide1_bg.jpg\";s:5:\"sizes\";a:21:{s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide1_bg-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide1_bg-600x375.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide1_bg-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide1_bg-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide1_bg-300x188.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:188;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide1_bg-768x480.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:37:\"home_webdesign_slide1_bg-1024x640.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:640;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide1_bg-234x146.jpg\";s:5:\"width\";i:234;s:6:\"height\";i:146;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:34:\"home_webdesign_slide1_bg-50x31.jpg\";s:5:\"width\";i:50;s:6:\"height\";i:31;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"portfolio-mf\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide1_bg-960x750.jpg\";s:5:\"width\";i:960;s:6:\"height\";i:750;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide1_bg-960x375.jpg\";s:5:\"width\";i:960;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-t\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide1_bg-480x750.jpg\";s:5:\"width\";i:480;s:6:\"height\";i:750;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-list\";a:4:{s:4:\"file\";s:37:\"home_webdesign_slide1_bg-1160x450.jpg\";s:5:\"width\";i:1160;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-single\";a:4:{s:4:\"file\";s:37:\"home_webdesign_slide1_bg-1200x480.jpg\";s:5:\"width\";i:1200;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:34:\"home_webdesign_slide1_bg-80x80.jpg\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:35:\"home_webdesign_slide1_bg-120x75.jpg\";s:5:\"width\";i:120;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"slider-content\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide1_bg-890x470.jpg\";s:5:\"width\";i:890;s:6:\"height\";i:470;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:34:\"home_webdesign_slide1_bg-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"home_webdesign_slide1_bg-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide1_bg-600x375.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide1_bg-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("311","90","_wp_attached_file","2015/03/home_webdesign_slider_sep.png");
INSERT INTO `st_postmeta` VALUES("312","90","_wp_attachment_metadata","a:5:{s:5:\"width\";i:83;s:6:\"height\";i:3;s:4:\"file\";s:37:\"2015/03/home_webdesign_slider_sep.png\";s:5:\"sizes\";a:2:{s:5:\"50x50\";a:4:{s:4:\"file\";s:34:\"home_webdesign_slider_sep-50x2.png\";s:5:\"width\";i:50;s:6:\"height\";i:2;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:34:\"home_webdesign_slider_sep-80x3.png\";s:5:\"width\";i:80;s:6:\"height\";i:3;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("313","91","_wp_attached_file","2015/03/home_webdesign_newsletter_bg.jpg");
INSERT INTO `st_postmeta` VALUES("314","91","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:972;s:4:\"file\";s:40:\"2015/03/home_webdesign_newsletter_bg.jpg\";s:5:\"sizes\";a:21:{s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:40:\"home_webdesign_newsletter_bg-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:40:\"home_webdesign_newsletter_bg-600x304.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:304;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:40:\"home_webdesign_newsletter_bg-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:40:\"home_webdesign_newsletter_bg-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:40:\"home_webdesign_newsletter_bg-300x152.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:152;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:40:\"home_webdesign_newsletter_bg-768x389.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:389;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:41:\"home_webdesign_newsletter_bg-1024x518.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:518;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:40:\"home_webdesign_newsletter_bg-260x132.jpg\";s:5:\"width\";i:260;s:6:\"height\";i:132;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:38:\"home_webdesign_newsletter_bg-50x25.jpg\";s:5:\"width\";i:50;s:6:\"height\";i:25;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"portfolio-mf\";a:4:{s:4:\"file\";s:40:\"home_webdesign_newsletter_bg-960x750.jpg\";s:5:\"width\";i:960;s:6:\"height\";i:750;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:40:\"home_webdesign_newsletter_bg-960x375.jpg\";s:5:\"width\";i:960;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-t\";a:4:{s:4:\"file\";s:40:\"home_webdesign_newsletter_bg-480x750.jpg\";s:5:\"width\";i:480;s:6:\"height\";i:750;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-list\";a:4:{s:4:\"file\";s:41:\"home_webdesign_newsletter_bg-1160x450.jpg\";s:5:\"width\";i:1160;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-single\";a:4:{s:4:\"file\";s:41:\"home_webdesign_newsletter_bg-1200x480.jpg\";s:5:\"width\";i:1200;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:38:\"home_webdesign_newsletter_bg-80x80.jpg\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:39:\"home_webdesign_newsletter_bg-148x75.jpg\";s:5:\"width\";i:148;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"slider-content\";a:4:{s:4:\"file\";s:40:\"home_webdesign_newsletter_bg-890x470.jpg\";s:5:\"width\";i:890;s:6:\"height\";i:470;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:38:\"home_webdesign_newsletter_bg-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:40:\"home_webdesign_newsletter_bg-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:40:\"home_webdesign_newsletter_bg-600x304.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:304;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:40:\"home_webdesign_newsletter_bg-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("315","92","_wp_attached_file","2015/03/home_webdesign_new.png");
INSERT INTO `st_postmeta` VALUES("316","92","_wp_attachment_metadata","a:5:{s:5:\"width\";i:375;s:6:\"height\";i:110;s:4:\"file\";s:30:\"2015/03/home_webdesign_new.png\";s:5:\"sizes\";a:11:{s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:30:\"home_webdesign_new-300x110.png\";s:5:\"width\";i:300;s:6:\"height\";i:110;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:30:\"home_webdesign_new-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:30:\"home_webdesign_new-150x110.png\";s:5:\"width\";i:150;s:6:\"height\";i:110;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:29:\"home_webdesign_new-300x88.png\";s:5:\"width\";i:300;s:6:\"height\";i:88;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:29:\"home_webdesign_new-260x76.png\";s:5:\"width\";i:260;s:6:\"height\";i:76;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:28:\"home_webdesign_new-50x15.png\";s:5:\"width\";i:50;s:6:\"height\";i:15;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:28:\"home_webdesign_new-80x80.png\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:29:\"home_webdesign_new-150x44.png\";s:5:\"width\";i:150;s:6:\"height\";i:44;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:28:\"home_webdesign_new-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:30:\"home_webdesign_new-300x110.png\";s:5:\"width\";i:300;s:6:\"height\";i:110;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:30:\"home_webdesign_new-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("317","93","_wp_attached_file","2015/03/client_11.png");
INSERT INTO `st_postmeta` VALUES("318","93","_wp_attachment_metadata","a:5:{s:5:\"width\";i:155;s:6:\"height\";i:80;s:4:\"file\";s:21:\"2015/03/client_11.png\";s:5:\"sizes\";a:7:{s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:20:\"client_11-100x80.png\";s:5:\"width\";i:100;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"client_11-150x80.png\";s:5:\"width\";i:150;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:19:\"client_11-50x26.png\";s:5:\"width\";i:50;s:6:\"height\";i:26;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:19:\"client_11-80x80.png\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:20:\"client_11-145x75.png\";s:5:\"width\";i:145;s:6:\"height\";i:75;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:19:\"client_11-85x80.png\";s:5:\"width\";i:85;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:20:\"client_11-100x80.png\";s:5:\"width\";i:100;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("319","94","_wp_attached_file","2015/03/client_22.png");
INSERT INTO `st_postmeta` VALUES("320","94","_wp_attachment_metadata","a:5:{s:5:\"width\";i:155;s:6:\"height\";i:80;s:4:\"file\";s:21:\"2015/03/client_22.png\";s:5:\"sizes\";a:7:{s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:20:\"client_22-100x80.png\";s:5:\"width\";i:100;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"client_22-150x80.png\";s:5:\"width\";i:150;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:19:\"client_22-50x26.png\";s:5:\"width\";i:50;s:6:\"height\";i:26;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:19:\"client_22-80x80.png\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:20:\"client_22-145x75.png\";s:5:\"width\";i:145;s:6:\"height\";i:75;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:19:\"client_22-85x80.png\";s:5:\"width\";i:85;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:20:\"client_22-100x80.png\";s:5:\"width\";i:100;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("321","95","_wp_attached_file","2015/03/client_33.png");
INSERT INTO `st_postmeta` VALUES("322","95","_wp_attachment_metadata","a:5:{s:5:\"width\";i:155;s:6:\"height\";i:80;s:4:\"file\";s:21:\"2015/03/client_33.png\";s:5:\"sizes\";a:7:{s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:20:\"client_33-100x80.png\";s:5:\"width\";i:100;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"client_33-150x80.png\";s:5:\"width\";i:150;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:19:\"client_33-50x26.png\";s:5:\"width\";i:50;s:6:\"height\";i:26;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:19:\"client_33-80x80.png\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:20:\"client_33-145x75.png\";s:5:\"width\";i:145;s:6:\"height\";i:75;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:19:\"client_33-85x80.png\";s:5:\"width\";i:85;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:20:\"client_33-100x80.png\";s:5:\"width\";i:100;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("323","23","_wp_attached_file","2015/03/client_44.png");
INSERT INTO `st_postmeta` VALUES("324","23","_wp_attachment_metadata","a:5:{s:5:\"width\";i:155;s:6:\"height\";i:80;s:4:\"file\";s:21:\"2015/03/client_44.png\";s:5:\"sizes\";a:7:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"client_44-150x80.png\";s:5:\"width\";i:150;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:19:\"client_44-50x26.png\";s:5:\"width\";i:50;s:6:\"height\";i:26;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:19:\"client_44-80x80.png\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:20:\"client_44-145x75.png\";s:5:\"width\";i:145;s:6:\"height\";i:75;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:19:\"client_44-85x80.png\";s:5:\"width\";i:85;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:20:\"client_44-100x80.png\";s:5:\"width\";i:100;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:20:\"client_44-100x80.png\";s:5:\"width\";i:100;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("325","96","_wp_attached_file","2015/03/home_webdesign_pattern1.png");
INSERT INTO `st_postmeta` VALUES("326","96","_wp_attachment_metadata","a:5:{s:5:\"width\";i:7;s:6:\"height\";i:7;s:4:\"file\";s:35:\"2015/03/home_webdesign_pattern1.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("327","97","_wp_attached_file","2015/03/home_webdesign_about_bg.jpg");
INSERT INTO `st_postmeta` VALUES("328","97","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:607;s:4:\"file\";s:35:\"2015/03/home_webdesign_about_bg.jpg\";s:5:\"sizes\";a:21:{s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:35:\"home_webdesign_about_bg-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:35:\"home_webdesign_about_bg-600x190.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:190;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:35:\"home_webdesign_about_bg-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:35:\"home_webdesign_about_bg-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:34:\"home_webdesign_about_bg-300x95.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:95;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:35:\"home_webdesign_about_bg-768x243.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:243;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:36:\"home_webdesign_about_bg-1024x324.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:324;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:34:\"home_webdesign_about_bg-260x82.jpg\";s:5:\"width\";i:260;s:6:\"height\";i:82;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:33:\"home_webdesign_about_bg-50x16.jpg\";s:5:\"width\";i:50;s:6:\"height\";i:16;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"portfolio-mf\";a:4:{s:4:\"file\";s:35:\"home_webdesign_about_bg-960x607.jpg\";s:5:\"width\";i:960;s:6:\"height\";i:607;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:35:\"home_webdesign_about_bg-960x375.jpg\";s:5:\"width\";i:960;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-t\";a:4:{s:4:\"file\";s:35:\"home_webdesign_about_bg-480x607.jpg\";s:5:\"width\";i:480;s:6:\"height\";i:607;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-list\";a:4:{s:4:\"file\";s:36:\"home_webdesign_about_bg-1160x450.jpg\";s:5:\"width\";i:1160;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-single\";a:4:{s:4:\"file\";s:36:\"home_webdesign_about_bg-1200x480.jpg\";s:5:\"width\";i:1200;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:33:\"home_webdesign_about_bg-80x80.jpg\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:34:\"home_webdesign_about_bg-150x47.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:47;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"slider-content\";a:4:{s:4:\"file\";s:35:\"home_webdesign_about_bg-890x470.jpg\";s:5:\"width\";i:890;s:6:\"height\";i:470;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:33:\"home_webdesign_about_bg-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:35:\"home_webdesign_about_bg-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:35:\"home_webdesign_about_bg-600x190.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:190;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:35:\"home_webdesign_about_bg-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("329","98","_wp_attached_file","2015/03/client_1.png");
INSERT INTO `st_postmeta` VALUES("330","98","_wp_attachment_metadata","a:5:{s:5:\"width\";i:155;s:6:\"height\";i:80;s:4:\"file\";s:20:\"2015/03/client_1.png\";s:5:\"sizes\";a:7:{s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:19:\"client_1-100x80.png\";s:5:\"width\";i:100;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"client_1-150x80.png\";s:5:\"width\";i:150;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:18:\"client_1-50x26.png\";s:5:\"width\";i:50;s:6:\"height\";i:26;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:18:\"client_1-80x80.png\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:19:\"client_1-145x75.png\";s:5:\"width\";i:145;s:6:\"height\";i:75;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:18:\"client_1-85x80.png\";s:5:\"width\";i:85;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:19:\"client_1-100x80.png\";s:5:\"width\";i:100;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("331","99","_wp_attached_file","2015/03/client_2.png");
INSERT INTO `st_postmeta` VALUES("332","99","_wp_attachment_metadata","a:5:{s:5:\"width\";i:155;s:6:\"height\";i:80;s:4:\"file\";s:20:\"2015/03/client_2.png\";s:5:\"sizes\";a:7:{s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:19:\"client_2-100x80.png\";s:5:\"width\";i:100;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"client_2-150x80.png\";s:5:\"width\";i:150;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:18:\"client_2-50x26.png\";s:5:\"width\";i:50;s:6:\"height\";i:26;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:18:\"client_2-80x80.png\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:19:\"client_2-145x75.png\";s:5:\"width\";i:145;s:6:\"height\";i:75;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:18:\"client_2-85x80.png\";s:5:\"width\";i:85;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:19:\"client_2-100x80.png\";s:5:\"width\";i:100;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("333","100","_wp_attached_file","2015/03/client_3.png");
INSERT INTO `st_postmeta` VALUES("334","100","_wp_attachment_metadata","a:5:{s:5:\"width\";i:155;s:6:\"height\";i:80;s:4:\"file\";s:20:\"2015/03/client_3.png\";s:5:\"sizes\";a:7:{s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:19:\"client_3-100x80.png\";s:5:\"width\";i:100;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"client_3-150x80.png\";s:5:\"width\";i:150;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:18:\"client_3-50x26.png\";s:5:\"width\";i:50;s:6:\"height\";i:26;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:18:\"client_3-80x80.png\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:19:\"client_3-145x75.png\";s:5:\"width\";i:145;s:6:\"height\";i:75;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:18:\"client_3-85x80.png\";s:5:\"width\";i:85;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:19:\"client_3-100x80.png\";s:5:\"width\";i:100;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("335","101","_wp_attached_file","2015/03/client_4.png");
INSERT INTO `st_postmeta` VALUES("336","101","_wp_attachment_metadata","a:5:{s:5:\"width\";i:155;s:6:\"height\";i:80;s:4:\"file\";s:20:\"2015/03/client_4.png\";s:5:\"sizes\";a:7:{s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:19:\"client_4-100x80.png\";s:5:\"width\";i:100;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"client_4-150x80.png\";s:5:\"width\";i:150;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:18:\"client_4-50x26.png\";s:5:\"width\";i:50;s:6:\"height\";i:26;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:18:\"client_4-80x80.png\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:19:\"client_4-145x75.png\";s:5:\"width\";i:145;s:6:\"height\";i:75;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:18:\"client_4-85x80.png\";s:5:\"width\";i:85;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:19:\"client_4-100x80.png\";s:5:\"width\";i:100;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("337","102","_wp_attached_file","2015/03/home_webdesign_pattern2.png");
INSERT INTO `st_postmeta` VALUES("338","102","_wp_attachment_metadata","a:5:{s:5:\"width\";i:7;s:6:\"height\";i:7;s:4:\"file\";s:35:\"2015/03/home_webdesign_pattern2.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("339","103","_wp_attached_file","2015/03/home_webdesign_ico_c.png");
INSERT INTO `st_postmeta` VALUES("340","103","_wp_attachment_metadata","a:5:{s:5:\"width\";i:49;s:6:\"height\";i:45;s:4:\"file\";s:32:\"2015/03/home_webdesign_ico_c.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("341","104","_wp_attached_file","2015/03/home_webdesign_pattern3.png");
INSERT INTO `st_postmeta` VALUES("342","104","_wp_attachment_metadata","a:5:{s:5:\"width\";i:20;s:6:\"height\";i:61;s:4:\"file\";s:35:\"2015/03/home_webdesign_pattern3.png\";s:5:\"sizes\";a:1:{s:5:\"50x50\";a:4:{s:4:\"file\";s:33:\"home_webdesign_pattern3-16x50.png\";s:5:\"width\";i:16;s:6:\"height\";i:50;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("536","2196","_wp_attached_file","2015/03/home_webdesign_footer_logo-1.png");
INSERT INTO `st_postmeta` VALUES("345","105","mfn-post-love","0");
INSERT INTO `st_postmeta` VALUES("346","106","_wp_page_template","default");
INSERT INTO `st_postmeta` VALUES("1768","106","mfn-page-items-seo","<div style=\"border: 1px solid #797979; padding: 20px 30px 15px; display: inline-block; border-radius: 5px; background: #fff; ;\">
<img style=\"display: inline-block;\" src=\"http://foolstacks.ir/wp-content/uploads/2018/11/Web-Design-Blog-Image.jpg\" alt=\"\" />
<span style=\"font-size: 54px; line-height: 54px; font-weight: 300; color: #000000; display: inline-block; top: -8px; position: relative; margin-left: 20px;\"></span>
</div>

<h2>چه چیزهایی پیشنهاد می کنیم؟ </h2>
<h5>وردپرس، فروشگاه، پرتال، بلاگ، برندسازی و ...</h5>

center

<img src=\"http://foolstacks.ir/wp-content/uploads/2018/11/blog.png\" alt=\"\"/>

#0c7baf

بلاگ نویسی

<a href=\"http://foolstacks.ir/?page_id=2315\">http://foolstacks.ir/?page_id=2315</a>

<img src=\"http://foolstacks.ir/wp-content/uploads/2018/11/portal.png\" alt=\"\"/>

#ec2e85

پرتال سازمانی

<a href=\"http://foolstacks.ir/?page_id=2313\">http://foolstacks.ir/?page_id=2313</a>

default

<img src=\"http://foolstacks.ir/wp-content/uploads/2018/11/store-1.png\" alt=\"\"/>

#e8a735

فروشگاه

<a href=\"http://foolstacks.ir/?page_id=2323\">http://foolstacks.ir/?page_id=2323</a>

<img src=\"http://foolstacks.ir/wp-content/uploads/2018/11/wp.jpg\" alt=\"\"/>

#0c325f

وردپرس

<a href=\"http://foolstacks.ir/?page_id=2319\">http://foolstacks.ir/?page_id=2319</a>

<img src=\"http://foolstacks.ir/wp-content/uploads/2018/11/brand.png\" alt=\"\"/>

#0c325f

برندسازی

<a href=\"http://foolstacks.ir/?page_id=2317\">http://foolstacks.ir/?page_id=2317</a>

Button

[button title=\"بازدید از وبلاگ\" link=\"http://foolstacks.ir/?page_id=29\" color=\"#000000\" font_color=\"#000000\" large=\"1\" ]

center

<h2>و طراحی صدها سایت دیگر <br/>
 برای معرفی <br/>
و پیش برد کسب و کار شماr</h2>
[divider height=\"40\"]

[divider height=\"40\"]
<a style=\"font-size: 24px; line-height: 24px;\" href=\"http://foolstacks.ir/%D8%AF%D8%B1%D8%A8%D8%A7%D8%B1%D9%87/\">در باره ما بیشتر بدانید</a>

Our clients

<h3>برخی از مشتریان ما</h3>

<img src=\"http://foolstacks.ir/wp-content/uploads/2015/03/client_33.png\" alt=\"\"/>

http://foolstacks.ir/wp-content/uploads/2015/03/client_3.png

<a href=\"#\">#</a>

<img src=\"http://foolstacks.ir/wp-content/uploads/2015/03/client_11.png\" alt=\"\"/>

http://foolstacks.ir/wp-content/uploads/2015/03/client_1.png

<a href=\"#\">#</a>

<img src=\"http://foolstacks.ir/wp-content/uploads/2015/03/client_44.png\" alt=\"\"/>

http://foolstacks.ir/wp-content/uploads/2015/03/client_4.png

<a href=\"#\">#</a>

<img src=\"http://foolstacks.ir/wp-content/uploads/2015/03/client_22.png\" alt=\"\"/>

http://foolstacks.ir/wp-content/uploads/2015/03/client_2.png

<a href=\"#\">#</a>

http://foolstacks.ir/wp-content/uploads/2015/03/home_webdesign_new.png

Sign in

<h3 style=\"color: #fff; position: relative; top: -9px; margin-left: 10px\"><span class=\"themecolor\" style=\"font-weight: 700;\">با ما فقط به اوج فکرکنید</span><br />
پروژه های جدید<br />
به روز رسانی سریع</h3>

");
INSERT INTO `st_postmeta` VALUES("1766","106","slide_template","default");
INSERT INTO `st_postmeta` VALUES("1767","106","mfn-page-items","YTo1OntpOjA7YToyOntzOjQ6ImF0dHIiO2E6MTY6e3M6NToidGl0bGUiO3M6MDoiIjtzOjg6ImJnX2NvbG9yIjtzOjA6IiI7czo4OiJiZ19pbWFnZSI7czo3NToiaHR0cDovL2Zvb2xzdGFja3MuaXIvd3AtY29udGVudC91cGxvYWRzLzIwMTUvMDMvaG9tZV93ZWJkZXNpZ25fcGF0dGVybjEucG5nIjtzOjExOiJiZ19wb3NpdGlvbiI7czoxNToicmVwZWF0O2NlbnRlcjs7IjtzOjEyOiJiZ192aWRlb19tcDQiO3M6MDoiIjtzOjEyOiJiZ192aWRlb19vZ3YiO3M6MDoiIjtzOjEzOiJjb2x1bW5fbWFyZ2luIjtzOjA6IiI7czoxMToicGFkZGluZ190b3AiO3M6MjoiNzAiO3M6MTQ6InBhZGRpbmdfYm90dG9tIjtzOjI6IjMwIjtzOjc6ImRpdmlkZXIiO3M6MDoiIjtzOjY6ImxheW91dCI7czoxMDoibm8tc2lkZWJhciI7czoxMDoibmF2aWdhdGlvbiI7czowOiIiO3M6NToic3R5bGUiO3M6MDoiIjtzOjU6ImNsYXNzIjtzOjA6IiI7czoxMDoic2VjdGlvbl9pZCI7czowOiIiO3M6MTA6InZpc2liaWxpdHkiO3M6MDoiIjt9czo1OiJpdGVtcyI7YToxOntpOjA7YTozOntzOjQ6InR5cGUiO3M6NjoiY29sdW1uIjtzOjQ6InNpemUiO3M6MzoiMS8xIjtzOjY6ImZpZWxkcyI7YTo3OntzOjU6InRpdGxlIjtzOjA6IiI7czo3OiJjb250ZW50IjtzOjQzMzoiPGRpdiBzdHlsZT0iYm9yZGVyOiAxcHggc29saWQgIzc5Nzk3OTsgcGFkZGluZzogMjBweCAzMHB4IDE1cHg7IGRpc3BsYXk6IGlubGluZS1ibG9jazsgYm9yZGVyLXJhZGl1czogNXB4OyBiYWNrZ3JvdW5kOiAjZmZmOyA7Ij4NCjxpbWcgc3R5bGU9ImRpc3BsYXk6IGlubGluZS1ibG9jazsiIHNyYz0iaHR0cDovL2Zvb2xzdGFja3MuaXIvd3AtY29udGVudC91cGxvYWRzLzIwMTgvMTEvV2ViLURlc2lnbi1CbG9nLUltYWdlLmpwZyIgYWx0PSIiIC8+DQo8c3BhbiBzdHlsZT0iZm9udC1zaXplOiA1NHB4OyBsaW5lLWhlaWdodDogNTRweDsgZm9udC13ZWlnaHQ6IDMwMDsgY29sb3I6ICMwMDAwMDA7IGRpc3BsYXk6IGlubGluZS1ibG9jazsgdG9wOiAtOHB4OyBwb3NpdGlvbjogcmVsYXRpdmU7IG1hcmdpbi1sZWZ0OiAyMHB4OyI+PC9zcGFuPg0KPC9kaXY+DQoNCiI7czo1OiJhbGlnbiI7czowOiIiO3M6OToiY29sdW1uX2JnIjtzOjA6IiI7czo3OiJwYWRkaW5nIjtzOjA6IiI7czo3OiJhbmltYXRlIjtzOjA6IiI7czo3OiJjbGFzc2VzIjtzOjA6IiI7fX19fWk6MTthOjI6e3M6NDoiYXR0ciI7YToxNjp7czo1OiJ0aXRsZSI7czowOiIiO3M6ODoiYmdfY29sb3IiO3M6MDoiIjtzOjg6ImJnX2ltYWdlIjtzOjA6IiI7czoxMToiYmdfcG9zaXRpb24iO3M6MjI6Im5vLXJlcGVhdDtjZW50ZXIgdG9wOzsiO3M6MTI6ImJnX3ZpZGVvX21wNCI7czowOiIiO3M6MTI6ImJnX3ZpZGVvX29ndiI7czowOiIiO3M6MTM6ImNvbHVtbl9tYXJnaW4iO3M6MDoiIjtzOjExOiJwYWRkaW5nX3RvcCI7czoyOiI3MCI7czoxNDoicGFkZGluZ19ib3R0b20iO3M6MToiMCI7czo3OiJkaXZpZGVyIjtzOjA6IiI7czo2OiJsYXlvdXQiO3M6MTA6Im5vLXNpZGViYXIiO3M6MTA6Im5hdmlnYXRpb24iO3M6MDoiIjtzOjU6InN0eWxlIjtzOjA6IiI7czo1OiJjbGFzcyI7czowOiIiO3M6MTA6InNlY3Rpb25faWQiO3M6MDoiIjtzOjEwOiJ2aXNpYmlsaXR5IjtzOjA6IiI7fXM6NToiaXRlbXMiO2E6ODp7aTowO2E6Mzp7czo0OiJ0eXBlIjtzOjY6ImNvbHVtbiI7czo0OiJzaXplIjtzOjM6IjEvMSI7czo2OiJmaWVsZHMiO2E6Nzp7czo1OiJ0aXRsZSI7czowOiIiO3M6NzoiY29udGVudCI7czoxNTI6IjxoMj7ahtmHINqG24zYstmH2KfbjNuMINm+24zYtNmG2YfYp9ivINmF24wg2qnZhtuM2YXYnyA8L2gyPg0KPGg1PtmI2LHYr9m+2LHYs9iMINmB2LHZiNi02q/Yp9mH2Iwg2b7Ysdiq2KfZhNiMINio2YTYp9qv2Iwg2KjYsdmG2K/Ys9in2LLbjCDZiCAuLi48L2g1Pg0KIjtzOjU6ImFsaWduIjtzOjY6ImNlbnRlciI7czo5OiJjb2x1bW5fYmciO3M6MDoiIjtzOjc6InBhZGRpbmciO3M6MDoiIjtzOjc6ImFuaW1hdGUiO3M6MDoiIjtzOjc6ImNsYXNzZXMiO3M6MDoiIjt9fWk6MTthOjM6e3M6NDoidHlwZSI7czo4OiJ6b29tX2JveCI7czo0OiJzaXplIjtzOjM6IjEvMiI7czo2OiJmaWVsZHMiO2E6Nzp7czo1OiJpbWFnZSI7czo1NjoiaHR0cDovL2Zvb2xzdGFja3MuaXIvd3AtY29udGVudC91cGxvYWRzLzIwMTgvMTEvYmxvZy5wbmciO3M6ODoiYmdfY29sb3IiO3M6NzoiIzBjN2JhZiI7czoxMzoiY29udGVudF9pbWFnZSI7czowOiIiO3M6NzoiY29udGVudCI7czoxOToi2KjZhNin2q8g2YbZiNuM2LPbjCI7czo0OiJsaW5rIjtzOjM1OiJodHRwOi8vZm9vbHN0YWNrcy5pci8/cGFnZV9pZD0yMzE1ICI7czo2OiJ0YXJnZXQiO3M6MToiMCI7czo3OiJjbGFzc2VzIjtzOjA6IiI7fX1pOjI7YTozOntzOjQ6InR5cGUiO3M6ODoiem9vbV9ib3giO3M6NDoic2l6ZSI7czozOiIxLzIiO3M6NjoiZmllbGRzIjthOjc6e3M6NToiaW1hZ2UiO3M6NTg6Imh0dHA6Ly9mb29sc3RhY2tzLmlyL3dwLWNvbnRlbnQvdXBsb2Fkcy8yMDE4LzExL3BvcnRhbC5wbmciO3M6ODoiYmdfY29sb3IiO3M6NzoiI2VjMmU4NSI7czoxMzoiY29udGVudF9pbWFnZSI7czowOiIiO3M6NzoiY29udGVudCI7czoyNToi2b7Ysdiq2KfZhCDYs9in2LLZhdin2YbbjCI7czo0OiJsaW5rIjtzOjM0OiJodHRwOi8vZm9vbHN0YWNrcy5pci8/cGFnZV9pZD0yMzEzIjtzOjY6InRhcmdldCI7czoxOiIwIjtzOjc6ImNsYXNzZXMiO3M6MDoiIjt9fWk6MzthOjM6e3M6NDoidHlwZSI7czo3OiJkaXZpZGVyIjtzOjQ6InNpemUiO3M6MzoiMS8xIjtzOjY6ImZpZWxkcyI7YTo1OntzOjY6ImhlaWdodCI7czowOiIiO3M6NToic3R5bGUiO3M6NzoiZGVmYXVsdCI7czo0OiJsaW5lIjtzOjA6IiI7czoxMDoidGhlbWVjb2xvciI7czoxOiIwIjtzOjc6ImNsYXNzZXMiO3M6MDoiIjt9fWk6NDthOjM6e3M6NDoidHlwZSI7czo4OiJ6b29tX2JveCI7czo0OiJzaXplIjtzOjM6IjEvMyI7czo2OiJmaWVsZHMiO2E6Nzp7czo1OiJpbWFnZSI7czo1OToiaHR0cDovL2Zvb2xzdGFja3MuaXIvd3AtY29udGVudC91cGxvYWRzLzIwMTgvMTEvc3RvcmUtMS5wbmciO3M6ODoiYmdfY29sb3IiO3M6NzoiI2U4YTczNSI7czoxMzoiY29udGVudF9pbWFnZSI7czowOiIiO3M6NzoiY29udGVudCI7czoxNDoi2YHYsdmI2LTar9in2YciO3M6NDoibGluayI7czozNDoiaHR0cDovL2Zvb2xzdGFja3MuaXIvP3BhZ2VfaWQ9MjMyMyI7czo2OiJ0YXJnZXQiO3M6MToiMCI7czo3OiJjbGFzc2VzIjtzOjA6IiI7fX1pOjU7YTozOntzOjQ6InR5cGUiO3M6ODoiem9vbV9ib3giO3M6NDoic2l6ZSI7czozOiIxLzMiO3M6NjoiZmllbGRzIjthOjc6e3M6NToiaW1hZ2UiO3M6NTQ6Imh0dHA6Ly9mb29sc3RhY2tzLmlyL3dwLWNvbnRlbnQvdXBsb2Fkcy8yMDE4LzExL3dwLmpwZyI7czo4OiJiZ19jb2xvciI7czo3OiIjMGMzMjVmIjtzOjEzOiJjb250ZW50X2ltYWdlIjtzOjA6IiI7czo3OiJjb250ZW50IjtzOjEyOiLZiNix2K/Zvtix2LMiO3M6NDoibGluayI7czozNDoiaHR0cDovL2Zvb2xzdGFja3MuaXIvP3BhZ2VfaWQ9MjMxOSI7czo2OiJ0YXJnZXQiO3M6MToiMCI7czo3OiJjbGFzc2VzIjtzOjA6IiI7fX1pOjY7YTozOntzOjQ6InR5cGUiO3M6ODoiem9vbV9ib3giO3M6NDoic2l6ZSI7czozOiIxLzMiO3M6NjoiZmllbGRzIjthOjc6e3M6NToiaW1hZ2UiO3M6NTc6Imh0dHA6Ly9mb29sc3RhY2tzLmlyL3dwLWNvbnRlbnQvdXBsb2Fkcy8yMDE4LzExL2JyYW5kLnBuZyI7czo4OiJiZ19jb2xvciI7czo3OiIjMGMzMjVmIjtzOjEzOiJjb250ZW50X2ltYWdlIjtzOjA6IiI7czo3OiJjb250ZW50IjtzOjE2OiLYqNix2YbYr9iz2KfYstuMIjtzOjQ6ImxpbmsiO3M6MzU6Imh0dHA6Ly9mb29sc3RhY2tzLmlyLz9wYWdlX2lkPTIzMTcgIjtzOjY6InRhcmdldCI7czoxOiIwIjtzOjc6ImNsYXNzZXMiO3M6MDoiIjt9fWk6NzthOjM6e3M6NDoidHlwZSI7czo2OiJjb2x1bW4iO3M6NDoic2l6ZSI7czozOiIxLzEiO3M6NjoiZmllbGRzIjthOjc6e3M6NToidGl0bGUiO3M6NjoiQnV0dG9uIjtzOjc6ImNvbnRlbnQiO3M6MTM1OiJbYnV0dG9uIHRpdGxlPSLYqNin2LLYr9uM2K8g2KfYsiDZiNio2YTYp9qvIiBsaW5rPSJodHRwOi8vZm9vbHN0YWNrcy5pci8/cGFnZV9pZD0yOSIgY29sb3I9IiMwMDAwMDAiIGZvbnRfY29sb3I9IiMwMDAwMDAiIGxhcmdlPSIxIiBdDQoiO3M6NToiYWxpZ24iO3M6NjoiY2VudGVyIjtzOjk6ImNvbHVtbl9iZyI7czowOiIiO3M6NzoicGFkZGluZyI7czowOiIiO3M6NzoiYW5pbWF0ZSI7czowOiIiO3M6NzoiY2xhc3NlcyI7czowOiIiO319fX1pOjI7YToyOntzOjQ6ImF0dHIiO2E6MTY6e3M6NToidGl0bGUiO3M6MDoiIjtzOjg6ImJnX2NvbG9yIjtzOjA6IiI7czo4OiJiZ19pbWFnZSI7czo3NToiaHR0cDovL2Zvb2xzdGFja3MuaXIvd3AtY29udGVudC91cGxvYWRzLzIwMTUvMDMvaG9tZV93ZWJkZXNpZ25fYWJvdXRfYmcuanBnIjtzOjExOiJiZ19wb3NpdGlvbiI7czoyNToibm8tcmVwZWF0O2NlbnRlciBib3R0b207OyI7czoxMjoiYmdfdmlkZW9fbXA0IjtzOjA6IiI7czoxMjoiYmdfdmlkZW9fb2d2IjtzOjA6IiI7czoxMzoiY29sdW1uX21hcmdpbiI7czowOiIiO3M6MTE6InBhZGRpbmdfdG9wIjtzOjM6IjEwMCI7czoxNDoicGFkZGluZ19ib3R0b20iO3M6MjoiODAiO3M6NzoiZGl2aWRlciI7czowOiIiO3M6NjoibGF5b3V0IjtzOjEwOiJuby1zaWRlYmFyIjtzOjEwOiJuYXZpZ2F0aW9uIjtzOjA6IiI7czo1OiJzdHlsZSI7czowOiIiO3M6NToiY2xhc3MiO3M6MDoiIjtzOjEwOiJzZWN0aW9uX2lkIjtzOjA6IiI7czoxMDoidmlzaWJpbGl0eSI7czowOiIiO31zOjU6Iml0ZW1zIjthOjE6e2k6MDthOjM6e3M6NDoidHlwZSI7czo2OiJjb2x1bW4iO3M6NDoic2l6ZSI7czozOiIxLzIiO3M6NjoiZmllbGRzIjthOjc6e3M6NToidGl0bGUiO3M6MDoiIjtzOjc6ImNvbnRlbnQiO3M6MzM1OiI8aDI+2Ygg2LfYsdin2K3bjCDYtdiv2YfYpyDYs9in24zYqiDYr9uM2q/YsSA8YnIvPg0KINio2LHYp9uMINmF2LnYsdmB24wgPGJyLz4NCtmIINm+24zYtCDYqNix2K8g2qnYs9ioINmIINqp2KfYsSDYtNmF2KdyPC9oMj4NCltkaXZpZGVyIGhlaWdodD0iNDAiXQ0KDQpbZGl2aWRlciBoZWlnaHQ9IjQwIl0NCjxhIHN0eWxlPSJmb250LXNpemU6IDI0cHg7IGxpbmUtaGVpZ2h0OiAyNHB4OyIgaHJlZj0iaHR0cDovL2Zvb2xzdGFja3MuaXIvJUQ4JUFGJUQ4JUIxJUQ4JUE4JUQ4JUE3JUQ4JUIxJUQ5JTg3LyI+2K/YsSDYqNin2LHZhyDZhdinINio24zYtNiq2LEg2KjYr9in2YbbjNivPC9hPiI7czo1OiJhbGlnbiI7czowOiIiO3M6OToiY29sdW1uX2JnIjtzOjA6IiI7czo3OiJwYWRkaW5nIjtzOjA6IiI7czo3OiJhbmltYXRlIjtzOjA6IiI7czo3OiJjbGFzc2VzIjtzOjA6IiI7fX19fWk6MzthOjI6e3M6NDoiYXR0ciI7YToxNjp7czo1OiJ0aXRsZSI7czowOiIiO3M6ODoiYmdfY29sb3IiO3M6MDoiIjtzOjg6ImJnX2ltYWdlIjtzOjc1OiJodHRwOi8vZm9vbHN0YWNrcy5pci93cC1jb250ZW50L3VwbG9hZHMvMjAxNS8wMy9ob21lX3dlYmRlc2lnbl9wYXR0ZXJuMS5wbmciO3M6MTE6ImJnX3Bvc2l0aW9uIjtzOjE1OiJyZXBlYXQ7Y2VudGVyOzsiO3M6MTI6ImJnX3ZpZGVvX21wNCI7czowOiIiO3M6MTI6ImJnX3ZpZGVvX29ndiI7czowOiIiO3M6MTM6ImNvbHVtbl9tYXJnaW4iO3M6MDoiIjtzOjExOiJwYWRkaW5nX3RvcCI7czozOiIxMDAiO3M6MTQ6InBhZGRpbmdfYm90dG9tIjtzOjI6IjUwIjtzOjc6ImRpdmlkZXIiO3M6MDoiIjtzOjY6ImxheW91dCI7czoxMDoibm8tc2lkZWJhciI7czoxMDoibmF2aWdhdGlvbiI7czowOiIiO3M6NToic3R5bGUiO3M6MDoiIjtzOjU6ImNsYXNzIjtzOjA6IiI7czoxMDoic2VjdGlvbl9pZCI7czowOiIiO3M6MTA6InZpc2liaWxpdHkiO3M6MDoiIjt9czo1OiJpdGVtcyI7YTo1OntpOjA7YTozOntzOjQ6InR5cGUiO3M6NjoiY29sdW1uIjtzOjQ6InNpemUiO3M6MzoiMS8zIjtzOjY6ImZpZWxkcyI7YTo3OntzOjU6InRpdGxlIjtzOjExOiJPdXIgY2xpZW50cyI7czo3OiJjb250ZW50IjtzOjQ0OiI8aDM+2KjYsdiu24wg2KfYsiDZhdi02KrYsduM2KfZhiDZhdinPC9oMz4NCiI7czo1OiJhbGlnbiI7czowOiIiO3M6OToiY29sdW1uX2JnIjtzOjA6IiI7czo3OiJwYWRkaW5nIjtzOjA6IiI7czo3OiJhbmltYXRlIjtzOjA6IiI7czo3OiJjbGFzc2VzIjtzOjA6IiI7fX1pOjE7YTozOntzOjQ6InR5cGUiO3M6OToiaG92ZXJfYm94IjtzOjQ6InNpemUiO3M6MzoiMS82IjtzOjY6ImZpZWxkcyI7YTo2OntzOjU6ImltYWdlIjtzOjYxOiJodHRwOi8vZm9vbHN0YWNrcy5pci93cC1jb250ZW50L3VwbG9hZHMvMjAxNS8wMy9jbGllbnRfMzMucG5nIjtzOjExOiJpbWFnZV9ob3ZlciI7czo2MDoiaHR0cDovL2Zvb2xzdGFja3MuaXIvd3AtY29udGVudC91cGxvYWRzLzIwMTUvMDMvY2xpZW50XzMucG5nIjtzOjM6ImFsdCI7czowOiIiO3M6NDoibGluayI7czoxOiIjIjtzOjY6InRhcmdldCI7czoxOiIwIjtzOjc6ImNsYXNzZXMiO3M6MDoiIjt9fWk6MjthOjM6e3M6NDoidHlwZSI7czo5OiJob3Zlcl9ib3giO3M6NDoic2l6ZSI7czozOiIxLzYiO3M6NjoiZmllbGRzIjthOjY6e3M6NToiaW1hZ2UiO3M6NjE6Imh0dHA6Ly9mb29sc3RhY2tzLmlyL3dwLWNvbnRlbnQvdXBsb2Fkcy8yMDE1LzAzL2NsaWVudF8xMS5wbmciO3M6MTE6ImltYWdlX2hvdmVyIjtzOjYwOiJodHRwOi8vZm9vbHN0YWNrcy5pci93cC1jb250ZW50L3VwbG9hZHMvMjAxNS8wMy9jbGllbnRfMS5wbmciO3M6MzoiYWx0IjtzOjA6IiI7czo0OiJsaW5rIjtzOjE6IiMiO3M6NjoidGFyZ2V0IjtzOjE6IjAiO3M6NzoiY2xhc3NlcyI7czowOiIiO319aTozO2E6Mzp7czo0OiJ0eXBlIjtzOjk6ImhvdmVyX2JveCI7czo0OiJzaXplIjtzOjM6IjEvNiI7czo2OiJmaWVsZHMiO2E6Njp7czo1OiJpbWFnZSI7czo2MToiaHR0cDovL2Zvb2xzdGFja3MuaXIvd3AtY29udGVudC91cGxvYWRzLzIwMTUvMDMvY2xpZW50XzQ0LnBuZyI7czoxMToiaW1hZ2VfaG92ZXIiO3M6NjA6Imh0dHA6Ly9mb29sc3RhY2tzLmlyL3dwLWNvbnRlbnQvdXBsb2Fkcy8yMDE1LzAzL2NsaWVudF80LnBuZyI7czozOiJhbHQiO3M6MDoiIjtzOjQ6ImxpbmsiO3M6MToiIyI7czo2OiJ0YXJnZXQiO3M6MToiMCI7czo3OiJjbGFzc2VzIjtzOjA6IiI7fX1pOjQ7YTozOntzOjQ6InR5cGUiO3M6OToiaG92ZXJfYm94IjtzOjQ6InNpemUiO3M6MzoiMS82IjtzOjY6ImZpZWxkcyI7YTo2OntzOjU6ImltYWdlIjtzOjYxOiJodHRwOi8vZm9vbHN0YWNrcy5pci93cC1jb250ZW50L3VwbG9hZHMvMjAxNS8wMy9jbGllbnRfMjIucG5nIjtzOjExOiJpbWFnZV9ob3ZlciI7czo2MDoiaHR0cDovL2Zvb2xzdGFja3MuaXIvd3AtY29udGVudC91cGxvYWRzLzIwMTUvMDMvY2xpZW50XzIucG5nIjtzOjM6ImFsdCI7czowOiIiO3M6NDoibGluayI7czoxOiIjIjtzOjY6InRhcmdldCI7czoxOiIwIjtzOjc6ImNsYXNzZXMiO3M6MDoiIjt9fX19aTo0O2E6Mjp7czo0OiJhdHRyIjthOjE2OntzOjU6InRpdGxlIjtzOjA6IiI7czo4OiJiZ19jb2xvciI7czowOiIiO3M6ODoiYmdfaW1hZ2UiO3M6ODA6Imh0dHA6Ly9mb29sc3RhY2tzLmlyL3dwLWNvbnRlbnQvdXBsb2Fkcy8yMDE1LzAzL2hvbWVfd2ViZGVzaWduX25ld3NsZXR0ZXJfYmcuanBnIjtzOjExOiJiZ19wb3NpdGlvbiI7czozMjoibm8tcmVwZWF0O2NlbnRlciB0b3A7Zml4ZWQ7Y292ZXIiO3M6MTI6ImJnX3ZpZGVvX21wNCI7czowOiIiO3M6MTI6ImJnX3ZpZGVvX29ndiI7czowOiIiO3M6MTM6ImNvbHVtbl9tYXJnaW4iO3M6MDoiIjtzOjExOiJwYWRkaW5nX3RvcCI7czozOiIxNTAiO3M6MTQ6InBhZGRpbmdfYm90dG9tIjtzOjM6IjExMCI7czo3OiJkaXZpZGVyIjtzOjA6IiI7czo2OiJsYXlvdXQiO3M6MTA6Im5vLXNpZGViYXIiO3M6MTA6Im5hdmlnYXRpb24iO3M6MDoiIjtzOjU6InN0eWxlIjtzOjA6IiI7czo1OiJjbGFzcyI7czowOiIiO3M6MTA6InNlY3Rpb25faWQiO3M6MDoiIjtzOjEwOiJ2aXNpYmlsaXR5IjtzOjA6IiI7fXM6NToiaXRlbXMiO2E6Mjp7aTowO2E6Mzp7czo0OiJ0eXBlIjtzOjU6ImltYWdlIjtzOjQ6InNpemUiO3M6MzoiMS8zIjtzOjY6ImZpZWxkcyI7YToxNDp7czozOiJzcmMiO3M6NzA6Imh0dHA6Ly9mb29sc3RhY2tzLmlyL3dwLWNvbnRlbnQvdXBsb2Fkcy8yMDE1LzAzL2hvbWVfd2ViZGVzaWduX25ldy5wbmciO3M6NToid2lkdGgiO3M6MDoiIjtzOjY6ImhlaWdodCI7czowOiIiO3M6NjoiYm9yZGVyIjtzOjE6IjAiO3M6NToiYWxpZ24iO3M6MDoiIjtzOjY6Im1hcmdpbiI7czowOiIiO3M6MzoiYWx0IjtzOjA6IiI7czo3OiJjYXB0aW9uIjtzOjA6IiI7czoxMDoibGlua19pbWFnZSI7czowOiIiO3M6NDoibGluayI7czowOiIiO3M6NjoidGFyZ2V0IjtzOjE6IjAiO3M6OToiZ3JleXNjYWxlIjtzOjE6IjAiO3M6NzoiYW5pbWF0ZSI7czowOiIiO3M6NzoiY2xhc3NlcyI7czowOiIiO319aToxO2E6Mzp7czo0OiJ0eXBlIjtzOjY6ImNvbHVtbiI7czo0OiJzaXplIjtzOjM6IjIvMyI7czo2OiJmaWVsZHMiO2E6Nzp7czo1OiJ0aXRsZSI7czo3OiJTaWduIGluIjtzOjc6ImNvbnRlbnQiO3M6MjUzOiI8aDMgc3R5bGU9ImNvbG9yOiAjZmZmOyBwb3NpdGlvbjogcmVsYXRpdmU7IHRvcDogLTlweDsgbWFyZ2luLWxlZnQ6IDEwcHgiPjxzcGFuIGNsYXNzPSJ0aGVtZWNvbG9yIiBzdHlsZT0iZm9udC13ZWlnaHQ6IDcwMDsiPtio2Kcg2YXYpyDZgdmC2Lcg2KjZhyDYp9mI2Kwg2YHaqdix2qnZhtuM2K88L3NwYW4+PGJyIC8+DQrZvtix2YjamNmHINmH2KfbjCDYrNiv24zYrzxiciAvPg0K2KjZhyDYsdmI2LIg2LHYs9in2YbbjCDYs9ix24zYuTwvaDM+IjtzOjU6ImFsaWduIjtzOjA6IiI7czo5OiJjb2x1bW5fYmciO3M6MDoiIjtzOjc6InBhZGRpbmciO3M6MDoiIjtzOjc6ImFuaW1hdGUiO3M6MDoiIjtzOjc6ImNsYXNzZXMiO3M6MDoiIjt9fX19fQ==");
INSERT INTO `st_postmeta` VALUES("1769","106","mfn-post-hide-content","0");
INSERT INTO `st_postmeta` VALUES("1770","106","mfn-post-custom-layout","0");
INSERT INTO `st_postmeta` VALUES("1771","106","mfn-post-layout","no-sidebar");
INSERT INTO `st_postmeta` VALUES("1772","106","mfn-post-slider","slider2");
INSERT INTO `st_postmeta` VALUES("1773","106","mfn-post-slider-layer","0");
INSERT INTO `st_postmeta` VALUES("1774","106","mfn-post-menu","0");
INSERT INTO `st_postmeta` VALUES("675","2253","_wp_attached_file","2018/11/slider-2.jpg");
INSERT INTO `st_postmeta` VALUES("676","2253","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:1200;s:4:\"file\";s:20:\"2018/11/slider-2.jpg\";s:5:\"sizes\";a:21:{s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:20:\"slider-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:20:\"slider-2-600x375.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:20:\"slider-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"slider-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"slider-2-300x188.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:188;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"slider-2-768x480.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"slider-2-1024x640.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:640;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:20:\"slider-2-234x146.jpg\";s:5:\"width\";i:234;s:6:\"height\";i:146;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:18:\"slider-2-50x31.jpg\";s:5:\"width\";i:50;s:6:\"height\";i:31;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"portfolio-mf\";a:4:{s:4:\"file\";s:20:\"slider-2-960x750.jpg\";s:5:\"width\";i:960;s:6:\"height\";i:750;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:20:\"slider-2-960x375.jpg\";s:5:\"width\";i:960;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-t\";a:4:{s:4:\"file\";s:20:\"slider-2-480x750.jpg\";s:5:\"width\";i:480;s:6:\"height\";i:750;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-list\";a:4:{s:4:\"file\";s:21:\"slider-2-1160x450.jpg\";s:5:\"width\";i:1160;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-single\";a:4:{s:4:\"file\";s:21:\"slider-2-1200x480.jpg\";s:5:\"width\";i:1200;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:18:\"slider-2-80x80.jpg\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:19:\"slider-2-120x75.jpg\";s:5:\"width\";i:120;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"slider-content\";a:4:{s:4:\"file\";s:20:\"slider-2-890x470.jpg\";s:5:\"width\";i:890;s:6:\"height\";i:470;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:18:\"slider-2-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:20:\"slider-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:20:\"slider-2-600x375.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:20:\"slider-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("663","2247","_wp_attached_file","2018/11/99we.jpg");
INSERT INTO `st_postmeta` VALUES("664","2247","_wp_attachment_metadata","a:5:{s:5:\"width\";i:574;s:6:\"height\";i:349;s:4:\"file\";s:16:\"2018/11/99we.jpg\";s:5:\"sizes\";a:12:{s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:16:\"99we-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:16:\"99we-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:16:\"99we-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:16:\"99we-300x182.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:182;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:16:\"99we-240x146.jpg\";s:5:\"width\";i:240;s:6:\"height\";i:146;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:14:\"99we-50x30.jpg\";s:5:\"width\";i:50;s:6:\"height\";i:30;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-t\";a:4:{s:4:\"file\";s:16:\"99we-480x349.jpg\";s:5:\"width\";i:480;s:6:\"height\";i:349;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:14:\"99we-80x80.jpg\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:15:\"99we-123x75.jpg\";s:5:\"width\";i:123;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:14:\"99we-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:16:\"99we-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:16:\"99we-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("998","2309","_wp_attachment_metadata","a:5:{s:5:\"width\";i:584;s:6:\"height\";i:457;s:4:\"file\";s:18:\"2018/11/portal.png\";s:5:\"sizes\";a:14:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"portal-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"portal-300x235.png\";s:5:\"width\";i:300;s:6:\"height\";i:235;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:18:\"portal-187x146.png\";s:5:\"width\";i:187;s:6:\"height\";i:146;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:16:\"portal-50x39.png\";s:5:\"width\";i:50;s:6:\"height\";i:39;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:18:\"portal-584x375.png\";s:5:\"width\";i:584;s:6:\"height\";i:375;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"portfolio-mf-t\";a:4:{s:4:\"file\";s:18:\"portal-480x457.png\";s:5:\"width\";i:480;s:6:\"height\";i:457;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"portfolio-list\";a:4:{s:4:\"file\";s:18:\"portal-584x450.png\";s:5:\"width\";i:584;s:6:\"height\";i:450;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:16:\"portal-80x80.png\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:16:\"portal-96x75.png\";s:5:\"width\";i:96;s:6:\"height\";i:75;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:16:\"portal-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:18:\"portal-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:18:\"portal-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:18:\"portal-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:18:\"portal-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("997","2309","_wp_attached_file","2018/11/portal.png");
INSERT INTO `st_postmeta` VALUES("982","2290","_thumbnail_id","2304");
INSERT INTO `st_postmeta` VALUES("986","2305","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("985","2305","_edit_lock","1542140440:1");
INSERT INTO `st_postmeta` VALUES("987","2305","_wp_trash_meta_time","1542140444");
INSERT INTO `st_postmeta` VALUES("988","2305","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("991","2306","_wp_attached_file","2018/11/Web-Design-Blog-Image.jpg");
INSERT INTO `st_postmeta` VALUES("992","2306","_wp_attachment_metadata","a:5:{s:5:\"width\";i:850;s:6:\"height\";i:467;s:4:\"file\";s:33:\"2018/11/Web-Design-Blog-Image.jpg\";s:5:\"sizes\";a:17:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:33:\"Web-Design-Blog-Image-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:33:\"Web-Design-Blog-Image-300x165.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:165;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:33:\"Web-Design-Blog-Image-768x422.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:422;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:33:\"Web-Design-Blog-Image-260x143.jpg\";s:5:\"width\";i:260;s:6:\"height\";i:143;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:31:\"Web-Design-Blog-Image-50x27.jpg\";s:5:\"width\";i:50;s:6:\"height\";i:27;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:33:\"Web-Design-Blog-Image-850x375.jpg\";s:5:\"width\";i:850;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-t\";a:4:{s:4:\"file\";s:33:\"Web-Design-Blog-Image-480x467.jpg\";s:5:\"width\";i:480;s:6:\"height\";i:467;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-list\";a:4:{s:4:\"file\";s:33:\"Web-Design-Blog-Image-850x450.jpg\";s:5:\"width\";i:850;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:31:\"Web-Design-Blog-Image-80x80.jpg\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:32:\"Web-Design-Blog-Image-137x75.jpg\";s:5:\"width\";i:137;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:31:\"Web-Design-Blog-Image-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:33:\"Web-Design-Blog-Image-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:33:\"Web-Design-Blog-Image-600x330.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:330;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:33:\"Web-Design-Blog-Image-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:33:\"Web-Design-Blog-Image-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:33:\"Web-Design-Blog-Image-600x330.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:330;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:33:\"Web-Design-Blog-Image-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("1127","2339","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("993","2307","_wp_attached_file","2018/11/blog.png");
INSERT INTO `st_postmeta` VALUES("994","2307","_wp_attachment_metadata","a:5:{s:5:\"width\";i:608;s:6:\"height\";i:478;s:4:\"file\";s:16:\"2018/11/blog.png\";s:5:\"sizes\";a:17:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:16:\"blog-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:16:\"blog-300x236.png\";s:5:\"width\";i:300;s:6:\"height\";i:236;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:16:\"blog-186x146.png\";s:5:\"width\";i:186;s:6:\"height\";i:146;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:14:\"blog-50x39.png\";s:5:\"width\";i:50;s:6:\"height\";i:39;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:16:\"blog-608x375.png\";s:5:\"width\";i:608;s:6:\"height\";i:375;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"portfolio-mf-t\";a:4:{s:4:\"file\";s:16:\"blog-480x478.png\";s:5:\"width\";i:480;s:6:\"height\";i:478;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"portfolio-list\";a:4:{s:4:\"file\";s:16:\"blog-608x450.png\";s:5:\"width\";i:608;s:6:\"height\";i:450;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:14:\"blog-80x80.png\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:14:\"blog-95x75.png\";s:5:\"width\";i:95;s:6:\"height\";i:75;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"slider-content\";a:4:{s:4:\"file\";s:16:\"blog-608x470.png\";s:5:\"width\";i:608;s:6:\"height\";i:470;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:14:\"blog-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:16:\"blog-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:16:\"blog-600x472.png\";s:5:\"width\";i:600;s:6:\"height\";i:472;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:16:\"blog-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:16:\"blog-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:16:\"blog-600x472.png\";s:5:\"width\";i:600;s:6:\"height\";i:472;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:16:\"blog-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("995","2308","_wp_attached_file","2018/11/brand.png");
INSERT INTO `st_postmeta` VALUES("996","2308","_wp_attachment_metadata","a:5:{s:5:\"width\";i:850;s:6:\"height\";i:540;s:4:\"file\";s:17:\"2018/11/brand.png\";s:5:\"sizes\";a:19:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"brand-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:17:\"brand-300x191.png\";s:5:\"width\";i:300;s:6:\"height\";i:191;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:17:\"brand-768x488.png\";s:5:\"width\";i:768;s:6:\"height\";i:488;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:17:\"brand-230x146.png\";s:5:\"width\";i:230;s:6:\"height\";i:146;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:15:\"brand-50x32.png\";s:5:\"width\";i:50;s:6:\"height\";i:32;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:17:\"brand-850x375.png\";s:5:\"width\";i:850;s:6:\"height\";i:375;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"portfolio-mf-t\";a:4:{s:4:\"file\";s:17:\"brand-480x540.png\";s:5:\"width\";i:480;s:6:\"height\";i:540;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"portfolio-list\";a:4:{s:4:\"file\";s:17:\"brand-850x450.png\";s:5:\"width\";i:850;s:6:\"height\";i:450;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"blog-single\";a:4:{s:4:\"file\";s:17:\"brand-850x480.png\";s:5:\"width\";i:850;s:6:\"height\";i:480;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:15:\"brand-80x80.png\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:16:\"brand-118x75.png\";s:5:\"width\";i:118;s:6:\"height\";i:75;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"slider-content\";a:4:{s:4:\"file\";s:17:\"brand-850x470.png\";s:5:\"width\";i:850;s:6:\"height\";i:470;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:15:\"brand-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:17:\"brand-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:17:\"brand-600x381.png\";s:5:\"width\";i:600;s:6:\"height\";i:381;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:17:\"brand-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:17:\"brand-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:17:\"brand-600x381.png\";s:5:\"width\";i:600;s:6:\"height\";i:381;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:17:\"brand-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("538","2197","_wp_attached_file","2015/03/retina-webdesign.png");
INSERT INTO `st_postmeta` VALUES("539","2197","_wp_attachment_metadata","a:5:{s:5:\"width\";i:354;s:6:\"height\";i:90;s:4:\"file\";s:28:\"2015/03/retina-webdesign.png\";s:5:\"sizes\";a:11:{s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:27:\"retina-webdesign-300x90.png\";s:5:\"width\";i:300;s:6:\"height\";i:90;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:27:\"retina-webdesign-100x90.png\";s:5:\"width\";i:100;s:6:\"height\";i:90;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:27:\"retina-webdesign-150x90.png\";s:5:\"width\";i:150;s:6:\"height\";i:90;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:27:\"retina-webdesign-300x76.png\";s:5:\"width\";i:300;s:6:\"height\";i:76;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:27:\"retina-webdesign-260x66.png\";s:5:\"width\";i:260;s:6:\"height\";i:66;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:26:\"retina-webdesign-50x13.png\";s:5:\"width\";i:50;s:6:\"height\";i:13;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:26:\"retina-webdesign-80x80.png\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:27:\"retina-webdesign-150x38.png\";s:5:\"width\";i:150;s:6:\"height\";i:38;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:26:\"retina-webdesign-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:27:\"retina-webdesign-300x90.png\";s:5:\"width\";i:300;s:6:\"height\";i:90;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:27:\"retina-webdesign-100x90.png\";s:5:\"width\";i:100;s:6:\"height\";i:90;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("968","105","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("969","105","_wp_trash_meta_time","1542139595");
INSERT INTO `st_postmeta` VALUES("970","105","_wp_desired_post_slug","hello-world");
INSERT INTO `st_postmeta` VALUES("971","105","_wp_trash_meta_comments_status","a:1:{i:2;s:1:\"1\";}");
INSERT INTO `st_postmeta` VALUES("972","2302","_wp_attached_file","2018/06/hw.jpeg");
INSERT INTO `st_postmeta` VALUES("973","2302","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1600;s:6:\"height\";i:463;s:4:\"file\";s:15:\"2018/06/hw.jpeg\";s:5:\"sizes\";a:21:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"hw-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"hw-300x87.jpeg\";s:5:\"width\";i:300;s:6:\"height\";i:87;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:15:\"hw-768x222.jpeg\";s:5:\"width\";i:768;s:6:\"height\";i:222;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:16:\"hw-1024x296.jpeg\";s:5:\"width\";i:1024;s:6:\"height\";i:296;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:14:\"hw-260x75.jpeg\";s:5:\"width\";i:260;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:13:\"hw-50x14.jpeg\";s:5:\"width\";i:50;s:6:\"height\";i:14;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"portfolio-mf\";a:4:{s:4:\"file\";s:15:\"hw-960x463.jpeg\";s:5:\"width\";i:960;s:6:\"height\";i:463;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:15:\"hw-960x375.jpeg\";s:5:\"width\";i:960;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-t\";a:4:{s:4:\"file\";s:15:\"hw-480x463.jpeg\";s:5:\"width\";i:480;s:6:\"height\";i:463;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-list\";a:4:{s:4:\"file\";s:16:\"hw-1160x450.jpeg\";s:5:\"width\";i:1160;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-single\";a:4:{s:4:\"file\";s:16:\"hw-1200x463.jpeg\";s:5:\"width\";i:1200;s:6:\"height\";i:463;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:13:\"hw-80x80.jpeg\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:14:\"hw-150x43.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:43;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"slider-content\";a:4:{s:4:\"file\";s:15:\"hw-890x463.jpeg\";s:5:\"width\";i:890;s:6:\"height\";i:463;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:13:\"hw-85x85.jpeg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:15:\"hw-300x300.jpeg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:15:\"hw-600x174.jpeg\";s:5:\"width\";i:600;s:6:\"height\";i:174;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:15:\"hw-100x100.jpeg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:15:\"hw-300x300.jpeg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:15:\"hw-600x174.jpeg\";s:5:\"width\";i:600;s:6:\"height\";i:174;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:15:\"hw-100x100.jpeg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("980","2304","_wp_attached_file","2018/11/Marvel.jpg");
INSERT INTO `st_postmeta` VALUES("976","1","mfn-post-layout","right-sidebar");
INSERT INTO `st_postmeta` VALUES("977","1","mfn-post-header-bg","http://foolstacks.ir/wp-content/uploads/2018/06/hw.jpeg");
INSERT INTO `st_postmeta` VALUES("981","2304","_wp_attachment_metadata","a:5:{s:5:\"width\";i:2000;s:6:\"height\";i:1000;s:4:\"file\";s:18:\"2018/11/Marvel.jpg\";s:5:\"sizes\";a:21:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"Marvel-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"Marvel-300x150.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:18:\"Marvel-768x384.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:384;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"Marvel-1024x512.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:18:\"Marvel-260x130.jpg\";s:5:\"width\";i:260;s:6:\"height\";i:130;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:16:\"Marvel-50x25.jpg\";s:5:\"width\";i:50;s:6:\"height\";i:25;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"portfolio-mf\";a:4:{s:4:\"file\";s:18:\"Marvel-960x750.jpg\";s:5:\"width\";i:960;s:6:\"height\";i:750;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:18:\"Marvel-960x375.jpg\";s:5:\"width\";i:960;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-t\";a:4:{s:4:\"file\";s:18:\"Marvel-480x750.jpg\";s:5:\"width\";i:480;s:6:\"height\";i:750;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-list\";a:4:{s:4:\"file\";s:19:\"Marvel-1160x450.jpg\";s:5:\"width\";i:1160;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-single\";a:4:{s:4:\"file\";s:19:\"Marvel-1200x480.jpg\";s:5:\"width\";i:1200;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:16:\"Marvel-80x80.jpg\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:17:\"Marvel-150x75.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"slider-content\";a:4:{s:4:\"file\";s:18:\"Marvel-890x470.jpg\";s:5:\"width\";i:890;s:6:\"height\";i:470;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:16:\"Marvel-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:18:\"Marvel-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:18:\"Marvel-600x300.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:18:\"Marvel-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:18:\"Marvel-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:18:\"Marvel-600x300.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:18:\"Marvel-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("370","108","_wp_page_template","default");
INSERT INTO `st_postmeta` VALUES("371","108","slide_template","default");
INSERT INTO `st_postmeta` VALUES("372","108","mfn-page-items","YTo0OntpOjA7YToyOntzOjQ6ImF0dHIiO2E6MTY6e3M6NToidGl0bGUiO3M6OToiU3ViaGVhZGVyIjtzOjg6ImJnX2NvbG9yIjtzOjA6IiI7czo4OiJiZ19pbWFnZSI7czo3ODoiaHR0cDovL2Zvb2xzdGFja3MuaXIvd3AtY29udGVudC91cGxvYWRzLzIwMTUvMDMvaG9tZV93ZWJkZXNpZ25fc3ViaGVhZGVyXzIuanBnIjtzOjExOiJiZ19wb3NpdGlvbiI7czoyMjoibm8tcmVwZWF0O2NlbnRlciB0b3A7OyI7czoxMjoiYmdfdmlkZW9fbXA0IjtzOjA6IiI7czoxMjoiYmdfdmlkZW9fb2d2IjtzOjA6IiI7czoxMzoiY29sdW1uX21hcmdpbiI7czowOiIiO3M6MTE6InBhZGRpbmdfdG9wIjtzOjM6IjIwMCI7czoxNDoicGFkZGluZ19ib3R0b20iO3M6MjoiODAiO3M6NzoiZGl2aWRlciI7czowOiIiO3M6NjoibGF5b3V0IjtzOjEwOiJuby1zaWRlYmFyIjtzOjEwOiJuYXZpZ2F0aW9uIjtzOjA6IiI7czo1OiJzdHlsZSI7czo0OiJkYXJrIjtzOjU6ImNsYXNzIjtzOjA6IiI7czoxMDoic2VjdGlvbl9pZCI7czowOiIiO3M6MTA6InZpc2liaWxpdHkiO3M6MDoiIjt9czo1OiJpdGVtcyI7YToxOntpOjA7YTozOntzOjQ6InR5cGUiO3M6NjoiY29sdW1uIjtzOjQ6InNpemUiO3M6MzoiMS8xIjtzOjY6ImZpZWxkcyI7YTo3OntzOjU6InRpdGxlIjtzOjk6IlN1YmhlYWRlciI7czo3OiJjb250ZW50IjtzOjE0ODoiPGgyIHN0eWxlPSJmb250LXdlaWdodDogNzAwOyI+T1VSIE9GRkVSPC9oMj4NCltpbWFnZSBzcmM9Imh0dHA6Ly9mb29sc3RhY2tzLmlyL3dwLWNvbnRlbnQvdXBsb2Fkcy8yMDE1LzAzL2hvbWVfd2ViZGVzaWduX3NsaWRlcl9zZXAucG5nIiBib3JkZXI9IjAiXSI7czo1OiJhbGlnbiI7czowOiIiO3M6OToiY29sdW1uX2JnIjtzOjA6IiI7czo3OiJwYWRkaW5nIjtzOjA6IiI7czo3OiJhbmltYXRlIjtzOjA6IiI7czo3OiJjbGFzc2VzIjtzOjA6IiI7fX19fWk6MTthOjI6e3M6NDoiYXR0ciI7YToxNjp7czo1OiJ0aXRsZSI7czowOiIiO3M6ODoiYmdfY29sb3IiO3M6MDoiIjtzOjg6ImJnX2ltYWdlIjtzOjA6IiI7czoxMToiYmdfcG9zaXRpb24iO3M6MjI6Im5vLXJlcGVhdDtjZW50ZXIgdG9wOzsiO3M6MTI6ImJnX3ZpZGVvX21wNCI7czowOiIiO3M6MTI6ImJnX3ZpZGVvX29ndiI7czowOiIiO3M6MTM6ImNvbHVtbl9tYXJnaW4iO3M6MDoiIjtzOjExOiJwYWRkaW5nX3RvcCI7czoyOiI3MCI7czoxNDoicGFkZGluZ19ib3R0b20iO3M6MToiMCI7czo3OiJkaXZpZGVyIjtzOjA6IiI7czo2OiJsYXlvdXQiO3M6MTA6Im5vLXNpZGViYXIiO3M6MTA6Im5hdmlnYXRpb24iO3M6MDoiIjtzOjU6InN0eWxlIjtzOjA6IiI7czo1OiJjbGFzcyI7czowOiIiO3M6MTA6InNlY3Rpb25faWQiO3M6MDoiIjtzOjEwOiJ2aXNpYmlsaXR5IjtzOjA6IiI7fXM6NToiaXRlbXMiO2E6MTp7aTowO2E6Mzp7czo0OiJ0eXBlIjtzOjY6ImNvbHVtbiI7czo0OiJzaXplIjtzOjM6IjEvMSI7czo2OiJmaWVsZHMiO2E6Nzp7czo1OiJ0aXRsZSI7czowOiIiO3M6NzoiY29udGVudCI7czoxMTA6IjxoMz5NYXVyaXMgb3JuYXJlIG1hZ25hIHNlZCBtb2xlc3RpZSBmaW5pYnVzLiBEdWlzIGF0IGRpYW0gb3JjaTxiciAvPlBoYXNlbGx1cyBsb3JlbSB1cm5hLCBjb25zZXF1YXQgdXQ8L2gzPg0KIjtzOjU6ImFsaWduIjtzOjY6ImNlbnRlciI7czo5OiJjb2x1bW5fYmciO3M6MDoiIjtzOjc6InBhZGRpbmciO3M6MDoiIjtzOjc6ImFuaW1hdGUiO3M6MDoiIjtzOjc6ImNsYXNzZXMiO3M6MDoiIjt9fX19aToyO2E6Mjp7czo0OiJhdHRyIjthOjE2OntzOjU6InRpdGxlIjtzOjA6IiI7czo4OiJiZ19jb2xvciI7czowOiIiO3M6ODoiYmdfaW1hZ2UiO3M6MDoiIjtzOjExOiJiZ19wb3NpdGlvbiI7czoyMjoibm8tcmVwZWF0O2NlbnRlciB0b3A7OyI7czoxMjoiYmdfdmlkZW9fbXA0IjtzOjA6IiI7czoxMjoiYmdfdmlkZW9fb2d2IjtzOjA6IiI7czoxMzoiY29sdW1uX21hcmdpbiI7czowOiIiO3M6MTE6InBhZGRpbmdfdG9wIjtzOjE6IjAiO3M6MTQ6InBhZGRpbmdfYm90dG9tIjtzOjI6IjMwIjtzOjc6ImRpdmlkZXIiO3M6MDoiIjtzOjY6ImxheW91dCI7czoxMDoibm8tc2lkZWJhciI7czoxMDoibmF2aWdhdGlvbiI7czowOiIiO3M6NToic3R5bGUiO3M6MDoiIjtzOjU6ImNsYXNzIjtzOjA6IiI7czoxMDoic2VjdGlvbl9pZCI7czowOiIiO3M6MTA6InZpc2liaWxpdHkiO3M6MDoiIjt9czo1OiJpdGVtcyI7YToxNTp7aTowO2E6Mzp7czo0OiJ0eXBlIjtzOjU6ImltYWdlIjtzOjQ6InNpemUiO3M6MzoiMS8zIjtzOjY6ImZpZWxkcyI7YToxNDp7czozOiJzcmMiO3M6NzY6Imh0dHA6Ly9mb29sc3RhY2tzLmlyL3dwLWNvbnRlbnQvdXBsb2Fkcy8yMDE1LzAzL2hvbWVfd2ViZGVzaWduX29mZmVyMV9iZy5qcGciO3M6NToid2lkdGgiO3M6MDoiIjtzOjY6ImhlaWdodCI7czowOiIiO3M6NjoiYm9yZGVyIjtzOjE6IjAiO3M6NToiYWxpZ24iO3M6MDoiIjtzOjY6Im1hcmdpbiI7czowOiIiO3M6MzoiYWx0IjtzOjA6IiI7czo3OiJjYXB0aW9uIjtzOjA6IiI7czoxMDoibGlua19pbWFnZSI7czowOiIiO3M6NDoibGluayI7czowOiIiO3M6NjoidGFyZ2V0IjtzOjE6IjAiO3M6OToiZ3JleXNjYWxlIjtzOjE6IjAiO3M6NzoiYW5pbWF0ZSI7czowOiIiO3M6NzoiY2xhc3NlcyI7czowOiIiO319aToxO2E6Mzp7czo0OiJ0eXBlIjtzOjY6ImNvbHVtbiI7czo0OiJzaXplIjtzOjM6IjIvMyI7czo2OiJmaWVsZHMiO2E6Nzp7czo1OiJ0aXRsZSI7czowOiIiO3M6NzoiY29udGVudCI7czoxMDE2OiI8aDMgc3R5bGU9ImZvbnQtd2VpZ2h0OiA3MDA7Ij48c3BhbiBzdHlsZT0iZGlzcGxheTogaW5saW5lLWJsb2NrOyB3aWR0aDogMjVweDsgaGVpZ2h0OiAyNXB4OyBiYWNrZ3JvdW5kOiAjZThhNzM1OyBvdmVyZmxvdzogaGlkZGVuOyBtYXJnaW4tcmlnaHQ6IDE1cHg7Ij48L3NwYW4+U21hbGwgYnVzaW5lc3Mgd2Vic2l0ZXM8L2gzPg0KDQpbb25lX3NlY29uZF0NCjxwIGNsYXNzPSJiaWciIHN0eWxlPSJtYXJnaW46IDA7Ij4gTG9yZW0gaXBzdW0gZG9sb3Igc2l0IGFtZXQgZW5pbS4gRXRpYW0gdWxsYW1jb3JwZXIuIFN1c3BlbmRpc3NlIGEgcGVsbGVudGVzcXVlIGR1aSwgbm9uIGZlbGlzLiBNYWVjZW5hcyBtYWxlc3VhZGEgZWxpdCBsZWN0dXMgZmVsaXMsIG1hbGVzdWFkYSB1bHRyaWNpZXMuIEN1cmFiaXR1ciBldCBsaWd1bGEuIFV0IG1vbGVzdGllIGEsIHVsdHJpY2llcyBwb3J0YSB1cm5hLiBWZXN0aWJ1bHVtIGNvbW1vZG8gdm9sdXRwYXQgYSwgY29udmFsbGlzIGFjLCBsYW9yZWV0IGVuaW0uPC9wPg0KWy9vbmVfc2Vjb25kXQ0KDQpbb25lX3NlY29uZF0NCjxwPk51bGxhIGltcGVyZGlldCBzaXQgYW1ldCBtYWduYS4gVmVzdGlidWx1bSBkYXBpYnVzLCBtYXVyaXMgbmVjIG1hbGVzdWFkYSBmYW1lcyBhYyB0dXJwaXMgdmVsaXQsIHJob25jdXMgZXUsIGx1Y3R1cyBldCBpbnRlcmR1bSBhZGlwaXNjaW5nIHdpc2kuIEFsaXF1YW0gZXJhdCBhYyBpcHN1bS48L3A+DQo8cCBzdHlsZT0ibWFyZ2luOiAwOyI+SW50ZWdlciBhbGlxdWFtIHB1cnVzLiBRdWlzcXVlIGxvcmVtIHRvcnRvciBmcmluZ2lsbGEgc2VkLCB2ZXN0aWJ1bHVtIGlkLCBlbGVpZmVuZCBqdXN0byB2ZWwgYmliZW5kdW0gc2FwaWVuIG1hc3NhLjwvcD4NClsvb25lX3NlY29uZF0NCg0KW2RpdmlkZXIgaGVpZ2h0PSIxIl0NCjxwIHN0eWxlPSJ0b3A6IC0yMHB4OyBwb3NpdGlvbjogcmVsYXRpdmU7IiBjbGFzcz0iYmlnIj48YSBzdHlsZT0iY29sb3I6ICNlOGE3MzU7IiBocmVmPSIjIj5TZWUgcHJvamVjdHM8L2E+PC9wPiI7czo1OiJhbGlnbiI7czowOiIiO3M6OToiY29sdW1uX2JnIjtzOjA6IiI7czo3OiJwYWRkaW5nIjtzOjA6IiI7czo3OiJhbmltYXRlIjtzOjA6IiI7czo3OiJjbGFzc2VzIjtzOjA6IiI7fX1pOjI7YTozOntzOjQ6InR5cGUiO3M6NzoiZGl2aWRlciI7czo0OiJzaXplIjtzOjM6IjEvMSI7czo2OiJmaWVsZHMiO2E6NTp7czo2OiJoZWlnaHQiO3M6MjoiNDAiO3M6NToic3R5bGUiO3M6NzoiZGVmYXVsdCI7czo0OiJsaW5lIjtzOjQ6IndpZGUiO3M6MTA6InRoZW1lY29sb3IiO3M6MToiMCI7czo3OiJjbGFzc2VzIjtzOjA6IiI7fX1pOjM7YTozOntzOjQ6InR5cGUiO3M6NjoiY29sdW1uIjtzOjQ6InNpemUiO3M6MzoiMS8zIjtzOjY6ImZpZWxkcyI7YTo3OntzOjU6InRpdGxlIjtzOjA6IiI7czo3OiJjb250ZW50IjtzOjU2NDoiPGgzIHN0eWxlPSJmb250LXdlaWdodDogNzAwOyI+PHNwYW4gc3R5bGU9ImRpc3BsYXk6IGlubGluZS1ibG9jazsgd2lkdGg6IDI1cHg7IGhlaWdodDogMjVweDsgYmFja2dyb3VuZDogIzBjMzI1Zjsgb3ZlcmZsb3c6IGhpZGRlbjsgbWFyZ2luLXJpZ2h0OiAxNXB4OyI+PC9zcGFuPlBvcnRhbHMgZm9yIGxhcmdlDQpzY2FsZTwvaDM+DQoNCjxwIGNsYXNzPSJiaWciPkFsaXF1YW0gZXJhdCBhYyBpcHN1bS4gSW50ZWdlciBhbGlxdWFtIHB1cnVzLiBRdWlzcXVlIGxvcmVtIHRvcnRvciBmcmluZ2lsbGEgc2VkLCB2ZXN0aWJ1bHVtIGlkIGVsZWlmZW5kLiBDdXJhYml0dXIgZXQgbGlndWxhLiBVdCBtb2xlc3RpZSBhLCB1bHRyaWNpZXMgcG9ydGEgdXJuYS4gVmVzdGlidWx1bSBjb21tb2RvIHZvbHV0cGF0IGEsIGNvbnZhbGxpcyBhYywgbGFvcmVldCBlbmltLiBQaGFzZWxsdXMgZmVybWVudHVtIGluLCBkb2xvci4gUGVsbGVudGVzcXVlIGZhY2lsaXNpcy48L3A+DQoNCjxwIGNsYXNzPSJiaWciPjxhIHN0eWxlPSJjb2xvcjogIzBjMzI1ZjsiIGhyZWY9IiMiPlNlZSBwcm9qZWN0czwvYT48L3A+IjtzOjU6ImFsaWduIjtzOjA6IiI7czo5OiJjb2x1bW5fYmciO3M6MDoiIjtzOjc6InBhZGRpbmciO3M6MDoiIjtzOjc6ImFuaW1hdGUiO3M6MDoiIjtzOjc6ImNsYXNzZXMiO3M6MDoiIjt9fWk6NDthOjM6e3M6NDoidHlwZSI7czo1OiJpbWFnZSI7czo0OiJzaXplIjtzOjM6IjIvMyI7czo2OiJmaWVsZHMiO2E6MTQ6e3M6Mzoic3JjIjtzOjc2OiJodHRwOi8vZm9vbHN0YWNrcy5pci93cC1jb250ZW50L3VwbG9hZHMvMjAxNS8wMy9ob21lX3dlYmRlc2lnbl9vZmZlcjZfYmcuanBnIjtzOjU6IndpZHRoIjtzOjA6IiI7czo2OiJoZWlnaHQiO3M6MDoiIjtzOjY6ImJvcmRlciI7czoxOiIwIjtzOjU6ImFsaWduIjtzOjA6IiI7czo2OiJtYXJnaW4iO3M6MDoiIjtzOjM6ImFsdCI7czowOiIiO3M6NzoiY2FwdGlvbiI7czowOiIiO3M6MTA6ImxpbmtfaW1hZ2UiO3M6MDoiIjtzOjQ6ImxpbmsiO3M6MDoiIjtzOjY6InRhcmdldCI7czoxOiIwIjtzOjk6ImdyZXlzY2FsZSI7czoxOiIwIjtzOjc6ImFuaW1hdGUiO3M6MDoiIjtzOjc6ImNsYXNzZXMiO3M6MDoiIjt9fWk6NTthOjM6e3M6NDoidHlwZSI7czo3OiJkaXZpZGVyIjtzOjQ6InNpemUiO3M6MzoiMS8xIjtzOjY6ImZpZWxkcyI7YTo1OntzOjY6ImhlaWdodCI7czowOiIiO3M6NToic3R5bGUiO3M6NzoiZGVmYXVsdCI7czo0OiJsaW5lIjtzOjA6IiI7czoxMDoidGhlbWVjb2xvciI7czoxOiIwIjtzOjc6ImNsYXNzZXMiO3M6MDoiIjt9fWk6NjthOjM6e3M6NDoidHlwZSI7czo1OiJpbWFnZSI7czo0OiJzaXplIjtzOjM6IjEvMyI7czo2OiJmaWVsZHMiO2E6MTQ6e3M6Mzoic3JjIjtzOjc2OiJodHRwOi8vZm9vbHN0YWNrcy5pci93cC1jb250ZW50L3VwbG9hZHMvMjAxNS8wMy9ob21lX3dlYmRlc2lnbl9vZmZlcjdfYmcuanBnIjtzOjU6IndpZHRoIjtzOjA6IiI7czo2OiJoZWlnaHQiO3M6MDoiIjtzOjY6ImJvcmRlciI7czoxOiIwIjtzOjU6ImFsaWduIjtzOjA6IiI7czo2OiJtYXJnaW4iO3M6MDoiIjtzOjM6ImFsdCI7czowOiIiO3M6NzoiY2FwdGlvbiI7czowOiIiO3M6MTA6ImxpbmtfaW1hZ2UiO3M6MDoiIjtzOjQ6ImxpbmsiO3M6MDoiIjtzOjY6InRhcmdldCI7czoxOiIwIjtzOjk6ImdyZXlzY2FsZSI7czoxOiIwIjtzOjc6ImFuaW1hdGUiO3M6MDoiIjtzOjc6ImNsYXNzZXMiO3M6MDoiIjt9fWk6NzthOjM6e3M6NDoidHlwZSI7czo2OiJjb2x1bW4iO3M6NDoic2l6ZSI7czozOiIxLzMiO3M6NjoiZmllbGRzIjthOjc6e3M6NToidGl0bGUiO3M6MDoiIjtzOjc6ImNvbnRlbnQiO3M6NDY1OiI8cCBjbGFzcz0iYmlnIj5DdW0gc29jaWlzIG5hdG9xdWUgcGVuYXRpYnVzIGV0IHVsdHJpY2VzIHZvbHV0cGF0LiBOdWxsYW0gd2lzaSB1bHRyaWNpZXMgYSwgZ3JhdmlkYSB2aXRhZSwgZGFwaWJ1cyByaXN1cyBhbnRlIHNvZGFsZXMgbGVjdHVzIGJsYW5kaXQgZXUsIHRlbXBvciBkaWFtIHBlZGUgY3Vyc3VzIHZpdGFlLCB1bHRyaWNpZXMgZXUsIGZhdWNpYnVzIHF1aXMsIHBvcnR0aXRvciBlcm9zIGN1cnN1cyBsZWN0dXMsIHBlbGxlbnRlc3F1ZSBlZ2V0LCBiaWJlbmR1bSBhLCBncmF2aWRhIHVsbGFtY29ycGVyIHF1YW0uIE51bGxhbSB2aXZlcnJhIGNvbnNlY3RldHVlci4gUXVpc3F1ZSBjdXJzdXMgZXQsIHBvcnR0aXRvciByaXN1cy4gQWxpcXVhbSBzZW0uIEluIGhlbmRyZXJpdCBudWxsYSBxdWFtIG51bmMsIGFjY3Vtc2FuIGNvbmd1ZS4gTG9yZW0gaXBzdW0gcHJpbWlzIGluIG5pYmggdmVsIHJpc3VzLjwvcD4iO3M6NToiYWxpZ24iO3M6MDoiIjtzOjk6ImNvbHVtbl9iZyI7czowOiIiO3M6NzoicGFkZGluZyI7czowOiIiO3M6NzoiYW5pbWF0ZSI7czowOiIiO3M6NzoiY2xhc3NlcyI7czowOiIiO319aTo4O2E6Mzp7czo0OiJ0eXBlIjtzOjY6ImNvbHVtbiI7czo0OiJzaXplIjtzOjM6IjEvMyI7czo2OiJmaWVsZHMiO2E6Nzp7czo1OiJ0aXRsZSI7czowOiIiO3M6NzoiY29udGVudCI7czozNzg6IjxwIGNsYXNzPSJiaWciPkZhdWNpYnVzIHF1aXMsIHBvcnR0aXRvciBlcm9zIGN1cnN1cyBsZWN0dXMsIHBlbGxlbnRlc3F1ZSBlZ2V0LCBiaWJlbmR1bSBhLCBncmF2aWRhIHVsbGFtY29ycGVyIHF1YW0uIE51bGxhbSB2aXZlcnJhIGNvbnNlY3RldHVlci4gUXVpc3F1ZSBjdXJzdXMgZXQsIHBvcnR0aXRvciByaXN1cy4gQWxpcXVhbSBzZW0uIEluIGhlbmRyZXJpdCBudWxsYSBxdWFtIG51bmMsIGFjY3Vtc2FuIGNvbmd1ZS4gTG9yZW0gaXBzdW0gcHJpbWlzIGluIG5pYmggdmVsIHJpc3VzLiBTZWQgdmVsIGxlY3R1cy4gVXQgc2FnaXR0aXMsIGlwc3VtIGRvbG9yIHF1YW0uICBTZWQgdmVsIGxlY3R1cy4gVXQgc2FnaXR0aXMsIGlwc3VtIGRvbG9yIHF1YW0uPC9wPiI7czo1OiJhbGlnbiI7czowOiIiO3M6OToiY29sdW1uX2JnIjtzOjA6IiI7czo3OiJwYWRkaW5nIjtzOjA6IiI7czo3OiJhbmltYXRlIjtzOjA6IiI7czo3OiJjbGFzc2VzIjtzOjA6IiI7fX1pOjk7YTozOntzOjQ6InR5cGUiO3M6NzoiZGl2aWRlciI7czo0OiJzaXplIjtzOjM6IjEvMSI7czo2OiJmaWVsZHMiO2E6NTp7czo2OiJoZWlnaHQiO3M6MjoiNDAiO3M6NToic3R5bGUiO3M6NzoiZGVmYXVsdCI7czo0OiJsaW5lIjtzOjQ6IndpZGUiO3M6MTA6InRoZW1lY29sb3IiO3M6MToiMCI7czo3OiJjbGFzc2VzIjtzOjA6IiI7fX1pOjEwO2E6Mzp7czo0OiJ0eXBlIjtzOjY6ImNvbHVtbiI7czo0OiJzaXplIjtzOjM6IjEvMiI7czo2OiJmaWVsZHMiO2E6Nzp7czo1OiJ0aXRsZSI7czowOiIiO3M6NzoiY29udGVudCI7czo3MjU6IjxoMyBzdHlsZT0iZm9udC13ZWlnaHQ6IDcwMDsiPjxzcGFuIHN0eWxlPSJkaXNwbGF5OiBpbmxpbmUtYmxvY2s7IHdpZHRoOiAyNXB4OyBoZWlnaHQ6IDI1cHg7IGJhY2tncm91bmQ6ICNlYzJlODU7IG92ZXJmbG93OiBoaWRkZW47IG1hcmdpbi1yaWdodDogMTVweDsiPjwvc3Bhbj5Db21wbGV0ZSBvbmxpbmUgc2hvcHM8L2gzPg0KDQo8cCBjbGFzcz0iYmlnIj5OdWxsYSBpbXBlcmRpZXQgc2l0IGFtZXQgbWFnbmEuIFZlc3RpYnVsdW0gZGFwaWJ1cywgbWF1cmlzIG5lYyBtYWxlc3VhZGEgZmFtZXMgYWMgdHVycGlzIHZlbGl0LCByaG9uY3VzIGV1LCBsdWN0dXMgZXQgaW50ZXJkdW0gYWRpcGlzY2luZyB3aXNpLiBBbGlxdWFtIGVyYXQgYWMgaXBzdW0uIEludGVnZXIgYWxpcXVhbSBwdXJ1cy4gUXVpc3F1ZSBsb3JlbSB0b3J0b3IgZnJpbmdpbGxhIHNlZCwgdmVzdGlidWx1bSBpZCBlbGVpZmVuZC48L3A+DQo8cCBjbGFzcz0iYmlnIj5DdXJhYml0dXIgZXQgbGlndWxhLiBVdCBtb2xlc3RpZSBhLCB1bHRyaWNpZXMgcG9ydGEgdXJuYS4gVmVzdGlidWx1bSBjb21tb2RvIHZvbHV0cGF0IGEsIGNvbnZhbGxpcyBhYywgbGFvcmVldCBlbmltLiBQaGFzZWxsdXMgZmVybWVudHVtIGluLCBkb2xvci4gUGVsbGVudGVzcXVlIGZhY2lsaXNpcy48L3A+DQoNCjxwIGNsYXNzPSJiaWciPjxhIHN0eWxlPSJjb2xvcjogI2VjMmU4NTsiIGhyZWY9IiMiPlNlZSBwcm9qZWN0czwvYT48L3A+IjtzOjU6ImFsaWduIjtzOjA6IiI7czo5OiJjb2x1bW5fYmciO3M6MDoiIjtzOjc6InBhZGRpbmciO3M6MDoiIjtzOjc6ImFuaW1hdGUiO3M6MDoiIjtzOjc6ImNsYXNzZXMiO3M6MDoiIjt9fWk6MTE7YTozOntzOjQ6InR5cGUiO3M6NToiaW1hZ2UiO3M6NDoic2l6ZSI7czozOiIxLzIiO3M6NjoiZmllbGRzIjthOjE0OntzOjM6InNyYyI7czo3NjoiaHR0cDovL2Zvb2xzdGFja3MuaXIvd3AtY29udGVudC91cGxvYWRzLzIwMTUvMDMvaG9tZV93ZWJkZXNpZ25fb2ZmZXI0X2JnLmpwZyI7czo1OiJ3aWR0aCI7czowOiIiO3M6NjoiaGVpZ2h0IjtzOjA6IiI7czo2OiJib3JkZXIiO3M6MToiMCI7czo1OiJhbGlnbiI7czowOiIiO3M6NjoibWFyZ2luIjtzOjA6IiI7czozOiJhbHQiO3M6MDoiIjtzOjc6ImNhcHRpb24iO3M6MDoiIjtzOjEwOiJsaW5rX2ltYWdlIjtzOjA6IiI7czo0OiJsaW5rIjtzOjA6IiI7czo2OiJ0YXJnZXQiO3M6MToiMCI7czo5OiJncmV5c2NhbGUiO3M6MToiMCI7czo3OiJhbmltYXRlIjtzOjA6IiI7czo3OiJjbGFzc2VzIjtzOjA6IiI7fX1pOjEyO2E6Mzp7czo0OiJ0eXBlIjtzOjc6ImRpdmlkZXIiO3M6NDoic2l6ZSI7czozOiIxLzEiO3M6NjoiZmllbGRzIjthOjU6e3M6NjoiaGVpZ2h0IjtzOjI6IjQwIjtzOjU6InN0eWxlIjtzOjc6ImRlZmF1bHQiO3M6NDoibGluZSI7czo0OiJ3aWRlIjtzOjEwOiJ0aGVtZWNvbG9yIjtzOjE6IjAiO3M6NzoiY2xhc3NlcyI7czowOiIiO319aToxMzthOjM6e3M6NDoidHlwZSI7czo1OiJpbWFnZSI7czo0OiJzaXplIjtzOjM6IjEvMiI7czo2OiJmaWVsZHMiO2E6MTQ6e3M6Mzoic3JjIjtzOjc2OiJodHRwOi8vZm9vbHN0YWNrcy5pci93cC1jb250ZW50L3VwbG9hZHMvMjAxNS8wMy9ob21lX3dlYmRlc2lnbl9vZmZlcjRfYmcuanBnIjtzOjU6IndpZHRoIjtzOjA6IiI7czo2OiJoZWlnaHQiO3M6MDoiIjtzOjY6ImJvcmRlciI7czoxOiIwIjtzOjU6ImFsaWduIjtzOjA6IiI7czo2OiJtYXJnaW4iO3M6MDoiIjtzOjM6ImFsdCI7czowOiIiO3M6NzoiY2FwdGlvbiI7czowOiIiO3M6MTA6ImxpbmtfaW1hZ2UiO3M6MDoiIjtzOjQ6ImxpbmsiO3M6MDoiIjtzOjY6InRhcmdldCI7czoxOiIwIjtzOjk6ImdyZXlzY2FsZSI7czoxOiIwIjtzOjc6ImFuaW1hdGUiO3M6MDoiIjtzOjc6ImNsYXNzZXMiO3M6MDoiIjt9fWk6MTQ7YTozOntzOjQ6InR5cGUiO3M6NjoiY29sdW1uIjtzOjQ6InNpemUiO3M6MzoiMS8yIjtzOjY6ImZpZWxkcyI7YTo3OntzOjU6InRpdGxlIjtzOjA6IiI7czo3OiJjb250ZW50IjtzOjc5MjoiPGgzIHN0eWxlPSJmb250LXdlaWdodDogNzAwOyI+PHNwYW4gc3R5bGU9ImRpc3BsYXk6IGlubGluZS1ibG9jazsgd2lkdGg6IDI1cHg7IGhlaWdodDogMjVweDsgYmFja2dyb3VuZDogIzBjN2JhZjsgb3ZlcmZsb3c6IGhpZGRlbjsgbWFyZ2luLXJpZ2h0OiAxNXB4OyI+PC9zcGFuPldvcmRQcmVzcyAmIEpvb21sYSB0aGVtZXM8L2gzPg0KDQo8cCBjbGFzcz0iYmlnIj5OdWxsYSBpbXBlcmRpZXQgc2l0IGFtZXQgbWFnbmEuIFZlc3RpYnVsdW0gZGFwaWJ1cywgbWF1cmlzIG5lYyBtYWxlc3VhZGEgZmFtZXMgYWMgdHVycGlzIHZlbGl0LCByaG9uY3VzIGV1LCBsdWN0dXMgZXQgaW50ZXJkdW0gYWRpcGlzY2luZyB3aXNpLiBBbGlxdWFtIGVyYXQgYWMgaXBzdW0uIEludGVnZXIgYWxpcXVhbSBwdXJ1cy4gUXVpc3F1ZSBsb3JlbSB0b3J0b3IgZnJpbmdpbGxhIHNlZCwgdmVzdGlidWx1bSBpZCwgZWxlaWZlbmQganVzdG8gdmVsIGJpYmVuZHVtIHNhcGllbiBtYXNzYSBhYyB0dXJwaXMgZmF1Y2lidXMgb3JjaSBsdWN0dXMgbm9uPC9wPg0KPHAgY2xhc3M9ImJpZyI+TnVsbGFtIHdpc2kgdWx0cmljaWVzIGEsIGdyYXZpZGEgdml0YWUsIGRhcGlidXMgcmlzdXMgYW50ZSBzb2RhbGVzIGxlY3R1cyBibGFuZGl0IGV1LCB0ZW1wb3IgZGlhbSBwZWRlIGN1cnN1cyB2aXRhZSwgdWx0cmljaWVzIGV1LCBmYXVjaWJ1cyBxdWlzLCBwb3J0dGl0b3IgZXJvcyBjdXJzdS48L3A+DQoNCjxwIGNsYXNzPSJiaWciPjxhIHN0eWxlPSJjb2xvcjogIzBjN2JhZjsiIGhyZWY9IiMiPlNlZSBwcm9qZWN0czwvYT48L3A+IjtzOjU6ImFsaWduIjtzOjA6IiI7czo5OiJjb2x1bW5fYmciO3M6MDoiIjtzOjc6InBhZGRpbmciO3M6MDoiIjtzOjc6ImFuaW1hdGUiO3M6MDoiIjtzOjc6ImNsYXNzZXMiO3M6MDoiIjt9fX19aTozO2E6Mjp7czo0OiJhdHRyIjthOjE2OntzOjU6InRpdGxlIjtzOjA6IiI7czo4OiJiZ19jb2xvciI7czowOiIiO3M6ODoiYmdfaW1hZ2UiO3M6ODA6Imh0dHA6Ly9mb29sc3RhY2tzLmlyL3dwLWNvbnRlbnQvdXBsb2Fkcy8yMDE1LzAzL2hvbWVfd2ViZGVzaWduX25ld3NsZXR0ZXJfYmcuanBnIjtzOjExOiJiZ19wb3NpdGlvbiI7czoyMjoibm8tcmVwZWF0O2NlbnRlciB0b3A7OyI7czoxMjoiYmdfdmlkZW9fbXA0IjtzOjA6IiI7czoxMjoiYmdfdmlkZW9fb2d2IjtzOjA6IiI7czoxMzoiY29sdW1uX21hcmdpbiI7czowOiIiO3M6MTE6InBhZGRpbmdfdG9wIjtzOjM6IjE1MCI7czoxNDoicGFkZGluZ19ib3R0b20iO3M6MzoiMTEwIjtzOjc6ImRpdmlkZXIiO3M6MDoiIjtzOjY6ImxheW91dCI7czoxMDoibm8tc2lkZWJhciI7czoxMDoibmF2aWdhdGlvbiI7czowOiIiO3M6NToic3R5bGUiO3M6MDoiIjtzOjU6ImNsYXNzIjtzOjA6IiI7czoxMDoic2VjdGlvbl9pZCI7czowOiIiO3M6MTA6InZpc2liaWxpdHkiO3M6MDoiIjt9czo1OiJpdGVtcyI7YTozOntpOjA7YTozOntzOjQ6InR5cGUiO3M6NToiaW1hZ2UiO3M6NDoic2l6ZSI7czozOiIxLzMiO3M6NjoiZmllbGRzIjthOjE0OntzOjM6InNyYyI7czo3MDoiaHR0cDovL2Zvb2xzdGFja3MuaXIvd3AtY29udGVudC91cGxvYWRzLzIwMTUvMDMvaG9tZV93ZWJkZXNpZ25fbmV3LnBuZyI7czo1OiJ3aWR0aCI7czowOiIiO3M6NjoiaGVpZ2h0IjtzOjA6IiI7czo2OiJib3JkZXIiO3M6MToiMCI7czo1OiJhbGlnbiI7czowOiIiO3M6NjoibWFyZ2luIjtzOjA6IiI7czozOiJhbHQiO3M6MDoiIjtzOjc6ImNhcHRpb24iO3M6MDoiIjtzOjEwOiJsaW5rX2ltYWdlIjtzOjA6IiI7czo0OiJsaW5rIjtzOjA6IiI7czo2OiJ0YXJnZXQiO3M6MToiMCI7czo5OiJncmV5c2NhbGUiO3M6MToiMCI7czo3OiJhbmltYXRlIjtzOjA6IiI7czo3OiJjbGFzc2VzIjtzOjA6IiI7fX1pOjE7YTozOntzOjQ6InR5cGUiO3M6NjoiY29sdW1uIjtzOjQ6InNpemUiO3M6MzoiMS8zIjtzOjY6ImZpZWxkcyI7YTo3OntzOjU6InRpdGxlIjtzOjc6IlNpZ24gaW4iO3M6NzoiY29udGVudCI7czoxOTc6IjxoMyBzdHlsZT0iY29sb3I6ICNmZmY7IHBvc2l0aW9uOiByZWxhdGl2ZTsgdG9wOiAtOXB4OyBtYXJnaW4tbGVmdDogMTBweCI+PHNwYW4gY2xhc3M9InRoZW1lY29sb3IiIHN0eWxlPSJmb250LXdlaWdodDogNzAwOyI+U0lHTiBJTiBUTyBSRUNFSVZFPC9zcGFuPjxiciAvPg0KTkVXIFBST0pFQ1RTPGJyIC8+DQpPTiBZT1VSIEUtTUFJTDwvaDM+IjtzOjU6ImFsaWduIjtzOjA6IiI7czo5OiJjb2x1bW5fYmciO3M6MDoiIjtzOjc6InBhZGRpbmciO3M6MDoiIjtzOjc6ImFuaW1hdGUiO3M6MDoiIjtzOjc6ImNsYXNzZXMiO3M6MDoiIjt9fWk6MjthOjM6e3M6NDoidHlwZSI7czo2OiJjb2x1bW4iO3M6NDoic2l6ZSI7czozOiIxLzMiO3M6NjoiZmllbGRzIjthOjc6e3M6NToidGl0bGUiO3M6MTA6Ik5ld3NsZXR0ZXIiO3M6NzoiY29udGVudCI7czo1MzoiPGRpdiBzdHlsZT0ibWFyZ2luLXRvcDogMzNweDsiPg0KW21jNHdwX2Zvcm1dDQo8L2Rpdj4iO3M6NToiYWxpZ24iO3M6MDoiIjtzOjk6ImNvbHVtbl9iZyI7czowOiIiO3M6NzoicGFkZGluZyI7czowOiIiO3M6NzoiYW5pbWF0ZSI7czowOiIiO3M6NzoiY2xhc3NlcyI7czowOiIiO319fX19");
INSERT INTO `st_postmeta` VALUES("373","108","mfn-page-items-seo","Subheader

<h2 style=\"font-weight: 700;\">OUR OFFER</h2>
[image src=\"http://foolstacks.ir/wp-content/uploads/2015/03/home_webdesign_slider_sep.png\" border=\"0\"]

<h3>Mauris ornare magna sed molestie finibus. Duis at diam orci<br />Phasellus lorem urna, consequat ut</h3>

center

http://foolstacks.ir/wp-content/uploads/2015/03/home_webdesign_offer1_bg.jpg

<h3 style=\"font-weight: 700;\"><span style=\"display: inline-block; width: 25px; height: 25px; background: #e8a735; overflow: hidden; margin-right: 15px;\"></span>Small business websites</h3>

[one_second]
<p class=\"big\" style=\"margin: 0;\"> Lorem ipsum dolor sit amet enim. Etiam ullamcorper. Suspendisse a pellentesque dui, non felis. Maecenas malesuada elit lectus felis, malesuada ultricies. Curabitur et ligula. Ut molestie a, ultricies porta urna. Vestibulum commodo volutpat a, convallis ac, laoreet enim.</p>
[/one_second]

[one_second]
<p>Nulla imperdiet sit amet magna. Vestibulum dapibus, mauris nec malesuada fames ac turpis velit, rhoncus eu, luctus et interdum adipiscing wisi. Aliquam erat ac ipsum.</p>
<p style=\"margin: 0;\">Integer aliquam purus. Quisque lorem tortor fringilla sed, vestibulum id, eleifend justo vel bibendum sapien massa.</p>
[/one_second]

[divider height=\"1\"]
<p style=\"top: -20px; position: relative;\" class=\"big\"><a style=\"color: #e8a735;\" href=\"#\">See projects</a></p>

40

default

wide

<h3 style=\"font-weight: 700;\"><span style=\"display: inline-block; width: 25px; height: 25px; background: #0c325f; overflow: hidden; margin-right: 15px;\"></span>Portals for large
scale</h3>

<p class=\"big\">Aliquam erat ac ipsum. Integer aliquam purus. Quisque lorem tortor fringilla sed, vestibulum id eleifend. Curabitur et ligula. Ut molestie a, ultricies porta urna. Vestibulum commodo volutpat a, convallis ac, laoreet enim. Phasellus fermentum in, dolor. Pellentesque facilisis.</p>

<p class=\"big\"><a style=\"color: #0c325f;\" href=\"#\">See projects</a></p>

http://foolstacks.ir/wp-content/uploads/2015/03/home_webdesign_offer6_bg.jpg

default

http://foolstacks.ir/wp-content/uploads/2015/03/home_webdesign_offer7_bg.jpg

<p class=\"big\">Cum sociis natoque penatibus et ultrices volutpat. Nullam wisi ultricies a, gravida vitae, dapibus risus ante sodales lectus blandit eu, tempor diam pede cursus vitae, ultricies eu, faucibus quis, porttitor eros cursus lectus, pellentesque eget, bibendum a, gravida ullamcorper quam. Nullam viverra consectetuer. Quisque cursus et, porttitor risus. Aliquam sem. In hendrerit nulla quam nunc, accumsan congue. Lorem ipsum primis in nibh vel risus.</p>

<p class=\"big\">Faucibus quis, porttitor eros cursus lectus, pellentesque eget, bibendum a, gravida ullamcorper quam. Nullam viverra consectetuer. Quisque cursus et, porttitor risus. Aliquam sem. In hendrerit nulla quam nunc, accumsan congue. Lorem ipsum primis in nibh vel risus. Sed vel lectus. Ut sagittis, ipsum dolor quam.  Sed vel lectus. Ut sagittis, ipsum dolor quam.</p>

40

default

wide

<h3 style=\"font-weight: 700;\"><span style=\"display: inline-block; width: 25px; height: 25px; background: #ec2e85; overflow: hidden; margin-right: 15px;\"></span>Complete online shops</h3>

<p class=\"big\">Nulla imperdiet sit amet magna. Vestibulum dapibus, mauris nec malesuada fames ac turpis velit, rhoncus eu, luctus et interdum adipiscing wisi. Aliquam erat ac ipsum. Integer aliquam purus. Quisque lorem tortor fringilla sed, vestibulum id eleifend.</p>
<p class=\"big\">Curabitur et ligula. Ut molestie a, ultricies porta urna. Vestibulum commodo volutpat a, convallis ac, laoreet enim. Phasellus fermentum in, dolor. Pellentesque facilisis.</p>

<p class=\"big\"><a style=\"color: #ec2e85;\" href=\"#\">See projects</a></p>

http://foolstacks.ir/wp-content/uploads/2015/03/home_webdesign_offer4_bg.jpg

40

default

wide

http://foolstacks.ir/wp-content/uploads/2015/03/home_webdesign_offer4_bg.jpg

<h3 style=\"font-weight: 700;\"><span style=\"display: inline-block; width: 25px; height: 25px; background: #0c7baf; overflow: hidden; margin-right: 15px;\"></span>WordPress & Joomla themes</h3>

<p class=\"big\">Nulla imperdiet sit amet magna. Vestibulum dapibus, mauris nec malesuada fames ac turpis velit, rhoncus eu, luctus et interdum adipiscing wisi. Aliquam erat ac ipsum. Integer aliquam purus. Quisque lorem tortor fringilla sed, vestibulum id, eleifend justo vel bibendum sapien massa ac turpis faucibus orci luctus non</p>
<p class=\"big\">Nullam wisi ultricies a, gravida vitae, dapibus risus ante sodales lectus blandit eu, tempor diam pede cursus vitae, ultricies eu, faucibus quis, porttitor eros cursu.</p>

<p class=\"big\"><a style=\"color: #0c7baf;\" href=\"#\">See projects</a></p>

http://foolstacks.ir/wp-content/uploads/2015/03/home_webdesign_new.png

Sign in

<h3 style=\"color: #fff; position: relative; top: -9px; margin-left: 10px\"><span class=\"themecolor\" style=\"font-weight: 700;\">SIGN IN TO RECEIVE</span><br />
NEW PROJECTS<br />
ON YOUR E-MAIL</h3>

Newsletter

<div style=\"margin-top: 33px;\">
[mc4wp_form]
</div>

");
INSERT INTO `st_postmeta` VALUES("959","108","_yoast_wpseo_content_score","30");
INSERT INTO `st_postmeta` VALUES("374","108","mfn-post-hide-content","0");
INSERT INTO `st_postmeta` VALUES("375","108","mfn-post-custom-layout","0");
INSERT INTO `st_postmeta` VALUES("376","108","mfn-post-slider","0");
INSERT INTO `st_postmeta` VALUES("377","108","mfn-post-slider-layer","0");
INSERT INTO `st_postmeta` VALUES("378","108","mfn-post-menu","0");
INSERT INTO `st_postmeta` VALUES("379","108","mfn-post-one-page","0");
INSERT INTO `st_postmeta` VALUES("380","108","mfn-post-hide-title","0");
INSERT INTO `st_postmeta` VALUES("381","108","mfn-post-remove-padding","1");
INSERT INTO `st_postmeta` VALUES("1317","2364","id_field","ID");
INSERT INTO `st_postmeta` VALUES("1316","2364","filter","raw");
INSERT INTO `st_postmeta` VALUES("1315","2364","__defaults_set","1");
INSERT INTO `st_postmeta` VALUES("1305","2363","id_field","ID");
INSERT INTO `st_postmeta` VALUES("1304","2363","filter","raw");
INSERT INTO `st_postmeta` VALUES("1303","2363","__defaults_set","1");
INSERT INTO `st_postmeta` VALUES("1293","2362","id_field","ID");
INSERT INTO `st_postmeta` VALUES("1292","2362","filter","raw");
INSERT INTO `st_postmeta` VALUES("1291","2362","__defaults_set","1");
INSERT INTO `st_postmeta` VALUES("392","110","_wp_page_template","default");
INSERT INTO `st_postmeta` VALUES("393","110","slide_template","default");
INSERT INTO `st_postmeta` VALUES("394","110","mfn-page-items","YTozOntpOjA7YToyOntzOjQ6ImF0dHIiO2E6MTY6e3M6NToidGl0bGUiO3M6OToiU3ViaGVhZGVyIjtzOjg6ImJnX2ltYWdlIjtzOjc4OiJodHRwOi8vZm9vbHN0YWNrcy5pci93cC1jb250ZW50L3VwbG9hZHMvMjAxNS8wMy9ob21lX3dlYmRlc2lnbl9zdWJoZWFkZXJfNC5qcGciO3M6MTE6ImJnX3Bvc2l0aW9uIjtzOjIyOiJuby1yZXBlYXQ7Y2VudGVyIHRvcDs7IjtzOjg6ImJnX2NvbG9yIjtzOjA6IiI7czo3OiJkaXZpZGVyIjtzOjA6IiI7czoxMjoiYmdfdmlkZW9fbXA0IjtzOjA6IiI7czoxMjoiYmdfdmlkZW9fb2d2IjtzOjA6IiI7czo2OiJsYXlvdXQiO3M6MTA6Im5vLXNpZGViYXIiO3M6MTE6InBhZGRpbmdfdG9wIjtzOjM6IjIwMCI7czoxNDoicGFkZGluZ19ib3R0b20iO3M6MjoiODAiO3M6MTM6ImNvbHVtbl9tYXJnaW4iO3M6MDoiIjtzOjU6InN0eWxlIjtzOjQ6ImRhcmsiO3M6MTA6Im5hdmlnYXRpb24iO3M6MDoiIjtzOjU6ImNsYXNzIjtzOjA6IiI7czoxMDoic2VjdGlvbl9pZCI7czowOiIiO3M6MTA6InZpc2liaWxpdHkiO3M6MDoiIjt9czo1OiJpdGVtcyI7YToxOntpOjA7YTozOntzOjQ6InR5cGUiO3M6NjoiY29sdW1uIjtzOjQ6InNpemUiO3M6MzoiMS8xIjtzOjY6ImZpZWxkcyI7YTo1OntzOjU6InRpdGxlIjtzOjk6IlN1YmhlYWRlciI7czo3OiJjb250ZW50IjtzOjE0OToiPGgyIHN0eWxlPSJmb250LXdlaWdodDogNzAwOyI+Q09OVEFDVCBVUzwvaDI+DQpbaW1hZ2Ugc3JjPSJodHRwOi8vZm9vbHN0YWNrcy5pci93cC1jb250ZW50L3VwbG9hZHMvMjAxNS8wMy9ob21lX3dlYmRlc2lnbl9zbGlkZXJfc2VwLnBuZyIgYm9yZGVyPSIwIl0iO3M6NToiYWxpZ24iO3M6MDoiIjtzOjc6ImFuaW1hdGUiO3M6MDoiIjtzOjc6ImNsYXNzZXMiO3M6MDoiIjt9fX19aToxO2E6Mjp7czo0OiJhdHRyIjthOjE2OntzOjU6InRpdGxlIjtzOjA6IiI7czo4OiJiZ19pbWFnZSI7czowOiIiO3M6MTE6ImJnX3Bvc2l0aW9uIjtzOjIyOiJuby1yZXBlYXQ7Y2VudGVyIHRvcDs7IjtzOjg6ImJnX2NvbG9yIjtzOjA6IiI7czo3OiJkaXZpZGVyIjtzOjA6IiI7czoxMjoiYmdfdmlkZW9fbXA0IjtzOjA6IiI7czoxMjoiYmdfdmlkZW9fb2d2IjtzOjA6IiI7czo2OiJsYXlvdXQiO3M6MTA6Im5vLXNpZGViYXIiO3M6MTE6InBhZGRpbmdfdG9wIjtzOjI6IjcwIjtzOjE0OiJwYWRkaW5nX2JvdHRvbSI7czoyOiIzMCI7czoxMzoiY29sdW1uX21hcmdpbiI7czowOiIiO3M6NToic3R5bGUiO3M6MDoiIjtzOjEwOiJuYXZpZ2F0aW9uIjtzOjA6IiI7czo1OiJjbGFzcyI7czowOiIiO3M6MTA6InNlY3Rpb25faWQiO3M6MDoiIjtzOjEwOiJ2aXNpYmlsaXR5IjtzOjA6IiI7fXM6NToiaXRlbXMiO2E6Mzp7aTowO2E6Mzp7czo0OiJ0eXBlIjtzOjY6ImNvbHVtbiI7czo0OiJzaXplIjtzOjM6IjEvMSI7czo2OiJmaWVsZHMiO2E6NTp7czo1OiJ0aXRsZSI7czowOiIiO3M6NzoiY29udGVudCI7czoxMTU6IjxoMz5NYWVjZW5hcyBpbiBkaWFtIHNpdCBhbWV0IG51bmMgc2FnaXR0aXMgPHN0cm9uZz5jb25kaSBtZW50dW08L3N0cm9uZz48YnIgLz5lZ2V0IG5vbiB0b3J0b3IgbnVsbGFtIG9yY2kgZHVpPC9oMz4iO3M6NToiYWxpZ24iO3M6NjoiY2VudGVyIjtzOjc6ImFuaW1hdGUiO3M6MDoiIjtzOjc6ImNsYXNzZXMiO3M6MDoiIjt9fWk6MTthOjM6e3M6NDoidHlwZSI7czo2OiJjb2x1bW4iO3M6NDoic2l6ZSI7czozOiIxLzIiO3M6NjoiZmllbGRzIjthOjU6e3M6NToidGl0bGUiO3M6MDoiIjtzOjc6ImNvbnRlbnQiO3M6ODExOiI8aDM+T3VyIDxzdHJvbmc+YWRyZXNzPC9zdHJvbmc+PC9oMz4NCg0KW29uZV9zZWNvbmRdDQpbaW1hZ2Ugc3JjPSJodHRwOi8vZm9vbHN0YWNrcy5pci93cC1jb250ZW50L3VwbG9hZHMvMjAxNS8wMy9ob21lX3dlYmRlc2lnbl9jb250YWN0X3Bob3RvLmpwZyIgbGluaz0iIyIgYm9yZGVyPSIwIl0NClsvb25lX3NlY29uZF0NCltvbmVfc2Vjb25kXQ0KPGg0PkJlV2ViZGVzaWduPC9oND4NCjxoNiBzdHlsZT0ibWFyZ2luLWJvdHRvbTogN3B4OyI+TWl0IHNhbWV0IGV0IG9tbmlhIHZhbml0YXM8L2g1Pg0KPHA+TW9yYmkgYWNjdW1zYW4gaXBzdW0gdmVsaXQuIE5hbSBuZWMgdGVsbHVzIGEgb2RpbyB0aW5jaWR1bnQgYXVjdG88L3A+DQo8cCBzdHlsZT0ibWFyZ2luLWJvdHRvbTogN3B4OyI+PGEgaHJlZj0iIyI+U2VuZCB1cyBlLW1haWw8L2E+PC9wPg0KPHA+PGEgaHJlZj0iIyIgY2xhc3M9ImFycm93X2xpbmsiPkNhbGwgdXM6IDIzMyA0NTUgNzc1PC9hPjwvcD4NClsvb25lX3NlY29uZF0NCg0KW2RpdmlkZXIgaGVpZ2h0PSIxIl0NCg0KPGgzPlNlbmQgdXMgPHN0cm9uZz5hIG1lc3NhZ2U8L3N0cm9uZz48L2gzPg0KPHAgY2xhc3M9ImJpZyI+Vml0YWUgYWRpcGlzY2luZyB0dXJwaXMuIEFlbmVhbiBsaWd1bGEgbmliaCwgbW9sZXN0aWUgIEFlbmVhbiBsaWd1bGEgbmliaCwgbW9sZXN0aWUgaWQgdml2ZXJyYSBhLCBkYXBpYnVzIGF0IGRvbG9yLiBJbiBpYWN1bGlzIHZpdmVycmEgbmVxdWUsIGFjIGVsZWlmZW5kIGFudGUgbG9ib3J0aXMuPC9wPg0KW2NvbnRhY3QtZm9ybS03IGlkPSI5MiIgdGl0bGU9IkNvbnRhY3QgcGFnZSJdIjtzOjU6ImFsaWduIjtzOjA6IiI7czo3OiJhbmltYXRlIjtzOjA6IiI7czo3OiJjbGFzc2VzIjtzOjA6IiI7fX1pOjI7YTozOntzOjQ6InR5cGUiO3M6MzoibWFwIjtzOjQ6InNpemUiO3M6MzoiMS8yIjtzOjY6ImZpZWxkcyI7YToxNDp7czozOiJsYXQiO3M6ODoiLTMzLjg3MTAiO3M6MzoibG5nIjtzOjg6IjE1MS4yMDM5IjtzOjQ6Inpvb20iO3M6MjoiMTMiO3M6NjoiaGVpZ2h0IjtzOjM6Ijc2MCI7czo2OiJib3JkZXIiO3M6MToiMCI7czo0OiJpY29uIjtzOjcwOiJodHRwOi8vZm9vbHN0YWNrcy5pci93cC1jb250ZW50L3VwbG9hZHMvMjAxNS8wMy9ob21lX3dlYmRlc2lnbl9waW4ucG5nIjtzOjY6InN0eWxlcyI7czo3OTg6Ilt7ImZlYXR1cmVUeXBlIjoiYWRtaW5pc3RyYXRpdmUiLCJlbGVtZW50VHlwZSI6ImxhYmVscy50ZXh0LmZpbGwiLCJzdHlsZXJzIjpbeyJjb2xvciI6IiM0NDQ0NDQifV19LHsiZmVhdHVyZVR5cGUiOiJsYW5kc2NhcGUiLCJlbGVtZW50VHlwZSI6ImFsbCIsInN0eWxlcnMiOlt7ImNvbG9yIjoiI2YyZjJmMiJ9XX0seyJmZWF0dXJlVHlwZSI6InBvaSIsImVsZW1lbnRUeXBlIjoiYWxsIiwic3R5bGVycyI6W3sidmlzaWJpbGl0eSI6Im9mZiJ9XX0seyJmZWF0dXJlVHlwZSI6InJvYWQiLCJlbGVtZW50VHlwZSI6ImFsbCIsInN0eWxlcnMiOlt7InNhdHVyYXRpb24iOi0xMDB9LHsibGlnaHRuZXNzIjo0NX1dfSx7ImZlYXR1cmVUeXBlIjoicm9hZC5oaWdod2F5IiwiZWxlbWVudFR5cGUiOiJhbGwiLCJzdHlsZXJzIjpbeyJ2aXNpYmlsaXR5Ijoic2ltcGxpZmllZCJ9XX0seyJmZWF0dXJlVHlwZSI6InJvYWQuaGlnaHdheSIsImVsZW1lbnRUeXBlIjoiZ2VvbWV0cnkuZmlsbCIsInN0eWxlcnMiOlt7ImNvbG9yIjoiI2ZmZmZmZiJ9XX0seyJmZWF0dXJlVHlwZSI6InJvYWQuYXJ0ZXJpYWwiLCJlbGVtZW50VHlwZSI6ImxhYmVscy5pY29uIiwic3R5bGVycyI6W3sidmlzaWJpbGl0eSI6Im9mZiJ9XX0seyJmZWF0dXJlVHlwZSI6InRyYW5zaXQiLCJlbGVtZW50VHlwZSI6ImFsbCIsInN0eWxlcnMiOlt7InZpc2liaWxpdHkiOiJvZmYifV19LHsiZmVhdHVyZVR5cGUiOiJ3YXRlciIsImVsZW1lbnRUeXBlIjoiYWxsIiwic3R5bGVycyI6W3siY29sb3IiOiIjZGRlNmU4In0seyJ2aXNpYmlsaXR5Ijoib24ifV19XSI7czo2OiJsYXRsbmciO3M6MDoiIjtzOjU6InRpdGxlIjtzOjA6IiI7czo3OiJjb250ZW50IjtzOjA6IiI7czo5OiJ0ZWxlcGhvbmUiO3M6MDoiIjtzOjU6ImVtYWlsIjtzOjA6IiI7czozOiJ3d3ciO3M6MDoiIjtzOjc6ImNsYXNzZXMiO3M6MDoiIjt9fX19aToyO2E6Mjp7czo0OiJhdHRyIjthOjE2OntzOjU6InRpdGxlIjtzOjA6IiI7czo4OiJiZ19pbWFnZSI7czo4MDoiaHR0cDovL2Zvb2xzdGFja3MuaXIvd3AtY29udGVudC91cGxvYWRzLzIwMTUvMDMvaG9tZV93ZWJkZXNpZ25fbmV3c2xldHRlcl9iZy5qcGciO3M6MTE6ImJnX3Bvc2l0aW9uIjtzOjIyOiJuby1yZXBlYXQ7Y2VudGVyIHRvcDs7IjtzOjg6ImJnX2NvbG9yIjtzOjA6IiI7czo3OiJkaXZpZGVyIjtzOjA6IiI7czoxMjoiYmdfdmlkZW9fbXA0IjtzOjA6IiI7czoxMjoiYmdfdmlkZW9fb2d2IjtzOjA6IiI7czo2OiJsYXlvdXQiO3M6MTA6Im5vLXNpZGViYXIiO3M6MTE6InBhZGRpbmdfdG9wIjtzOjM6IjE1MCI7czoxNDoicGFkZGluZ19ib3R0b20iO3M6MzoiMTEwIjtzOjEzOiJjb2x1bW5fbWFyZ2luIjtzOjA6IiI7czo1OiJzdHlsZSI7czowOiIiO3M6MTA6Im5hdmlnYXRpb24iO3M6MDoiIjtzOjU6ImNsYXNzIjtzOjA6IiI7czoxMDoic2VjdGlvbl9pZCI7czowOiIiO3M6MTA6InZpc2liaWxpdHkiO3M6MDoiIjt9czo1OiJpdGVtcyI7YTozOntpOjA7YTozOntzOjQ6InR5cGUiO3M6NToiaW1hZ2UiO3M6NDoic2l6ZSI7czozOiIxLzMiO3M6NjoiZmllbGRzIjthOjE0OntzOjM6InNyYyI7czo3MDoiaHR0cDovL2Zvb2xzdGFja3MuaXIvd3AtY29udGVudC91cGxvYWRzLzIwMTUvMDMvaG9tZV93ZWJkZXNpZ25fbmV3LnBuZyI7czo1OiJ3aWR0aCI7czowOiIiO3M6NjoiaGVpZ2h0IjtzOjA6IiI7czo2OiJib3JkZXIiO3M6MToiMCI7czo1OiJhbGlnbiI7czowOiIiO3M6NjoibWFyZ2luIjtzOjA6IiI7czozOiJhbHQiO3M6MDoiIjtzOjc6ImNhcHRpb24iO3M6MDoiIjtzOjEwOiJsaW5rX2ltYWdlIjtzOjA6IiI7czo0OiJsaW5rIjtzOjA6IiI7czo2OiJ0YXJnZXQiO3M6MToiMCI7czo5OiJncmV5c2NhbGUiO3M6MToiMCI7czo3OiJhbmltYXRlIjtzOjA6IiI7czo3OiJjbGFzc2VzIjtzOjA6IiI7fX1pOjE7YTozOntzOjQ6InR5cGUiO3M6NjoiY29sdW1uIjtzOjQ6InNpemUiO3M6MzoiMS8zIjtzOjY6ImZpZWxkcyI7YTo1OntzOjU6InRpdGxlIjtzOjc6IlNpZ24gaW4iO3M6NzoiY29udGVudCI7czoxOTc6IjxoMyBzdHlsZT0iY29sb3I6ICNmZmY7IHBvc2l0aW9uOiByZWxhdGl2ZTsgdG9wOiAtOXB4OyBtYXJnaW4tbGVmdDogMTBweCI+PHNwYW4gY2xhc3M9InRoZW1lY29sb3IiIHN0eWxlPSJmb250LXdlaWdodDogNzAwOyI+U0lHTiBJTiBUTyBSRUNFSVZFPC9zcGFuPjxiciAvPg0KTkVXIFBST0pFQ1RTPGJyIC8+DQpPTiBZT1VSIEUtTUFJTDwvaDM+IjtzOjU6ImFsaWduIjtzOjA6IiI7czo3OiJhbmltYXRlIjtzOjA6IiI7czo3OiJjbGFzc2VzIjtzOjA6IiI7fX1pOjI7YTozOntzOjQ6InR5cGUiO3M6NjoiY29sdW1uIjtzOjQ6InNpemUiO3M6MzoiMS8zIjtzOjY6ImZpZWxkcyI7YTo1OntzOjU6InRpdGxlIjtzOjEwOiJOZXdzbGV0dGVyIjtzOjc6ImNvbnRlbnQiO3M6NTM6IjxkaXYgc3R5bGU9Im1hcmdpbi10b3A6IDMzcHg7Ij4NClttYzR3cF9mb3JtXQ0KPC9kaXY+IjtzOjU6ImFsaWduIjtzOjA6IiI7czo3OiJhbmltYXRlIjtzOjA6IiI7czo3OiJjbGFzc2VzIjtzOjA6IiI7fX19fX0=");
INSERT INTO `st_postmeta` VALUES("395","110","mfn-page-items-seo","Subheader

<h2 style=\"font-weight: 700;\">CONTACT US</h2>
[image src=\"http://themes.muffingroup.com/be/webdesign/wp-content/uploads/2015/03/home_webdesign_slider_sep.png\" border=\"0\"]

<h3>Maecenas in diam sit amet nunc sagittis <strong>condi mentum</strong><br />eget non tortor nullam orci dui</h3>

center

<h3>Our <strong>adress</strong></h3>

[one_second]
[image src=\"http://themes.muffingroup.com/be/webdesign/wp-content/uploads/2015/03/home_webdesign_contact_photo.jpg\" link=\"#\" border=\"0\"]
[/one_second]
[one_second]
<h4>BeWebdesign</h4>
<h6 style=\"margin-bottom: 7px;\">Mit samet et omnia vanitas</h5>
<p>Morbi accumsan ipsum velit. Nam nec tellus a odio tincidunt aucto</p>
<p style=\"margin-bottom: 7px;\"><a href=\"#\">Send us e-mail</a></p>
<p><a href=\"#\" class=\"arrow_link\">Call us: 233 455 775</a></p>
[/one_second]

[divider height=\"1\"]

<h3>Send us <strong>a message</strong></h3>
<p class=\"big\">Vitae adipiscing turpis. Aenean ligula nibh, molestie  Aenean ligula nibh, molestie id viverra a, dapibus at dolor. In iaculis viverra neque, ac eleifend ante lobortis.</p>
[contact-form-7 id=\"92\" title=\"Contact page\"]

-33.8710

151.2039

13

760

http://themes.muffingroup.com/be/webdesign/wp-content/uploads/2015/03/home_webdesign_pin.png

[{\"featureType\":\"administrative\",\"elementType\":\"labels.text.fill\",\"stylers\":[{\"color\":\"#444444\"}]},{\"featureType\":\"landscape\",\"elementType\":\"all\",\"stylers\":[{\"color\":\"#f2f2f2\"}]},{\"featureType\":\"poi\",\"elementType\":\"all\",\"stylers\":[{\"visibility\":\"off\"}]},{\"featureType\":\"road\",\"elementType\":\"all\",\"stylers\":[{\"saturation\":-100},{\"lightness\":45}]},{\"featureType\":\"road.highway\",\"elementType\":\"all\",\"stylers\":[{\"visibility\":\"simplified\"}]},{\"featureType\":\"road.highway\",\"elementType\":\"geometry.fill\",\"stylers\":[{\"color\":\"#ffffff\"}]},{\"featureType\":\"road.arterial\",\"elementType\":\"labels.icon\",\"stylers\":[{\"visibility\":\"off\"}]},{\"featureType\":\"transit\",\"elementType\":\"all\",\"stylers\":[{\"visibility\":\"off\"}]},{\"featureType\":\"water\",\"elementType\":\"all\",\"stylers\":[{\"color\":\"#dde6e8\"},{\"visibility\":\"on\"}]}]

http://themes.muffingroup.com/be/webdesign/wp-content/uploads/2015/03/home_webdesign_new.png

Sign in

<h3 style=\"color: #fff; position: relative; top: -9px; margin-left: 10px\"><span class=\"themecolor\" style=\"font-weight: 700;\">SIGN IN TO RECEIVE</span><br />
NEW PROJECTS<br />
ON YOUR E-MAIL</h3>

Newsletter

<div style=\"margin-top: 33px;\">
[mc4wp_form]
</div>

");
INSERT INTO `st_postmeta` VALUES("396","110","mfn-post-hide-content","0");
INSERT INTO `st_postmeta` VALUES("397","110","mfn-post-custom-layout","0");
INSERT INTO `st_postmeta` VALUES("398","110","mfn-post-slider","0");
INSERT INTO `st_postmeta` VALUES("399","110","mfn-post-slider-layer","0");
INSERT INTO `st_postmeta` VALUES("400","110","mfn-post-menu","0");
INSERT INTO `st_postmeta` VALUES("401","110","mfn-post-one-page","0");
INSERT INTO `st_postmeta` VALUES("402","110","mfn-post-hide-title","0");
INSERT INTO `st_postmeta` VALUES("403","110","mfn-post-remove-padding","1");
INSERT INTO `st_postmeta` VALUES("404","111","_wp_page_template","default");
INSERT INTO `st_postmeta` VALUES("405","111","slide_template","default");
INSERT INTO `st_postmeta` VALUES("406","111","mfn-post-hide-content","0");
INSERT INTO `st_postmeta` VALUES("407","111","mfn-post-custom-layout","0");
INSERT INTO `st_postmeta` VALUES("408","111","mfn-post-slider","0");
INSERT INTO `st_postmeta` VALUES("409","111","mfn-post-slider-layer","0");
INSERT INTO `st_postmeta` VALUES("410","111","mfn-post-menu","0");
INSERT INTO `st_postmeta` VALUES("411","111","mfn-post-one-page","0");
INSERT INTO `st_postmeta` VALUES("412","111","mfn-post-hide-title","0");
INSERT INTO `st_postmeta` VALUES("413","111","mfn-post-remove-padding","1");
INSERT INTO `st_postmeta` VALUES("414","111","mfn-page-items","YTozOntpOjA7YToyOntzOjQ6ImF0dHIiO2E6MTY6e3M6NToidGl0bGUiO3M6OToiU3ViaGVhZGVyIjtzOjg6ImJnX2NvbG9yIjtzOjA6IiI7czo4OiJiZ19pbWFnZSI7czo3ODoiaHR0cDovL2Zvb2xzdGFja3MuaXIvd3AtY29udGVudC91cGxvYWRzLzIwMTUvMDMvaG9tZV93ZWJkZXNpZ25fc3ViaGVhZGVyXzMuanBnIjtzOjExOiJiZ19wb3NpdGlvbiI7czoyMjoibm8tcmVwZWF0O2NlbnRlciB0b3A7OyI7czoxMjoiYmdfdmlkZW9fbXA0IjtzOjA6IiI7czoxMjoiYmdfdmlkZW9fb2d2IjtzOjA6IiI7czoxMzoiY29sdW1uX21hcmdpbiI7czowOiIiO3M6MTE6InBhZGRpbmdfdG9wIjtzOjM6IjIwMCI7czoxNDoicGFkZGluZ19ib3R0b20iO3M6MjoiODAiO3M6NzoiZGl2aWRlciI7czowOiIiO3M6NjoibGF5b3V0IjtzOjEwOiJuby1zaWRlYmFyIjtzOjEwOiJuYXZpZ2F0aW9uIjtzOjA6IiI7czo1OiJzdHlsZSI7czo0OiJkYXJrIjtzOjU6ImNsYXNzIjtzOjA6IiI7czoxMDoic2VjdGlvbl9pZCI7czowOiIiO3M6MTA6InZpc2liaWxpdHkiO3M6MDoiIjt9czo1OiJpdGVtcyI7YToxOntpOjA7YTozOntzOjQ6InR5cGUiO3M6NjoiY29sdW1uIjtzOjQ6InNpemUiO3M6MzoiMS8xIjtzOjY6ImZpZWxkcyI7YTo3OntzOjU6InRpdGxlIjtzOjk6IlN1YmhlYWRlciI7czo3OiJjb250ZW50IjtzOjE1MToiPGgyIHN0eWxlPSJmb250LXdlaWdodDogNzAwOyI+UkVBTElTQVRJT05TPC9oMj4NCltpbWFnZSBzcmM9Imh0dHA6Ly9mb29sc3RhY2tzLmlyL3dwLWNvbnRlbnQvdXBsb2Fkcy8yMDE1LzAzL2hvbWVfd2ViZGVzaWduX3NsaWRlcl9zZXAucG5nIiBib3JkZXI9IjAiXSI7czo1OiJhbGlnbiI7czowOiIiO3M6OToiY29sdW1uX2JnIjtzOjA6IiI7czo3OiJwYWRkaW5nIjtzOjA6IiI7czo3OiJhbmltYXRlIjtzOjA6IiI7czo3OiJjbGFzc2VzIjtzOjA6IiI7fX19fWk6MTthOjI6e3M6NDoiYXR0ciI7YToxNjp7czo1OiJ0aXRsZSI7czowOiIiO3M6ODoiYmdfY29sb3IiO3M6MDoiIjtzOjg6ImJnX2ltYWdlIjtzOjA6IiI7czoxMToiYmdfcG9zaXRpb24iO3M6MjI6Im5vLXJlcGVhdDtjZW50ZXIgdG9wOzsiO3M6MTI6ImJnX3ZpZGVvX21wNCI7czowOiIiO3M6MTI6ImJnX3ZpZGVvX29ndiI7czowOiIiO3M6MTM6ImNvbHVtbl9tYXJnaW4iO3M6MDoiIjtzOjExOiJwYWRkaW5nX3RvcCI7czoyOiI3MCI7czoxNDoicGFkZGluZ19ib3R0b20iO3M6MjoiMzAiO3M6NzoiZGl2aWRlciI7czowOiIiO3M6NjoibGF5b3V0IjtzOjEwOiJuby1zaWRlYmFyIjtzOjEwOiJuYXZpZ2F0aW9uIjtzOjA6IiI7czo1OiJzdHlsZSI7czowOiIiO3M6NToiY2xhc3MiO3M6MDoiIjtzOjEwOiJzZWN0aW9uX2lkIjtzOjA6IiI7czoxMDoidmlzaWJpbGl0eSI7czowOiIiO31zOjU6Iml0ZW1zIjthOjI6e2k6MDthOjM6e3M6NDoidHlwZSI7czo2OiJjb2x1bW4iO3M6NDoic2l6ZSI7czozOiIxLzEiO3M6NjoiZmllbGRzIjthOjc6e3M6NToidGl0bGUiO3M6MDoiIjtzOjc6ImNvbnRlbnQiO3M6MTE1OiI8aDM+TWFlY2VuYXMgaW4gZGlhbSBzaXQgYW1ldCBudW5jIHNhZ2l0dGlzIDxzdHJvbmc+Y29uZGkgbWVudHVtPC9zdHJvbmc+PGJyIC8+ZWdldCBub24gdG9ydG9yIG51bGxhbSBvcmNpIGR1aTwvaDM+IjtzOjU6ImFsaWduIjtzOjY6ImNlbnRlciI7czo5OiJjb2x1bW5fYmciO3M6MDoiIjtzOjc6InBhZGRpbmciO3M6MDoiIjtzOjc6ImFuaW1hdGUiO3M6MDoiIjtzOjc6ImNsYXNzZXMiO3M6MDoiIjt9fWk6MTthOjM6e3M6NDoidHlwZSI7czo5OiJwb3J0Zm9saW8iO3M6NDoic2l6ZSI7czozOiIxLzEiO3M6NjoiZmllbGRzIjthOjEyOntzOjU6ImNvdW50IjtzOjE6IjYiO3M6ODoiY2F0ZWdvcnkiO3M6MDoiIjtzOjE0OiJjYXRlZ29yeV9tdWx0aSI7czowOiIiO3M6NToic3R5bGUiO3M6NzoibWFzb25yeSI7czo3OiJjb2x1bW5zIjtzOjE6IjMiO3M6OToiZ3JleXNjYWxlIjtzOjE6IjAiO3M6Nzoib3JkZXJieSI7czo0OiJkYXRlIjtzOjU6Im9yZGVyIjtzOjQ6IkRFU0MiO3M6NzoiZmlsdGVycyI7czoxOiIwIjtzOjEwOiJwYWdpbmF0aW9uIjtzOjE6IjAiO3M6OToibG9hZF9tb3JlIjtzOjE6IjEiO3M6NzoiY2xhc3NlcyI7czowOiIiO319fX1pOjI7YToyOntzOjQ6ImF0dHIiO2E6MTY6e3M6NToidGl0bGUiO3M6MDoiIjtzOjg6ImJnX2NvbG9yIjtzOjA6IiI7czo4OiJiZ19pbWFnZSI7czo4MDoiaHR0cDovL2Zvb2xzdGFja3MuaXIvd3AtY29udGVudC91cGxvYWRzLzIwMTUvMDMvaG9tZV93ZWJkZXNpZ25fbmV3c2xldHRlcl9iZy5qcGciO3M6MTE6ImJnX3Bvc2l0aW9uIjtzOjIyOiJuby1yZXBlYXQ7Y2VudGVyIHRvcDs7IjtzOjEyOiJiZ192aWRlb19tcDQiO3M6MDoiIjtzOjEyOiJiZ192aWRlb19vZ3YiO3M6MDoiIjtzOjEzOiJjb2x1bW5fbWFyZ2luIjtzOjA6IiI7czoxMToicGFkZGluZ190b3AiO3M6MzoiMTUwIjtzOjE0OiJwYWRkaW5nX2JvdHRvbSI7czozOiIxMTAiO3M6NzoiZGl2aWRlciI7czowOiIiO3M6NjoibGF5b3V0IjtzOjEwOiJuby1zaWRlYmFyIjtzOjEwOiJuYXZpZ2F0aW9uIjtzOjA6IiI7czo1OiJzdHlsZSI7czowOiIiO3M6NToiY2xhc3MiO3M6MDoiIjtzOjEwOiJzZWN0aW9uX2lkIjtzOjA6IiI7czoxMDoidmlzaWJpbGl0eSI7czowOiIiO31zOjU6Iml0ZW1zIjthOjM6e2k6MDthOjM6e3M6NDoidHlwZSI7czo1OiJpbWFnZSI7czo0OiJzaXplIjtzOjM6IjEvMyI7czo2OiJmaWVsZHMiO2E6MTQ6e3M6Mzoic3JjIjtzOjcwOiJodHRwOi8vZm9vbHN0YWNrcy5pci93cC1jb250ZW50L3VwbG9hZHMvMjAxNS8wMy9ob21lX3dlYmRlc2lnbl9uZXcucG5nIjtzOjU6IndpZHRoIjtzOjA6IiI7czo2OiJoZWlnaHQiO3M6MDoiIjtzOjY6ImJvcmRlciI7czoxOiIwIjtzOjU6ImFsaWduIjtzOjA6IiI7czo2OiJtYXJnaW4iO3M6MDoiIjtzOjM6ImFsdCI7czowOiIiO3M6NzoiY2FwdGlvbiI7czowOiIiO3M6MTA6ImxpbmtfaW1hZ2UiO3M6MDoiIjtzOjQ6ImxpbmsiO3M6MDoiIjtzOjY6InRhcmdldCI7czoxOiIwIjtzOjk6ImdyZXlzY2FsZSI7czoxOiIwIjtzOjc6ImFuaW1hdGUiO3M6MDoiIjtzOjc6ImNsYXNzZXMiO3M6MDoiIjt9fWk6MTthOjM6e3M6NDoidHlwZSI7czo2OiJjb2x1bW4iO3M6NDoic2l6ZSI7czozOiIxLzMiO3M6NjoiZmllbGRzIjthOjc6e3M6NToidGl0bGUiO3M6NzoiU2lnbiBpbiI7czo3OiJjb250ZW50IjtzOjE5NzoiPGgzIHN0eWxlPSJjb2xvcjogI2ZmZjsgcG9zaXRpb246IHJlbGF0aXZlOyB0b3A6IC05cHg7IG1hcmdpbi1sZWZ0OiAxMHB4Ij48c3BhbiBjbGFzcz0idGhlbWVjb2xvciIgc3R5bGU9ImZvbnQtd2VpZ2h0OiA3MDA7Ij5TSUdOIElOIFRPIFJFQ0VJVkU8L3NwYW4+PGJyIC8+DQpORVcgUFJPSkVDVFM8YnIgLz4NCk9OIFlPVVIgRS1NQUlMPC9oMz4iO3M6NToiYWxpZ24iO3M6MDoiIjtzOjk6ImNvbHVtbl9iZyI7czowOiIiO3M6NzoicGFkZGluZyI7czowOiIiO3M6NzoiYW5pbWF0ZSI7czowOiIiO3M6NzoiY2xhc3NlcyI7czowOiIiO319aToyO2E6Mzp7czo0OiJ0eXBlIjtzOjY6ImNvbHVtbiI7czo0OiJzaXplIjtzOjM6IjEvMyI7czo2OiJmaWVsZHMiO2E6Nzp7czo1OiJ0aXRsZSI7czoxMDoiTmV3c2xldHRlciI7czo3OiJjb250ZW50IjtzOjUzOiI8ZGl2IHN0eWxlPSJtYXJnaW4tdG9wOiAzM3B4OyI+DQpbbWM0d3BfZm9ybV0NCjwvZGl2PiI7czo1OiJhbGlnbiI7czowOiIiO3M6OToiY29sdW1uX2JnIjtzOjA6IiI7czo3OiJwYWRkaW5nIjtzOjA6IiI7czo3OiJhbmltYXRlIjtzOjA6IiI7czo3OiJjbGFzc2VzIjtzOjA6IiI7fX19fX0=");
INSERT INTO `st_postmeta` VALUES("415","111","mfn-page-items-seo","Subheader

<h2 style=\"font-weight: 700;\">REALISATIONS</h2>
[image src=\"http://foolstacks.ir/wp-content/uploads/2015/03/home_webdesign_slider_sep.png\" border=\"0\"]

<h3>Maecenas in diam sit amet nunc sagittis <strong>condi mentum</strong><br />eget non tortor nullam orci dui</h3>

center

6

masonry

3

date

DESC

http://foolstacks.ir/wp-content/uploads/2015/03/home_webdesign_new.png

Sign in

<h3 style=\"color: #fff; position: relative; top: -9px; margin-left: 10px\"><span class=\"themecolor\" style=\"font-weight: 700;\">SIGN IN TO RECEIVE</span><br />
NEW PROJECTS<br />
ON YOUR E-MAIL</h3>

Newsletter

<div style=\"margin-top: 33px;\">
[mc4wp_form]
</div>

");
INSERT INTO `st_postmeta` VALUES("1281","2361","id_field","ID");
INSERT INTO `st_postmeta` VALUES("1280","2361","filter","raw");
INSERT INTO `st_postmeta` VALUES("1279","2361","__defaults_set","1");
INSERT INTO `st_postmeta` VALUES("1269","2360","id_field","ID");
INSERT INTO `st_postmeta` VALUES("1268","2360","filter","raw");
INSERT INTO `st_postmeta` VALUES("1267","2360","__defaults_set","1");
INSERT INTO `st_postmeta` VALUES("1257","2359","id_field","ID");
INSERT INTO `st_postmeta` VALUES("1256","2359","filter","raw");
INSERT INTO `st_postmeta` VALUES("1255","2359","__defaults_set","1");
INSERT INTO `st_postmeta` VALUES("1245","2358","id_field","ID");
INSERT INTO `st_postmeta` VALUES("1244","2358","filter","raw");
INSERT INTO `st_postmeta` VALUES("1243","2358","__defaults_set","1");
INSERT INTO `st_postmeta` VALUES("1230","2357","id_field","ID");
INSERT INTO `st_postmeta` VALUES("1229","2357","filter","raw");
INSERT INTO `st_postmeta` VALUES("1228","2357","__defaults_set","1");
INSERT INTO `st_postmeta` VALUES("1233","2356","id_field","ID");
INSERT INTO `st_postmeta` VALUES("1232","2356","filter","raw");
INSERT INTO `st_postmeta` VALUES("1231","2356","__defaults_set","1");
INSERT INTO `st_postmeta` VALUES("690","28","_wpb_vc_js_status","false");
INSERT INTO `st_postmeta` VALUES("691","28","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("692","28","slide_template","default");
INSERT INTO `st_postmeta` VALUES("693","28","mfn-post-hide-content","0");
INSERT INTO `st_postmeta` VALUES("694","28","mfn-post-custom-layout","0");
INSERT INTO `st_postmeta` VALUES("695","28","mfn-post-slider","0");
INSERT INTO `st_postmeta` VALUES("687","2256","_additional_settings","");
INSERT INTO `st_postmeta` VALUES("688","2256","_locale","fa_IR");
INSERT INTO `st_postmeta` VALUES("689","28","_wp_page_template","default");
INSERT INTO `st_postmeta` VALUES("684","2256","_mail","a:9:{s:6:\"active\";b:1;s:7:\"subject\";s:16:\"\"[your-subject]\"\";s:6:\"sender\";s:37:\"[your-name] <wordpress@foolstacks.ir>\";s:9:\"recipient\";s:26:\"fullstackdiaries@gmail.com\";s:4:\"body\";s:258:\"از : [your-name] <[your-email]>
تلفن: [mobile]
موضوع: [your-subject]

محتوای پیام :
[your-message]

فایل: [fileUpload]
-- 
این ایمیل از فرم تماس در روزمره ها (http://foolstacks.ir) ارسال شده است.\";s:18:\"additional_headers\";s:22:\"Reply-To: [your-email]\";s:11:\"attachments\";s:12:\"[fileUpload]\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}");
INSERT INTO `st_postmeta` VALUES("685","2256","_mail_2","a:9:{s:6:\"active\";b:0;s:7:\"subject\";s:34:\"روزمره ها \"[your-subject]\"\";s:6:\"sender\";s:43:\"روزمره ها <wordpress@foolstacks.ir>\";s:9:\"recipient\";s:12:\"[your-email]\";s:4:\"body\";s:154:\"محتوای پیام :
[your-message]

-- 
این ایمیل از فرم تماس در روزمره ها (http://foolstacks.ir) ارسال شده است.\";s:18:\"additional_headers\";s:36:\"Reply-To: fullstackdiaries@gmail.com\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}");
INSERT INTO `st_postmeta` VALUES("686","2256","_messages","a:23:{s:12:\"mail_sent_ok\";s:88:\"از پیام شما متشکریم، پیام شما با موفقیت ارسال شد.\";s:12:\"mail_sent_ng\";s:112:\"مشکلی در ارسال پیام شما بوجود آمده است، لطفا دوباره تلاش کنید.\";s:16:\"validation_error\";s:137:\"یک یا چند تا از مقادیر وارد شده مشکل دارد، لطفا پس از بررسی دوباره تلاش کنید.\";s:4:\"spam\";s:112:\"مشکلی در ارسال پیام شما بوجود آمده است، لطفا دوباره تلاش کنید.\";s:12:\"accept_terms\";s:120:\"شما باید با شرایط و قوانین موافقت کنید تا قادر به ارسال پیام باشید.\";s:16:\"invalid_required\";s:50:\"پر کردن این قسمت اجباری است.\";s:16:\"invalid_too_long\";s:47:\"مقدار وارد شده طولانی است.\";s:17:\"invalid_too_short\";s:45:\"مقدار وارد شده کوتاه است.\";s:12:\"invalid_date\";s:44:\"ساختار تاریخ نادرست است.\";s:14:\"date_too_early\";s:69:\"تاریخ نسبت به حداقل محدودیت زودتر است.\";s:13:\"date_too_late\";s:71:\"تاریخ نسبت به حداکثر محدودیت دیرتر است.\";s:13:\"upload_failed\";s:64:\"مشکلی در آپلود فایل شما رخ داده است.\";s:24:\"upload_file_type_invalid\";s:79:\"شما اجازه ندارید از این نوع فایل آپلود کنید.\";s:21:\"upload_file_too_large\";s:50:\"حجم فایل شما بسیار زیاد است.\";s:23:\"upload_failed_php_error\";s:64:\"مشکلی در آپلود فایل شما رخ داده است.\";s:14:\"invalid_number\";s:38:\"فرمت عدد نامعتبر است.\";s:16:\"number_too_small\";s:59:\"این مقدار کمتر از حداقل مجاز است.\";s:16:\"number_too_large\";s:63:\"این مقدار بیشتر از حداکثر مجاز است.\";s:23:\"quiz_answer_not_correct\";s:52:\"جواب شما به آزمون اشتباه است.\";s:17:\"captcha_not_match\";s:39:\"کد وارد شده صحیح نیست.\";s:13:\"invalid_email\";s:47:\"ایمیل وارد شده اشتباه است.\";s:11:\"invalid_url\";s:45:\"آدرس وارد شده اشتباه است.\";s:11:\"invalid_tel\";s:56:\"شماره تلفن وارد شده اشتباه است.\";}");
INSERT INTO `st_postmeta` VALUES("683","2256","_form","<label> نام شما (الزامی)
    [text* your-name] </label>

<label> ایمیل شما (الزامی)
    [email* your-email] </label>

<label> شماره تماس
    [tel mobile] </label>

<label> موضوع
    [text your-subject] </label>

<label> پیام شما
    [textarea your-message] </label>

<label> افزودن فایل (کمتر از 2 مگابایت)
    [file fileUpload limit:2mb  filetypes:jpeg|png|jpg] </label>

[submit \"ارسال \"]");
INSERT INTO `st_postmeta` VALUES("442","2187","slide_template","default");
INSERT INTO `st_postmeta` VALUES("443","2187","mfn-post-hide-content","0");
INSERT INTO `st_postmeta` VALUES("444","2187","mfn-post-sidebar","0");
INSERT INTO `st_postmeta` VALUES("445","2187","mfn-post-slider","0");
INSERT INTO `st_postmeta` VALUES("446","2187","mfn-post-slider-header","1");
INSERT INTO `st_postmeta` VALUES("447","2187","mfn-post-size","wide");
INSERT INTO `st_postmeta` VALUES("448","2187","mfn-post-client","");
INSERT INTO `st_postmeta` VALUES("449","2187","mfn-post-task","Suspendisse fermentum erat. Duis consequat tortor. Mauris ut tellus a dolor. Suspendisse nec tellus.");
INSERT INTO `st_postmeta` VALUES("450","2187","mfn-post-love","75");
INSERT INTO `st_postmeta` VALUES("451","2187","mfn-page-items","YToyOntpOjA7YToyOntzOjQ6ImF0dHIiO2E6MTY6e3M6NToidGl0bGUiO3M6MDoiIjtzOjg6ImJnX2ltYWdlIjtzOjA6IiI7czoxMToiYmdfcG9zaXRpb24iO3M6MjI6Im5vLXJlcGVhdDtjZW50ZXIgdG9wOzsiO3M6ODoiYmdfY29sb3IiO3M6MDoiIjtzOjc6ImRpdmlkZXIiO3M6MDoiIjtzOjEyOiJiZ192aWRlb19tcDQiO3M6MDoiIjtzOjEyOiJiZ192aWRlb19vZ3YiO3M6MDoiIjtzOjY6ImxheW91dCI7czoxMDoibm8tc2lkZWJhciI7czoxMToicGFkZGluZ190b3AiO3M6MToiMCI7czoxNDoicGFkZGluZ19ib3R0b20iO3M6MToiMCI7czoxMzoiY29sdW1uX21hcmdpbiI7czowOiIiO3M6NToic3R5bGUiO3M6MDoiIjtzOjEwOiJuYXZpZ2F0aW9uIjtzOjA6IiI7czo1OiJjbGFzcyI7czowOiIiO3M6MTA6InNlY3Rpb25faWQiO3M6MDoiIjtzOjEwOiJ2aXNpYmlsaXR5IjtzOjA6IiI7fXM6NToiaXRlbXMiO2E6Nzp7aTowO2E6Mzp7czo0OiJ0eXBlIjtzOjU6ImltYWdlIjtzOjQ6InNpemUiO3M6MzoiMS8zIjtzOjY6ImZpZWxkcyI7YToxNDp7czozOiJzcmMiO3M6NzY6Imh0dHA6Ly9mb29sc3RhY2tzLmlyL3dwLWNvbnRlbnQvdXBsb2Fkcy8yMDE1LzAzL2hvbWVfd2ViZGVzaWduX3NsaWRlMV9iZy5qcGciO3M6NToid2lkdGgiO3M6MDoiIjtzOjY6ImhlaWdodCI7czowOiIiO3M6NjoiYm9yZGVyIjtzOjE6IjEiO3M6NToiYWxpZ24iO3M6NjoiY2VudGVyIjtzOjY6Im1hcmdpbiI7czowOiIiO3M6MzoiYWx0IjtzOjA6IiI7czo3OiJjYXB0aW9uIjtzOjA6IiI7czoxMDoibGlua19pbWFnZSI7czowOiIiO3M6NDoibGluayI7czowOiIiO3M6NjoidGFyZ2V0IjtzOjE6IjAiO3M6OToiZ3JleXNjYWxlIjtzOjE6IjAiO3M6NzoiYW5pbWF0ZSI7czowOiIiO3M6NzoiY2xhc3NlcyI7czowOiIiO319aToxO2E6Mzp7czo0OiJ0eXBlIjtzOjU6ImltYWdlIjtzOjQ6InNpemUiO3M6MzoiMS8zIjtzOjY6ImZpZWxkcyI7YToxNDp7czozOiJzcmMiO3M6NzY6Imh0dHA6Ly9mb29sc3RhY2tzLmlyL3dwLWNvbnRlbnQvdXBsb2Fkcy8yMDE1LzAzL2hvbWVfd2ViZGVzaWduX3NsaWRlNF9iZy5qcGciO3M6NToid2lkdGgiO3M6MDoiIjtzOjY6ImhlaWdodCI7czowOiIiO3M6NjoiYm9yZGVyIjtzOjE6IjEiO3M6NToiYWxpZ24iO3M6NjoiY2VudGVyIjtzOjY6Im1hcmdpbiI7czowOiIiO3M6MzoiYWx0IjtzOjA6IiI7czo3OiJjYXB0aW9uIjtzOjA6IiI7czoxMDoibGlua19pbWFnZSI7czowOiIiO3M6NDoibGluayI7czowOiIiO3M6NjoidGFyZ2V0IjtzOjE6IjAiO3M6OToiZ3JleXNjYWxlIjtzOjE6IjAiO3M6NzoiYW5pbWF0ZSI7czowOiIiO3M6NzoiY2xhc3NlcyI7czowOiIiO319aToyO2E6Mzp7czo0OiJ0eXBlIjtzOjU6ImltYWdlIjtzOjQ6InNpemUiO3M6MzoiMS8zIjtzOjY6ImZpZWxkcyI7YToxNDp7czozOiJzcmMiO3M6NzY6Imh0dHA6Ly9mb29sc3RhY2tzLmlyL3dwLWNvbnRlbnQvdXBsb2Fkcy8yMDE1LzAzL2hvbWVfd2ViZGVzaWduX3NsaWRlMl9iZy5qcGciO3M6NToid2lkdGgiO3M6MDoiIjtzOjY6ImhlaWdodCI7czowOiIiO3M6NjoiYm9yZGVyIjtzOjE6IjEiO3M6NToiYWxpZ24iO3M6NjoiY2VudGVyIjtzOjY6Im1hcmdpbiI7czowOiIiO3M6MzoiYWx0IjtzOjA6IiI7czo3OiJjYXB0aW9uIjtzOjA6IiI7czoxMDoibGlua19pbWFnZSI7czowOiIiO3M6NDoibGluayI7czowOiIiO3M6NjoidGFyZ2V0IjtzOjE6IjAiO3M6OToiZ3JleXNjYWxlIjtzOjE6IjAiO3M6NzoiYW5pbWF0ZSI7czowOiIiO3M6NzoiY2xhc3NlcyI7czowOiIiO319aTozO2E6Mzp7czo0OiJ0eXBlIjtzOjc6ImRpdmlkZXIiO3M6NDoic2l6ZSI7czozOiIxLzEiO3M6NjoiZmllbGRzIjthOjU6e3M6NjoiaGVpZ2h0IjtzOjA6IiI7czo1OiJzdHlsZSI7czo3OiJkZWZhdWx0IjtzOjQ6ImxpbmUiO3M6MDoiIjtzOjEwOiJ0aGVtZWNvbG9yIjtzOjE6IjAiO3M6NzoiY2xhc3NlcyI7czowOiIiO319aTo0O2E6Mzp7czo0OiJ0eXBlIjtzOjY6ImNvbHVtbiI7czo0OiJzaXplIjtzOjM6IjEvMyI7czo2OiJmaWVsZHMiO2E6NTp7czo1OiJ0aXRsZSI7czo0OiJEZXNjIjtzOjc6ImNvbnRlbnQiO3M6NDM3OiI8cCBjbGFzcz0iYmlnIj5QZWxsZW50ZXNxdWUgaGFiaXRhbnQgbW9yYmkgdHJpc3RpcXVlIHNlbmVjdHVzIGV0IG5ldHVzIGV0IG1hbGVzdWFkYSBmYW1lcyBhYyB0dXJwaXMgZWdlc3RhcywgdWx0cmljaWVzIGVnZXQsIHRlbXBvciBzaXQgYW1ldCBzdWFkYSBmYW1lcyBhYyB0dXJwaXMgZWdlc3RhIGdpbGxhIHNlbXBlci48L3A+DQo8cD5QZWxsZW50ZXNxdWUgaGFiaXRhbnQgbW9yYmkgdHJpc3RpcXVlIHNlbmVjdHVzIGV0IG5ldHVzIGV0IG1hbGVzdWFkYSBmYW1lcyBhYyB0dXJwaXMgZWdlc3Rhcy4gVmVzdGlidWx1bSB0b3J0byBtZXMgYWMgdHVycGlzIGVnZXN0IGxvcmVtbGlndWxhciBxdWFtLCBmZXVnaWF0IHZpdGFlLCB1bHRyaWNpZXMgZWdldCwgdGVtcG9yIHNpdCBhbWV0IGFudGUuIERvbmVjIGV1IGxpYiBlcm8gc2l0IGFtZXQgcXVhbSBlZ2VzLjwvcD4NCiI7czo1OiJhbGlnbiI7czowOiIiO3M6NzoiYW5pbWF0ZSI7czowOiIiO3M6NzoiY2xhc3NlcyI7czowOiIiO319aTo1O2E6Mzp7czo0OiJ0eXBlIjtzOjY6ImNvbHVtbiI7czo0OiJzaXplIjtzOjM6IjEvMyI7czo2OiJmaWVsZHMiO2E6NTp7czo1OiJ0aXRsZSI7czo0OiJEZXNjIjtzOjc6ImNvbnRlbnQiO3M6NDg3OiI8cD5Mb3JlbSBpcHN1bSBkb2xvciBzaXQgYW1ldCBlbmltLiBFdGlhbSB1bGxhbWNvcnBlci4gU3VzcGVuZGlzc2UgYSBwZWxsZW50ZXNxdWUgZHVpLCBub24gZmVsaXMuIE1hZWNlbmFzIG1hbGVzdWFkYSBlbGl0IGxlY3R1cyBmZWxpcywgbWFsZXN1YWRhIHVsdHJpY2llcy4gQ3VyYWJpdHVyIGV0IGxpZ3VsYS4gVXQgbW9sZXN0aWUgYSwgdWx0cmljaWVzIHBvcnRhIHVybmEuIFZlc3RpYnVsdW0gY29tbW9kbyB2b2x1dDwvcD4NCjxwPlBlbGxlbnRlc3F1ZSBmYWNpbGlzaXMuIE51bGxhIGltcGVyZGlldCBzaXQgYW1ldCBtYWduYS4gVmVzdGlidWx1bSBkYXBpYnVzLCBtYXVyaXMgbmVjIG1hbGVzdWFkYSBmYW1lcyBhYyB0dXJwaXMgdmVsaXQsIHJob25jdXMgZXUsIGx1Y3R1cyBldCBpbnRlcmR1bSBhZGlwaXNjaW5nIHdpc2kuIEFsaXF1YW0gZXJhdCBhYyBpcHN1bS4gSW50ZWdlciBhbGlxdWFtIHB1cnVzLiBRdWlzcXVlIGxvcmVtIHRvcnRvci48L3A+IjtzOjU6ImFsaWduIjtzOjA6IiI7czo3OiJhbmltYXRlIjtzOjA6IiI7czo3OiJjbGFzc2VzIjtzOjA6IiI7fX1pOjY7YTozOntzOjQ6InR5cGUiO3M6NjoiY29sdW1uIjtzOjQ6InNpemUiO3M6MzoiMS8zIjtzOjY6ImZpZWxkcyI7YTo1OntzOjU6InRpdGxlIjtzOjQ6IkRlc2MiO3M6NzoiY29udGVudCI7czozMzQ6IjxoNSBzdHlsZT0ibWFyZ2luLWJvdHRvbTogNXB4OyI+Q2xpZW50OjwvaDU+DQo8cD5baWNvbiB0eXBlPSJpY29uLXZjYXJkIl0gTXVmZmluIEdyb3VwPC9wPg0KPGg1IHN0eWxlPSJtYXJnaW4tYm90dG9tOiA1cHg7Ij5EYXRlOjwvaDU+DQo8cD5baWNvbiB0eXBlPSJpY29uLWJhY2staW4tdGltZSJdIE1heSAxMywgMjAxNDwvcD4NCjxoNSBzdHlsZT0ibWFyZ2luLWJvdHRvbTogNXB4OyI+V2Vic2l0ZTo8L2g1Pg0KPHA+W2ljb24gdHlwZT0iaWNvbi13aW5kb3ciXSA8YSBocmVmPSJodHRwOi8vdGhlbWVmb3Jlc3QubmV0IiB0YXJnZXQ9Il9ibGFuayI+VmlldyB3ZWJzaXRlPC9hPjwvcD4iO3M6NToiYWxpZ24iO3M6MDoiIjtzOjc6ImFuaW1hdGUiO3M6MDoiIjtzOjc6ImNsYXNzZXMiO3M6MDoiIjt9fX19aToxO2E6Mjp7czo0OiJhdHRyIjthOjE2OntzOjU6InRpdGxlIjtzOjk6IlN0eWxlIENTUyI7czo4OiJiZ19pbWFnZSI7czowOiIiO3M6MTE6ImJnX3Bvc2l0aW9uIjtzOjIyOiJuby1yZXBlYXQ7Y2VudGVyIHRvcDs7IjtzOjg6ImJnX2NvbG9yIjtzOjA6IiI7czo3OiJkaXZpZGVyIjtzOjA6IiI7czoxMjoiYmdfdmlkZW9fbXA0IjtzOjA6IiI7czoxMjoiYmdfdmlkZW9fb2d2IjtzOjA6IiI7czo2OiJsYXlvdXQiO3M6MTA6Im5vLXNpZGViYXIiO3M6MTE6InBhZGRpbmdfdG9wIjtzOjE6IjAiO3M6MTQ6InBhZGRpbmdfYm90dG9tIjtzOjE6IjAiO3M6MTM6ImNvbHVtbl9tYXJnaW4iO3M6MDoiIjtzOjU6InN0eWxlIjtzOjEwOiJmdWxsLXdpZHRoIjtzOjEwOiJuYXZpZ2F0aW9uIjtzOjA6IiI7czo1OiJjbGFzcyI7czowOiIiO3M6MTA6InNlY3Rpb25faWQiO3M6MDoiIjtzOjEwOiJ2aXNpYmlsaXR5IjtzOjA6IiI7fXM6NToiaXRlbXMiO2E6MTp7aTowO2E6Mzp7czo0OiJ0eXBlIjtzOjY6ImNvbHVtbiI7czo0OiJzaXplIjtzOjM6IjEvMSI7czo2OiJmaWVsZHMiO2E6NTp7czo1OiJ0aXRsZSI7czo5OiJTdHlsZSBDU1MiO3M6NzoiY29udGVudCI7czo4MToiPHN0eWxlPg0KLnNpbmdsZS1waG90by13cmFwcGVyLCAucHJvamVjdC1kZXNjcmlwdGlvbiB7IGRpc3BsYXk6IG5vbmU7IH0NCjwvc3R5bGU+IjtzOjU6ImFsaWduIjtzOjA6IiI7czo3OiJhbmltYXRlIjtzOjA6IiI7czo3OiJjbGFzc2VzIjtzOjA6IiI7fX19fX0=");
INSERT INTO `st_postmeta` VALUES("452","2187","mfn-page-items-seo","http://themes.muffingroup.com/be/webdesign/wp-content/uploads/2015/03/home_webdesign_slide1_bg.jpg

center

http://themes.muffingroup.com/be/webdesign/wp-content/uploads/2015/03/home_webdesign_slide4_bg.jpg

center

http://themes.muffingroup.com/be/webdesign/wp-content/uploads/2015/03/home_webdesign_slide2_bg.jpg

center

default

Desc

<p class=\"big\">Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas, ultricies eget, tempor sit amet suada fames ac turpis egesta gilla semper.</p>
<p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum torto mes ac turpis egest loremligular quam, feugiat vitae, ultricies eget, tempor sit amet ante. Donec eu lib ero sit amet quam eges.</p>

Desc

<p>Lorem ipsum dolor sit amet enim. Etiam ullamcorper. Suspendisse a pellentesque dui, non felis. Maecenas malesuada elit lectus felis, malesuada ultricies. Curabitur et ligula. Ut molestie a, ultricies porta urna. Vestibulum commodo volut</p>
<p>Pellentesque facilisis. Nulla imperdiet sit amet magna. Vestibulum dapibus, mauris nec malesuada fames ac turpis velit, rhoncus eu, luctus et interdum adipiscing wisi. Aliquam erat ac ipsum. Integer aliquam purus. Quisque lorem tortor.</p>

Desc

<h5 style=\"margin-bottom: 5px;\">Client:</h5>
<p>[icon type=\"icon-vcard\"] Muffin Group</p>
<h5 style=\"margin-bottom: 5px;\">Date:</h5>
<p>[icon type=\"icon-back-in-time\"] May 13, 2014</p>
<h5 style=\"margin-bottom: 5px;\">Website:</h5>
<p>[icon type=\"icon-window\"] <a href=\"http://themeforest.net\" target=\"_blank\">View website</a></p>

Style CSS

<style>
.single-photo-wrapper, .project-description { display: none; }
</style>

");
INSERT INTO `st_postmeta` VALUES("453","2187","mfn-post-custom-layout","0");
INSERT INTO `st_postmeta` VALUES("454","2187","mfn-post-slider-layer","0");
INSERT INTO `st_postmeta` VALUES("455","2187","_thumbnail_id","45");
INSERT INTO `st_postmeta` VALUES("456","2188","slide_template","default");
INSERT INTO `st_postmeta` VALUES("457","2188","mfn-post-hide-content","0");
INSERT INTO `st_postmeta` VALUES("458","2188","mfn-post-sidebar","0");
INSERT INTO `st_postmeta` VALUES("459","2188","mfn-post-slider","0");
INSERT INTO `st_postmeta` VALUES("460","2188","mfn-post-slider-header","1");
INSERT INTO `st_postmeta` VALUES("461","2188","mfn-post-size","");
INSERT INTO `st_postmeta` VALUES("462","2188","mfn-post-love","53");
INSERT INTO `st_postmeta` VALUES("463","2188","mfn-page-items","YToyOntpOjA7YToyOntzOjQ6ImF0dHIiO2E6MTY6e3M6NToidGl0bGUiO3M6MDoiIjtzOjg6ImJnX2ltYWdlIjtzOjA6IiI7czoxMToiYmdfcG9zaXRpb24iO3M6MjI6Im5vLXJlcGVhdDtjZW50ZXIgdG9wOzsiO3M6ODoiYmdfY29sb3IiO3M6MDoiIjtzOjc6ImRpdmlkZXIiO3M6MDoiIjtzOjEyOiJiZ192aWRlb19tcDQiO3M6MDoiIjtzOjEyOiJiZ192aWRlb19vZ3YiO3M6MDoiIjtzOjY6ImxheW91dCI7czoxMDoibm8tc2lkZWJhciI7czoxMToicGFkZGluZ190b3AiO3M6MToiMCI7czoxNDoicGFkZGluZ19ib3R0b20iO3M6MToiMCI7czoxMzoiY29sdW1uX21hcmdpbiI7czowOiIiO3M6NToic3R5bGUiO3M6MDoiIjtzOjEwOiJuYXZpZ2F0aW9uIjtzOjA6IiI7czo1OiJjbGFzcyI7czowOiIiO3M6MTA6InNlY3Rpb25faWQiO3M6MDoiIjtzOjEwOiJ2aXNpYmlsaXR5IjtzOjA6IiI7fXM6NToiaXRlbXMiO2E6Mjp7aTowO2E6Mzp7czo0OiJ0eXBlIjtzOjY6ImNvbHVtbiI7czo0OiJzaXplIjtzOjM6IjMvNCI7czo2OiJmaWVsZHMiO2E6NTp7czo1OiJ0aXRsZSI7czowOiIiO3M6NzoiY29udGVudCI7czo1MDoiW2dhbGxlcnkgY29sdW1ucz0iMiIgbGluaz0iZmlsZSIgaWRzPSI1Niw3LDQ1LDQ0Il0iO3M6NToiYWxpZ24iO3M6MDoiIjtzOjc6ImFuaW1hdGUiO3M6MDoiIjtzOjc6ImNsYXNzZXMiO3M6MDoiIjt9fWk6MTthOjM6e3M6NDoidHlwZSI7czo2OiJjb2x1bW4iO3M6NDoic2l6ZSI7czozOiIxLzQiO3M6NjoiZmllbGRzIjthOjU6e3M6NToidGl0bGUiO3M6NDoiRGVzYyI7czo3OiJjb250ZW50IjtzOjEwODE6IjxwPlBoYXNlbGx1cyBmZXJtZW50dW0gaW4sIGRvbG9yLiBQZWxsZW50ZXNxdWUgZmFjaWxpc2lzLiBOdWxsYSBpbXBlcmRpZXQgc2l0IGFtZXQgbWFnbmEuIFZlc3RpYnVsdW0gZGFwaWJ1cywgbWF1cmlzIG5lYyBtYWxlc3VhZGEgZmFtZXMgYWMgW3Rvb2x0aXAgaGludD0iTWFsZXN1YWRhIGZhbWVzIGFjIHR1cnBpcyBlZ2VzdGFzLCB1bHRyaWNpZXMiXXR1cnBpcyB2ZWxpdFsvdG9vbHRpcF0sIHJob25jdXMgZXUsIGx1Y3R1cyBldCBpbnRlcmR1bSBhZGlwaXNjaW5nIHdpc2kgYWxpcXVhbSBlcmF0LjwvcD4NCjxoNSBzdHlsZT0ibWFyZ2luLWJvdHRvbTogNXB4OyI+Q2xpZW50OjwvaDU+DQo8cD5baWNvbiB0eXBlPSJpY29uLXZjYXJkIl0gTXVmZmluIEdyb3VwPC9wPg0KPGg1IHN0eWxlPSJtYXJnaW4tYm90dG9tOiA1cHg7Ij5EYXRlOjwvaDU+DQo8cD5baWNvbiB0eXBlPSJpY29uLWJhY2staW4tdGltZSJdIE1heSAxMywgMjAxNDwvcD4NCjxoNSBzdHlsZT0ibWFyZ2luLWJvdHRvbTogNXB4OyI+V2Vic2l0ZTo8L2g1Pg0KPHA+W2ljb24gdHlwZT0iaWNvbi13aW5kb3ciXSA8YSBocmVmPSJodHRwOi8vdGhlbWVmb3Jlc3QubmV0IiB0YXJnZXQ9Il9ibGFuayI+VmlldyB3ZWJzaXRlPC9hPjwvcD4NCjxoNSBzdHlsZT0ibWFyZ2luLWJvdHRvbTogNXB4OyI+VGFzazo8L2g1Pg0KPHAgc3R5bGU9Im1hcmdpbi1ib3R0b206IDMwcHg7Ij5baWNvbiB0eXBlPSJpY29uLWRvYy10ZXh0Il0gU3VzcGVuIGRpc3NlIGZlcm1lbiB0dW08L3A+DQpbaWNvbl9iYXIgaWNvbj0iaWNvbi1mYWNlYm9vayIgbGluaz0iIyIgdGFyZ2V0PSIiIHNpemU9InNtYWxsIiBzb2NpYWw9ImZhY2Vib29rIl1baWNvbl9iYXIgaWNvbj0iaWNvbi1ncGx1cyIgbGluaz0iIyIgdGFyZ2V0PSIiIHNpemU9InNtYWxsIiBzb2NpYWw9Imdvb2dsZSJdW2ljb25fYmFyIGljb249Imljb24tcGludGVyZXN0IiBsaW5rPSIjIiB0YXJnZXQ9IiIgc2l6ZT0ic21hbGwiIHNvY2lhbD0icGludGVyZXN0Il1baWNvbl9iYXIgaWNvbj0iaWNvbi1kcmliYmJsZSIgbGluaz0iIyIgdGFyZ2V0PSIiIHNpemU9InNtYWxsIiBzb2NpYWw9ImRyaWJiYmxlIl0iO3M6NToiYWxpZ24iO3M6MDoiIjtzOjc6ImFuaW1hdGUiO3M6MDoiIjtzOjc6ImNsYXNzZXMiO3M6MDoiIjt9fX19aToxO2E6Mjp7czo0OiJhdHRyIjthOjE2OntzOjU6InRpdGxlIjtzOjk6IlN0eWxlIENTUyI7czo4OiJiZ19pbWFnZSI7czowOiIiO3M6MTE6ImJnX3Bvc2l0aW9uIjtzOjIyOiJuby1yZXBlYXQ7Y2VudGVyIHRvcDs7IjtzOjg6ImJnX2NvbG9yIjtzOjA6IiI7czo3OiJkaXZpZGVyIjtzOjA6IiI7czoxMjoiYmdfdmlkZW9fbXA0IjtzOjA6IiI7czoxMjoiYmdfdmlkZW9fb2d2IjtzOjA6IiI7czo2OiJsYXlvdXQiO3M6MTA6Im5vLXNpZGViYXIiO3M6MTE6InBhZGRpbmdfdG9wIjtzOjE6IjAiO3M6MTQ6InBhZGRpbmdfYm90dG9tIjtzOjE6IjAiO3M6MTM6ImNvbHVtbl9tYXJnaW4iO3M6MDoiIjtzOjU6InN0eWxlIjtzOjEwOiJmdWxsLXdpZHRoIjtzOjEwOiJuYXZpZ2F0aW9uIjtzOjA6IiI7czo1OiJjbGFzcyI7czowOiIiO3M6MTA6InNlY3Rpb25faWQiO3M6MDoiIjtzOjEwOiJ2aXNpYmlsaXR5IjtzOjA6IiI7fXM6NToiaXRlbXMiO2E6MTp7aTowO2E6Mzp7czo0OiJ0eXBlIjtzOjY6ImNvbHVtbiI7czo0OiJzaXplIjtzOjM6IjEvMSI7czo2OiJmaWVsZHMiO2E6NTp7czo1OiJ0aXRsZSI7czo5OiJTdHlsZSBDU1MiO3M6NzoiY29udGVudCI7czo4MToiPHN0eWxlPg0KLnNpbmdsZS1waG90by13cmFwcGVyLCAucHJvamVjdC1kZXNjcmlwdGlvbiB7IGRpc3BsYXk6IG5vbmU7IH0NCjwvc3R5bGU+IjtzOjU6ImFsaWduIjtzOjA6IiI7czo3OiJhbmltYXRlIjtzOjA6IiI7czo3OiJjbGFzc2VzIjtzOjA6IiI7fX19fX0=");
INSERT INTO `st_postmeta` VALUES("464","2188","mfn-page-items-seo","[gallery columns=\"2\" link=\"file\" ids=\"56,7,45,44\"]

Desc

<p>Phasellus fermentum in, dolor. Pellentesque facilisis. Nulla imperdiet sit amet magna. Vestibulum dapibus, mauris nec malesuada fames ac [tooltip hint=\"Malesuada fames ac turpis egestas, ultricies\"]turpis velit[/tooltip], rhoncus eu, luctus et interdum adipiscing wisi aliquam erat.</p>
<h5 style=\"margin-bottom: 5px;\">Client:</h5>
<p>[icon type=\"icon-vcard\"] Muffin Group</p>
<h5 style=\"margin-bottom: 5px;\">Date:</h5>
<p>[icon type=\"icon-back-in-time\"] May 13, 2014</p>
<h5 style=\"margin-bottom: 5px;\">Website:</h5>
<p>[icon type=\"icon-window\"] <a href=\"http://themeforest.net\" target=\"_blank\">View website</a></p>
<h5 style=\"margin-bottom: 5px;\">Task:</h5>
<p style=\"margin-bottom: 30px;\">[icon type=\"icon-doc-text\"] Suspen disse fermen tum</p>
[icon_bar icon=\"icon-facebook\" link=\"#\" target=\"\" size=\"small\" social=\"facebook\"][icon_bar icon=\"icon-gplus\" link=\"#\" target=\"\" size=\"small\" social=\"google\"][icon_bar icon=\"icon-pinterest\" link=\"#\" target=\"\" size=\"small\" social=\"pinterest\"][icon_bar icon=\"icon-dribbble\" link=\"#\" target=\"\" size=\"small\" social=\"dribbble\"]

Style CSS

<style>
.single-photo-wrapper, .project-description { display: none; }
</style>

");
INSERT INTO `st_postmeta` VALUES("465","2188","mfn-post-custom-layout","0");
INSERT INTO `st_postmeta` VALUES("466","2188","mfn-post-slider-layer","0");
INSERT INTO `st_postmeta` VALUES("467","2188","_thumbnail_id","44");
INSERT INTO `st_postmeta` VALUES("468","2189","slide_template","default");
INSERT INTO `st_postmeta` VALUES("469","2189","mfn-post-hide-content","0");
INSERT INTO `st_postmeta` VALUES("470","2189","mfn-post-sidebar","0");
INSERT INTO `st_postmeta` VALUES("471","2189","mfn-post-slider","0");
INSERT INTO `st_postmeta` VALUES("472","2189","mfn-post-slider-header","1");
INSERT INTO `st_postmeta` VALUES("473","2189","mfn-post-love","41");
INSERT INTO `st_postmeta` VALUES("474","2189","mfn-page-items","YToyOntpOjA7YToyOntzOjQ6ImF0dHIiO2E6MTY6e3M6NToidGl0bGUiO3M6MDoiIjtzOjg6ImJnX2ltYWdlIjtzOjA6IiI7czoxMToiYmdfcG9zaXRpb24iO3M6MjI6Im5vLXJlcGVhdDtjZW50ZXIgdG9wOzsiO3M6ODoiYmdfY29sb3IiO3M6MDoiIjtzOjc6ImRpdmlkZXIiO3M6MDoiIjtzOjEyOiJiZ192aWRlb19tcDQiO3M6MDoiIjtzOjEyOiJiZ192aWRlb19vZ3YiO3M6MDoiIjtzOjY6ImxheW91dCI7czoxMDoibm8tc2lkZWJhciI7czoxMToicGFkZGluZ190b3AiO3M6MToiMCI7czoxNDoicGFkZGluZ19ib3R0b20iO3M6MToiMCI7czoxMzoiY29sdW1uX21hcmdpbiI7czowOiIiO3M6NToic3R5bGUiO3M6MDoiIjtzOjEwOiJuYXZpZ2F0aW9uIjtzOjA6IiI7czo1OiJjbGFzcyI7czowOiIiO3M6MTA6InNlY3Rpb25faWQiO3M6MDoiIjtzOjEwOiJ2aXNpYmlsaXR5IjtzOjA6IiI7fXM6NToiaXRlbXMiO2E6NTp7aTowO2E6Mzp7czo0OiJ0eXBlIjtzOjY6ImNvbHVtbiI7czo0OiJzaXplIjtzOjM6IjEvMSI7czo2OiJmaWVsZHMiO2E6NTp7czo1OiJ0aXRsZSI7czo3OiJHYWxsZXJ5IjtzOjc6ImNvbnRlbnQiO3M6NTA6IltnYWxsZXJ5IGNvbHVtbnM9IjQiIGxpbms9ImZpbGUiIGlkcz0iNyw0NCw0NSw1NiJdIjtzOjU6ImFsaWduIjtzOjA6IiI7czo3OiJhbmltYXRlIjtzOjA6IiI7czo3OiJjbGFzc2VzIjtzOjA6IiI7fX1pOjE7YTozOntzOjQ6InR5cGUiO3M6NzoiZGl2aWRlciI7czo0OiJzaXplIjtzOjM6IjEvMSI7czo2OiJmaWVsZHMiO2E6NTp7czo2OiJoZWlnaHQiO3M6MDoiIjtzOjU6InN0eWxlIjtzOjc6ImRlZmF1bHQiO3M6NDoibGluZSI7czowOiIiO3M6MTA6InRoZW1lY29sb3IiO3M6MToiMCI7czo3OiJjbGFzc2VzIjtzOjA6IiI7fX1pOjI7YTozOntzOjQ6InR5cGUiO3M6NjoiY29sdW1uIjtzOjQ6InNpemUiO3M6MzoiMS8zIjtzOjY6ImZpZWxkcyI7YTo1OntzOjU6InRpdGxlIjtzOjQ6IkRlc2MiO3M6NzoiY29udGVudCI7czo0Mzc6IjxwIGNsYXNzPSJiaWciPlBlbGxlbnRlc3F1ZSBoYWJpdGFudCBtb3JiaSB0cmlzdGlxdWUgc2VuZWN0dXMgZXQgbmV0dXMgZXQgbWFsZXN1YWRhIGZhbWVzIGFjIHR1cnBpcyBlZ2VzdGFzLCB1bHRyaWNpZXMgZWdldCwgdGVtcG9yIHNpdCBhbWV0IHN1YWRhIGZhbWVzIGFjIHR1cnBpcyBlZ2VzdGEgZ2lsbGEgc2VtcGVyLjwvcD4NCjxwPlBlbGxlbnRlc3F1ZSBoYWJpdGFudCBtb3JiaSB0cmlzdGlxdWUgc2VuZWN0dXMgZXQgbmV0dXMgZXQgbWFsZXN1YWRhIGZhbWVzIGFjIHR1cnBpcyBlZ2VzdGFzLiBWZXN0aWJ1bHVtIHRvcnRvIG1lcyBhYyB0dXJwaXMgZWdlc3QgbG9yZW1saWd1bGFyIHF1YW0sIGZldWdpYXQgdml0YWUsIHVsdHJpY2llcyBlZ2V0LCB0ZW1wb3Igc2l0IGFtZXQgYW50ZS4gRG9uZWMgZXUgbGliIGVybyBzaXQgYW1ldCBxdWFtIGVnZXMuPC9wPg0KIjtzOjU6ImFsaWduIjtzOjA6IiI7czo3OiJhbmltYXRlIjtzOjA6IiI7czo3OiJjbGFzc2VzIjtzOjA6IiI7fX1pOjM7YTozOntzOjQ6InR5cGUiO3M6NjoiY29sdW1uIjtzOjQ6InNpemUiO3M6MzoiMS8zIjtzOjY6ImZpZWxkcyI7YTo1OntzOjU6InRpdGxlIjtzOjQ6IkRlc2MiO3M6NzoiY29udGVudCI7czo1NTY6IjxwPkxvcmVtIGlwc3VtIGRvbG9yIHNpdCBhbWV0IGVuaW0uIEV0aWFtIHVsbGFtY29ycGVyLiBTdXNwZW4gZGlzc2UgYSBwZWxsZW50ZXNxdWUgZHVpLCBub24gZmVsaXMuIE1hZWNlbmFzIG1hbGVzdWFkYSBlbGl0IGxlY3R1cyBmZWxpcywgbWFsZXN1YWRhIHVsdHJpY2llcy4gQ3VyYWJpdHVyIGV0IGxpZ3VsYS4gVXQgbW9sZXN0aWUgYSwgdWx0cmljaWVzIHBvcnRhIHVybmEuIFZlc3RpYnVsdW0gY29tbW9kbyB2b2x1dC4gUGVsbGVudGVzcXVlIGZhY2lsaXNpcy4gTnVsbGEgaW1wZXJkaWV0IHNpdCBhbWV0IG1hZ25hLiBWZXN0aSBidWx1bSBkYXBpYnVzLCBtYXVyaXMgbmVjIG1hbGVzdWEgbGVudGVzcXVlIGZhY2lsaXNpcy4gTnVsbGEgaW1wZXJkaWRhIGZhbWVzIGFjIHR1cnBpcyB2ZWxpdCwgcmhvbmN1cyBldSwgbHVjdHVzIGV0IGludGVyZHVtIGFkaXBpc2Npbmcgd2lzaS4gQWxpcXVhbSBlcmF0IGFjIGlwc3VtLiBJbnRlZ2VyIGFsaXF1YW0gcHVydXMuIFF1aXNxdWUgbG9yZW0gdG9ydG9yIG1hbGVzdWFkYSBlbGl0IGxlY3R1cyBmZWxpcyBtYWxlIHN1YWRhLjwvcD4iO3M6NToiYWxpZ24iO3M6MDoiIjtzOjc6ImFuaW1hdGUiO3M6MDoiIjtzOjc6ImNsYXNzZXMiO3M6MDoiIjt9fWk6NDthOjM6e3M6NDoidHlwZSI7czo2OiJjb2x1bW4iO3M6NDoic2l6ZSI7czozOiIxLzMiO3M6NjoiZmllbGRzIjthOjU6e3M6NToidGl0bGUiO3M6NDoiRGVzYyI7czo3OiJjb250ZW50IjtzOjMzNDoiPGg1IHN0eWxlPSJtYXJnaW4tYm90dG9tOiA1cHg7Ij5DbGllbnQ6PC9oNT4NCjxwPltpY29uIHR5cGU9Imljb24tdmNhcmQiXSBNdWZmaW4gR3JvdXA8L3A+DQo8aDUgc3R5bGU9Im1hcmdpbi1ib3R0b206IDVweDsiPkRhdGU6PC9oNT4NCjxwPltpY29uIHR5cGU9Imljb24tYmFjay1pbi10aW1lIl0gTWF5IDEzLCAyMDE0PC9wPg0KPGg1IHN0eWxlPSJtYXJnaW4tYm90dG9tOiA1cHg7Ij5XZWJzaXRlOjwvaDU+DQo8cD5baWNvbiB0eXBlPSJpY29uLXdpbmRvdyJdIDxhIGhyZWY9Imh0dHA6Ly90aGVtZWZvcmVzdC5uZXQiIHRhcmdldD0iX2JsYW5rIj5WaWV3IHdlYnNpdGU8L2E+PC9wPiI7czo1OiJhbGlnbiI7czowOiIiO3M6NzoiYW5pbWF0ZSI7czowOiIiO3M6NzoiY2xhc3NlcyI7czowOiIiO319fX1pOjE7YToyOntzOjQ6ImF0dHIiO2E6MTY6e3M6NToidGl0bGUiO3M6OToiU3R5bGUgQ1NTIjtzOjg6ImJnX2ltYWdlIjtzOjA6IiI7czoxMToiYmdfcG9zaXRpb24iO3M6MjI6Im5vLXJlcGVhdDtjZW50ZXIgdG9wOzsiO3M6ODoiYmdfY29sb3IiO3M6MDoiIjtzOjc6ImRpdmlkZXIiO3M6MDoiIjtzOjEyOiJiZ192aWRlb19tcDQiO3M6MDoiIjtzOjEyOiJiZ192aWRlb19vZ3YiO3M6MDoiIjtzOjY6ImxheW91dCI7czoxMDoibm8tc2lkZWJhciI7czoxMToicGFkZGluZ190b3AiO3M6MToiMCI7czoxNDoicGFkZGluZ19ib3R0b20iO3M6MToiMCI7czoxMzoiY29sdW1uX21hcmdpbiI7czowOiIiO3M6NToic3R5bGUiO3M6MTA6ImZ1bGwtd2lkdGgiO3M6MTA6Im5hdmlnYXRpb24iO3M6MDoiIjtzOjU6ImNsYXNzIjtzOjA6IiI7czoxMDoic2VjdGlvbl9pZCI7czowOiIiO3M6MTA6InZpc2liaWxpdHkiO3M6MDoiIjt9czo1OiJpdGVtcyI7YToxOntpOjA7YTozOntzOjQ6InR5cGUiO3M6NjoiY29sdW1uIjtzOjQ6InNpemUiO3M6MzoiMS8xIjtzOjY6ImZpZWxkcyI7YTo1OntzOjU6InRpdGxlIjtzOjk6IlN0eWxlIENTUyI7czo3OiJjb250ZW50IjtzOjgxOiI8c3R5bGU+DQouc2luZ2xlLXBob3RvLXdyYXBwZXIsIC5wcm9qZWN0LWRlc2NyaXB0aW9uIHsgZGlzcGxheTogbm9uZTsgfQ0KPC9zdHlsZT4iO3M6NToiYWxpZ24iO3M6MDoiIjtzOjc6ImFuaW1hdGUiO3M6MDoiIjtzOjc6ImNsYXNzZXMiO3M6MDoiIjt9fX19fQ==");
INSERT INTO `st_postmeta` VALUES("475","2189","mfn-page-items-seo","Gallery

[gallery columns=\"4\" link=\"file\" ids=\"7,44,45,56\"]

default

Desc

<p class=\"big\">Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas, ultricies eget, tempor sit amet suada fames ac turpis egesta gilla semper.</p>
<p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum torto mes ac turpis egest loremligular quam, feugiat vitae, ultricies eget, tempor sit amet ante. Donec eu lib ero sit amet quam eges.</p>

Desc

<p>Lorem ipsum dolor sit amet enim. Etiam ullamcorper. Suspen disse a pellentesque dui, non felis. Maecenas malesuada elit lectus felis, malesuada ultricies. Curabitur et ligula. Ut molestie a, ultricies porta urna. Vestibulum commodo volut. Pellentesque facilisis. Nulla imperdiet sit amet magna. Vesti bulum dapibus, mauris nec malesua lentesque facilisis. Nulla imperdida fames ac turpis velit, rhoncus eu, luctus et interdum adipiscing wisi. Aliquam erat ac ipsum. Integer aliquam purus. Quisque lorem tortor malesuada elit lectus felis male suada.</p>

Desc

<h5 style=\"margin-bottom: 5px;\">Client:</h5>
<p>[icon type=\"icon-vcard\"] Muffin Group</p>
<h5 style=\"margin-bottom: 5px;\">Date:</h5>
<p>[icon type=\"icon-back-in-time\"] May 13, 2014</p>
<h5 style=\"margin-bottom: 5px;\">Website:</h5>
<p>[icon type=\"icon-window\"] <a href=\"http://themeforest.net\" target=\"_blank\">View website</a></p>

Style CSS

<style>
.single-photo-wrapper, .project-description { display: none; }
</style>

");
INSERT INTO `st_postmeta` VALUES("476","2189","mfn-post-custom-layout","0");
INSERT INTO `st_postmeta` VALUES("477","2189","mfn-post-slider-layer","0");
INSERT INTO `st_postmeta` VALUES("478","2189","mfn-post-size","tall");
INSERT INTO `st_postmeta` VALUES("479","2189","_thumbnail_id","89");
INSERT INTO `st_postmeta` VALUES("480","2190","slide_template","default");
INSERT INTO `st_postmeta` VALUES("481","2190","mfn-post-hide-content","0");
INSERT INTO `st_postmeta` VALUES("482","2190","mfn-post-sidebar","0");
INSERT INTO `st_postmeta` VALUES("483","2190","mfn-post-slider","0");
INSERT INTO `st_postmeta` VALUES("484","2190","mfn-post-slider-header","1");
INSERT INTO `st_postmeta` VALUES("485","2190","mfn-post-love","100");
INSERT INTO `st_postmeta` VALUES("486","2190","mfn-page-items","YToyOntpOjA7YToyOntzOjQ6ImF0dHIiO2E6MTY6e3M6NToidGl0bGUiO3M6MDoiIjtzOjg6ImJnX2ltYWdlIjtzOjA6IiI7czoxMToiYmdfcG9zaXRpb24iO3M6MjI6Im5vLXJlcGVhdDtjZW50ZXIgdG9wOzsiO3M6ODoiYmdfY29sb3IiO3M6MDoiIjtzOjc6ImRpdmlkZXIiO3M6MDoiIjtzOjEyOiJiZ192aWRlb19tcDQiO3M6MDoiIjtzOjEyOiJiZ192aWRlb19vZ3YiO3M6MDoiIjtzOjY6ImxheW91dCI7czoxMDoibm8tc2lkZWJhciI7czoxMToicGFkZGluZ190b3AiO3M6MToiMCI7czoxNDoicGFkZGluZ19ib3R0b20iO3M6MToiMCI7czoxMzoiY29sdW1uX21hcmdpbiI7czowOiIiO3M6NToic3R5bGUiO3M6MDoiIjtzOjEwOiJuYXZpZ2F0aW9uIjtzOjA6IiI7czo1OiJjbGFzcyI7czowOiIiO3M6MTA6InNlY3Rpb25faWQiO3M6MDoiIjtzOjEwOiJ2aXNpYmlsaXR5IjtzOjA6IiI7fXM6NToiaXRlbXMiO2E6NDp7aTowO2E6Mzp7czo0OiJ0eXBlIjtzOjU6InZpZGVvIjtzOjQ6InNpemUiO3M6MzoiMS8xIjtzOjY6ImZpZWxkcyI7YTo4OntzOjU6InZpZGVvIjtzOjg6Ijk0MDAyNjM4IjtzOjEwOiJwYXJhbWV0ZXJzIjtzOjA6IiI7czozOiJtcDQiO3M6MDoiIjtzOjM6Im9ndiI7czowOiIiO3M6MTE6InBsYWNlaG9sZGVyIjtzOjA6IiI7czo1OiJ3aWR0aCI7czo0OiIxMTc2IjtzOjY6ImhlaWdodCI7czozOiI2NjIiO3M6NzoiY2xhc3NlcyI7czowOiIiO319aToxO2E6Mzp7czo0OiJ0eXBlIjtzOjc6ImRpdmlkZXIiO3M6NDoic2l6ZSI7czozOiIxLzEiO3M6NjoiZmllbGRzIjthOjU6e3M6NjoiaGVpZ2h0IjtzOjA6IiI7czo1OiJzdHlsZSI7czo3OiJkZWZhdWx0IjtzOjQ6ImxpbmUiO3M6MDoiIjtzOjEwOiJ0aGVtZWNvbG9yIjtzOjE6IjAiO3M6NzoiY2xhc3NlcyI7czowOiIiO319aToyO2E6Mzp7czo0OiJ0eXBlIjtzOjY6ImNvbHVtbiI7czo0OiJzaXplIjtzOjM6IjEvMiI7czo2OiJmaWVsZHMiO2E6NTp7czo1OiJ0aXRsZSI7czo0OiJEZXNjIjtzOjc6ImNvbnRlbnQiO3M6NDM3OiI8cCBjbGFzcz0iYmlnIj5QZWxsZW50ZXNxdWUgaGFiaXRhbnQgbW9yYmkgdHJpc3RpcXVlIHNlbmVjdHVzIGV0IG5ldHVzIGV0IG1hbGVzdWFkYSBmYW1lcyBhYyB0dXJwaXMgZWdlc3RhcywgdWx0cmljaWVzIGVnZXQsIHRlbXBvciBzaXQgYW1ldCBzdWFkYSBmYW1lcyBhYyB0dXJwaXMgZWdlc3RhIGdpbGxhIHNlbXBlci48L3A+DQo8cD5QZWxsZW50ZXNxdWUgaGFiaXRhbnQgbW9yYmkgdHJpc3RpcXVlIHNlbmVjdHVzIGV0IG5ldHVzIGV0IG1hbGVzdWFkYSBmYW1lcyBhYyB0dXJwaXMgZWdlc3Rhcy4gVmVzdGlidWx1bSB0b3J0byBtZXMgYWMgdHVycGlzIGVnZXN0IGxvcmVtbGlndWxhciBxdWFtLCBmZXVnaWF0IHZpdGFlLCB1bHRyaWNpZXMgZWdldCwgdGVtcG9yIHNpdCBhbWV0IGFudGUuIERvbmVjIGV1IGxpYiBlcm8gc2l0IGFtZXQgcXVhbSBlZ2VzLjwvcD4NCiI7czo1OiJhbGlnbiI7czowOiIiO3M6NzoiYW5pbWF0ZSI7czowOiIiO3M6NzoiY2xhc3NlcyI7czowOiIiO319aTozO2E6Mzp7czo0OiJ0eXBlIjtzOjY6ImNvbHVtbiI7czo0OiJzaXplIjtzOjM6IjEvMiI7czo2OiJmaWVsZHMiO2E6NTp7czo1OiJ0aXRsZSI7czo0OiJEZXNjIjtzOjc6ImNvbnRlbnQiO3M6NTU2OiI8cD5Mb3JlbSBpcHN1bSBkb2xvciBzaXQgYW1ldCBlbmltLiBFdGlhbSB1bGxhbWNvcnBlci4gU3VzcGVuIGRpc3NlIGEgcGVsbGVudGVzcXVlIGR1aSwgbm9uIGZlbGlzLiBNYWVjZW5hcyBtYWxlc3VhZGEgZWxpdCBsZWN0dXMgZmVsaXMsIG1hbGVzdWFkYSB1bHRyaWNpZXMuIEN1cmFiaXR1ciBldCBsaWd1bGEuIFV0IG1vbGVzdGllIGEsIHVsdHJpY2llcyBwb3J0YSB1cm5hLiBWZXN0aWJ1bHVtIGNvbW1vZG8gdm9sdXQuIFBlbGxlbnRlc3F1ZSBmYWNpbGlzaXMuIE51bGxhIGltcGVyZGlldCBzaXQgYW1ldCBtYWduYS4gVmVzdGkgYnVsdW0gZGFwaWJ1cywgbWF1cmlzIG5lYyBtYWxlc3VhIGxlbnRlc3F1ZSBmYWNpbGlzaXMuIE51bGxhIGltcGVyZGlkYSBmYW1lcyBhYyB0dXJwaXMgdmVsaXQsIHJob25jdXMgZXUsIGx1Y3R1cyBldCBpbnRlcmR1bSBhZGlwaXNjaW5nIHdpc2kuIEFsaXF1YW0gZXJhdCBhYyBpcHN1bS4gSW50ZWdlciBhbGlxdWFtIHB1cnVzLiBRdWlzcXVlIGxvcmVtIHRvcnRvciBtYWxlc3VhZGEgZWxpdCBsZWN0dXMgZmVsaXMgbWFsZSBzdWFkYS48L3A+IjtzOjU6ImFsaWduIjtzOjA6IiI7czo3OiJhbmltYXRlIjtzOjA6IiI7czo3OiJjbGFzc2VzIjtzOjA6IiI7fX19fWk6MTthOjI6e3M6NDoiYXR0ciI7YToxNjp7czo1OiJ0aXRsZSI7czo5OiJTdHlsZSBDU1MiO3M6ODoiYmdfaW1hZ2UiO3M6MDoiIjtzOjExOiJiZ19wb3NpdGlvbiI7czoyMjoibm8tcmVwZWF0O2NlbnRlciB0b3A7OyI7czo4OiJiZ19jb2xvciI7czowOiIiO3M6NzoiZGl2aWRlciI7czowOiIiO3M6MTI6ImJnX3ZpZGVvX21wNCI7czowOiIiO3M6MTI6ImJnX3ZpZGVvX29ndiI7czowOiIiO3M6NjoibGF5b3V0IjtzOjEwOiJuby1zaWRlYmFyIjtzOjExOiJwYWRkaW5nX3RvcCI7czoxOiIwIjtzOjE0OiJwYWRkaW5nX2JvdHRvbSI7czoxOiIwIjtzOjEzOiJjb2x1bW5fbWFyZ2luIjtzOjA6IiI7czo1OiJzdHlsZSI7czoxMDoiZnVsbC13aWR0aCI7czoxMDoibmF2aWdhdGlvbiI7czowOiIiO3M6NToiY2xhc3MiO3M6MDoiIjtzOjEwOiJzZWN0aW9uX2lkIjtzOjA6IiI7czoxMDoidmlzaWJpbGl0eSI7czowOiIiO31zOjU6Iml0ZW1zIjthOjE6e2k6MDthOjM6e3M6NDoidHlwZSI7czo2OiJjb2x1bW4iO3M6NDoic2l6ZSI7czozOiIxLzEiO3M6NjoiZmllbGRzIjthOjU6e3M6NToidGl0bGUiO3M6OToiU3R5bGUgQ1NTIjtzOjc6ImNvbnRlbnQiO3M6ODE6IjxzdHlsZT4NCi5zaW5nbGUtcGhvdG8td3JhcHBlciwgLnByb2plY3QtZGVzY3JpcHRpb24geyBkaXNwbGF5OiBub25lOyB9DQo8L3N0eWxlPiI7czo1OiJhbGlnbiI7czowOiIiO3M6NzoiYW5pbWF0ZSI7czowOiIiO3M6NzoiY2xhc3NlcyI7czowOiIiO319fX19");
INSERT INTO `st_postmeta` VALUES("487","2190","mfn-page-items-seo","94002638

1176

662

default

Desc

<p class=\"big\">Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas, ultricies eget, tempor sit amet suada fames ac turpis egesta gilla semper.</p>
<p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum torto mes ac turpis egest loremligular quam, feugiat vitae, ultricies eget, tempor sit amet ante. Donec eu lib ero sit amet quam eges.</p>

Desc

<p>Lorem ipsum dolor sit amet enim. Etiam ullamcorper. Suspen disse a pellentesque dui, non felis. Maecenas malesuada elit lectus felis, malesuada ultricies. Curabitur et ligula. Ut molestie a, ultricies porta urna. Vestibulum commodo volut. Pellentesque facilisis. Nulla imperdiet sit amet magna. Vesti bulum dapibus, mauris nec malesua lentesque facilisis. Nulla imperdida fames ac turpis velit, rhoncus eu, luctus et interdum adipiscing wisi. Aliquam erat ac ipsum. Integer aliquam purus. Quisque lorem tortor malesuada elit lectus felis male suada.</p>

Style CSS

<style>
.single-photo-wrapper, .project-description { display: none; }
</style>

");
INSERT INTO `st_postmeta` VALUES("488","2190","mfn-post-custom-layout","0");
INSERT INTO `st_postmeta` VALUES("489","2190","mfn-post-slider-layer","0");
INSERT INTO `st_postmeta` VALUES("490","2190","_thumbnail_id","89");
INSERT INTO `st_postmeta` VALUES("491","2191","slide_template","default");
INSERT INTO `st_postmeta` VALUES("492","2191","mfn-post-hide-content","0");
INSERT INTO `st_postmeta` VALUES("493","2191","mfn-post-sidebar","0");
INSERT INTO `st_postmeta` VALUES("494","2191","mfn-post-slider","0");
INSERT INTO `st_postmeta` VALUES("495","2191","mfn-post-slider-header","1");
INSERT INTO `st_postmeta` VALUES("496","2191","mfn-post-size","");
INSERT INTO `st_postmeta` VALUES("497","2191","mfn-post-love","28");
INSERT INTO `st_postmeta` VALUES("498","2191","mfn-page-items","YToyOntpOjA7YToyOntzOjQ6ImF0dHIiO2E6MTY6e3M6NToidGl0bGUiO3M6MDoiIjtzOjg6ImJnX2ltYWdlIjtzOjA6IiI7czoxMToiYmdfcG9zaXRpb24iO3M6MjI6Im5vLXJlcGVhdDtjZW50ZXIgdG9wOzsiO3M6ODoiYmdfY29sb3IiO3M6MDoiIjtzOjc6ImRpdmlkZXIiO3M6MDoiIjtzOjEyOiJiZ192aWRlb19tcDQiO3M6MDoiIjtzOjEyOiJiZ192aWRlb19vZ3YiO3M6MDoiIjtzOjY6ImxheW91dCI7czoxMDoibm8tc2lkZWJhciI7czoxMToicGFkZGluZ190b3AiO3M6MToiMCI7czoxNDoicGFkZGluZ19ib3R0b20iO3M6MToiMCI7czoxMzoiY29sdW1uX21hcmdpbiI7czowOiIiO3M6NToic3R5bGUiO3M6MDoiIjtzOjEwOiJuYXZpZ2F0aW9uIjtzOjA6IiI7czo1OiJjbGFzcyI7czowOiIiO3M6MTA6InNlY3Rpb25faWQiO3M6MDoiIjtzOjEwOiJ2aXNpYmlsaXR5IjtzOjA6IiI7fXM6NToiaXRlbXMiO2E6NTp7aTowO2E6Mzp7czo0OiJ0eXBlIjtzOjU6ImltYWdlIjtzOjQ6InNpemUiO3M6MzoiMS8yIjtzOjY6ImZpZWxkcyI7YToxNDp7czozOiJzcmMiO3M6NzY6Imh0dHA6Ly9mb29sc3RhY2tzLmlyL3dwLWNvbnRlbnQvdXBsb2Fkcy8yMDE1LzAzL2hvbWVfd2ViZGVzaWduX3NsaWRlM19iZy5qcGciO3M6NToid2lkdGgiO3M6MDoiIjtzOjY6ImhlaWdodCI7czowOiIiO3M6NjoiYm9yZGVyIjtzOjE6IjEiO3M6NToiYWxpZ24iO3M6NjoiY2VudGVyIjtzOjY6Im1hcmdpbiI7czowOiIiO3M6MzoiYWx0IjtzOjA6IiI7czo3OiJjYXB0aW9uIjtzOjA6IiI7czoxMDoibGlua19pbWFnZSI7czowOiIiO3M6NDoibGluayI7czowOiIiO3M6NjoidGFyZ2V0IjtzOjE6IjAiO3M6OToiZ3JleXNjYWxlIjtzOjE6IjAiO3M6NzoiYW5pbWF0ZSI7czowOiIiO3M6NzoiY2xhc3NlcyI7czowOiIiO319aToxO2E6Mzp7czo0OiJ0eXBlIjtzOjU6ImltYWdlIjtzOjQ6InNpemUiO3M6MzoiMS8yIjtzOjY6ImZpZWxkcyI7YToxNDp7czozOiJzcmMiO3M6NzY6Imh0dHA6Ly9mb29sc3RhY2tzLmlyL3dwLWNvbnRlbnQvdXBsb2Fkcy8yMDE1LzAzL2hvbWVfd2ViZGVzaWduX3NsaWRlNF9iZy5qcGciO3M6NToid2lkdGgiO3M6MDoiIjtzOjY6ImhlaWdodCI7czowOiIiO3M6NjoiYm9yZGVyIjtzOjE6IjEiO3M6NToiYWxpZ24iO3M6NjoiY2VudGVyIjtzOjY6Im1hcmdpbiI7czowOiIiO3M6MzoiYWx0IjtzOjA6IiI7czo3OiJjYXB0aW9uIjtzOjA6IiI7czoxMDoibGlua19pbWFnZSI7czowOiIiO3M6NDoibGluayI7czowOiIiO3M6NjoidGFyZ2V0IjtzOjE6IjAiO3M6OToiZ3JleXNjYWxlIjtzOjE6IjAiO3M6NzoiYW5pbWF0ZSI7czowOiIiO3M6NzoiY2xhc3NlcyI7czowOiIiO319aToyO2E6Mzp7czo0OiJ0eXBlIjtzOjc6ImRpdmlkZXIiO3M6NDoic2l6ZSI7czozOiIxLzEiO3M6NjoiZmllbGRzIjthOjU6e3M6NjoiaGVpZ2h0IjtzOjA6IiI7czo1OiJzdHlsZSI7czo3OiJkZWZhdWx0IjtzOjQ6ImxpbmUiO3M6MDoiIjtzOjEwOiJ0aGVtZWNvbG9yIjtzOjE6IjAiO3M6NzoiY2xhc3NlcyI7czowOiIiO319aTozO2E6Mzp7czo0OiJ0eXBlIjtzOjY6ImNvbHVtbiI7czo0OiJzaXplIjtzOjM6IjEvMiI7czo2OiJmaWVsZHMiO2E6NTp7czo1OiJ0aXRsZSI7czo0OiJEZXNjIjtzOjc6ImNvbnRlbnQiO3M6MTA3MjoiPHAgY2xhc3M9ImJpZyI+UGVsbGVudGVzcXVlIGhhYml0YW50IG1vcmJpIHRyaXN0aXF1ZSBzZW5lY3R1cyBldCBuZXR1cyBldCBtYWxlc3VhZGEgZmFtZXMgYWMgdHVycGlzIGVnZXN0YXMsIHVsdHJpY2llcyBlZ2V0LCB0ZW1wb3Igc2l0IGFtZXQgc3VhZGEgZmFtZXMgYWMgdHVycGlzIGVnZXN0YSBnaWxsYSBzZW1wZXIgbWxpZ3VsYXIgcXVhbSwgZmV1Z2lhdCB2aXRhZSwgdWx0cmljaWVzIGVnZXQsIHRlbXBvciBzaXQgYW1ldCBhbnRlLiBEb25lYyBldSBsaWIgZXJvIHNpdC48L3A+DQo8cD5OdWxsYSBpcHN1bSBkb2xvciBsYWN1cywgc3VzY2lwaXQgYWRpcGlzY2luZy4gQ3VtIHNvY2lpcyBuYXRvcXVlIHBlbmF0aWJ1cyBldCB1bHRyaWNlcyB2b2x1dHBhdC4gTnVsbGFtIHdpc2kgdWx0cmljaWVzIGEsIGdyYXZpZGEgdml0YWUsIGRhcGlidXMgcmlzdXMgYW50ZSBzb2RhbGVzIGxlY3R1cyBibGFuZGl0IGV1LCB0ZW1wb3IgZGlhbSBwZWRlIGN1cnN1cyB2aXRhZSwgdWx0cmljaWVzIGV1LCBmYXVjaWJ1cyBxdWlzLCBwb3J0dGl0b3IgZXJvcyBjdXJzdXMgbGVjdHVzLCBwZWxsZW50ZXNxdWUgZWdldCwgYmliZW5kdW0gYSwgZ3JhdmlkYSB1bGxhbWNvcnBlciBxdWFtLiBOdWxsYW0gdml2ZXJyYSBjb25zZWN0ZXR1ZXIuIFF1aXNxdWUgY3Vyc3VzIGV0LCBwb3J0dGl0b3IgcmlzdXMuIEFsaXF1YW0gc2VtLiBJbiBoZW5kcmVyaXQgbnVsbGEgcXVhbSBudW5jLCBhY2N1bXNhbiBjb25ndWUuIExvcmVtIGlwc3VtIHByaW1pcyBpbiBuaWJoIHZlbCByaXN1cy4gU2VkIHZlbCBsZWN0dXMuIFV0IHNhZ2l0dGlzLCBpcHN1bSBkb2xvciBxdWFtLjwvcD4NCjxwPlBlbGxlbnRlc3F1ZSBoYWJpdGFudCBtb3JiaSB0cmlzdGlxdWUgc2VuZWN0dXMgZXQgbmV0dXMgZXQgbWFsZXN1YWRhIGZhbWVzIGFjIHR1cnBpcyBlZ2VzdGFzLiBWZXN0aWJ1bHVtIHRvcnRvIG1lcyBhYyB0dXJwaXMgZWdlc3QgbG9yZW1saWd1bGFyIHF1YW0sIGZldWdpYXQgdml0YWUsIHVsdHJpY2llcyBlZ2V0LCB0ZW1wb3Igc2l0IGFtZXQgYW50ZS4gRG9uZWMgZXUgbGliIGVybyBzaXQgYW1ldCBxdWFtIGVnZXMuPC9wPiI7czo1OiJhbGlnbiI7czowOiIiO3M6NzoiYW5pbWF0ZSI7czowOiIiO3M6NzoiY2xhc3NlcyI7czowOiIiO319aTo0O2E6Mzp7czo0OiJ0eXBlIjtzOjY6ImNvbHVtbiI7czo0OiJzaXplIjtzOjM6IjEvMiI7czo2OiJmaWVsZHMiO2E6NTp7czo1OiJ0aXRsZSI7czo3OiJHYWxsZXJ5IjtzOjc6ImNvbnRlbnQiO3M6NTA6IltnYWxsZXJ5IGNvbHVtbnM9IjQiIGxpbms9ImZpbGUiIGlkcz0iNyw0NCw0NSw1NiJdIjtzOjU6ImFsaWduIjtzOjA6IiI7czo3OiJhbmltYXRlIjtzOjA6IiI7czo3OiJjbGFzc2VzIjtzOjA6IiI7fX19fWk6MTthOjI6e3M6NDoiYXR0ciI7YToxNjp7czo1OiJ0aXRsZSI7czo5OiJTdHlsZSBDU1MiO3M6ODoiYmdfaW1hZ2UiO3M6MDoiIjtzOjExOiJiZ19wb3NpdGlvbiI7czoyMjoibm8tcmVwZWF0O2NlbnRlciB0b3A7OyI7czo4OiJiZ19jb2xvciI7czowOiIiO3M6NzoiZGl2aWRlciI7czowOiIiO3M6MTI6ImJnX3ZpZGVvX21wNCI7czowOiIiO3M6MTI6ImJnX3ZpZGVvX29ndiI7czowOiIiO3M6NjoibGF5b3V0IjtzOjEwOiJuby1zaWRlYmFyIjtzOjExOiJwYWRkaW5nX3RvcCI7czoxOiIwIjtzOjE0OiJwYWRkaW5nX2JvdHRvbSI7czoxOiIwIjtzOjEzOiJjb2x1bW5fbWFyZ2luIjtzOjA6IiI7czo1OiJzdHlsZSI7czoxMDoiZnVsbC13aWR0aCI7czoxMDoibmF2aWdhdGlvbiI7czowOiIiO3M6NToiY2xhc3MiO3M6MDoiIjtzOjEwOiJzZWN0aW9uX2lkIjtzOjA6IiI7czoxMDoidmlzaWJpbGl0eSI7czowOiIiO31zOjU6Iml0ZW1zIjthOjE6e2k6MDthOjM6e3M6NDoidHlwZSI7czo2OiJjb2x1bW4iO3M6NDoic2l6ZSI7czozOiIxLzEiO3M6NjoiZmllbGRzIjthOjU6e3M6NToidGl0bGUiO3M6OToiU3R5bGUgQ1NTIjtzOjc6ImNvbnRlbnQiO3M6ODE6IjxzdHlsZT4NCi5zaW5nbGUtcGhvdG8td3JhcHBlciwgLnByb2plY3QtZGVzY3JpcHRpb24geyBkaXNwbGF5OiBub25lOyB9DQo8L3N0eWxlPiI7czo1OiJhbGlnbiI7czowOiIiO3M6NzoiYW5pbWF0ZSI7czowOiIiO3M6NzoiY2xhc3NlcyI7czowOiIiO319fX19");
INSERT INTO `st_postmeta` VALUES("537","2196","_wp_attachment_metadata","a:5:{s:5:\"width\";i:55;s:6:\"height\";i:38;s:4:\"file\";s:40:\"2015/03/home_webdesign_footer_logo-1.png\";s:5:\"sizes\";a:1:{s:5:\"50x50\";a:4:{s:4:\"file\";s:38:\"home_webdesign_footer_logo-1-50x35.png\";s:5:\"width\";i:50;s:6:\"height\";i:35;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("499","2191","mfn-page-items-seo","http://themes.muffingroup.com/be/webdesign/wp-content/uploads/2015/03/home_webdesign_slide3_bg.jpg

center

http://themes.muffingroup.com/be/webdesign/wp-content/uploads/2015/03/home_webdesign_slide4_bg.jpg

center

default

Desc

<p class=\"big\">Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas, ultricies eget, tempor sit amet suada fames ac turpis egesta gilla semper mligular quam, feugiat vitae, ultricies eget, tempor sit amet ante. Donec eu lib ero sit.</p>
<p>Nulla ipsum dolor lacus, suscipit adipiscing. Cum sociis natoque penatibus et ultrices volutpat. Nullam wisi ultricies a, gravida vitae, dapibus risus ante sodales lectus blandit eu, tempor diam pede cursus vitae, ultricies eu, faucibus quis, porttitor eros cursus lectus, pellentesque eget, bibendum a, gravida ullamcorper quam. Nullam viverra consectetuer. Quisque cursus et, porttitor risus. Aliquam sem. In hendrerit nulla quam nunc, accumsan congue. Lorem ipsum primis in nibh vel risus. Sed vel lectus. Ut sagittis, ipsum dolor quam.</p>
<p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum torto mes ac turpis egest loremligular quam, feugiat vitae, ultricies eget, tempor sit amet ante. Donec eu lib ero sit amet quam eges.</p>

Gallery

[gallery columns=\"4\" link=\"file\" ids=\"7,44,45,56\"]

Style CSS

<style>
.single-photo-wrapper, .project-description { display: none; }
</style>

");
INSERT INTO `st_postmeta` VALUES("500","2191","mfn-post-custom-layout","0");
INSERT INTO `st_postmeta` VALUES("501","2191","mfn-post-slider-layer","0");
INSERT INTO `st_postmeta` VALUES("502","2191","_thumbnail_id","44");
INSERT INTO `st_postmeta` VALUES("503","2193","slide_template","default");
INSERT INTO `st_postmeta` VALUES("504","2193","mfn-post-hide-content","0");
INSERT INTO `st_postmeta` VALUES("505","2193","mfn-post-sidebar","0");
INSERT INTO `st_postmeta` VALUES("506","2193","mfn-post-slider","0");
INSERT INTO `st_postmeta` VALUES("507","2193","mfn-post-slider-header","1");
INSERT INTO `st_postmeta` VALUES("508","2193","mfn-post-size","");
INSERT INTO `st_postmeta` VALUES("509","2193","mfn-post-love","52");
INSERT INTO `st_postmeta` VALUES("510","2193","mfn-page-items","YToyOntpOjA7YToyOntzOjQ6ImF0dHIiO2E6MTY6e3M6NToidGl0bGUiO3M6MDoiIjtzOjg6ImJnX2ltYWdlIjtzOjA6IiI7czoxMToiYmdfcG9zaXRpb24iO3M6MjI6Im5vLXJlcGVhdDtjZW50ZXIgdG9wOzsiO3M6ODoiYmdfY29sb3IiO3M6MDoiIjtzOjc6ImRpdmlkZXIiO3M6MDoiIjtzOjEyOiJiZ192aWRlb19tcDQiO3M6MDoiIjtzOjEyOiJiZ192aWRlb19vZ3YiO3M6MDoiIjtzOjY6ImxheW91dCI7czoxMDoibm8tc2lkZWJhciI7czoxMToicGFkZGluZ190b3AiO3M6MToiMCI7czoxNDoicGFkZGluZ19ib3R0b20iO3M6MToiMCI7czoxMzoiY29sdW1uX21hcmdpbiI7czowOiIiO3M6NToic3R5bGUiO3M6MDoiIjtzOjEwOiJuYXZpZ2F0aW9uIjtzOjA6IiI7czo1OiJjbGFzcyI7czowOiIiO3M6MTA6InNlY3Rpb25faWQiO3M6MDoiIjtzOjEwOiJ2aXNpYmlsaXR5IjtzOjA6IiI7fXM6NToiaXRlbXMiO2E6Mzp7aTowO2E6Mzp7czo0OiJ0eXBlIjtzOjU6ImltYWdlIjtzOjQ6InNpemUiO3M6MzoiMS8zIjtzOjY6ImZpZWxkcyI7YToxNDp7czozOiJzcmMiO3M6NzY6Imh0dHA6Ly9mb29sc3RhY2tzLmlyL3dwLWNvbnRlbnQvdXBsb2Fkcy8yMDE1LzAzL2hvbWVfd2ViZGVzaWduX3NsaWRlMl9iZy5qcGciO3M6NToid2lkdGgiO3M6MDoiIjtzOjY6ImhlaWdodCI7czowOiIiO3M6NjoiYm9yZGVyIjtzOjE6IjEiO3M6NToiYWxpZ24iO3M6NjoiY2VudGVyIjtzOjY6Im1hcmdpbiI7czowOiIiO3M6MzoiYWx0IjtzOjA6IiI7czo3OiJjYXB0aW9uIjtzOjA6IiI7czoxMDoibGlua19pbWFnZSI7czowOiIiO3M6NDoibGluayI7czowOiIiO3M6NjoidGFyZ2V0IjtzOjE6IjAiO3M6OToiZ3JleXNjYWxlIjtzOjE6IjAiO3M6NzoiYW5pbWF0ZSI7czowOiIiO3M6NzoiY2xhc3NlcyI7czowOiIiO319aToxO2E6Mzp7czo0OiJ0eXBlIjtzOjU6ImltYWdlIjtzOjQ6InNpemUiO3M6MzoiMS8zIjtzOjY6ImZpZWxkcyI7YToxNDp7czozOiJzcmMiO3M6NzY6Imh0dHA6Ly9mb29sc3RhY2tzLmlyL3dwLWNvbnRlbnQvdXBsb2Fkcy8yMDE1LzAzL2hvbWVfd2ViZGVzaWduX3NsaWRlNF9iZy5qcGciO3M6NToid2lkdGgiO3M6MDoiIjtzOjY6ImhlaWdodCI7czowOiIiO3M6NjoiYm9yZGVyIjtzOjE6IjEiO3M6NToiYWxpZ24iO3M6NjoiY2VudGVyIjtzOjY6Im1hcmdpbiI7czowOiIiO3M6MzoiYWx0IjtzOjA6IiI7czo3OiJjYXB0aW9uIjtzOjA6IiI7czoxMDoibGlua19pbWFnZSI7czowOiIiO3M6NDoibGluayI7czowOiIiO3M6NjoidGFyZ2V0IjtzOjE6IjAiO3M6OToiZ3JleXNjYWxlIjtzOjE6IjAiO3M6NzoiYW5pbWF0ZSI7czowOiIiO3M6NzoiY2xhc3NlcyI7czowOiIiO319aToyO2E6Mzp7czo0OiJ0eXBlIjtzOjY6ImNvbHVtbiI7czo0OiJzaXplIjtzOjM6IjEvMyI7czo2OiJmaWVsZHMiO2E6NTp7czo1OiJ0aXRsZSI7czo0OiJEZXNjIjtzOjc6ImNvbnRlbnQiO3M6ODQyOiI8cD5QaGFzZWxsdXMgZmVybWVudHVtIGluLCBkb2xvci4gUGVsbGVudGVzcXVlIGZhY2lsaXNpcy4gTnVsbGEgaW1wZXJkaWV0IHNpdCBhbWV0IG1hZ25hLiBWZXN0aWJ1bHVtIGRhcGlidXMsIG1hdXJpcyBuZWMgbWFsZXN1YWRhIGZhbWVzIGFjIFt0b29sdGlwIGhpbnQ9Ik1hbGVzdWFkYSBmYW1lcyBhYyB0dXJwaXMgZWdlc3RhcywgdWx0cmljaWVzIl10dXJwaXMgdmVsaXRbL3Rvb2x0aXBdLCByaG9uY3VzIGV1LCBsdWN0dXMgZXQgaW50ZXJkdW0gYWRpcGlzY2luZyB3aXNpIGFsaXF1YW0gZXJhdC48L3A+DQo8aDUgc3R5bGU9Im1hcmdpbi1ib3R0b206IDVweDsiPkRhdGU6PC9oNT4NCjxwPltpY29uIHR5cGU9Imljb24tYmFjay1pbi10aW1lIl0gTWF5IDEzLCAyMDE0PC9wPg0KPGg1IHN0eWxlPSJtYXJnaW4tYm90dG9tOiA1cHg7Ij5UYXNrOjwvaDU+DQo8cCBzdHlsZT0ibWFyZ2luLWJvdHRvbTogMzBweDsiPltpY29uIHR5cGU9Imljb24tZG9jLXRleHQiXSBTdXNwZW4gZGlzc2UgZmVybWVuIHR1bTwvcD4NCltpY29uX2JhciBpY29uPSJpY29uLWZhY2Vib29rIiBsaW5rPSIjIiB0YXJnZXQ9IiIgc2l6ZT0ic21hbGwiIHNvY2lhbD0iZmFjZWJvb2siXVtpY29uX2JhciBpY29uPSJpY29uLWdwbHVzIiBsaW5rPSIjIiB0YXJnZXQ9IiIgc2l6ZT0ic21hbGwiIHNvY2lhbD0iZ29vZ2xlIl1baWNvbl9iYXIgaWNvbj0iaWNvbi1waW50ZXJlc3QiIGxpbms9IiMiIHRhcmdldD0iIiBzaXplPSJzbWFsbCIgc29jaWFsPSJwaW50ZXJlc3QiXVtpY29uX2JhciBpY29uPSJpY29uLWRyaWJiYmxlIiBsaW5rPSIjIiB0YXJnZXQ9IiIgc2l6ZT0ic21hbGwiIHNvY2lhbD0iZHJpYmJibGUiXSI7czo1OiJhbGlnbiI7czowOiIiO3M6NzoiYW5pbWF0ZSI7czowOiIiO3M6NzoiY2xhc3NlcyI7czowOiIiO319fX1pOjE7YToyOntzOjQ6ImF0dHIiO2E6MTY6e3M6NToidGl0bGUiO3M6OToiU3R5bGUgQ1NTIjtzOjg6ImJnX2ltYWdlIjtzOjA6IiI7czoxMToiYmdfcG9zaXRpb24iO3M6MjI6Im5vLXJlcGVhdDtjZW50ZXIgdG9wOzsiO3M6ODoiYmdfY29sb3IiO3M6MDoiIjtzOjc6ImRpdmlkZXIiO3M6MDoiIjtzOjEyOiJiZ192aWRlb19tcDQiO3M6MDoiIjtzOjEyOiJiZ192aWRlb19vZ3YiO3M6MDoiIjtzOjY6ImxheW91dCI7czoxMDoibm8tc2lkZWJhciI7czoxMToicGFkZGluZ190b3AiO3M6MToiMCI7czoxNDoicGFkZGluZ19ib3R0b20iO3M6MToiMCI7czoxMzoiY29sdW1uX21hcmdpbiI7czowOiIiO3M6NToic3R5bGUiO3M6MTA6ImZ1bGwtd2lkdGgiO3M6MTA6Im5hdmlnYXRpb24iO3M6MDoiIjtzOjU6ImNsYXNzIjtzOjA6IiI7czoxMDoic2VjdGlvbl9pZCI7czowOiIiO3M6MTA6InZpc2liaWxpdHkiO3M6MDoiIjt9czo1OiJpdGVtcyI7YToxOntpOjA7YTozOntzOjQ6InR5cGUiO3M6NjoiY29sdW1uIjtzOjQ6InNpemUiO3M6MzoiMS8xIjtzOjY6ImZpZWxkcyI7YTo1OntzOjU6InRpdGxlIjtzOjk6IlN0eWxlIENTUyI7czo3OiJjb250ZW50IjtzOjgxOiI8c3R5bGU+DQouc2luZ2xlLXBob3RvLXdyYXBwZXIsIC5wcm9qZWN0LWRlc2NyaXB0aW9uIHsgZGlzcGxheTogbm9uZTsgfQ0KPC9zdHlsZT4iO3M6NToiYWxpZ24iO3M6MDoiIjtzOjc6ImFuaW1hdGUiO3M6MDoiIjtzOjc6ImNsYXNzZXMiO3M6MDoiIjt9fX19fQ==");
INSERT INTO `st_postmeta` VALUES("511","2193","mfn-page-items-seo","http://themes.muffingroup.com/be/webdesign/wp-content/uploads/2015/03/home_webdesign_slide2_bg.jpg

center

http://themes.muffingroup.com/be/webdesign/wp-content/uploads/2015/03/home_webdesign_slide4_bg.jpg

center

Desc

<p>Phasellus fermentum in, dolor. Pellentesque facilisis. Nulla imperdiet sit amet magna. Vestibulum dapibus, mauris nec malesuada fames ac [tooltip hint=\"Malesuada fames ac turpis egestas, ultricies\"]turpis velit[/tooltip], rhoncus eu, luctus et interdum adipiscing wisi aliquam erat.</p>
<h5 style=\"margin-bottom: 5px;\">Date:</h5>
<p>[icon type=\"icon-back-in-time\"] May 13, 2014</p>
<h5 style=\"margin-bottom: 5px;\">Task:</h5>
<p style=\"margin-bottom: 30px;\">[icon type=\"icon-doc-text\"] Suspen disse fermen tum</p>
[icon_bar icon=\"icon-facebook\" link=\"#\" target=\"\" size=\"small\" social=\"facebook\"][icon_bar icon=\"icon-gplus\" link=\"#\" target=\"\" size=\"small\" social=\"google\"][icon_bar icon=\"icon-pinterest\" link=\"#\" target=\"\" size=\"small\" social=\"pinterest\"][icon_bar icon=\"icon-dribbble\" link=\"#\" target=\"\" size=\"small\" social=\"dribbble\"]

Style CSS

<style>
.single-photo-wrapper, .project-description { display: none; }
</style>

");
INSERT INTO `st_postmeta` VALUES("512","2193","mfn-post-custom-layout","0");
INSERT INTO `st_postmeta` VALUES("513","2193","mfn-post-slider-layer","0");
INSERT INTO `st_postmeta` VALUES("514","2193","_thumbnail_id","56");
INSERT INTO `st_postmeta` VALUES("515","2194","_menu_item_type","post_type");
INSERT INTO `st_postmeta` VALUES("516","2194","_menu_item_menu_item_parent","0");
INSERT INTO `st_postmeta` VALUES("517","2194","_menu_item_object_id","106");
INSERT INTO `st_postmeta` VALUES("518","2194","_menu_item_object","page");
INSERT INTO `st_postmeta` VALUES("519","2194","_menu_item_target","");
INSERT INTO `st_postmeta` VALUES("520","2194","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `st_postmeta` VALUES("521","2194","_menu_item_xfn","");
INSERT INTO `st_postmeta` VALUES("522","2194","_menu_item_url","");
INSERT INTO `st_postmeta` VALUES("523","2194","menu-item-mfn-megamenu","");
INSERT INTO `st_postmeta` VALUES("524","2194","menu-item-mfn-bg","");
INSERT INTO `st_postmeta` VALUES("965","108","_wp_trash_meta_time","1542139530");
INSERT INTO `st_postmeta` VALUES("964","108","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("963","111","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("962","111","_wp_desired_post_slug","realisations");
INSERT INTO `st_postmeta` VALUES("961","111","_wp_trash_meta_time","1542139530");
INSERT INTO `st_postmeta` VALUES("960","111","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("535","105","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("540","2198","_wp_attached_file","2015/03/webdesign.png");
INSERT INTO `st_postmeta` VALUES("541","2198","_wp_attachment_metadata","a:5:{s:5:\"width\";i:177;s:6:\"height\";i:45;s:4:\"file\";s:21:\"2015/03/webdesign.png\";s:5:\"sizes\";a:7:{s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:20:\"webdesign-100x45.png\";s:5:\"width\";i:100;s:6:\"height\";i:45;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"webdesign-150x45.png\";s:5:\"width\";i:150;s:6:\"height\";i:45;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:19:\"webdesign-50x13.png\";s:5:\"width\";i:50;s:6:\"height\";i:13;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:19:\"webdesign-80x45.png\";s:5:\"width\";i:80;s:6:\"height\";i:45;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:20:\"webdesign-150x38.png\";s:5:\"width\";i:150;s:6:\"height\";i:38;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:19:\"webdesign-85x45.png\";s:5:\"width\";i:85;s:6:\"height\";i:45;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:20:\"webdesign-100x45.png\";s:5:\"width\";i:100;s:6:\"height\";i:45;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("542","2199","_wp_attached_file","2015/03/home_webdesign_slide1_cover.png");
INSERT INTO `st_postmeta` VALUES("543","2199","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1719;s:6:\"height\";i:1600;s:4:\"file\";s:39:\"2015/03/home_webdesign_slide1_cover.png\";s:5:\"sizes\";a:21:{s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide1_cover-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide1_cover-600x558.png\";s:5:\"width\";i:600;s:6:\"height\";i:558;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide1_cover-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide1_cover-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide1_cover-300x279.png\";s:5:\"width\";i:300;s:6:\"height\";i:279;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide1_cover-768x715.png\";s:5:\"width\";i:768;s:6:\"height\";i:715;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide1_cover-1024x953.png\";s:5:\"width\";i:1024;s:6:\"height\";i:953;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide1_cover-157x146.png\";s:5:\"width\";i:157;s:6:\"height\";i:146;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:37:\"home_webdesign_slide1_cover-50x47.png\";s:5:\"width\";i:50;s:6:\"height\";i:47;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"portfolio-mf\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide1_cover-960x750.png\";s:5:\"width\";i:960;s:6:\"height\";i:750;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide1_cover-960x375.png\";s:5:\"width\";i:960;s:6:\"height\";i:375;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"portfolio-mf-t\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide1_cover-480x750.png\";s:5:\"width\";i:480;s:6:\"height\";i:750;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"portfolio-list\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide1_cover-1160x450.png\";s:5:\"width\";i:1160;s:6:\"height\";i:450;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"blog-single\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide1_cover-1200x480.png\";s:5:\"width\";i:1200;s:6:\"height\";i:480;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:37:\"home_webdesign_slide1_cover-80x80.png\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:37:\"home_webdesign_slide1_cover-81x75.png\";s:5:\"width\";i:81;s:6:\"height\";i:75;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"slider-content\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide1_cover-890x470.png\";s:5:\"width\";i:890;s:6:\"height\";i:470;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:37:\"home_webdesign_slide1_cover-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:39:\"home_webdesign_slide1_cover-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide1_cover-600x558.png\";s:5:\"width\";i:600;s:6:\"height\";i:558;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide1_cover-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("544","2200","_wp_attached_file","2015/03/home_webdesign_slide1_cover2.png");
INSERT INTO `st_postmeta` VALUES("545","2200","_wp_attachment_metadata","a:5:{s:5:\"width\";i:335;s:6:\"height\";i:402;s:4:\"file\";s:40:\"2015/03/home_webdesign_slide1_cover2.png\";s:5:\"sizes\";a:12:{s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide1_cover2-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide1_cover2-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide1_cover2-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide1_cover2-250x300.png\";s:5:\"width\";i:250;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide1_cover2-122x146.png\";s:5:\"width\";i:122;s:6:\"height\";i:146;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:38:\"home_webdesign_slide1_cover2-42x50.png\";s:5:\"width\";i:42;s:6:\"height\";i:50;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide1_cover2-335x375.png\";s:5:\"width\";i:335;s:6:\"height\";i:375;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:38:\"home_webdesign_slide1_cover2-80x80.png\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:38:\"home_webdesign_slide1_cover2-63x75.png\";s:5:\"width\";i:63;s:6:\"height\";i:75;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:38:\"home_webdesign_slide1_cover2-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:40:\"home_webdesign_slide1_cover2-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide1_cover2-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("546","2201","_wp_attached_file","2015/03/home_webdesign_slide3_bg.jpg");
INSERT INTO `st_postmeta` VALUES("547","2201","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:1200;s:4:\"file\";s:36:\"2015/03/home_webdesign_slide3_bg.jpg\";s:5:\"sizes\";a:21:{s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide3_bg-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide3_bg-600x375.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide3_bg-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide3_bg-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide3_bg-300x188.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:188;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide3_bg-768x480.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:37:\"home_webdesign_slide3_bg-1024x640.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:640;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide3_bg-234x146.jpg\";s:5:\"width\";i:234;s:6:\"height\";i:146;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:34:\"home_webdesign_slide3_bg-50x31.jpg\";s:5:\"width\";i:50;s:6:\"height\";i:31;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"portfolio-mf\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide3_bg-960x750.jpg\";s:5:\"width\";i:960;s:6:\"height\";i:750;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide3_bg-960x375.jpg\";s:5:\"width\";i:960;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-t\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide3_bg-480x750.jpg\";s:5:\"width\";i:480;s:6:\"height\";i:750;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-list\";a:4:{s:4:\"file\";s:37:\"home_webdesign_slide3_bg-1160x450.jpg\";s:5:\"width\";i:1160;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-single\";a:4:{s:4:\"file\";s:37:\"home_webdesign_slide3_bg-1200x480.jpg\";s:5:\"width\";i:1200;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:34:\"home_webdesign_slide3_bg-80x80.jpg\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:35:\"home_webdesign_slide3_bg-120x75.jpg\";s:5:\"width\";i:120;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"slider-content\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide3_bg-890x470.jpg\";s:5:\"width\";i:890;s:6:\"height\";i:470;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:34:\"home_webdesign_slide3_bg-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"home_webdesign_slide3_bg-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide3_bg-600x375.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide3_bg-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("548","2202","_wp_attached_file","2015/03/home_webdesign_slide4_bg.jpg");
INSERT INTO `st_postmeta` VALUES("549","2202","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:1200;s:4:\"file\";s:36:\"2015/03/home_webdesign_slide4_bg.jpg\";s:5:\"sizes\";a:21:{s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide4_bg-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide4_bg-600x375.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide4_bg-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide4_bg-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide4_bg-300x188.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:188;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide4_bg-768x480.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:37:\"home_webdesign_slide4_bg-1024x640.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:640;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide4_bg-234x146.jpg\";s:5:\"width\";i:234;s:6:\"height\";i:146;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:34:\"home_webdesign_slide4_bg-50x31.jpg\";s:5:\"width\";i:50;s:6:\"height\";i:31;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"portfolio-mf\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide4_bg-960x750.jpg\";s:5:\"width\";i:960;s:6:\"height\";i:750;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide4_bg-960x375.jpg\";s:5:\"width\";i:960;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-t\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide4_bg-480x750.jpg\";s:5:\"width\";i:480;s:6:\"height\";i:750;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-list\";a:4:{s:4:\"file\";s:37:\"home_webdesign_slide4_bg-1160x450.jpg\";s:5:\"width\";i:1160;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-single\";a:4:{s:4:\"file\";s:37:\"home_webdesign_slide4_bg-1200x480.jpg\";s:5:\"width\";i:1200;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:34:\"home_webdesign_slide4_bg-80x80.jpg\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:35:\"home_webdesign_slide4_bg-120x75.jpg\";s:5:\"width\";i:120;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"slider-content\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide4_bg-890x470.jpg\";s:5:\"width\";i:890;s:6:\"height\";i:470;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:34:\"home_webdesign_slide4_bg-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"home_webdesign_slide4_bg-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide4_bg-600x375.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide4_bg-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("550","2203","_wp_attached_file","2015/03/home_webdesign_slide3_cover.png");
INSERT INTO `st_postmeta` VALUES("551","2203","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1719;s:6:\"height\";i:1600;s:4:\"file\";s:39:\"2015/03/home_webdesign_slide3_cover.png\";s:5:\"sizes\";a:21:{s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide3_cover-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide3_cover-600x558.png\";s:5:\"width\";i:600;s:6:\"height\";i:558;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide3_cover-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide3_cover-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide3_cover-300x279.png\";s:5:\"width\";i:300;s:6:\"height\";i:279;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide3_cover-768x715.png\";s:5:\"width\";i:768;s:6:\"height\";i:715;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide3_cover-1024x953.png\";s:5:\"width\";i:1024;s:6:\"height\";i:953;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide3_cover-157x146.png\";s:5:\"width\";i:157;s:6:\"height\";i:146;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:37:\"home_webdesign_slide3_cover-50x47.png\";s:5:\"width\";i:50;s:6:\"height\";i:47;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"portfolio-mf\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide3_cover-960x750.png\";s:5:\"width\";i:960;s:6:\"height\";i:750;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide3_cover-960x375.png\";s:5:\"width\";i:960;s:6:\"height\";i:375;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"portfolio-mf-t\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide3_cover-480x750.png\";s:5:\"width\";i:480;s:6:\"height\";i:750;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"portfolio-list\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide3_cover-1160x450.png\";s:5:\"width\";i:1160;s:6:\"height\";i:450;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"blog-single\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide3_cover-1200x480.png\";s:5:\"width\";i:1200;s:6:\"height\";i:480;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:37:\"home_webdesign_slide3_cover-80x80.png\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:37:\"home_webdesign_slide3_cover-81x75.png\";s:5:\"width\";i:81;s:6:\"height\";i:75;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"slider-content\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide3_cover-890x470.png\";s:5:\"width\";i:890;s:6:\"height\";i:470;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:37:\"home_webdesign_slide3_cover-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:39:\"home_webdesign_slide3_cover-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide3_cover-600x558.png\";s:5:\"width\";i:600;s:6:\"height\";i:558;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide3_cover-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("552","2204","_wp_attached_file","2015/03/home_webdesign_slide3_cover2.png");
INSERT INTO `st_postmeta` VALUES("553","2204","_wp_attachment_metadata","a:5:{s:5:\"width\";i:335;s:6:\"height\";i:402;s:4:\"file\";s:40:\"2015/03/home_webdesign_slide3_cover2.png\";s:5:\"sizes\";a:12:{s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide3_cover2-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide3_cover2-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide3_cover2-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide3_cover2-250x300.png\";s:5:\"width\";i:250;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide3_cover2-122x146.png\";s:5:\"width\";i:122;s:6:\"height\";i:146;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:38:\"home_webdesign_slide3_cover2-42x50.png\";s:5:\"width\";i:42;s:6:\"height\";i:50;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide3_cover2-335x375.png\";s:5:\"width\";i:335;s:6:\"height\";i:375;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:38:\"home_webdesign_slide3_cover2-80x80.png\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:38:\"home_webdesign_slide3_cover2-63x75.png\";s:5:\"width\";i:63;s:6:\"height\";i:75;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:38:\"home_webdesign_slide3_cover2-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:40:\"home_webdesign_slide3_cover2-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide3_cover2-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("554","2205","_wp_attached_file","2015/03/home_webdesign_slide4_cover2.png");
INSERT INTO `st_postmeta` VALUES("555","2205","_wp_attachment_metadata","a:5:{s:5:\"width\";i:335;s:6:\"height\";i:402;s:4:\"file\";s:40:\"2015/03/home_webdesign_slide4_cover2.png\";s:5:\"sizes\";a:12:{s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide4_cover2-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide4_cover2-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide4_cover2-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide4_cover2-250x300.png\";s:5:\"width\";i:250;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide4_cover2-122x146.png\";s:5:\"width\";i:122;s:6:\"height\";i:146;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:38:\"home_webdesign_slide4_cover2-42x50.png\";s:5:\"width\";i:42;s:6:\"height\";i:50;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide4_cover2-335x375.png\";s:5:\"width\";i:335;s:6:\"height\";i:375;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:38:\"home_webdesign_slide4_cover2-80x80.png\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:38:\"home_webdesign_slide4_cover2-63x75.png\";s:5:\"width\";i:63;s:6:\"height\";i:75;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:38:\"home_webdesign_slide4_cover2-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:40:\"home_webdesign_slide4_cover2-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide4_cover2-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("556","2206","_wp_attached_file","2015/03/home_webdesign_slide4_cover.png");
INSERT INTO `st_postmeta` VALUES("557","2207","_wp_attached_file","revslider/webdesign/home_webdesign_slide1_bg.jpg");
INSERT INTO `st_postmeta` VALUES("558","2207","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:1200;s:4:\"file\";s:48:\"revslider/webdesign/home_webdesign_slide1_bg.jpg\";s:5:\"sizes\";a:21:{s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide1_bg-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide1_bg-600x375.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide1_bg-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide1_bg-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide1_bg-300x188.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:188;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide1_bg-768x480.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:37:\"home_webdesign_slide1_bg-1024x640.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:640;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide1_bg-234x146.jpg\";s:5:\"width\";i:234;s:6:\"height\";i:146;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:34:\"home_webdesign_slide1_bg-50x31.jpg\";s:5:\"width\";i:50;s:6:\"height\";i:31;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"portfolio-mf\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide1_bg-960x750.jpg\";s:5:\"width\";i:960;s:6:\"height\";i:750;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide1_bg-960x375.jpg\";s:5:\"width\";i:960;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-t\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide1_bg-480x750.jpg\";s:5:\"width\";i:480;s:6:\"height\";i:750;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-list\";a:4:{s:4:\"file\";s:37:\"home_webdesign_slide1_bg-1160x450.jpg\";s:5:\"width\";i:1160;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-single\";a:4:{s:4:\"file\";s:37:\"home_webdesign_slide1_bg-1200x480.jpg\";s:5:\"width\";i:1200;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:34:\"home_webdesign_slide1_bg-80x80.jpg\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:35:\"home_webdesign_slide1_bg-120x75.jpg\";s:5:\"width\";i:120;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"slider-content\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide1_bg-890x470.jpg\";s:5:\"width\";i:890;s:6:\"height\";i:470;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:34:\"home_webdesign_slide1_bg-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"home_webdesign_slide1_bg-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide1_bg-600x375.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide1_bg-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("559","2208","_wp_attached_file","revslider/webdesign/home_webdesign_slide1_cover2.png");
INSERT INTO `st_postmeta` VALUES("560","2208","_wp_attachment_metadata","a:5:{s:5:\"width\";i:335;s:6:\"height\";i:402;s:4:\"file\";s:52:\"revslider/webdesign/home_webdesign_slide1_cover2.png\";s:5:\"sizes\";a:12:{s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide1_cover2-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide1_cover2-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide1_cover2-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide1_cover2-250x300.png\";s:5:\"width\";i:250;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide1_cover2-122x146.png\";s:5:\"width\";i:122;s:6:\"height\";i:146;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:38:\"home_webdesign_slide1_cover2-42x50.png\";s:5:\"width\";i:42;s:6:\"height\";i:50;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide1_cover2-335x375.png\";s:5:\"width\";i:335;s:6:\"height\";i:375;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:38:\"home_webdesign_slide1_cover2-80x80.png\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:38:\"home_webdesign_slide1_cover2-63x75.png\";s:5:\"width\";i:63;s:6:\"height\";i:75;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:38:\"home_webdesign_slide1_cover2-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:40:\"home_webdesign_slide1_cover2-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide1_cover2-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("561","2209","_wp_attached_file","revslider/webdesign/home_webdesign_slide1_cover.png");
INSERT INTO `st_postmeta` VALUES("562","2209","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1719;s:6:\"height\";i:1600;s:4:\"file\";s:51:\"revslider/webdesign/home_webdesign_slide1_cover.png\";s:5:\"sizes\";a:21:{s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide1_cover-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide1_cover-600x558.png\";s:5:\"width\";i:600;s:6:\"height\";i:558;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide1_cover-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide1_cover-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide1_cover-300x279.png\";s:5:\"width\";i:300;s:6:\"height\";i:279;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide1_cover-768x715.png\";s:5:\"width\";i:768;s:6:\"height\";i:715;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide1_cover-1024x953.png\";s:5:\"width\";i:1024;s:6:\"height\";i:953;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide1_cover-157x146.png\";s:5:\"width\";i:157;s:6:\"height\";i:146;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:37:\"home_webdesign_slide1_cover-50x47.png\";s:5:\"width\";i:50;s:6:\"height\";i:47;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"portfolio-mf\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide1_cover-960x750.png\";s:5:\"width\";i:960;s:6:\"height\";i:750;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide1_cover-960x375.png\";s:5:\"width\";i:960;s:6:\"height\";i:375;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"portfolio-mf-t\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide1_cover-480x750.png\";s:5:\"width\";i:480;s:6:\"height\";i:750;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"portfolio-list\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide1_cover-1160x450.png\";s:5:\"width\";i:1160;s:6:\"height\";i:450;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"blog-single\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide1_cover-1200x480.png\";s:5:\"width\";i:1200;s:6:\"height\";i:480;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:37:\"home_webdesign_slide1_cover-80x80.png\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:37:\"home_webdesign_slide1_cover-81x75.png\";s:5:\"width\";i:81;s:6:\"height\";i:75;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"slider-content\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide1_cover-890x470.png\";s:5:\"width\";i:890;s:6:\"height\";i:470;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:37:\"home_webdesign_slide1_cover-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:39:\"home_webdesign_slide1_cover-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide1_cover-600x558.png\";s:5:\"width\";i:600;s:6:\"height\";i:558;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide1_cover-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("563","2210","_wp_attached_file","revslider/webdesign/home_webdesign_slide1_num.png");
INSERT INTO `st_postmeta` VALUES("564","2210","_wp_attachment_metadata","a:5:{s:5:\"width\";i:82;s:6:\"height\";i:73;s:4:\"file\";s:49:\"revslider/webdesign/home_webdesign_slide1_num.png\";s:5:\"sizes\";a:2:{s:5:\"50x50\";a:4:{s:4:\"file\";s:35:\"home_webdesign_slide1_num-50x45.png\";s:5:\"width\";i:50;s:6:\"height\";i:45;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:35:\"home_webdesign_slide1_num-80x73.png\";s:5:\"width\";i:80;s:6:\"height\";i:73;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("565","2211","_wp_attached_file","revslider/webdesign/home_webdesign_slider_sep.png");
INSERT INTO `st_postmeta` VALUES("566","2211","_wp_attachment_metadata","a:5:{s:5:\"width\";i:83;s:6:\"height\";i:3;s:4:\"file\";s:49:\"revslider/webdesign/home_webdesign_slider_sep.png\";s:5:\"sizes\";a:2:{s:5:\"50x50\";a:4:{s:4:\"file\";s:34:\"home_webdesign_slider_sep-50x2.png\";s:5:\"width\";i:50;s:6:\"height\";i:2;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:34:\"home_webdesign_slider_sep-80x3.png\";s:5:\"width\";i:80;s:6:\"height\";i:3;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("567","2212","_wp_attached_file","revslider/webdesign/home_webdesign_slide3_bg.jpg");
INSERT INTO `st_postmeta` VALUES("568","2212","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:1200;s:4:\"file\";s:48:\"revslider/webdesign/home_webdesign_slide3_bg.jpg\";s:5:\"sizes\";a:21:{s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide3_bg-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide3_bg-600x375.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide3_bg-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide3_bg-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide3_bg-300x188.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:188;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide3_bg-768x480.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:37:\"home_webdesign_slide3_bg-1024x640.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:640;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide3_bg-234x146.jpg\";s:5:\"width\";i:234;s:6:\"height\";i:146;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:34:\"home_webdesign_slide3_bg-50x31.jpg\";s:5:\"width\";i:50;s:6:\"height\";i:31;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"portfolio-mf\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide3_bg-960x750.jpg\";s:5:\"width\";i:960;s:6:\"height\";i:750;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide3_bg-960x375.jpg\";s:5:\"width\";i:960;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-t\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide3_bg-480x750.jpg\";s:5:\"width\";i:480;s:6:\"height\";i:750;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-list\";a:4:{s:4:\"file\";s:37:\"home_webdesign_slide3_bg-1160x450.jpg\";s:5:\"width\";i:1160;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-single\";a:4:{s:4:\"file\";s:37:\"home_webdesign_slide3_bg-1200x480.jpg\";s:5:\"width\";i:1200;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:34:\"home_webdesign_slide3_bg-80x80.jpg\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:35:\"home_webdesign_slide3_bg-120x75.jpg\";s:5:\"width\";i:120;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"slider-content\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide3_bg-890x470.jpg\";s:5:\"width\";i:890;s:6:\"height\";i:470;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:34:\"home_webdesign_slide3_bg-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"home_webdesign_slide3_bg-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide3_bg-600x375.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide3_bg-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("569","2213","_wp_attached_file","revslider/webdesign/home_webdesign_slide3_cover2.png");
INSERT INTO `st_postmeta` VALUES("570","2213","_wp_attachment_metadata","a:5:{s:5:\"width\";i:335;s:6:\"height\";i:402;s:4:\"file\";s:52:\"revslider/webdesign/home_webdesign_slide3_cover2.png\";s:5:\"sizes\";a:12:{s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide3_cover2-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide3_cover2-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide3_cover2-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide3_cover2-250x300.png\";s:5:\"width\";i:250;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide3_cover2-122x146.png\";s:5:\"width\";i:122;s:6:\"height\";i:146;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:38:\"home_webdesign_slide3_cover2-42x50.png\";s:5:\"width\";i:42;s:6:\"height\";i:50;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide3_cover2-335x375.png\";s:5:\"width\";i:335;s:6:\"height\";i:375;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:38:\"home_webdesign_slide3_cover2-80x80.png\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:38:\"home_webdesign_slide3_cover2-63x75.png\";s:5:\"width\";i:63;s:6:\"height\";i:75;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:38:\"home_webdesign_slide3_cover2-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:40:\"home_webdesign_slide3_cover2-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide3_cover2-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("571","2214","_wp_attached_file","revslider/webdesign/home_webdesign_slide3_cover.png");
INSERT INTO `st_postmeta` VALUES("572","2214","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1719;s:6:\"height\";i:1600;s:4:\"file\";s:51:\"revslider/webdesign/home_webdesign_slide3_cover.png\";s:5:\"sizes\";a:21:{s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide3_cover-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide3_cover-600x558.png\";s:5:\"width\";i:600;s:6:\"height\";i:558;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide3_cover-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide3_cover-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide3_cover-300x279.png\";s:5:\"width\";i:300;s:6:\"height\";i:279;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide3_cover-768x715.png\";s:5:\"width\";i:768;s:6:\"height\";i:715;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide3_cover-1024x953.png\";s:5:\"width\";i:1024;s:6:\"height\";i:953;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide3_cover-157x146.png\";s:5:\"width\";i:157;s:6:\"height\";i:146;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:37:\"home_webdesign_slide3_cover-50x47.png\";s:5:\"width\";i:50;s:6:\"height\";i:47;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"portfolio-mf\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide3_cover-960x750.png\";s:5:\"width\";i:960;s:6:\"height\";i:750;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide3_cover-960x375.png\";s:5:\"width\";i:960;s:6:\"height\";i:375;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"portfolio-mf-t\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide3_cover-480x750.png\";s:5:\"width\";i:480;s:6:\"height\";i:750;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"portfolio-list\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide3_cover-1160x450.png\";s:5:\"width\";i:1160;s:6:\"height\";i:450;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"blog-single\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide3_cover-1200x480.png\";s:5:\"width\";i:1200;s:6:\"height\";i:480;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:37:\"home_webdesign_slide3_cover-80x80.png\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:37:\"home_webdesign_slide3_cover-81x75.png\";s:5:\"width\";i:81;s:6:\"height\";i:75;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"slider-content\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide3_cover-890x470.png\";s:5:\"width\";i:890;s:6:\"height\";i:470;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:37:\"home_webdesign_slide3_cover-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:39:\"home_webdesign_slide3_cover-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide3_cover-600x558.png\";s:5:\"width\";i:600;s:6:\"height\";i:558;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide3_cover-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("573","2215","_wp_attached_file","revslider/webdesign/home_webdesign_slide2_num.png");
INSERT INTO `st_postmeta` VALUES("574","2215","_wp_attachment_metadata","a:5:{s:5:\"width\";i:114;s:6:\"height\";i:72;s:4:\"file\";s:49:\"revslider/webdesign/home_webdesign_slide2_num.png\";s:5:\"sizes\";a:5:{s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide2_num-100x72.png\";s:5:\"width\";i:100;s:6:\"height\";i:72;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:35:\"home_webdesign_slide2_num-50x32.png\";s:5:\"width\";i:50;s:6:\"height\";i:32;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:35:\"home_webdesign_slide2_num-80x72.png\";s:5:\"width\";i:80;s:6:\"height\";i:72;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:35:\"home_webdesign_slide2_num-85x72.png\";s:5:\"width\";i:85;s:6:\"height\";i:72;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide2_num-100x72.png\";s:5:\"width\";i:100;s:6:\"height\";i:72;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("575","2216","_wp_attached_file","revslider/webdesign/home_webdesign_slide4_bg.jpg");
INSERT INTO `st_postmeta` VALUES("576","2216","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:1200;s:4:\"file\";s:48:\"revslider/webdesign/home_webdesign_slide4_bg.jpg\";s:5:\"sizes\";a:21:{s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide4_bg-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide4_bg-600x375.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide4_bg-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide4_bg-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide4_bg-300x188.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:188;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide4_bg-768x480.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:37:\"home_webdesign_slide4_bg-1024x640.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:640;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide4_bg-234x146.jpg\";s:5:\"width\";i:234;s:6:\"height\";i:146;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:34:\"home_webdesign_slide4_bg-50x31.jpg\";s:5:\"width\";i:50;s:6:\"height\";i:31;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"portfolio-mf\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide4_bg-960x750.jpg\";s:5:\"width\";i:960;s:6:\"height\";i:750;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide4_bg-960x375.jpg\";s:5:\"width\";i:960;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-t\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide4_bg-480x750.jpg\";s:5:\"width\";i:480;s:6:\"height\";i:750;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-list\";a:4:{s:4:\"file\";s:37:\"home_webdesign_slide4_bg-1160x450.jpg\";s:5:\"width\";i:1160;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-single\";a:4:{s:4:\"file\";s:37:\"home_webdesign_slide4_bg-1200x480.jpg\";s:5:\"width\";i:1200;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:34:\"home_webdesign_slide4_bg-80x80.jpg\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:35:\"home_webdesign_slide4_bg-120x75.jpg\";s:5:\"width\";i:120;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"slider-content\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide4_bg-890x470.jpg\";s:5:\"width\";i:890;s:6:\"height\";i:470;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:34:\"home_webdesign_slide4_bg-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"home_webdesign_slide4_bg-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide4_bg-600x375.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide4_bg-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("577","2217","_wp_attached_file","revslider/webdesign/home_webdesign_slide4_cover2.png");
INSERT INTO `st_postmeta` VALUES("578","2217","_wp_attachment_metadata","a:5:{s:5:\"width\";i:335;s:6:\"height\";i:402;s:4:\"file\";s:52:\"revslider/webdesign/home_webdesign_slide4_cover2.png\";s:5:\"sizes\";a:12:{s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide4_cover2-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide4_cover2-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide4_cover2-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide4_cover2-250x300.png\";s:5:\"width\";i:250;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide4_cover2-122x146.png\";s:5:\"width\";i:122;s:6:\"height\";i:146;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:38:\"home_webdesign_slide4_cover2-42x50.png\";s:5:\"width\";i:42;s:6:\"height\";i:50;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide4_cover2-335x375.png\";s:5:\"width\";i:335;s:6:\"height\";i:375;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:38:\"home_webdesign_slide4_cover2-80x80.png\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:38:\"home_webdesign_slide4_cover2-63x75.png\";s:5:\"width\";i:63;s:6:\"height\";i:75;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:38:\"home_webdesign_slide4_cover2-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:40:\"home_webdesign_slide4_cover2-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide4_cover2-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("579","2218","_wp_attached_file","revslider/webdesign/home_webdesign_slide4_cover.png");
INSERT INTO `st_postmeta` VALUES("580","2218","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1719;s:6:\"height\";i:1600;s:4:\"file\";s:51:\"revslider/webdesign/home_webdesign_slide4_cover.png\";s:5:\"sizes\";a:21:{s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide4_cover-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide4_cover-600x558.png\";s:5:\"width\";i:600;s:6:\"height\";i:558;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide4_cover-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide4_cover-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide4_cover-300x279.png\";s:5:\"width\";i:300;s:6:\"height\";i:279;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide4_cover-768x715.png\";s:5:\"width\";i:768;s:6:\"height\";i:715;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide4_cover-1024x953.png\";s:5:\"width\";i:1024;s:6:\"height\";i:953;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide4_cover-157x146.png\";s:5:\"width\";i:157;s:6:\"height\";i:146;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:37:\"home_webdesign_slide4_cover-50x47.png\";s:5:\"width\";i:50;s:6:\"height\";i:47;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"portfolio-mf\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide4_cover-960x750.png\";s:5:\"width\";i:960;s:6:\"height\";i:750;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide4_cover-960x375.png\";s:5:\"width\";i:960;s:6:\"height\";i:375;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"portfolio-mf-t\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide4_cover-480x750.png\";s:5:\"width\";i:480;s:6:\"height\";i:750;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"portfolio-list\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide4_cover-1160x450.png\";s:5:\"width\";i:1160;s:6:\"height\";i:450;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"blog-single\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide4_cover-1200x480.png\";s:5:\"width\";i:1200;s:6:\"height\";i:480;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:37:\"home_webdesign_slide4_cover-80x80.png\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:37:\"home_webdesign_slide4_cover-81x75.png\";s:5:\"width\";i:81;s:6:\"height\";i:75;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"slider-content\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide4_cover-890x470.png\";s:5:\"width\";i:890;s:6:\"height\";i:470;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:37:\"home_webdesign_slide4_cover-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:39:\"home_webdesign_slide4_cover-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide4_cover-600x558.png\";s:5:\"width\";i:600;s:6:\"height\";i:558;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide4_cover-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("581","2219","_wp_attached_file","revslider/webdesign/home_webdesign_slide3.png");
INSERT INTO `st_postmeta` VALUES("582","2219","_wp_attachment_metadata","a:5:{s:5:\"width\";i:101;s:6:\"height\";i:72;s:4:\"file\";s:45:\"revslider/webdesign/home_webdesign_slide3.png\";s:5:\"sizes\";a:5:{s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:32:\"home_webdesign_slide3-100x72.png\";s:5:\"width\";i:100;s:6:\"height\";i:72;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:31:\"home_webdesign_slide3-50x36.png\";s:5:\"width\";i:50;s:6:\"height\";i:36;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:31:\"home_webdesign_slide3-80x72.png\";s:5:\"width\";i:80;s:6:\"height\";i:72;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:31:\"home_webdesign_slide3-85x72.png\";s:5:\"width\";i:85;s:6:\"height\";i:72;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:32:\"home_webdesign_slide3-100x72.png\";s:5:\"width\";i:100;s:6:\"height\";i:72;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("583","2220","_wp_attached_file","revslider/webdesign/home_webdesign_slide2_bg.jpg");
INSERT INTO `st_postmeta` VALUES("584","2220","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:1200;s:4:\"file\";s:48:\"revslider/webdesign/home_webdesign_slide2_bg.jpg\";s:5:\"sizes\";a:21:{s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide2_bg-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide2_bg-600x375.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide2_bg-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide2_bg-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide2_bg-300x188.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:188;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide2_bg-768x480.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:37:\"home_webdesign_slide2_bg-1024x640.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:640;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide2_bg-234x146.jpg\";s:5:\"width\";i:234;s:6:\"height\";i:146;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:34:\"home_webdesign_slide2_bg-50x31.jpg\";s:5:\"width\";i:50;s:6:\"height\";i:31;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"portfolio-mf\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide2_bg-960x750.jpg\";s:5:\"width\";i:960;s:6:\"height\";i:750;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide2_bg-960x375.jpg\";s:5:\"width\";i:960;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-t\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide2_bg-480x750.jpg\";s:5:\"width\";i:480;s:6:\"height\";i:750;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-list\";a:4:{s:4:\"file\";s:37:\"home_webdesign_slide2_bg-1160x450.jpg\";s:5:\"width\";i:1160;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-single\";a:4:{s:4:\"file\";s:37:\"home_webdesign_slide2_bg-1200x480.jpg\";s:5:\"width\";i:1200;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:34:\"home_webdesign_slide2_bg-80x80.jpg\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:35:\"home_webdesign_slide2_bg-120x75.jpg\";s:5:\"width\";i:120;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"slider-content\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide2_bg-890x470.jpg\";s:5:\"width\";i:890;s:6:\"height\";i:470;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:34:\"home_webdesign_slide2_bg-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"home_webdesign_slide2_bg-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide2_bg-600x375.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide2_bg-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("585","2221","_wp_attached_file","revslider/webdesign/home_webdesign_slide2_cover2.png");
INSERT INTO `st_postmeta` VALUES("586","2221","_wp_attachment_metadata","a:5:{s:5:\"width\";i:335;s:6:\"height\";i:402;s:4:\"file\";s:52:\"revslider/webdesign/home_webdesign_slide2_cover2.png\";s:5:\"sizes\";a:12:{s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide2_cover2-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide2_cover2-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide2_cover2-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide2_cover2-250x300.png\";s:5:\"width\";i:250;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide2_cover2-122x146.png\";s:5:\"width\";i:122;s:6:\"height\";i:146;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:38:\"home_webdesign_slide2_cover2-42x50.png\";s:5:\"width\";i:42;s:6:\"height\";i:50;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide2_cover2-335x375.png\";s:5:\"width\";i:335;s:6:\"height\";i:375;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:38:\"home_webdesign_slide2_cover2-80x80.png\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:38:\"home_webdesign_slide2_cover2-63x75.png\";s:5:\"width\";i:63;s:6:\"height\";i:75;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:38:\"home_webdesign_slide2_cover2-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:40:\"home_webdesign_slide2_cover2-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide2_cover2-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("587","2222","_wp_attached_file","revslider/webdesign/home_webdesign_slide2_cover.png");
INSERT INTO `st_postmeta` VALUES("588","2222","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1719;s:6:\"height\";i:1600;s:4:\"file\";s:51:\"revslider/webdesign/home_webdesign_slide2_cover.png\";s:5:\"sizes\";a:21:{s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide2_cover-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide2_cover-600x558.png\";s:5:\"width\";i:600;s:6:\"height\";i:558;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide2_cover-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide2_cover-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide2_cover-300x279.png\";s:5:\"width\";i:300;s:6:\"height\";i:279;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide2_cover-768x715.png\";s:5:\"width\";i:768;s:6:\"height\";i:715;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide2_cover-1024x953.png\";s:5:\"width\";i:1024;s:6:\"height\";i:953;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide2_cover-157x146.png\";s:5:\"width\";i:157;s:6:\"height\";i:146;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:37:\"home_webdesign_slide2_cover-50x47.png\";s:5:\"width\";i:50;s:6:\"height\";i:47;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"portfolio-mf\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide2_cover-960x750.png\";s:5:\"width\";i:960;s:6:\"height\";i:750;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide2_cover-960x375.png\";s:5:\"width\";i:960;s:6:\"height\";i:375;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"portfolio-mf-t\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide2_cover-480x750.png\";s:5:\"width\";i:480;s:6:\"height\";i:750;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"portfolio-list\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide2_cover-1160x450.png\";s:5:\"width\";i:1160;s:6:\"height\";i:450;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"blog-single\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide2_cover-1200x480.png\";s:5:\"width\";i:1200;s:6:\"height\";i:480;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:37:\"home_webdesign_slide2_cover-80x80.png\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:37:\"home_webdesign_slide2_cover-81x75.png\";s:5:\"width\";i:81;s:6:\"height\";i:75;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"slider-content\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide2_cover-890x470.png\";s:5:\"width\";i:890;s:6:\"height\";i:470;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:37:\"home_webdesign_slide2_cover-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:39:\"home_webdesign_slide2_cover-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide2_cover-600x558.png\";s:5:\"width\";i:600;s:6:\"height\";i:558;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide2_cover-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("589","2223","_wp_attached_file","revslider/webdesign/home_webdesign_slide4_num.png");
INSERT INTO `st_postmeta` VALUES("590","2223","_wp_attachment_metadata","a:5:{s:5:\"width\";i:111;s:6:\"height\";i:72;s:4:\"file\";s:49:\"revslider/webdesign/home_webdesign_slide4_num.png\";s:5:\"sizes\";a:5:{s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide4_num-100x72.png\";s:5:\"width\";i:100;s:6:\"height\";i:72;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:35:\"home_webdesign_slide4_num-50x32.png\";s:5:\"width\";i:50;s:6:\"height\";i:32;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:35:\"home_webdesign_slide4_num-80x72.png\";s:5:\"width\";i:80;s:6:\"height\";i:72;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:35:\"home_webdesign_slide4_num-85x72.png\";s:5:\"width\";i:85;s:6:\"height\";i:72;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"home_webdesign_slide4_num-100x72.png\";s:5:\"width\";i:100;s:6:\"height\";i:72;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("591","2224","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("592","2224","_wp_trash_meta_time","1541817164");
INSERT INTO `st_postmeta` VALUES("593","2224","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("594","2225","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("595","2225","_wp_trash_meta_time","1541817178");
INSERT INTO `st_postmeta` VALUES("596","2225","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("597","2226","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("598","2226","_wp_trash_meta_time","1541817203");
INSERT INTO `st_postmeta` VALUES("599","2226","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("600","2227","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("601","2227","_wp_trash_meta_time","1541817256");
INSERT INTO `st_postmeta` VALUES("602","2227","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("603","2228","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("604","2228","_wp_trash_meta_time","1541817270");
INSERT INTO `st_postmeta` VALUES("605","2228","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("606","2229","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("607","2229","_wp_trash_meta_time","1541817288");
INSERT INTO `st_postmeta` VALUES("608","2229","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("609","2230","_edit_lock","1541817342:1");
INSERT INTO `st_postmeta` VALUES("610","2230","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("611","2230","_wp_trash_meta_time","1541817360");
INSERT INTO `st_postmeta` VALUES("612","2230","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("613","2231","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("614","2231","_wp_trash_meta_time","1541817473");
INSERT INTO `st_postmeta` VALUES("615","2231","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("616","2232","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("617","2232","_wp_trash_meta_time","1541817649");
INSERT INTO `st_postmeta` VALUES("618","2232","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("619","2233","_edit_lock","1541817691:1");
INSERT INTO `st_postmeta` VALUES("620","2233","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("621","2233","_wp_trash_meta_time","1541817697");
INSERT INTO `st_postmeta` VALUES("622","2233","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("623","2234","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("624","2234","_wp_trash_meta_time","1541817723");
INSERT INTO `st_postmeta` VALUES("625","2234","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("1781","2383","_edit_last","1");
INSERT INTO `st_postmeta` VALUES("628","2236","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("629","2236","_wp_trash_meta_time","1541817770");
INSERT INTO `st_postmeta` VALUES("630","2236","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("631","2237","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("632","2237","_wp_trash_meta_time","1541817803");
INSERT INTO `st_postmeta` VALUES("633","2237","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("634","2238","_edit_lock","1541817828:1");
INSERT INTO `st_postmeta` VALUES("635","2238","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("636","2238","_wp_trash_meta_time","1541817836");
INSERT INTO `st_postmeta` VALUES("637","2238","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("638","2239","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("639","2239","_wp_trash_meta_time","1541817934");
INSERT INTO `st_postmeta` VALUES("640","2239","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("641","87","_thumbnail_id","77");
INSERT INTO `st_postmeta` VALUES("644","2241","_wp_attached_file","2018/11/108181-120425155J065.jpg");
INSERT INTO `st_postmeta` VALUES("645","2241","_wp_attachment_metadata","a:5:{s:5:\"width\";i:833;s:6:\"height\";i:1000;s:4:\"file\";s:32:\"2018/11/108181-120425155J065.jpg\";s:5:\"sizes\";a:20:{s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:32:\"108181-120425155J065-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:32:\"108181-120425155J065-600x720.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:720;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:32:\"108181-120425155J065-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:32:\"108181-120425155J065-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:32:\"108181-120425155J065-250x300.jpg\";s:5:\"width\";i:250;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:32:\"108181-120425155J065-768x922.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:922;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:32:\"108181-120425155J065-122x146.jpg\";s:5:\"width\";i:122;s:6:\"height\";i:146;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:30:\"108181-120425155J065-42x50.jpg\";s:5:\"width\";i:42;s:6:\"height\";i:50;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"portfolio-mf\";a:4:{s:4:\"file\";s:32:\"108181-120425155J065-833x750.jpg\";s:5:\"width\";i:833;s:6:\"height\";i:750;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:32:\"108181-120425155J065-833x375.jpg\";s:5:\"width\";i:833;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-t\";a:4:{s:4:\"file\";s:32:\"108181-120425155J065-480x750.jpg\";s:5:\"width\";i:480;s:6:\"height\";i:750;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-list\";a:4:{s:4:\"file\";s:32:\"108181-120425155J065-833x450.jpg\";s:5:\"width\";i:833;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-single\";a:4:{s:4:\"file\";s:32:\"108181-120425155J065-833x480.jpg\";s:5:\"width\";i:833;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:30:\"108181-120425155J065-80x80.jpg\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:30:\"108181-120425155J065-62x75.jpg\";s:5:\"width\";i:62;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"slider-content\";a:4:{s:4:\"file\";s:32:\"108181-120425155J065-833x470.jpg\";s:5:\"width\";i:833;s:6:\"height\";i:470;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:30:\"108181-120425155J065-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:32:\"108181-120425155J065-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:32:\"108181-120425155J065-600x720.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:720;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:32:\"108181-120425155J065-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("646","85","_thumbnail_id","2241");
INSERT INTO `st_postmeta` VALUES("649","2243","_wp_attached_file","2018/11/1476250569285.jpg");
INSERT INTO `st_postmeta` VALUES("650","2243","_wp_attachment_metadata","a:5:{s:5:\"width\";i:650;s:6:\"height\";i:535;s:4:\"file\";s:25:\"2018/11/1476250569285.jpg\";s:5:\"sizes\";a:18:{s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:25:\"1476250569285-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:25:\"1476250569285-600x494.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:494;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:25:\"1476250569285-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:25:\"1476250569285-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:25:\"1476250569285-300x247.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:247;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:25:\"1476250569285-177x146.jpg\";s:5:\"width\";i:177;s:6:\"height\";i:146;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:23:\"1476250569285-50x41.jpg\";s:5:\"width\";i:50;s:6:\"height\";i:41;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:25:\"1476250569285-650x375.jpg\";s:5:\"width\";i:650;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-t\";a:4:{s:4:\"file\";s:25:\"1476250569285-480x535.jpg\";s:5:\"width\";i:480;s:6:\"height\";i:535;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-list\";a:4:{s:4:\"file\";s:25:\"1476250569285-650x450.jpg\";s:5:\"width\";i:650;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-single\";a:4:{s:4:\"file\";s:25:\"1476250569285-650x480.jpg\";s:5:\"width\";i:650;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:23:\"1476250569285-80x80.jpg\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:23:\"1476250569285-91x75.jpg\";s:5:\"width\";i:91;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"slider-content\";a:4:{s:4:\"file\";s:25:\"1476250569285-650x470.jpg\";s:5:\"width\";i:650;s:6:\"height\";i:470;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:23:\"1476250569285-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:25:\"1476250569285-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:25:\"1476250569285-600x494.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:494;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:25:\"1476250569285-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:7:\"ET-0448\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("651","83","_thumbnail_id","2243");
INSERT INTO `st_postmeta` VALUES("654","2244","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("655","2244","_wp_trash_meta_time","1541821755");
INSERT INTO `st_postmeta` VALUES("656","2244","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("657","106","_edit_lock","1542347924:1");
INSERT INTO `st_postmeta` VALUES("658","2245","_wp_attached_file","2018/11/home_webdesign_pattern1.png");
INSERT INTO `st_postmeta` VALUES("659","2245","_wp_attachment_metadata","a:5:{s:5:\"width\";i:7;s:6:\"height\";i:7;s:4:\"file\";s:35:\"2018/11/home_webdesign_pattern1.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("660","106","_edit_last","1");
INSERT INTO `st_postmeta` VALUES("661","106","_wpb_vc_js_status","false");
INSERT INTO `st_postmeta` VALUES("662","106","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("666","2248","_wp_attachment_metadata","a:5:{s:5:\"width\";i:650;s:6:\"height\";i:550;s:4:\"file\";s:13:\"2018/11/1.jpg\";s:5:\"sizes\";a:18:{s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:13:\"1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:13:\"1-600x508.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:508;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:13:\"1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:13:\"1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:13:\"1-300x254.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:254;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:13:\"1-173x146.jpg\";s:5:\"width\";i:173;s:6:\"height\";i:146;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:11:\"1-50x42.jpg\";s:5:\"width\";i:50;s:6:\"height\";i:42;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:13:\"1-650x375.jpg\";s:5:\"width\";i:650;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-t\";a:4:{s:4:\"file\";s:13:\"1-480x550.jpg\";s:5:\"width\";i:480;s:6:\"height\";i:550;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-list\";a:4:{s:4:\"file\";s:13:\"1-650x450.jpg\";s:5:\"width\";i:650;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-single\";a:4:{s:4:\"file\";s:13:\"1-650x480.jpg\";s:5:\"width\";i:650;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:11:\"1-80x80.jpg\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:11:\"1-89x75.jpg\";s:5:\"width\";i:89;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"slider-content\";a:4:{s:4:\"file\";s:13:\"1-650x470.jpg\";s:5:\"width\";i:650;s:6:\"height\";i:470;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:11:\"1-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:13:\"1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:13:\"1-600x508.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:508;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:13:\"1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("665","2248","_wp_attached_file","2018/11/1.jpg");
INSERT INTO `st_postmeta` VALUES("667","2249","_wp_attached_file","2018/11/2.jpg");
INSERT INTO `st_postmeta` VALUES("668","2249","_wp_attachment_metadata","a:5:{s:5:\"width\";i:650;s:6:\"height\";i:550;s:4:\"file\";s:13:\"2018/11/2.jpg\";s:5:\"sizes\";a:18:{s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:13:\"2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:13:\"2-600x508.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:508;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:13:\"2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:13:\"2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:13:\"2-300x254.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:254;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:13:\"2-173x146.jpg\";s:5:\"width\";i:173;s:6:\"height\";i:146;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:11:\"2-50x42.jpg\";s:5:\"width\";i:50;s:6:\"height\";i:42;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:13:\"2-650x375.jpg\";s:5:\"width\";i:650;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-t\";a:4:{s:4:\"file\";s:13:\"2-480x550.jpg\";s:5:\"width\";i:480;s:6:\"height\";i:550;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-list\";a:4:{s:4:\"file\";s:13:\"2-650x450.jpg\";s:5:\"width\";i:650;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-single\";a:4:{s:4:\"file\";s:13:\"2-650x480.jpg\";s:5:\"width\";i:650;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:11:\"2-80x80.jpg\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:11:\"2-89x75.jpg\";s:5:\"width\";i:89;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"slider-content\";a:4:{s:4:\"file\";s:13:\"2-650x470.jpg\";s:5:\"width\";i:650;s:6:\"height\";i:470;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:11:\"2-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:13:\"2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:13:\"2-600x508.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:508;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:13:\"2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("669","2250","_wp_attached_file","2018/11/3.jpg");
INSERT INTO `st_postmeta` VALUES("670","2250","_wp_attachment_metadata","a:5:{s:5:\"width\";i:650;s:6:\"height\";i:550;s:4:\"file\";s:13:\"2018/11/3.jpg\";s:5:\"sizes\";a:18:{s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:13:\"3-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:13:\"3-600x508.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:508;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:13:\"3-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:13:\"3-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:13:\"3-300x254.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:254;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:13:\"3-173x146.jpg\";s:5:\"width\";i:173;s:6:\"height\";i:146;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:11:\"3-50x42.jpg\";s:5:\"width\";i:50;s:6:\"height\";i:42;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:13:\"3-650x375.jpg\";s:5:\"width\";i:650;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-t\";a:4:{s:4:\"file\";s:13:\"3-480x550.jpg\";s:5:\"width\";i:480;s:6:\"height\";i:550;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-list\";a:4:{s:4:\"file\";s:13:\"3-650x450.jpg\";s:5:\"width\";i:650;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-single\";a:4:{s:4:\"file\";s:13:\"3-650x480.jpg\";s:5:\"width\";i:650;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:11:\"3-80x80.jpg\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:11:\"3-89x75.jpg\";s:5:\"width\";i:89;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"slider-content\";a:4:{s:4:\"file\";s:13:\"3-650x470.jpg\";s:5:\"width\";i:650;s:6:\"height\";i:470;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:11:\"3-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:13:\"3-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:13:\"3-600x508.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:508;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:13:\"3-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("671","2251","_wp_attached_file","2018/11/4.jpg");
INSERT INTO `st_postmeta` VALUES("672","2251","_wp_attachment_metadata","a:5:{s:5:\"width\";i:650;s:6:\"height\";i:550;s:4:\"file\";s:13:\"2018/11/4.jpg\";s:5:\"sizes\";a:18:{s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:13:\"4-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:13:\"4-600x508.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:508;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:13:\"4-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:13:\"4-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:13:\"4-300x254.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:254;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:13:\"4-173x146.jpg\";s:5:\"width\";i:173;s:6:\"height\";i:146;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:11:\"4-50x42.jpg\";s:5:\"width\";i:50;s:6:\"height\";i:42;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:13:\"4-650x375.jpg\";s:5:\"width\";i:650;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-t\";a:4:{s:4:\"file\";s:13:\"4-480x550.jpg\";s:5:\"width\";i:480;s:6:\"height\";i:550;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-list\";a:4:{s:4:\"file\";s:13:\"4-650x450.jpg\";s:5:\"width\";i:650;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-single\";a:4:{s:4:\"file\";s:13:\"4-650x480.jpg\";s:5:\"width\";i:650;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:11:\"4-80x80.jpg\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:11:\"4-89x75.jpg\";s:5:\"width\";i:89;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"slider-content\";a:4:{s:4:\"file\";s:13:\"4-650x470.jpg\";s:5:\"width\";i:650;s:6:\"height\";i:470;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:11:\"4-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:13:\"4-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:13:\"4-600x508.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:508;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:13:\"4-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("673","2252","_wp_attached_file","2018/11/5.jpg");
INSERT INTO `st_postmeta` VALUES("674","2252","_wp_attachment_metadata","a:5:{s:5:\"width\";i:650;s:6:\"height\";i:550;s:4:\"file\";s:13:\"2018/11/5.jpg\";s:5:\"sizes\";a:18:{s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:13:\"5-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:13:\"5-600x508.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:508;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:13:\"5-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:13:\"5-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:13:\"5-300x254.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:254;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:13:\"5-173x146.jpg\";s:5:\"width\";i:173;s:6:\"height\";i:146;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:11:\"5-50x42.jpg\";s:5:\"width\";i:50;s:6:\"height\";i:42;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:13:\"5-650x375.jpg\";s:5:\"width\";i:650;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-t\";a:4:{s:4:\"file\";s:13:\"5-480x550.jpg\";s:5:\"width\";i:480;s:6:\"height\";i:550;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-list\";a:4:{s:4:\"file\";s:13:\"5-650x450.jpg\";s:5:\"width\";i:650;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-single\";a:4:{s:4:\"file\";s:13:\"5-650x480.jpg\";s:5:\"width\";i:650;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:11:\"5-80x80.jpg\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:11:\"5-89x75.jpg\";s:5:\"width\";i:89;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"slider-content\";a:4:{s:4:\"file\";s:13:\"5-650x470.jpg\";s:5:\"width\";i:650;s:6:\"height\";i:470;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:11:\"5-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:13:\"5-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:13:\"5-600x508.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:508;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:13:\"5-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("677","2254","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("678","2254","_wp_trash_meta_time","1542100928");
INSERT INTO `st_postmeta` VALUES("679","2254","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("680","2255","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("681","2255","_wp_trash_meta_time","1542100981");
INSERT INTO `st_postmeta` VALUES("682","2255","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("1668","2259","settings","eyJnYWxsZXJ5X3dpZHRoIjoiNzUwIiwiZ2FsbGVyeV9oZWlnaHQiOiI1MDAiLCJhdXRvcGxheSI6IjEiLCJwYXVzZW9uaG92ZXIiOiIxIiwiYXJyb3dzIjoiMCIsInRyYW5zaXRpb25fc3R5bGUiOiJzbGlkZSIsImludGVydmFsIjoiMzAwMCIsInRyYW5zaXRpb25fc3BlZWQiOiIzMDAiLCJzaG93X3RodW1ibmFpbF9saW5rIjoiMSIsInRodW1ibmFpbF9saW5rX3RleHQiOiJWaWV3IFRodW1ibmFpbHMiLCJkaXNwbGF5X3ZpZXciOiJkZWZhdWx0IiwidXNlX2xpZ2h0Ym94X2VmZmVjdCI6dHJ1ZSwidGVtcGxhdGUiOiIiLCJuZ2dfdHJpZ2dlcnNfZGlzcGxheSI6Im5ldmVyIiwiX2Vycm9ycyI6W119");
INSERT INTO `st_postmeta` VALUES("1667","2259","id_field","ID");
INSERT INTO `st_postmeta` VALUES("1666","2259","aliases","WyJiYXNpY19zbGlkZXNob3ciLCJuZXh0Z2VuX2Jhc2ljX3NsaWRlc2hvdyJd");
INSERT INTO `st_postmeta` VALUES("1663","2259","hidden_from_igw","");
INSERT INTO `st_postmeta` VALUES("1664","2259","__defaults_set","1");
INSERT INTO `st_postmeta` VALUES("1665","2259","entity_types","WyJpbWFnZSJd");
INSERT INTO `st_postmeta` VALUES("1662","2259","hidden_from_ui","");
INSERT INTO `st_postmeta` VALUES("1661","2259","installed_at_version","3.0.16");
INSERT INTO `st_postmeta` VALUES("1660","2259","name","photocrati-nextgen_basic_slideshow");
INSERT INTO `st_postmeta` VALUES("1659","2259","view_order","10010");
INSERT INTO `st_postmeta` VALUES("1658","2259","default_source","galleries");
INSERT INTO `st_postmeta` VALUES("1686","2260","id_field","ID");
INSERT INTO `st_postmeta` VALUES("1687","2260","settings","eyJhamF4X3BhZ2luYXRpb24iOiIxIiwiZGlzcGxheV92aWV3IjoiZGVmYXVsdC12aWV3LnBocCIsInRlbXBsYXRlIjoiIiwidXNlX2xpZ2h0Ym94X2VmZmVjdCI6dHJ1ZSwibmdnX3RyaWdnZXJzX2Rpc3BsYXkiOiJuZXZlciIsIl9lcnJvcnMiOltdfQ==");
INSERT INTO `st_postmeta` VALUES("1685","2260","aliases","WyJiYXNpY19pbWFnZWJyb3dzZXIiLCJpbWFnZWJyb3dzZXIiLCJuZXh0Z2VuX2Jhc2ljX2ltYWdlYnJvd3NlciJd");
INSERT INTO `st_postmeta` VALUES("1682","2260","hidden_from_igw","");
INSERT INTO `st_postmeta` VALUES("1683","2260","__defaults_set","1");
INSERT INTO `st_postmeta` VALUES("1684","2260","entity_types","WyJpbWFnZSJd");
INSERT INTO `st_postmeta` VALUES("1678","2260","view_order","10020");
INSERT INTO `st_postmeta` VALUES("1679","2260","name","photocrati-nextgen_basic_imagebrowser");
INSERT INTO `st_postmeta` VALUES("1681","2260","hidden_from_ui","");
INSERT INTO `st_postmeta` VALUES("1680","2260","installed_at_version","3.0.16");
INSERT INTO `st_postmeta` VALUES("1706","2261","settings","eyJ3aWR0aCI6IiIsImhlaWdodCI6IiIsImxpbmsiOiIiLCJsaW5rX3RhcmdldCI6Il9ibGFuayIsImZsb2F0IjoiIiwicXVhbGl0eSI6IjEwMCIsImNyb3AiOiIwIiwiZGlzcGxheV93YXRlcm1hcmsiOiIwIiwiZGlzcGxheV9yZWZsZWN0aW9uIjoiMCIsInRlbXBsYXRlIjoiIiwidXNlX2xpZ2h0Ym94X2VmZmVjdCI6dHJ1ZSwibW9kZSI6IiIsIm5nZ190cmlnZ2Vyc19kaXNwbGF5IjoibmV2ZXIiLCJfZXJyb3JzIjpbXX0=");
INSERT INTO `st_postmeta` VALUES("1705","2261","id_field","ID");
INSERT INTO `st_postmeta` VALUES("1704","2261","aliases","WyJiYXNpY19zaW5nbGVwaWMiLCJzaW5nbGVwaWMiLCJuZXh0Z2VuX2Jhc2ljX3NpbmdsZXBpYyJd");
INSERT INTO `st_postmeta` VALUES("1703","2261","entity_types","WyJpbWFnZSJd");
INSERT INTO `st_postmeta` VALUES("1702","2261","__defaults_set","1");
INSERT INTO `st_postmeta` VALUES("1701","2261","installed_at_version","3.0.16");
INSERT INTO `st_postmeta` VALUES("1696","2261","default_source","galleries");
INSERT INTO `st_postmeta` VALUES("1700","2261","name","photocrati-nextgen_basic_singlepic");
INSERT INTO `st_postmeta` VALUES("1699","2261","hidden_from_igw","1");
INSERT INTO `st_postmeta` VALUES("1697","2261","view_order","10060");
INSERT INTO `st_postmeta` VALUES("1698","2261","hidden_from_ui","1");
INSERT INTO `st_postmeta` VALUES("1775","106","mfn-post-one-page","0");
INSERT INTO `st_postmeta` VALUES("1725","2262","settings","eyJudW1iZXIiOiI0NSIsImdhbGxlcnlfZGlzcGxheV90eXBlIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX3RodW1ibmFpbHMiLCJ1c2VfbGlnaHRib3hfZWZmZWN0Ijp0cnVlLCJuZ2dfdHJpZ2dlcnNfZGlzcGxheSI6Im5ldmVyIiwiX2Vycm9ycyI6W119");
INSERT INTO `st_postmeta` VALUES("1724","2262","id_field","ID");
INSERT INTO `st_postmeta` VALUES("1721","2262","__defaults_set","1");
INSERT INTO `st_postmeta` VALUES("1722","2262","entity_types","WyJpbWFnZSJd");
INSERT INTO `st_postmeta` VALUES("1723","2262","aliases","WyJiYXNpY190YWdjbG91ZCIsInRhZ2Nsb3VkIiwibmV4dGdlbl9iYXNpY190YWdjbG91ZCJd");
INSERT INTO `st_postmeta` VALUES("1717","2262","name","photocrati-nextgen_basic_tagcloud");
INSERT INTO `st_postmeta` VALUES("1720","2262","hidden_from_igw","");
INSERT INTO `st_postmeta` VALUES("1719","2262","hidden_from_ui","");
INSERT INTO `st_postmeta` VALUES("1718","2262","installed_at_version","3.0.16");
INSERT INTO `st_postmeta` VALUES("1745","2263","settings","eyJnYWxsZXJ5X2Rpc3BsYXlfdHlwZSI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY190aHVtYm5haWxzIiwiZ2FsbGVyaWVzX3Blcl9wYWdlIjoiMCIsImVuYWJsZV9icmVhZGNydW1icyI6IjEiLCJkaXNwbGF5X3ZpZXciOiJkZWZhdWx0LXZpZXcucGhwIiwidGVtcGxhdGUiOiIiLCJlbmFibGVfZGVzY3JpcHRpb25zIjoiMCIsIm92ZXJyaWRlX3RodW1ibmFpbF9zZXR0aW5ncyI6IjEiLCJ0aHVtYm5haWxfd2lkdGgiOiIyNDAiLCJ0aHVtYm5haWxfaGVpZ2h0IjoiMTYwIiwidGh1bWJuYWlsX2Nyb3AiOiIxIiwidXNlX2xpZ2h0Ym94X2VmZmVjdCI6dHJ1ZSwiZGlzYWJsZV9wYWdpbmF0aW9uIjowLCJvcGVuX2dhbGxlcnlfaW5fbGlnaHRib3giOjAsInRodW1ibmFpbF9xdWFsaXR5IjoxMDAsInRodW1ibmFpbF93YXRlcm1hcmsiOjAsImdhbGxlcnlfZGlzcGxheV90ZW1wbGF0ZSI6IiIsIm5nZ190cmlnZ2Vyc19kaXNwbGF5IjoibmV2ZXIiLCJfZXJyb3JzIjpbXX0=");
INSERT INTO `st_postmeta` VALUES("1744","2263","id_field","ID");
INSERT INTO `st_postmeta` VALUES("1735","2263","default_source","albums");
INSERT INTO `st_postmeta` VALUES("1743","2263","aliases","WyJiYXNpY19jb21wYWN0X2FsYnVtIiwibmV4dGdlbl9iYXNpY19hbGJ1bSIsImJhc2ljX2FsYnVtX2NvbXBhY3QiLCJjb21wYWN0X2FsYnVtIl0=");
INSERT INTO `st_postmeta` VALUES("1742","2263","entity_types","WyJhbGJ1bSIsImdhbGxlcnkiXQ==");
INSERT INTO `st_postmeta` VALUES("1741","2263","__defaults_set","1");
INSERT INTO `st_postmeta` VALUES("1738","2263","installed_at_version","3.0.16");
INSERT INTO `st_postmeta` VALUES("1739","2263","hidden_from_ui","");
INSERT INTO `st_postmeta` VALUES("1740","2263","hidden_from_igw","");
INSERT INTO `st_postmeta` VALUES("1737","2263","name","photocrati-nextgen_basic_compact_album");
INSERT INTO `st_postmeta` VALUES("1736","2263","view_order","10200");
INSERT INTO `st_postmeta` VALUES("1765","2264","settings","eyJnYWxsZXJ5X2Rpc3BsYXlfdHlwZSI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY190aHVtYm5haWxzIiwiZ2FsbGVyaWVzX3Blcl9wYWdlIjoiMCIsImVuYWJsZV9icmVhZGNydW1icyI6IjEiLCJkaXNwbGF5X3ZpZXciOiJkZWZhdWx0LXZpZXcucGhwIiwidGVtcGxhdGUiOiIiLCJlbmFibGVfZGVzY3JpcHRpb25zIjoiMCIsIm92ZXJyaWRlX3RodW1ibmFpbF9zZXR0aW5ncyI6IjEiLCJ0aHVtYm5haWxfd2lkdGgiOiIzMDAiLCJ0aHVtYm5haWxfaGVpZ2h0IjoiMjAwIiwidGh1bWJuYWlsX2Nyb3AiOiIxIiwidXNlX2xpZ2h0Ym94X2VmZmVjdCI6dHJ1ZSwiZGlzYWJsZV9wYWdpbmF0aW9uIjowLCJvcGVuX2dhbGxlcnlfaW5fbGlnaHRib3giOjAsInRodW1ibmFpbF9xdWFsaXR5IjoxMDAsInRodW1ibmFpbF93YXRlcm1hcmsiOjAsImdhbGxlcnlfZGlzcGxheV90ZW1wbGF0ZSI6IiIsIm5nZ190cmlnZ2Vyc19kaXNwbGF5IjoibmV2ZXIiLCJfZXJyb3JzIjpbXX0=");
INSERT INTO `st_postmeta` VALUES("1755","2264","default_source","albums");
INSERT INTO `st_postmeta` VALUES("1756","2264","view_order","10210");
INSERT INTO `st_postmeta` VALUES("1757","2264","name","photocrati-nextgen_basic_extended_album");
INSERT INTO `st_postmeta` VALUES("1764","2264","id_field","ID");
INSERT INTO `st_postmeta` VALUES("1763","2264","aliases","WyJiYXNpY19leHRlbmRlZF9hbGJ1bSIsIm5leHRnZW5fYmFzaWNfZXh0ZW5kZWRfYWxidW0iLCJleHRlbmRlZF9hbGJ1bSJd");
INSERT INTO `st_postmeta` VALUES("1760","2264","hidden_from_igw","");
INSERT INTO `st_postmeta` VALUES("1761","2264","__defaults_set","1");
INSERT INTO `st_postmeta` VALUES("1762","2264","entity_types","WyJhbGJ1bSIsImdhbGxlcnkiXQ==");
INSERT INTO `st_postmeta` VALUES("1759","2264","hidden_from_ui","");
INSERT INTO `st_postmeta` VALUES("1758","2264","installed_at_version","3.0.16");
INSERT INTO `st_postmeta` VALUES("803","2265","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("804","2265","_wp_trash_meta_time","1542103667");
INSERT INTO `st_postmeta` VALUES("805","2265","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("806","2206","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1719;s:6:\"height\";i:1600;s:4:\"file\";s:39:\"2015/03/home_webdesign_slide4_cover.png\";s:5:\"sizes\";a:21:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide4_cover-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide4_cover-300x279.png\";s:5:\"width\";i:300;s:6:\"height\";i:279;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide4_cover-768x715.png\";s:5:\"width\";i:768;s:6:\"height\";i:715;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide4_cover-1024x953.png\";s:5:\"width\";i:1024;s:6:\"height\";i:953;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide4_cover-157x146.png\";s:5:\"width\";i:157;s:6:\"height\";i:146;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:37:\"home_webdesign_slide4_cover-50x47.png\";s:5:\"width\";i:50;s:6:\"height\";i:47;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"portfolio-mf\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide4_cover-960x750.png\";s:5:\"width\";i:960;s:6:\"height\";i:750;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide4_cover-960x375.png\";s:5:\"width\";i:960;s:6:\"height\";i:375;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"portfolio-mf-t\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide4_cover-480x750.png\";s:5:\"width\";i:480;s:6:\"height\";i:750;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"portfolio-list\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide4_cover-1160x450.png\";s:5:\"width\";i:1160;s:6:\"height\";i:450;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"blog-single\";a:4:{s:4:\"file\";s:40:\"home_webdesign_slide4_cover-1200x480.png\";s:5:\"width\";i:1200;s:6:\"height\";i:480;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:37:\"home_webdesign_slide4_cover-80x80.png\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:37:\"home_webdesign_slide4_cover-81x75.png\";s:5:\"width\";i:81;s:6:\"height\";i:75;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"slider-content\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide4_cover-890x470.png\";s:5:\"width\";i:890;s:6:\"height\";i:470;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:37:\"home_webdesign_slide4_cover-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide4_cover-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide4_cover-600x558.png\";s:5:\"width\";i:600;s:6:\"height\";i:558;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide4_cover-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:39:\"home_webdesign_slide4_cover-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide4_cover-600x558.png\";s:5:\"width\";i:600;s:6:\"height\";i:558;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:39:\"home_webdesign_slide4_cover-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("807","2266","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("808","2266","_wp_trash_meta_time","1542104034");
INSERT INTO `st_postmeta` VALUES("809","2266","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("810","2267","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("811","2267","_wp_trash_meta_time","1542104172");
INSERT INTO `st_postmeta` VALUES("812","2267","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("813","2268","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("814","2268","_wp_trash_meta_time","1542104214");
INSERT INTO `st_postmeta` VALUES("815","2268","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("816","2269","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("817","2269","_wp_trash_meta_time","1542104626");
INSERT INTO `st_postmeta` VALUES("818","2269","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("819","2270","_edit_lock","1542104760:1");
INSERT INTO `st_postmeta` VALUES("820","2270","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("821","2270","_wp_trash_meta_time","1542104780");
INSERT INTO `st_postmeta` VALUES("822","2270","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("823","2271","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("824","2271","_wp_trash_meta_time","1542104812");
INSERT INTO `st_postmeta` VALUES("825","2271","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("826","2272","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("827","2272","_wp_trash_meta_time","1542104840");
INSERT INTO `st_postmeta` VALUES("828","2272","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("829","2273","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("830","2273","_wp_trash_meta_time","1542105187");
INSERT INTO `st_postmeta` VALUES("831","2273","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("832","2274","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("833","2274","_wp_trash_meta_time","1542105311");
INSERT INTO `st_postmeta` VALUES("834","2274","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("835","2275","_wp_attached_file","2018/11/1-1.jpg");
INSERT INTO `st_postmeta` VALUES("836","2275","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:1200;s:4:\"file\";s:15:\"2018/11/1-1.jpg\";s:5:\"sizes\";a:21:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"1-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:15:\"1-1-300x188.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:188;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:15:\"1-1-768x480.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:16:\"1-1-1024x640.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:640;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:15:\"1-1-234x146.jpg\";s:5:\"width\";i:234;s:6:\"height\";i:146;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:13:\"1-1-50x31.jpg\";s:5:\"width\";i:50;s:6:\"height\";i:31;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"portfolio-mf\";a:4:{s:4:\"file\";s:15:\"1-1-960x750.jpg\";s:5:\"width\";i:960;s:6:\"height\";i:750;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:15:\"1-1-960x375.jpg\";s:5:\"width\";i:960;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-t\";a:4:{s:4:\"file\";s:15:\"1-1-480x750.jpg\";s:5:\"width\";i:480;s:6:\"height\";i:750;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-list\";a:4:{s:4:\"file\";s:16:\"1-1-1160x450.jpg\";s:5:\"width\";i:1160;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-single\";a:4:{s:4:\"file\";s:16:\"1-1-1200x480.jpg\";s:5:\"width\";i:1200;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:13:\"1-1-80x80.jpg\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:14:\"1-1-120x75.jpg\";s:5:\"width\";i:120;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"slider-content\";a:4:{s:4:\"file\";s:15:\"1-1-890x470.jpg\";s:5:\"width\";i:890;s:6:\"height\";i:470;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:13:\"1-1-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:15:\"1-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:15:\"1-1-600x375.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:15:\"1-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:15:\"1-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:15:\"1-1-600x375.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:15:\"1-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("837","2276","_wp_attached_file","2018/11/2-1.jpg");
INSERT INTO `st_postmeta` VALUES("838","2276","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:1200;s:4:\"file\";s:15:\"2018/11/2-1.jpg\";s:5:\"sizes\";a:21:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"2-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:15:\"2-1-300x188.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:188;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:15:\"2-1-768x480.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:16:\"2-1-1024x640.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:640;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:15:\"2-1-234x146.jpg\";s:5:\"width\";i:234;s:6:\"height\";i:146;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:13:\"2-1-50x31.jpg\";s:5:\"width\";i:50;s:6:\"height\";i:31;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"portfolio-mf\";a:4:{s:4:\"file\";s:15:\"2-1-960x750.jpg\";s:5:\"width\";i:960;s:6:\"height\";i:750;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:15:\"2-1-960x375.jpg\";s:5:\"width\";i:960;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-t\";a:4:{s:4:\"file\";s:15:\"2-1-480x750.jpg\";s:5:\"width\";i:480;s:6:\"height\";i:750;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-list\";a:4:{s:4:\"file\";s:16:\"2-1-1160x450.jpg\";s:5:\"width\";i:1160;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-single\";a:4:{s:4:\"file\";s:16:\"2-1-1200x480.jpg\";s:5:\"width\";i:1200;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:13:\"2-1-80x80.jpg\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:14:\"2-1-120x75.jpg\";s:5:\"width\";i:120;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"slider-content\";a:4:{s:4:\"file\";s:15:\"2-1-890x470.jpg\";s:5:\"width\";i:890;s:6:\"height\";i:470;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:13:\"2-1-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:15:\"2-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:15:\"2-1-600x375.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:15:\"2-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:15:\"2-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:15:\"2-1-600x375.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:15:\"2-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("839","2277","_wp_attached_file","2018/11/3.png");
INSERT INTO `st_postmeta` VALUES("840","2277","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:1200;s:4:\"file\";s:13:\"2018/11/3.png\";s:5:\"sizes\";a:21:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:13:\"3-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:13:\"3-300x188.png\";s:5:\"width\";i:300;s:6:\"height\";i:188;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:13:\"3-768x480.png\";s:5:\"width\";i:768;s:6:\"height\";i:480;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:14:\"3-1024x640.png\";s:5:\"width\";i:1024;s:6:\"height\";i:640;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:13:\"3-234x146.png\";s:5:\"width\";i:234;s:6:\"height\";i:146;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:11:\"3-50x31.png\";s:5:\"width\";i:50;s:6:\"height\";i:31;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"portfolio-mf\";a:4:{s:4:\"file\";s:13:\"3-960x750.png\";s:5:\"width\";i:960;s:6:\"height\";i:750;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:13:\"3-960x375.png\";s:5:\"width\";i:960;s:6:\"height\";i:375;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"portfolio-mf-t\";a:4:{s:4:\"file\";s:13:\"3-480x750.png\";s:5:\"width\";i:480;s:6:\"height\";i:750;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"portfolio-list\";a:4:{s:4:\"file\";s:14:\"3-1160x450.png\";s:5:\"width\";i:1160;s:6:\"height\";i:450;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"blog-single\";a:4:{s:4:\"file\";s:14:\"3-1200x480.png\";s:5:\"width\";i:1200;s:6:\"height\";i:480;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:11:\"3-80x80.png\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:12:\"3-120x75.png\";s:5:\"width\";i:120;s:6:\"height\";i:75;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"slider-content\";a:4:{s:4:\"file\";s:13:\"3-890x470.png\";s:5:\"width\";i:890;s:6:\"height\";i:470;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:11:\"3-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:13:\"3-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:13:\"3-600x375.png\";s:5:\"width\";i:600;s:6:\"height\";i:375;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:13:\"3-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:13:\"3-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:13:\"3-600x375.png\";s:5:\"width\";i:600;s:6:\"height\";i:375;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:13:\"3-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("841","2278","_wp_attached_file","2018/11/4-1.jpg");
INSERT INTO `st_postmeta` VALUES("842","2278","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:1200;s:4:\"file\";s:15:\"2018/11/4-1.jpg\";s:5:\"sizes\";a:21:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"4-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:15:\"4-1-300x188.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:188;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:15:\"4-1-768x480.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:16:\"4-1-1024x640.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:640;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:15:\"4-1-234x146.jpg\";s:5:\"width\";i:234;s:6:\"height\";i:146;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:13:\"4-1-50x31.jpg\";s:5:\"width\";i:50;s:6:\"height\";i:31;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"portfolio-mf\";a:4:{s:4:\"file\";s:15:\"4-1-960x750.jpg\";s:5:\"width\";i:960;s:6:\"height\";i:750;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:15:\"4-1-960x375.jpg\";s:5:\"width\";i:960;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-t\";a:4:{s:4:\"file\";s:15:\"4-1-480x750.jpg\";s:5:\"width\";i:480;s:6:\"height\";i:750;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-list\";a:4:{s:4:\"file\";s:16:\"4-1-1160x450.jpg\";s:5:\"width\";i:1160;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-single\";a:4:{s:4:\"file\";s:16:\"4-1-1200x480.jpg\";s:5:\"width\";i:1200;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:13:\"4-1-80x80.jpg\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:14:\"4-1-120x75.jpg\";s:5:\"width\";i:120;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"slider-content\";a:4:{s:4:\"file\";s:15:\"4-1-890x470.jpg\";s:5:\"width\";i:890;s:6:\"height\";i:470;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:13:\"4-1-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:15:\"4-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:15:\"4-1-600x375.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:15:\"4-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:15:\"4-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:15:\"4-1-600x375.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:15:\"4-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("843","2279","_wp_attached_file","2018/11/5-1.jpg");
INSERT INTO `st_postmeta` VALUES("844","2279","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:1200;s:4:\"file\";s:15:\"2018/11/5-1.jpg\";s:5:\"sizes\";a:21:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"5-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:15:\"5-1-300x188.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:188;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:15:\"5-1-768x480.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:16:\"5-1-1024x640.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:640;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:15:\"5-1-234x146.jpg\";s:5:\"width\";i:234;s:6:\"height\";i:146;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:13:\"5-1-50x31.jpg\";s:5:\"width\";i:50;s:6:\"height\";i:31;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"portfolio-mf\";a:4:{s:4:\"file\";s:15:\"5-1-960x750.jpg\";s:5:\"width\";i:960;s:6:\"height\";i:750;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:15:\"5-1-960x375.jpg\";s:5:\"width\";i:960;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-t\";a:4:{s:4:\"file\";s:15:\"5-1-480x750.jpg\";s:5:\"width\";i:480;s:6:\"height\";i:750;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-list\";a:4:{s:4:\"file\";s:16:\"5-1-1160x450.jpg\";s:5:\"width\";i:1160;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-single\";a:4:{s:4:\"file\";s:16:\"5-1-1200x480.jpg\";s:5:\"width\";i:1200;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:13:\"5-1-80x80.jpg\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:14:\"5-1-120x75.jpg\";s:5:\"width\";i:120;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"slider-content\";a:4:{s:4:\"file\";s:15:\"5-1-890x470.jpg\";s:5:\"width\";i:890;s:6:\"height\";i:470;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:13:\"5-1-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:15:\"5-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:15:\"5-1-600x375.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:15:\"5-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:15:\"5-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:15:\"5-1-600x375.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:15:\"5-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("845","28","_yoast_wpseo_content_score","90");
INSERT INTO `st_postmeta` VALUES("846","27","_wp_page_template","default");
INSERT INTO `st_postmeta` VALUES("847","27","_wpb_vc_js_status","false");
INSERT INTO `st_postmeta` VALUES("848","27","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("849","27","slide_template","default");
INSERT INTO `st_postmeta` VALUES("850","27","mfn-post-hide-content","0");
INSERT INTO `st_postmeta` VALUES("851","27","mfn-post-custom-layout","0");
INSERT INTO `st_postmeta` VALUES("852","27","mfn-post-slider","0");
INSERT INTO `st_postmeta` VALUES("853","27","mfn-post-slider-layer","0");
INSERT INTO `st_postmeta` VALUES("854","27","mfn-post-menu","0");
INSERT INTO `st_postmeta` VALUES("855","27","mfn-post-one-page","0");
INSERT INTO `st_postmeta` VALUES("856","27","mfn-post-hide-title","0");
INSERT INTO `st_postmeta` VALUES("857","27","mfn-post-remove-padding","0");
INSERT INTO `st_postmeta` VALUES("858","27","_yoast_wpseo_content_score","90");
INSERT INTO `st_postmeta` VALUES("871","105","_edit_lock","1542119432:1");
INSERT INTO `st_postmeta` VALUES("861","1","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("862","1","_wp_old_date","2018-11-10");
INSERT INTO `st_postmeta` VALUES("863","1","slide_template","default");
INSERT INTO `st_postmeta` VALUES("864","1","_yoast_wpseo_primary_category","");
INSERT INTO `st_postmeta` VALUES("865","1","mfn-post-hide-content","0");
INSERT INTO `st_postmeta` VALUES("866","1","mfn-post-slider","0");
INSERT INTO `st_postmeta` VALUES("867","1","mfn-post-slider-layer","0");
INSERT INTO `st_postmeta` VALUES("868","1","mfn-post-hide-title","0");
INSERT INTO `st_postmeta` VALUES("869","1","mfn-post-hide-image","0");
INSERT INTO `st_postmeta` VALUES("870","1","_yoast_wpseo_content_score","60");
INSERT INTO `st_postmeta` VALUES("872","105","_edit_last","1");
INSERT INTO `st_postmeta` VALUES("899","2285","_wp_attached_file","2018/11/What-is-a-Blog.mp4");
INSERT INTO `st_postmeta` VALUES("875","105","slide_template","default");
INSERT INTO `st_postmeta` VALUES("876","105","mfn-post-hide-content","0");
INSERT INTO `st_postmeta` VALUES("877","105","mfn-post-slider","0");
INSERT INTO `st_postmeta` VALUES("878","105","mfn-post-slider-layer","0");
INSERT INTO `st_postmeta` VALUES("879","105","mfn-post-hide-title","0");
INSERT INTO `st_postmeta` VALUES("880","105","mfn-post-hide-image","0");
INSERT INTO `st_postmeta` VALUES("881","105","_yoast_wpseo_content_score","90");
INSERT INTO `st_postmeta` VALUES("882","105","_wp_old_date","2015-03-10");
INSERT INTO `st_postmeta` VALUES("883","105","_yoast_wpseo_primary_category","");
INSERT INTO `st_postmeta` VALUES("896","87","_wp_old_date","2018-11-10");
INSERT INTO `st_postmeta` VALUES("886","83","_wp_old_date","2018-11-10");
INSERT INTO `st_postmeta` VALUES("887","83","_yoast_wpseo_primary_category","");
INSERT INTO `st_postmeta` VALUES("888","83","_yoast_wpseo_content_score","60");
INSERT INTO `st_postmeta` VALUES("900","2285","_wp_attachment_metadata","a:10:{s:8:\"filesize\";i:13164392;s:9:\"mime_type\";s:9:\"video/mp4\";s:6:\"length\";i:221;s:16:\"length_formatted\";s:4:\"3:41\";s:5:\"width\";i:1280;s:6:\"height\";i:720;s:10:\"fileformat\";s:3:\"mp4\";s:10:\"dataformat\";s:9:\"quicktime\";s:5:\"audio\";a:7:{s:10:\"dataformat\";s:3:\"mp4\";s:5:\"codec\";s:19:\"ISO/IEC 14496-3 AAC\";s:11:\"sample_rate\";d:44100;s:8:\"channels\";i:2;s:15:\"bits_per_sample\";i:16;s:8:\"lossless\";b:0;s:11:\"channelmode\";s:6:\"stereo\";}s:17:\"created_timestamp\";i:1540879922;}");
INSERT INTO `st_postmeta` VALUES("891","85","_wp_old_date","2018-11-10");
INSERT INTO `st_postmeta` VALUES("892","85","_yoast_wpseo_primary_category","");
INSERT INTO `st_postmeta` VALUES("893","85","_yoast_wpseo_content_score","60");
INSERT INTO `st_postmeta` VALUES("897","87","_yoast_wpseo_primary_category","");
INSERT INTO `st_postmeta` VALUES("898","87","_yoast_wpseo_content_score","60");
INSERT INTO `st_postmeta` VALUES("901","106","_yoast_wpseo_content_score","30");
INSERT INTO `st_postmeta` VALUES("902","2289","_wp_attached_file","2018/11/stan-lee-marvel-comics-comicbookcom-1070074-1280x0.jpeg");
INSERT INTO `st_postmeta` VALUES("903","2289","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1280;s:6:\"height\";i:705;s:4:\"file\";s:63:\"2018/11/stan-lee-marvel-comics-comicbookcom-1070074-1280x0.jpeg\";s:5:\"sizes\";a:21:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:63:\"stan-lee-marvel-comics-comicbookcom-1070074-1280x0-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:63:\"stan-lee-marvel-comics-comicbookcom-1070074-1280x0-300x165.jpeg\";s:5:\"width\";i:300;s:6:\"height\";i:165;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:63:\"stan-lee-marvel-comics-comicbookcom-1070074-1280x0-768x423.jpeg\";s:5:\"width\";i:768;s:6:\"height\";i:423;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:64:\"stan-lee-marvel-comics-comicbookcom-1070074-1280x0-1024x564.jpeg\";s:5:\"width\";i:1024;s:6:\"height\";i:564;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:63:\"stan-lee-marvel-comics-comicbookcom-1070074-1280x0-260x143.jpeg\";s:5:\"width\";i:260;s:6:\"height\";i:143;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:61:\"stan-lee-marvel-comics-comicbookcom-1070074-1280x0-50x28.jpeg\";s:5:\"width\";i:50;s:6:\"height\";i:28;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"portfolio-mf\";a:4:{s:4:\"file\";s:63:\"stan-lee-marvel-comics-comicbookcom-1070074-1280x0-960x705.jpeg\";s:5:\"width\";i:960;s:6:\"height\";i:705;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:63:\"stan-lee-marvel-comics-comicbookcom-1070074-1280x0-960x375.jpeg\";s:5:\"width\";i:960;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-t\";a:4:{s:4:\"file\";s:63:\"stan-lee-marvel-comics-comicbookcom-1070074-1280x0-480x705.jpeg\";s:5:\"width\";i:480;s:6:\"height\";i:705;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-list\";a:4:{s:4:\"file\";s:64:\"stan-lee-marvel-comics-comicbookcom-1070074-1280x0-1160x450.jpeg\";s:5:\"width\";i:1160;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"blog-single\";a:4:{s:4:\"file\";s:64:\"stan-lee-marvel-comics-comicbookcom-1070074-1280x0-1200x480.jpeg\";s:5:\"width\";i:1200;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:61:\"stan-lee-marvel-comics-comicbookcom-1070074-1280x0-80x80.jpeg\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:62:\"stan-lee-marvel-comics-comicbookcom-1070074-1280x0-136x75.jpeg\";s:5:\"width\";i:136;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"slider-content\";a:4:{s:4:\"file\";s:63:\"stan-lee-marvel-comics-comicbookcom-1070074-1280x0-890x470.jpeg\";s:5:\"width\";i:890;s:6:\"height\";i:470;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:61:\"stan-lee-marvel-comics-comicbookcom-1070074-1280x0-85x85.jpeg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:63:\"stan-lee-marvel-comics-comicbookcom-1070074-1280x0-300x300.jpeg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:63:\"stan-lee-marvel-comics-comicbookcom-1070074-1280x0-600x330.jpeg\";s:5:\"width\";i:600;s:6:\"height\";i:330;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:63:\"stan-lee-marvel-comics-comicbookcom-1070074-1280x0-100x100.jpeg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:63:\"stan-lee-marvel-comics-comicbookcom-1070074-1280x0-300x300.jpeg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:63:\"stan-lee-marvel-comics-comicbookcom-1070074-1280x0-600x330.jpeg\";s:5:\"width\";i:600;s:6:\"height\";i:330;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:63:\"stan-lee-marvel-comics-comicbookcom-1070074-1280x0-100x100.jpeg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("904","2290","_edit_last","1");
INSERT INTO `st_postmeta` VALUES("924","26","_wpb_vc_js_status","false");
INSERT INTO `st_postmeta` VALUES("920","2290","mfn-post-love","0");
INSERT INTO `st_postmeta` VALUES("907","2290","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("908","2290","slide_template","default");
INSERT INTO `st_postmeta` VALUES("909","2290","mfn-page-items","YToxOntpOjA7YToyOntzOjQ6ImF0dHIiO2E6MTY6e3M6NToidGl0bGUiO3M6MDoiIjtzOjg6ImJnX2NvbG9yIjtzOjA6IiI7czo4OiJiZ19pbWFnZSI7czowOiIiO3M6MTE6ImJnX3Bvc2l0aW9uIjtzOjIyOiJuby1yZXBlYXQ7Y2VudGVyIHRvcDs7IjtzOjEyOiJiZ192aWRlb19tcDQiO3M6MDoiIjtzOjEyOiJiZ192aWRlb19vZ3YiO3M6MDoiIjtzOjEzOiJjb2x1bW5fbWFyZ2luIjtzOjA6IiI7czoxMToicGFkZGluZ190b3AiO3M6MToiMCI7czoxNDoicGFkZGluZ19ib3R0b20iO3M6MToiMCI7czo3OiJkaXZpZGVyIjtzOjA6IiI7czo2OiJsYXlvdXQiO3M6MTA6Im5vLXNpZGViYXIiO3M6MTA6Im5hdmlnYXRpb24iO3M6MDoiIjtzOjU6InN0eWxlIjtzOjA6IiI7czo1OiJjbGFzcyI7czowOiIiO3M6MTA6InNlY3Rpb25faWQiO3M6MDoiIjtzOjEwOiJ2aXNpYmlsaXR5IjtzOjA6IiI7fXM6NToiaXRlbXMiO3M6MDoiIjt9fQ==");
INSERT INTO `st_postmeta` VALUES("910","2290","mfn-page-items-seo","");
INSERT INTO `st_postmeta` VALUES("911","2290","mfn-post-hide-content","0");
INSERT INTO `st_postmeta` VALUES("912","2290","mfn-post-layout","no-sidebar");
INSERT INTO `st_postmeta` VALUES("913","2290","mfn-post-slider","0");
INSERT INTO `st_postmeta` VALUES("914","2290","mfn-post-slider-layer","0");
INSERT INTO `st_postmeta` VALUES("915","2290","mfn-post-hide-title","0");
INSERT INTO `st_postmeta` VALUES("916","2290","mfn-post-hide-image","0");
INSERT INTO `st_postmeta` VALUES("917","2290","_yoast_wpseo_content_score","60");
INSERT INTO `st_postmeta` VALUES("918","2290","_yoast_wpseo_primary_category","37");
INSERT INTO `st_postmeta` VALUES("919","2290","_edit_lock","1542347207:1");
INSERT INTO `st_postmeta` VALUES("923","26","_wp_page_template","default");
INSERT INTO `st_postmeta` VALUES("925","26","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("926","26","slide_template","default");
INSERT INTO `st_postmeta` VALUES("927","26","mfn-post-hide-content","0");
INSERT INTO `st_postmeta` VALUES("928","26","mfn-post-custom-layout","0");
INSERT INTO `st_postmeta` VALUES("929","26","mfn-post-slider","0");
INSERT INTO `st_postmeta` VALUES("930","26","mfn-post-slider-layer","0");
INSERT INTO `st_postmeta` VALUES("931","26","mfn-post-menu","0");
INSERT INTO `st_postmeta` VALUES("932","26","mfn-post-one-page","0");
INSERT INTO `st_postmeta` VALUES("933","26","mfn-post-hide-title","0");
INSERT INTO `st_postmeta` VALUES("934","26","mfn-post-remove-padding","0");
INSERT INTO `st_postmeta` VALUES("935","26","_yoast_wpseo_content_score","60");
INSERT INTO `st_postmeta` VALUES("967","108","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("966","108","_wp_desired_post_slug","what-we-offer");
INSERT INTO `st_postmeta` VALUES("941","110","_edit_lock","1542139258:1");
INSERT INTO `st_postmeta` VALUES("942","28","mfn-page-items","YToxOntpOjA7YToyOntzOjQ6ImF0dHIiO2E6MTY6e3M6NToidGl0bGUiO3M6MDoiIjtzOjg6ImJnX2NvbG9yIjtzOjA6IiI7czo4OiJiZ19pbWFnZSI7czowOiIiO3M6MTE6ImJnX3Bvc2l0aW9uIjtzOjIyOiJuby1yZXBlYXQ7Y2VudGVyIHRvcDs7IjtzOjEyOiJiZ192aWRlb19tcDQiO3M6MDoiIjtzOjEyOiJiZ192aWRlb19vZ3YiO3M6MDoiIjtzOjEzOiJjb2x1bW5fbWFyZ2luIjtzOjA6IiI7czoxMToicGFkZGluZ190b3AiO3M6MToiMCI7czoxNDoicGFkZGluZ19ib3R0b20iO3M6MToiMCI7czo3OiJkaXZpZGVyIjtzOjA6IiI7czo2OiJsYXlvdXQiO3M6MTA6Im5vLXNpZGViYXIiO3M6MTA6Im5hdmlnYXRpb24iO3M6MDoiIjtzOjU6InN0eWxlIjtzOjA6IiI7czo1OiJjbGFzcyI7czowOiIiO3M6MTA6InNlY3Rpb25faWQiO3M6MDoiIjtzOjEwOiJ2aXNpYmlsaXR5IjtzOjA6IiI7fXM6NToiaXRlbXMiO3M6MDoiIjt9fQ==");
INSERT INTO `st_postmeta` VALUES("943","28","mfn-page-items-seo","");
INSERT INTO `st_postmeta` VALUES("944","28","mfn-post-layout","no-sidebar");
INSERT INTO `st_postmeta` VALUES("945","110","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("946","110","_wp_trash_meta_time","1542139416");
INSERT INTO `st_postmeta` VALUES("947","110","_wp_desired_post_slug","contact-us");
INSERT INTO `st_postmeta` VALUES("948","110","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("949","111","_edit_lock","1542139392:1");
INSERT INTO `st_postmeta` VALUES("950","108","_edit_lock","1542139394:1");
INSERT INTO `st_postmeta` VALUES("951","26","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("952","26","_wp_trash_meta_time","1542139439");
INSERT INTO `st_postmeta` VALUES("953","26","_wp_desired_post_slug","%d8%ae%d8%a7%d9%86%d9%87");
INSERT INTO `st_postmeta` VALUES("954","30","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("955","30","_wp_trash_meta_time","1542139446");
INSERT INTO `st_postmeta` VALUES("956","30","_wp_desired_post_slug","%db%8c%da%a9-%d8%a8%d8%ae%d8%b4-%d8%b5%d9%81%d8%ad%d9%87-%d8%ae%d8%a7%d9%86%da%af%db%8c");
INSERT INTO `st_postmeta` VALUES("957","30","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("958","111","_yoast_wpseo_content_score","30");
INSERT INTO `st_postmeta` VALUES("1128","2340","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("1129","2340","_wp_trash_meta_time","1542150882");
INSERT INTO `st_postmeta` VALUES("1126","2339","_wp_trash_meta_time","1542150854");
INSERT INTO `st_postmeta` VALUES("1083","29","slide_template","default");
INSERT INTO `st_postmeta` VALUES("1084","29","mfn-post-hide-content","0");
INSERT INTO `st_postmeta` VALUES("1085","29","mfn-post-custom-layout","0");
INSERT INTO `st_postmeta` VALUES("1086","29","mfn-post-slider","0");
INSERT INTO `st_postmeta` VALUES("1087","29","mfn-post-slider-layer","0");
INSERT INTO `st_postmeta` VALUES("1088","29","mfn-post-menu","0");
INSERT INTO `st_postmeta` VALUES("1089","29","mfn-post-one-page","0");
INSERT INTO `st_postmeta` VALUES("1090","29","mfn-post-hide-title","0");
INSERT INTO `st_postmeta` VALUES("1091","29","mfn-post-remove-padding","0");
INSERT INTO `st_postmeta` VALUES("1092","29","_yoast_wpseo_content_score","30");
INSERT INTO `st_postmeta` VALUES("1095","2331","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("1096","2332","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("1097","2332","_wp_trash_meta_time","1542150414");
INSERT INTO `st_postmeta` VALUES("1098","2332","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("1102","2334","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("1100","2333","_customize_changeset_uuid","15f03124-8b0f-4da3-b7e2-2db334789757");
INSERT INTO `st_postmeta` VALUES("1101","2333","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("1103","2334","_wp_trash_meta_time","1542150610");
INSERT INTO `st_postmeta` VALUES("1104","2334","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("1105","2336","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("1106","2336","_wp_trash_meta_time","1542150653");
INSERT INTO `st_postmeta` VALUES("1107","2336","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("1108","2337","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("1109","2337","_wp_trash_meta_time","1542150671");
INSERT INTO `st_postmeta` VALUES("1110","2337","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("1111","2333","_edit_lock","1542151026:1");
INSERT INTO `st_postmeta` VALUES("1112","2333","_edit_last","1");
INSERT INTO `st_postmeta` VALUES("1113","2333","_wp_page_template","default");
INSERT INTO `st_postmeta` VALUES("1114","2333","_wpb_vc_js_status","false");
INSERT INTO `st_postmeta` VALUES("1115","2333","slide_template","default");
INSERT INTO `st_postmeta` VALUES("1116","2333","mfn-post-hide-content","0");
INSERT INTO `st_postmeta` VALUES("1117","2333","mfn-post-custom-layout","0");
INSERT INTO `st_postmeta` VALUES("1118","2333","mfn-post-slider","0");
INSERT INTO `st_postmeta` VALUES("1119","2333","mfn-post-slider-layer","0");
INSERT INTO `st_postmeta` VALUES("1120","2333","mfn-post-menu","0");
INSERT INTO `st_postmeta` VALUES("1121","2333","mfn-post-one-page","0");
INSERT INTO `st_postmeta` VALUES("1122","2333","mfn-post-hide-title","0");
INSERT INTO `st_postmeta` VALUES("1123","2333","mfn-post-remove-padding","0");
INSERT INTO `st_postmeta` VALUES("1124","2333","_yoast_wpseo_content_score","30");
INSERT INTO `st_postmeta` VALUES("1125","2339","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("1001","2311","_wp_attached_file","2018/11/wp.jpg");
INSERT INTO `st_postmeta` VALUES("1002","2311","_wp_attachment_metadata","a:5:{s:5:\"width\";i:698;s:6:\"height\";i:400;s:4:\"file\";s:14:\"2018/11/wp.jpg\";s:5:\"sizes\";a:15:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"wp-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"wp-300x172.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:172;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:14:\"wp-255x146.jpg\";s:5:\"width\";i:255;s:6:\"height\";i:146;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:12:\"wp-50x29.jpg\";s:5:\"width\";i:50;s:6:\"height\";i:29;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:14:\"wp-698x375.jpg\";s:5:\"width\";i:698;s:6:\"height\";i:375;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"portfolio-mf-t\";a:4:{s:4:\"file\";s:14:\"wp-480x400.jpg\";s:5:\"width\";i:480;s:6:\"height\";i:400;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:12:\"wp-80x80.jpg\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:13:\"wp-131x75.jpg\";s:5:\"width\";i:131;s:6:\"height\";i:75;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:12:\"wp-85x85.jpg\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:14:\"wp-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:14:\"wp-600x344.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:344;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:14:\"wp-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:14:\"wp-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:14:\"wp-600x344.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:344;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:14:\"wp-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("1003","2312","_wp_attached_file","2018/11/store-1.png");
INSERT INTO `st_postmeta` VALUES("1004","2312","_wp_attachment_metadata","a:5:{s:5:\"width\";i:834;s:6:\"height\";i:521;s:4:\"file\";s:19:\"2018/11/store-1.png\";s:5:\"sizes\";a:19:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"store-1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"store-1-300x187.png\";s:5:\"width\";i:300;s:6:\"height\";i:187;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"store-1-768x480.png\";s:5:\"width\";i:768;s:6:\"height\";i:480;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:19:\"store-1-234x146.png\";s:5:\"width\";i:234;s:6:\"height\";i:146;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"50x50\";a:4:{s:4:\"file\";s:17:\"store-1-50x31.png\";s:5:\"width\";i:50;s:6:\"height\";i:31;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"portfolio-mf-w\";a:4:{s:4:\"file\";s:19:\"store-1-834x375.png\";s:5:\"width\";i:834;s:6:\"height\";i:375;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"portfolio-mf-t\";a:4:{s:4:\"file\";s:19:\"store-1-480x521.png\";s:5:\"width\";i:480;s:6:\"height\";i:521;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"portfolio-list\";a:4:{s:4:\"file\";s:19:\"store-1-834x450.png\";s:5:\"width\";i:834;s:6:\"height\";i:450;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"blog-single\";a:4:{s:4:\"file\";s:19:\"store-1-834x480.png\";s:5:\"width\";i:834;s:6:\"height\";i:480;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"blog-navi\";a:4:{s:4:\"file\";s:17:\"store-1-80x80.png\";s:5:\"width\";i:80;s:6:\"height\";i:80;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"clients-slider\";a:4:{s:4:\"file\";s:18:\"store-1-120x75.png\";s:5:\"width\";i:120;s:6:\"height\";i:75;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"slider-content\";a:4:{s:4:\"file\";s:19:\"store-1-834x470.png\";s:5:\"width\";i:834;s:6:\"height\";i:470;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"testimonials\";a:4:{s:4:\"file\";s:17:\"store-1-85x85.png\";s:5:\"width\";i:85;s:6:\"height\";i:85;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:19:\"store-1-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:19:\"store-1-600x375.png\";s:5:\"width\";i:600;s:6:\"height\";i:375;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:19:\"store-1-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:19:\"store-1-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:19:\"store-1-600x375.png\";s:5:\"width\";i:600;s:6:\"height\";i:375;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:19:\"store-1-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `st_postmeta` VALUES("1005","2313","_edit_last","1");
INSERT INTO `st_postmeta` VALUES("1006","2313","_edit_lock","1542145675:1");
INSERT INTO `st_postmeta` VALUES("1008","2313","_wp_page_template","default");
INSERT INTO `st_postmeta` VALUES("1009","2313","_wpb_vc_js_status","false");
INSERT INTO `st_postmeta` VALUES("1010","2313","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("1011","2313","slide_template","default");
INSERT INTO `st_postmeta` VALUES("1012","2313","mfn-post-hide-content","0");
INSERT INTO `st_postmeta` VALUES("1013","2313","mfn-post-custom-layout","0");
INSERT INTO `st_postmeta` VALUES("1014","2313","mfn-post-slider","0");
INSERT INTO `st_postmeta` VALUES("1015","2313","mfn-post-slider-layer","0");
INSERT INTO `st_postmeta` VALUES("1016","2313","mfn-post-menu","0");
INSERT INTO `st_postmeta` VALUES("1017","2313","mfn-post-one-page","0");
INSERT INTO `st_postmeta` VALUES("1018","2313","mfn-post-hide-title","0");
INSERT INTO `st_postmeta` VALUES("1019","2313","mfn-post-remove-padding","0");
INSERT INTO `st_postmeta` VALUES("1020","2313","_yoast_wpseo_content_score","60");
INSERT INTO `st_postmeta` VALUES("1094","2331","_wp_trash_meta_time","1542150345");
INSERT INTO `st_postmeta` VALUES("1021","2315","_edit_last","1");
INSERT INTO `st_postmeta` VALUES("1022","2315","_edit_lock","1542145571:1");
INSERT INTO `st_postmeta` VALUES("1023","2315","_wp_page_template","default");
INSERT INTO `st_postmeta` VALUES("1024","2315","_wpb_vc_js_status","false");
INSERT INTO `st_postmeta` VALUES("1025","2315","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("1026","2315","slide_template","default");
INSERT INTO `st_postmeta` VALUES("1027","2315","mfn-post-hide-content","0");
INSERT INTO `st_postmeta` VALUES("1028","2315","mfn-post-custom-layout","0");
INSERT INTO `st_postmeta` VALUES("1029","2315","mfn-post-slider","0");
INSERT INTO `st_postmeta` VALUES("1030","2315","mfn-post-slider-layer","0");
INSERT INTO `st_postmeta` VALUES("1031","2315","mfn-post-menu","0");
INSERT INTO `st_postmeta` VALUES("1032","2315","mfn-post-one-page","0");
INSERT INTO `st_postmeta` VALUES("1033","2315","mfn-post-hide-title","0");
INSERT INTO `st_postmeta` VALUES("1034","2315","mfn-post-remove-padding","0");
INSERT INTO `st_postmeta` VALUES("1035","2315","_yoast_wpseo_content_score","60");
INSERT INTO `st_postmeta` VALUES("1132","2341","_wp_trash_meta_time","1542150916");
INSERT INTO `st_postmeta` VALUES("1133","2341","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("1036","2317","_edit_last","1");
INSERT INTO `st_postmeta` VALUES("1037","2317","_edit_lock","1542148507:1");
INSERT INTO `st_postmeta` VALUES("1038","2317","_wp_page_template","default");
INSERT INTO `st_postmeta` VALUES("1039","2317","_wpb_vc_js_status","false");
INSERT INTO `st_postmeta` VALUES("1040","2317","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("1041","2317","slide_template","default");
INSERT INTO `st_postmeta` VALUES("1042","2317","mfn-post-hide-content","0");
INSERT INTO `st_postmeta` VALUES("1043","2317","mfn-post-custom-layout","0");
INSERT INTO `st_postmeta` VALUES("1044","2317","mfn-post-slider","0");
INSERT INTO `st_postmeta` VALUES("1045","2317","mfn-post-slider-layer","0");
INSERT INTO `st_postmeta` VALUES("1046","2317","mfn-post-menu","0");
INSERT INTO `st_postmeta` VALUES("1047","2317","mfn-post-one-page","0");
INSERT INTO `st_postmeta` VALUES("1048","2317","mfn-post-hide-title","0");
INSERT INTO `st_postmeta` VALUES("1049","2317","mfn-post-remove-padding","0");
INSERT INTO `st_postmeta` VALUES("1050","2317","_yoast_wpseo_content_score","60");
INSERT INTO `st_postmeta` VALUES("1051","2319","_edit_last","1");
INSERT INTO `st_postmeta` VALUES("1052","2319","_wp_page_template","default");
INSERT INTO `st_postmeta` VALUES("1053","2319","_wpb_vc_js_status","false");
INSERT INTO `st_postmeta` VALUES("1054","2319","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("1055","2319","slide_template","default");
INSERT INTO `st_postmeta` VALUES("1056","2319","mfn-post-hide-content","0");
INSERT INTO `st_postmeta` VALUES("1057","2319","mfn-post-custom-layout","0");
INSERT INTO `st_postmeta` VALUES("1058","2319","mfn-post-slider","0");
INSERT INTO `st_postmeta` VALUES("1059","2319","mfn-post-slider-layer","0");
INSERT INTO `st_postmeta` VALUES("1060","2319","mfn-post-menu","0");
INSERT INTO `st_postmeta` VALUES("1061","2319","mfn-post-one-page","0");
INSERT INTO `st_postmeta` VALUES("1062","2319","mfn-post-hide-title","0");
INSERT INTO `st_postmeta` VALUES("1063","2319","mfn-post-remove-padding","0");
INSERT INTO `st_postmeta` VALUES("1064","2319","_yoast_wpseo_content_score","60");
INSERT INTO `st_postmeta` VALUES("1065","2319","_edit_lock","1542145229:1");
INSERT INTO `st_postmeta` VALUES("1131","2341","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("1130","2340","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("1066","2323","_edit_last","1");
INSERT INTO `st_postmeta` VALUES("1067","2323","_edit_lock","1542145541:1");
INSERT INTO `st_postmeta` VALUES("1068","2323","_wp_page_template","default");
INSERT INTO `st_postmeta` VALUES("1069","2323","_wpb_vc_js_status","false");
INSERT INTO `st_postmeta` VALUES("1070","2323","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("1071","2323","slide_template","default");
INSERT INTO `st_postmeta` VALUES("1072","2323","mfn-post-hide-content","0");
INSERT INTO `st_postmeta` VALUES("1073","2323","mfn-post-custom-layout","0");
INSERT INTO `st_postmeta` VALUES("1074","2323","mfn-post-slider","0");
INSERT INTO `st_postmeta` VALUES("1075","2323","mfn-post-slider-layer","0");
INSERT INTO `st_postmeta` VALUES("1076","2323","mfn-post-menu","0");
INSERT INTO `st_postmeta` VALUES("1077","2323","mfn-post-one-page","0");
INSERT INTO `st_postmeta` VALUES("1078","2323","mfn-post-hide-title","0");
INSERT INTO `st_postmeta` VALUES("1079","2323","mfn-post-remove-padding","0");
INSERT INTO `st_postmeta` VALUES("1080","2323","_yoast_wpseo_content_score","60");
INSERT INTO `st_postmeta` VALUES("1138","2343","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("1135","2342","_customize_changeset_uuid","c2ba882a-6d44-4eb1-8757-a96bc1ff6886");
INSERT INTO `st_postmeta` VALUES("1136","2343","_edit_lock","1542151026:1");
INSERT INTO `st_postmeta` VALUES("1137","2342","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("1139","2343","_wp_trash_meta_time","1542151038");
INSERT INTO `st_postmeta` VALUES("1140","2343","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("1141","2342","_edit_lock","1542150976:1");
INSERT INTO `st_postmeta` VALUES("1142","2342","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("1143","2342","_wp_trash_meta_time","1542151142");
INSERT INTO `st_postmeta` VALUES("1144","2342","_wp_desired_post_slug","%d8%ae%d8%a7%d9%86%d9%87-2");
INSERT INTO `st_postmeta` VALUES("1145","2333","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("1146","2333","_wp_trash_meta_time","1542151168");
INSERT INTO `st_postmeta` VALUES("1147","2333","_wp_desired_post_slug","%d8%ae%d8%a7%d9%86%d9%87");
INSERT INTO `st_postmeta` VALUES("1148","2347","_wp_trash_meta_status","publish");
INSERT INTO `st_postmeta` VALUES("1149","2347","_wp_trash_meta_time","1542151243");
INSERT INTO `st_postmeta` VALUES("1150","2347","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("1151","2256","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("1152","2350","_edit_last","1");
INSERT INTO `st_postmeta` VALUES("1153","2350","_wp_page_template","default");
INSERT INTO `st_postmeta` VALUES("1154","2350","_wpb_vc_js_status","false");
INSERT INTO `st_postmeta` VALUES("1155","2350","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("1156","2350","slide_template","default");
INSERT INTO `st_postmeta` VALUES("1157","2350","mfn-post-hide-content","0");
INSERT INTO `st_postmeta` VALUES("1158","2350","mfn-post-custom-layout","0");
INSERT INTO `st_postmeta` VALUES("1159","2350","mfn-post-slider","0");
INSERT INTO `st_postmeta` VALUES("1160","2350","mfn-post-slider-layer","0");
INSERT INTO `st_postmeta` VALUES("1161","2350","mfn-post-menu","0");
INSERT INTO `st_postmeta` VALUES("1162","2350","mfn-post-one-page","0");
INSERT INTO `st_postmeta` VALUES("1163","2350","mfn-post-hide-title","0");
INSERT INTO `st_postmeta` VALUES("1164","2350","mfn-post-remove-padding","0");
INSERT INTO `st_postmeta` VALUES("1165","2350","_yoast_wpseo_content_score","30");
INSERT INTO `st_postmeta` VALUES("1166","2350","_edit_lock","1542186217:1");
INSERT INTO `st_postmeta` VALUES("1167","2352","_menu_item_type","post_type");
INSERT INTO `st_postmeta` VALUES("1168","2352","_menu_item_menu_item_parent","0");
INSERT INTO `st_postmeta` VALUES("1169","2352","_menu_item_object_id","2350");
INSERT INTO `st_postmeta` VALUES("1170","2352","_menu_item_object","page");
INSERT INTO `st_postmeta` VALUES("1171","2352","_menu_item_target","");
INSERT INTO `st_postmeta` VALUES("1172","2352","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `st_postmeta` VALUES("1173","2352","_menu_item_xfn","");
INSERT INTO `st_postmeta` VALUES("1174","2352","_menu_item_url","");
INSERT INTO `st_postmeta` VALUES("1213","2352","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("1176","2352","menu-item-mfn-megamenu","");
INSERT INTO `st_postmeta` VALUES("1177","2352","menu-item-mfn-bg","");
INSERT INTO `st_postmeta` VALUES("1178","2353","_menu_item_type","post_type");
INSERT INTO `st_postmeta` VALUES("1179","2353","_menu_item_menu_item_parent","0");
INSERT INTO `st_postmeta` VALUES("1180","2353","_menu_item_object_id","29");
INSERT INTO `st_postmeta` VALUES("1181","2353","_menu_item_object","page");
INSERT INTO `st_postmeta` VALUES("1182","2353","_menu_item_target","");
INSERT INTO `st_postmeta` VALUES("1183","2353","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `st_postmeta` VALUES("1184","2353","_menu_item_xfn","");
INSERT INTO `st_postmeta` VALUES("1185","2353","_menu_item_url","");
INSERT INTO `st_postmeta` VALUES("1212","2353","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("1187","2353","menu-item-mfn-megamenu","");
INSERT INTO `st_postmeta` VALUES("1188","2353","menu-item-mfn-bg","");
INSERT INTO `st_postmeta` VALUES("1189","2354","_menu_item_type","post_type");
INSERT INTO `st_postmeta` VALUES("1190","2354","_menu_item_menu_item_parent","0");
INSERT INTO `st_postmeta` VALUES("1191","2354","_menu_item_object_id","28");
INSERT INTO `st_postmeta` VALUES("1192","2354","_menu_item_object","page");
INSERT INTO `st_postmeta` VALUES("1193","2354","_menu_item_target","");
INSERT INTO `st_postmeta` VALUES("1194","2354","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `st_postmeta` VALUES("1195","2354","_menu_item_xfn","");
INSERT INTO `st_postmeta` VALUES("1196","2354","_menu_item_url","");
INSERT INTO `st_postmeta` VALUES("1214","2354","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("1198","2354","menu-item-mfn-megamenu","");
INSERT INTO `st_postmeta` VALUES("1199","2354","menu-item-mfn-bg","");
INSERT INTO `st_postmeta` VALUES("1200","2355","_menu_item_type","post_type");
INSERT INTO `st_postmeta` VALUES("1201","2355","_menu_item_menu_item_parent","0");
INSERT INTO `st_postmeta` VALUES("1202","2355","_menu_item_object_id","27");
INSERT INTO `st_postmeta` VALUES("1203","2355","_menu_item_object","page");
INSERT INTO `st_postmeta` VALUES("1204","2355","_menu_item_target","");
INSERT INTO `st_postmeta` VALUES("1205","2355","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `st_postmeta` VALUES("1206","2355","_menu_item_xfn","");
INSERT INTO `st_postmeta` VALUES("1207","2355","_menu_item_url","");
INSERT INTO `st_postmeta` VALUES("1215","2355","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("1209","2355","menu-item-mfn-megamenu","");
INSERT INTO `st_postmeta` VALUES("1210","2355","menu-item-mfn-bg","");
INSERT INTO `st_postmeta` VALUES("1211","2194","_vc_post_settings","a:2:{s:7:\"vc_grid\";a:0:{}s:10:\"vc_grid_id\";a:0:{}}");
INSERT INTO `st_postmeta` VALUES("1329","2365","id_field","ID");
INSERT INTO `st_postmeta` VALUES("1327","2365","__defaults_set","1");
INSERT INTO `st_postmeta` VALUES("1328","2365","filter","raw");
INSERT INTO `st_postmeta` VALUES("1341","2366","id_field","ID");
INSERT INTO `st_postmeta` VALUES("1339","2366","__defaults_set","1");
INSERT INTO `st_postmeta` VALUES("1340","2366","filter","raw");
INSERT INTO `st_postmeta` VALUES("1353","2367","id_field","ID");
INSERT INTO `st_postmeta` VALUES("1351","2367","__defaults_set","1");
INSERT INTO `st_postmeta` VALUES("1352","2367","filter","raw");
INSERT INTO `st_postmeta` VALUES("1370","2368","filter","raw");
INSERT INTO `st_postmeta` VALUES("1369","2368","__defaults_set","1");
INSERT INTO `st_postmeta` VALUES("1368","2369","id_field","ID");
INSERT INTO `st_postmeta` VALUES("1366","2369","__defaults_set","1");
INSERT INTO `st_postmeta` VALUES("1367","2369","filter","raw");
INSERT INTO `st_postmeta` VALUES("1371","2368","id_field","ID");
INSERT INTO `st_postmeta` VALUES("1383","2370","id_field","ID");
INSERT INTO `st_postmeta` VALUES("1381","2370","__defaults_set","1");
INSERT INTO `st_postmeta` VALUES("1382","2370","filter","raw");
INSERT INTO `st_postmeta` VALUES("1395","2371","id_field","ID");
INSERT INTO `st_postmeta` VALUES("1393","2371","__defaults_set","1");
INSERT INTO `st_postmeta` VALUES("1394","2371","filter","raw");
INSERT INTO `st_postmeta` VALUES("1407","2372","id_field","ID");
INSERT INTO `st_postmeta` VALUES("1405","2372","__defaults_set","1");
INSERT INTO `st_postmeta` VALUES("1406","2372","filter","raw");
INSERT INTO `st_postmeta` VALUES("1419","2373","id_field","ID");
INSERT INTO `st_postmeta` VALUES("1417","2373","__defaults_set","1");
INSERT INTO `st_postmeta` VALUES("1418","2373","filter","raw");
INSERT INTO `st_postmeta` VALUES("1431","2374","id_field","ID");
INSERT INTO `st_postmeta` VALUES("1429","2374","__defaults_set","1");
INSERT INTO `st_postmeta` VALUES("1430","2374","filter","raw");
INSERT INTO `st_postmeta` VALUES("1443","2375","id_field","ID");
INSERT INTO `st_postmeta` VALUES("1441","2375","__defaults_set","1");
INSERT INTO `st_postmeta` VALUES("1442","2375","filter","raw");
INSERT INTO `st_postmeta` VALUES("1455","2376","id_field","ID");
INSERT INTO `st_postmeta` VALUES("1453","2376","__defaults_set","1");
INSERT INTO `st_postmeta` VALUES("1454","2376","filter","raw");
INSERT INTO `st_postmeta` VALUES("1467","2377","id_field","ID");
INSERT INTO `st_postmeta` VALUES("1465","2377","__defaults_set","1");
INSERT INTO `st_postmeta` VALUES("1466","2377","filter","raw");
INSERT INTO `st_postmeta` VALUES("1479","2378","id_field","ID");
INSERT INTO `st_postmeta` VALUES("1477","2378","__defaults_set","1");
INSERT INTO `st_postmeta` VALUES("1478","2378","filter","raw");
INSERT INTO `st_postmeta` VALUES("1491","2379","id_field","ID");
INSERT INTO `st_postmeta` VALUES("1489","2379","__defaults_set","1");
INSERT INTO `st_postmeta` VALUES("1490","2379","filter","raw");
INSERT INTO `st_postmeta` VALUES("1632","2258","post_id","2258");
INSERT INTO `st_postmeta` VALUES("1633","2258","meta_key","name");
INSERT INTO `st_postmeta` VALUES("1634","2258","meta_value","photocrati-nextgen_basic_thumbnails");
INSERT INTO `st_postmeta` VALUES("1635","2258","title","NextGEN Basic Thumbnails");
INSERT INTO `st_postmeta` VALUES("1636","2258","module_id","photocrati-nextgen_basic_gallery");
INSERT INTO `st_postmeta` VALUES("1657","2259","preview_image_relpath","/nextgen-gallery/products/photocrati_nextgen/modules/nextgen_basic_gallery/static/slideshow_preview.jpg");
INSERT INTO `st_postmeta` VALUES("1650","2259","filter","raw");
INSERT INTO `st_postmeta` VALUES("1651","2259","meta_id","721");
INSERT INTO `st_postmeta` VALUES("1652","2259","post_id","2259");
INSERT INTO `st_postmeta` VALUES("1653","2259","meta_key","name");
INSERT INTO `st_postmeta` VALUES("1654","2259","meta_value","photocrati-nextgen_basic_slideshow");
INSERT INTO `st_postmeta` VALUES("1655","2259","title","NextGEN Basic Slideshow");
INSERT INTO `st_postmeta` VALUES("1656","2259","module_id","photocrati-nextgen_basic_gallery");
INSERT INTO `st_postmeta` VALUES("1677","2260","default_source","galleries");
INSERT INTO `st_postmeta` VALUES("1676","2260","preview_image_relpath","/nextgen-gallery/products/photocrati_nextgen/modules/nextgen_basic_imagebrowser/static/preview.jpg");
INSERT INTO `st_postmeta` VALUES("1672","2260","post_id","2260");
INSERT INTO `st_postmeta` VALUES("1673","2260","meta_key","name");
INSERT INTO `st_postmeta` VALUES("1674","2260","meta_value","photocrati-nextgen_basic_imagebrowser");
INSERT INTO `st_postmeta` VALUES("1675","2260","title","NextGEN Basic ImageBrowser");
INSERT INTO `st_postmeta` VALUES("1695","2261","preview_image_relpath","/nextgen-gallery/products/photocrati_nextgen/modules/nextgen_basic_singlepic/static/preview.gif");
INSERT INTO `st_postmeta` VALUES("1689","2261","filter","raw");
INSERT INTO `st_postmeta` VALUES("1690","2261","meta_id","751");
INSERT INTO `st_postmeta` VALUES("1691","2261","post_id","2261");
INSERT INTO `st_postmeta` VALUES("1692","2261","meta_key","name");
INSERT INTO `st_postmeta` VALUES("1693","2261","meta_value","photocrati-nextgen_basic_singlepic");
INSERT INTO `st_postmeta` VALUES("1694","2261","title","NextGEN Basic SinglePic");
INSERT INTO `st_postmeta` VALUES("1716","2262","view_order","10100");
INSERT INTO `st_postmeta` VALUES("1715","2262","default_source","tags");
INSERT INTO `st_postmeta` VALUES("1714","2262","preview_image_relpath","/nextgen-gallery/products/photocrati_nextgen/modules/nextgen_basic_tagcloud/static/preview.gif");
INSERT INTO `st_postmeta` VALUES("1710","2262","post_id","2262");
INSERT INTO `st_postmeta` VALUES("1711","2262","meta_key","name");
INSERT INTO `st_postmeta` VALUES("1712","2262","meta_value","photocrati-nextgen_basic_tagcloud");
INSERT INTO `st_postmeta` VALUES("1713","2262","title","NextGEN Basic TagCloud");
INSERT INTO `st_postmeta` VALUES("1727","2263","filter","raw");
INSERT INTO `st_postmeta` VALUES("1728","2263","meta_id","778");
INSERT INTO `st_postmeta` VALUES("1729","2263","post_id","2263");
INSERT INTO `st_postmeta` VALUES("1730","2263","meta_key","name");
INSERT INTO `st_postmeta` VALUES("1731","2263","meta_value","photocrati-nextgen_basic_compact_album");
INSERT INTO `st_postmeta` VALUES("1732","2263","title","NextGEN Basic Compact Album");
INSERT INTO `st_postmeta` VALUES("1733","2263","module_id","photocrati-nextgen_basic_album");
INSERT INTO `st_postmeta` VALUES("1734","2263","preview_image_relpath","/nextgen-gallery/products/photocrati_nextgen/modules/nextgen_basic_album/static/compact_preview.jpg");
INSERT INTO `st_postmeta` VALUES("1747","2264","filter","raw");
INSERT INTO `st_postmeta` VALUES("1748","2264","meta_id","793");
INSERT INTO `st_postmeta` VALUES("1749","2264","post_id","2264");
INSERT INTO `st_postmeta` VALUES("1750","2264","meta_key","name");
INSERT INTO `st_postmeta` VALUES("1751","2264","meta_value","photocrati-nextgen_basic_extended_album");
INSERT INTO `st_postmeta` VALUES("1752","2264","title","NextGEN Basic Extended Album");
INSERT INTO `st_postmeta` VALUES("1753","2264","module_id","photocrati-nextgen_basic_album");
INSERT INTO `st_postmeta` VALUES("1754","2264","preview_image_relpath","/nextgen-gallery/products/photocrati_nextgen/modules/nextgen_basic_album/static/extended_preview.jpg");
INSERT INTO `st_postmeta` VALUES("1630","2258","filter","raw");
INSERT INTO `st_postmeta` VALUES("1631","2258","meta_id","706");
INSERT INTO `st_postmeta` VALUES("1670","2260","filter","raw");
INSERT INTO `st_postmeta` VALUES("1671","2260","meta_id","735");
INSERT INTO `st_postmeta` VALUES("1708","2262","filter","raw");
INSERT INTO `st_postmeta` VALUES("1709","2262","meta_id","763");
INSERT INTO `st_postmeta` VALUES("1776","106","mfn-post-hide-title","0");
INSERT INTO `st_postmeta` VALUES("1777","106","mfn-post-remove-padding","1");
INSERT INTO `st_postmeta` VALUES("1778","106","_yoast_wpseo_focuskw","وردپرس - روزمره ها - سپیده- سایت شخصی -");
INSERT INTO `st_postmeta` VALUES("1779","106","_yoast_wpseo_metadesc","این سایت یک صفحه شخصی بوده و البته یک نمونه ایجاد شده توسط وردپرس است.");
INSERT INTO `st_postmeta` VALUES("1780","106","_yoast_wpseo_linkdex","25");


DROP TABLE IF EXISTS `st_posts`;

CREATE TABLE `st_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=MyISAM AUTO_INCREMENT=2386 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `st_posts` VALUES("1","1","2018-06-01 04:58:36","2018-06-01 04:58:36","<img class=\"size-medium wp-image-2302 aligncenter\" src=\"http://foolstacks.ir/wp-content/uploads/2018/06/hw-300x87.jpeg\" alt=\"\" width=\"300\" height=\"87\">
<h2 style=\"text-align: center;\"><strong>سلام دنیا!</strong></h2>","سلام دنیا!","","publish","open","open","","%d8%b3%d9%84%d8%a7%d9%85-%d8%af%d9%86%db%8c%d8%a7","","","2018-11-13 19:10:51","2018-11-13 20:10:51","","0","http://foolstacks.ir/?p=1","0","post","","1");
INSERT INTO `st_posts` VALUES("76","1","2018-11-10 05:39:07","2018-11-10 02:09:07","سلام دنیا!","سلام دنیا!","","inherit","closed","closed","","1-revision-v1","","","2018-11-10 05:39:07","2018-11-10 02:09:07","","1","http://foolstacks.ir/?p=76","0","revision","","0");
INSERT INTO `st_posts` VALUES("2","1","2018-11-10 04:58:36","2018-11-10 01:28:36","این یک برگه‌ی نمونه است که با یک نوشته در وبلاگ تفاوت دارد زیرا برگه‌ها در یک مکان ثابت می‌مانند و معمولاً در فهرست پیوندهای درونی سایت شما نمایش داده می‌شوند (در بیشتر پوسته‌ها). بیشتر افراد کار کردن با برگه‌ها را از یک برگه‌ی «درباره من» که آن‌ها را به خوانندگان سایت معرفی می‌کند، شروع می‌کنند. برای مثال این‌چنین می‌گویند:

<blockquote>سلام دوستان، من روزها یک کارمند اداری هستم و شب‌ها یک راننده تاکسی، این وبلاگ من است. من در اهواز زندگی می‌کنم که شهری در جنوب غربی ایران است.</blockquote>

یا چیزی شبیه این:

<blockquote>شرکت XYZ در سال ۱۳۶۵ تاسیس شد و ارائه‌دهنده محصولات صنعتی است. این شرکت ۲۰۰۰ کارگر و کارمند دارد. امیدواریم از محصولات ما راضی باشید.</blockquote>

به‌عنوان یک کاربر تازه‌ی وردپرس فارسی شما برای پاک کردن این برگه و ساختن برگه‌های تازه می‌توانید به <a href=\"http://foolstacks.ir/wp-admin/\">پیشخوان خود</a> مراجعه کنید. موفق باشید!","برگه نمونه","","trash","closed","open","","برگه-نمونه__trashed","","","2018-11-10 05:30:19","2018-11-10 02:00:19","","0","http://foolstacks.ir/?page_id=2","0","page","","0");
INSERT INTO `st_posts` VALUES("3","1","2018-11-10 04:58:36","2018-11-10 01:28:36","<h2>ما که هستیم</h2><p>نشانی وب‌سایت ما هست: http://foolstacks.ir.</p><h2>کدامیک از اطلاعات شخصی را جمع آوری میکنیم و چرا</h2><h3>دیدگاه‌ها</h3><p>هنگامی که بازدیدکنندگان نظرات خود را در سایت می نویسند، ما اطلاعاتی را که در فرم نظرات و همچنین بازدید کننده ها ارائه می شود جمع آوری می کنیم &#8217;s آدرس IP و رجیستر عامل کاربر مرورگر برای کمک به تشخیص هرزنامه.</p><p>یک رشته ناشناس ایجاد شده از آدرس ایمیل شما (همچنین هش نامیده می شود) ممکن است به سرویس Gravatar ارائه شود تا ببینید آیا از آن استفاده می کنید. سیاست حفظ حریم خصوصی خدمات Gravatar در اینجا در دسترس است: https://automattic.com/privacy/. پس از تأیید نظر شما، تصویر نمایه شما در متن نظر شما قابل مشاهده است.</p><h3>رسانه</h3><p>اگر تصاویر را به وبسایت آپلود کنید، نباید آپلود تصاویر با داده های مکان جغرافیایی (EXIF GPS) شامل شود. بازدیدکنندگان وب سایت می توانند هر گونه اطلاعات مکان را از تصاویر در وب سایت دانلود و استخراج کنند.</p><h3>فرم‌های تماس</h3><h3>کوکی‌ها</h3><p>اگر شما نظر خود را در سایت ما ثبت کنید، ممکن است برای ذخیره نام، آدرس ایمیل و وب سایت خود در کوکی ها تصمیم گیری کنید. اینها برای راحتی شما هستند، به طوری که شما مجبور نیستید دوباره جزئیات خود را پر کنید زمانی که نظر دیگری را ترک کنید. این کوکی ها یک سال طول خواهد کشید.</p><p>اگر حساب کاربری دارید و به این سایت وارد می شوید، ما کوکی موقت را برای تعیین اینکه آیا مرورگر شما کوکی ها را قبول می کند تنظیم می کند. این کوکی حاوی اطلاعات شخصی نیست و هنگامی که مرورگر شما را میبندد از بین میرود.</p><p>هنگام ورود به سیستم، ما همچنین کوکی ها را تنظیم خواهیم کرد تا اطلاعات ورود به سیستم و گزینه های صفحه نمایش خود را ذخیره کنید. کوکی های ورود به سیستم برای دو روز گذشته و کوکی های گزینه های صفحه نمایش برای یک سال گذشته است. اگر شما انتخاب کنید &quot; به یاد داشته باشید من Me&quot;، ورود شما برای دو هفته ادامه خواهد داشت. اگر از حساب خود خارج شوید، کوکی های ورود حذف خواهند شد.</p><p>اگر یک مقاله را ویرایش یا منتشر کنید، یک کوکی اضافی در مرورگر شما ذخیره خواهد شد. این کوکی حاوی اطلاعات شخصی نیست و به سادگی نشان می دهد که شناسه پست مقاله شما فقط ویرایش شده است. بعد از یک روز منقضی می شود.</p><h3>محتوای جاسازی‌شده از دیگر وب‌سایت‌ها</h3><p>مقالات موجود در این سایت ممکن است شامل محتوای تعبیه شده (مثلا ویدیوها، تصاویر، مقالات و غیره) باشد. مطالب جاسازی شده از وب سایت های دیگر رفتار دقیقا همان طوری که بازدید کننده از وب سایت دیگر بازدید کرده است.</p><p>این وب سایت ممکن است جمع آوری اطلاعات در مورد شما، با استفاده از کوکی ها، جاسازی ردیابی شخص ثالث اضافی، و نظارت بر تعامل خود را با که محتوای جاسازی شده، از جمله ردیابی تعامل خود را با محتوای جاسازی شده اگر شما یک حساب کاربری و در به که وب سایت وارد سایت شوید.</p><h3>تجزیه و تحلیل</h3><h2>اطلاعت شما را با چه کسی به اشتراک می گذاریم</h2><h2>چه مدت ما اطلاعات شما را حفظ می کنیم</h2><p>اگر یک نظر را ترک کنید، نظر و متادیتای آن به طور نامحدود حفظ می شوند. این به این معنا است که ما می توانیم به جای برگزاری آنها در یک خط مؤثر، به طور خودکار هر نظر پیگیری را تصدیق و تأیید کنیم.</p><p>برای کاربرانی که در وب سایت ما ثبت نام می کنند (اگر وجود داشته باشند)، ما همچنین اطلاعات شخصی را که در مشخصات کاربر آنها ارائه می کنیم، ذخیره می کنیم. همه کاربران می توانند اطلاعات شخصی خود را در هر زمان (به جز آنها که نمی توانند نام کاربری خود را تغییر دهند) ببینند، ویرایش و یا حذف کنند. مدیران وب سایت همچنین می توانند این اطلاعات را مشاهده و ویرایش کنند.</p><h2>حقوقی که بر روی داده‌هایتان دارید</h2><p>اگر در این سایت حساب کاربری دارید یا نظرها را ترک کرده اید، می توانید درخواست دریافت یک فایل صادر شده از اطلاعات شخصی که ما در مورد شما نگه می داریم، از جمله هر گونه داده ای که برای ما ارائه کرده اید. همچنین می توانید درخواست کنید که ما هر گونه اطلاعات شخصی که در مورد شما نگه داریم پاک کنیم. این شامل اطلاعاتی نیست که ما مجبور به نگهداری آنها برای اهداف اداری، قانونی یا امنیتی باشیم.</p><h2>کجا داده‌های شما را ارسال می کنیم</h2><p>دیدگاه‌های بازدیدکننده ممکن است از طریق یک سرویس تشخیص جفنگ بررسی شود.</p><h2>اطلاعات تماس شما</h2><h2>اطلاعات اضافی</h2><h3>چگونه از اطلاعات شما حفاظت می کنیم</h3><h3>چه رویه های نقض اطلاعات در حال حاضر وجود دارد</h3><h3>چه چیز جدیدی از داده ها دریافت می کنیم</h3><h3>تصمیم گیری خودکار و / یا پروفایل ما با داده های کاربر انجام می شود</h3><h3>الزامات افشای قانونی صنعت</h3>","سیاست حفظ حریم خصوصی","","trash","closed","open","","حفظ-حریم-خصوصی__trashed","","","2018-11-10 05:28:21","2018-11-10 01:58:21","","0","http://foolstacks.ir/?page_id=3","0","page","","0");
INSERT INTO `st_posts` VALUES("2383","1","2018-11-17 13:55:35","2018-11-17 10:25:35","برای رفع این خطا به ترتیب زیر عمل می کنیم:

The Tomcat connector configured to listen on port 8080 failed to start

ابتدا در cmd&nbsp; دستور زیر رو وارد می کنیم تا ببینیم که پورت 8080 رو کدوم برنامه اشغال کرده:

netstat -aon |findstr 0.0:80

حالا در ستون آخر نتایج نمایش داده شده،&nbsp; PID برنامه رو پیدا کردیم و خیلی راحت از طریق تسک منیجر اون برنامه رو متوقف می کنیم.

تامکت شما آماده هست!&nbsp;","رفع خطای راه اندازی تامکت هنگام کار در اکلیپس","","publish","open","open","","%d8%b1%d9%81%d8%b9-%d8%ae%d8%b7%d8%a7%db%8c-%d8%b1%d8%a7%d9%87-%d8%a7%d9%86%d8%af%d8%a7%d8%b2%db%8c-%d8%aa%d8%a7%d9%85%da%a9%d8%aa-%d9%87%d9%86%da%af%d8%a7%d9%85-%d8%a7%d8%aa%d8%b5%d8%a7%d9%84-%d8%a8","","","2018-11-17 13:56:31","2018-11-17 10:26:31","","0","http://foolstacks.ir/?p=2383","0","post","","0");
INSERT INTO `st_posts` VALUES("2384","1","2018-11-17 13:55:35","2018-11-17 10:25:35","برای رفع این خطا به ترتیب زیر عمل می کنیم:

The Tomcat connector configured to listen on port 8080 failed to start

ابتدا در cmd&nbsp; دستور زیر رو وارد می کنیم تا ببینیم که پورت 8080 رو کدوم برنامه اشغال کرده:

netstat -aon |findstr 0.0:80

حالا در ستون آخر نتایج نمایش داده شده،&nbsp; PID برنامه رو پیدا کردیم و خیلی راحت از طریق تسک منیجر اون برنامه رو متوقف می کنیم.

تامکت شما آماده هست!&nbsp;","رفع خطای راه اندازی تامکت هنگام اتصال به اکلیپس","","inherit","closed","closed","","2383-revision-v1","","","2018-11-17 13:55:35","2018-11-17 10:25:35","","2383","http://foolstacks.ir/2383-revision-v1/","0","revision","","0");
INSERT INTO `st_posts` VALUES("2385","1","2018-11-17 13:56:31","2018-11-17 10:26:31","برای رفع این خطا به ترتیب زیر عمل می کنیم:

The Tomcat connector configured to listen on port 8080 failed to start

ابتدا در cmd&nbsp; دستور زیر رو وارد می کنیم تا ببینیم که پورت 8080 رو کدوم برنامه اشغال کرده:

netstat -aon |findstr 0.0:80

حالا در ستون آخر نتایج نمایش داده شده،&nbsp; PID برنامه رو پیدا کردیم و خیلی راحت از طریق تسک منیجر اون برنامه رو متوقف می کنیم.

تامکت شما آماده هست!&nbsp;","رفع خطای راه اندازی تامکت هنگام کار در اکلیپس","","inherit","closed","closed","","2383-revision-v1","","","2018-11-17 13:56:31","2018-11-17 10:26:31","","2383","http://foolstacks.ir/2383-revision-v1/","0","revision","","0");
INSERT INTO `st_posts` VALUES("58","1","2018-11-10 05:24:31","2018-11-10 01:54:31","","about","","inherit","open","closed","","318714-130g210391134","","","2018-11-10 05:24:45","2018-11-10 01:54:45","","27","http://foolstacks.ir/wp-content/uploads/2018/11/318714-130G210391134.jpg","0","attachment","image/jpeg","0");
INSERT INTO `st_posts` VALUES("26","1","2018-11-10 05:12:31","2018-11-10 01:42:31","خودش آمدید!","صفحه اول","","trash","closed","closed","","%d8%ae%d8%a7%d9%86%d9%87__trashed","","","2018-11-13 19:03:59","2018-11-13 20:03:59","","0","http://foolstacks.ir/?page_id=26","0","page","","0");
INSERT INTO `st_posts` VALUES("64","1","2018-11-10 05:27:50","2018-11-10 01:57:50","","way","","inherit","open","closed","","background-alam-kartun-6","","","2018-11-10 05:28:04","2018-11-10 01:58:04","","30","http://foolstacks.ir/wp-content/uploads/2018/11/background-alam-kartun-6.jpg","0","attachment","image/jpeg","0");
INSERT INTO `st_posts` VALUES("27","1","2018-11-10 05:12:31","2018-11-10 01:42:31","[rev_slider webdesign]

[video width=\"1280\" height=\"720\" mp4=\"http://foolstacks.ir/wp-content/uploads/2018/11/What-is-a-Blog.mp4\"][/video]","درباره ما","","publish","closed","closed","","%d8%af%d8%b1%d8%a8%d8%a7%d8%b1%d9%87","","","2018-11-13 21:43:52","2018-11-13 22:43:52","","0","http://foolstacks.ir/?page_id=27","0","page","","0");
INSERT INTO `st_posts` VALUES("60","1","2018-11-10 05:25:29","2018-11-10 01:55:29","","blog","","inherit","open","closed","","girl-reading-book-wallpaper","","","2018-11-10 05:25:37","2018-11-10 01:55:37","","29","http://foolstacks.ir/wp-content/uploads/2018/11/Girl-Reading-Book-Wallpaper.jpg","0","attachment","image/jpeg","0");
INSERT INTO `st_posts` VALUES("28","1","2018-11-10 05:12:31","2018-11-10 01:42:31","<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d18329.307377441437!2d51.366665957120915!3d35.6968338514745!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3f8e00491ff3dcd9%3A0xf0b3697c567024bc!2sTehran%2C+Tehran+Province%2C+Iran!5e0!3m2!1sen!2s!4v1542183334626\" width=\"600\" height=\"450\" frameborder=\"0\" style=\"border:0\" allowfullscreen></iframe>

[contact-form-7 id=\"2256\" title=\"فرم تماس 1\"]","ارتباط با ما","","publish","closed","closed","","%d8%a7%d8%b1%d8%aa%d8%a8%d8%a7%d8%b7","","","2018-11-14 11:54:21","2018-11-14 08:24:21","","0","http://foolstacks.ir/?page_id=28","0","page","","0");
INSERT INTO `st_posts` VALUES("29","1","2018-11-10 05:12:31","2018-11-10 01:42:31","","بلاگ","","publish","closed","closed","","%d8%a8%d9%84%d8%a7%da%af","","","2018-11-13 21:43:55","2018-11-13 22:43:55","","0","http://foolstacks.ir/?page_id=29","0","page","","0");
INSERT INTO `st_posts` VALUES("30","1","2018-11-10 05:12:31","2018-11-10 01:42:31","بخش اول","یک بخش صفحه خانگی","","trash","closed","closed","","%db%8c%da%a9-%d8%a8%d8%ae%d8%b4-%d8%b5%d9%81%d8%ad%d9%87-%d8%ae%d8%a7%d9%86%da%af%db%8c__trashed","","","2018-11-13 19:04:06","2018-11-13 20:04:06","","0","http://foolstacks.ir/?page_id=30","0","page","","0");
INSERT INTO `st_posts` VALUES("66","1","2018-11-10 05:28:21","2018-11-10 01:58:21","<h2>ما که هستیم</h2><p>نشانی وب‌سایت ما هست: http://foolstacks.ir.</p><h2>کدامیک از اطلاعات شخصی را جمع آوری میکنیم و چرا</h2><h3>دیدگاه‌ها</h3><p>هنگامی که بازدیدکنندگان نظرات خود را در سایت می نویسند، ما اطلاعاتی را که در فرم نظرات و همچنین بازدید کننده ها ارائه می شود جمع آوری می کنیم &#8217;s آدرس IP و رجیستر عامل کاربر مرورگر برای کمک به تشخیص هرزنامه.</p><p>یک رشته ناشناس ایجاد شده از آدرس ایمیل شما (همچنین هش نامیده می شود) ممکن است به سرویس Gravatar ارائه شود تا ببینید آیا از آن استفاده می کنید. سیاست حفظ حریم خصوصی خدمات Gravatar در اینجا در دسترس است: https://automattic.com/privacy/. پس از تأیید نظر شما، تصویر نمایه شما در متن نظر شما قابل مشاهده است.</p><h3>رسانه</h3><p>اگر تصاویر را به وبسایت آپلود کنید، نباید آپلود تصاویر با داده های مکان جغرافیایی (EXIF GPS) شامل شود. بازدیدکنندگان وب سایت می توانند هر گونه اطلاعات مکان را از تصاویر در وب سایت دانلود و استخراج کنند.</p><h3>فرم‌های تماس</h3><h3>کوکی‌ها</h3><p>اگر شما نظر خود را در سایت ما ثبت کنید، ممکن است برای ذخیره نام، آدرس ایمیل و وب سایت خود در کوکی ها تصمیم گیری کنید. اینها برای راحتی شما هستند، به طوری که شما مجبور نیستید دوباره جزئیات خود را پر کنید زمانی که نظر دیگری را ترک کنید. این کوکی ها یک سال طول خواهد کشید.</p><p>اگر حساب کاربری دارید و به این سایت وارد می شوید، ما کوکی موقت را برای تعیین اینکه آیا مرورگر شما کوکی ها را قبول می کند تنظیم می کند. این کوکی حاوی اطلاعات شخصی نیست و هنگامی که مرورگر شما را میبندد از بین میرود.</p><p>هنگام ورود به سیستم، ما همچنین کوکی ها را تنظیم خواهیم کرد تا اطلاعات ورود به سیستم و گزینه های صفحه نمایش خود را ذخیره کنید. کوکی های ورود به سیستم برای دو روز گذشته و کوکی های گزینه های صفحه نمایش برای یک سال گذشته است. اگر شما انتخاب کنید &quot; به یاد داشته باشید من Me&quot;، ورود شما برای دو هفته ادامه خواهد داشت. اگر از حساب خود خارج شوید، کوکی های ورود حذف خواهند شد.</p><p>اگر یک مقاله را ویرایش یا منتشر کنید، یک کوکی اضافی در مرورگر شما ذخیره خواهد شد. این کوکی حاوی اطلاعات شخصی نیست و به سادگی نشان می دهد که شناسه پست مقاله شما فقط ویرایش شده است. بعد از یک روز منقضی می شود.</p><h3>محتوای جاسازی‌شده از دیگر وب‌سایت‌ها</h3><p>مقالات موجود در این سایت ممکن است شامل محتوای تعبیه شده (مثلا ویدیوها، تصاویر، مقالات و غیره) باشد. مطالب جاسازی شده از وب سایت های دیگر رفتار دقیقا همان طوری که بازدید کننده از وب سایت دیگر بازدید کرده است.</p><p>این وب سایت ممکن است جمع آوری اطلاعات در مورد شما، با استفاده از کوکی ها، جاسازی ردیابی شخص ثالث اضافی، و نظارت بر تعامل خود را با که محتوای جاسازی شده، از جمله ردیابی تعامل خود را با محتوای جاسازی شده اگر شما یک حساب کاربری و در به که وب سایت وارد سایت شوید.</p><h3>تجزیه و تحلیل</h3><h2>اطلاعت شما را با چه کسی به اشتراک می گذاریم</h2><h2>چه مدت ما اطلاعات شما را حفظ می کنیم</h2><p>اگر یک نظر را ترک کنید، نظر و متادیتای آن به طور نامحدود حفظ می شوند. این به این معنا است که ما می توانیم به جای برگزاری آنها در یک خط مؤثر، به طور خودکار هر نظر پیگیری را تصدیق و تأیید کنیم.</p><p>برای کاربرانی که در وب سایت ما ثبت نام می کنند (اگر وجود داشته باشند)، ما همچنین اطلاعات شخصی را که در مشخصات کاربر آنها ارائه می کنیم، ذخیره می کنیم. همه کاربران می توانند اطلاعات شخصی خود را در هر زمان (به جز آنها که نمی توانند نام کاربری خود را تغییر دهند) ببینند، ویرایش و یا حذف کنند. مدیران وب سایت همچنین می توانند این اطلاعات را مشاهده و ویرایش کنند.</p><h2>حقوقی که بر روی داده‌هایتان دارید</h2><p>اگر در این سایت حساب کاربری دارید یا نظرها را ترک کرده اید، می توانید درخواست دریافت یک فایل صادر شده از اطلاعات شخصی که ما در مورد شما نگه می داریم، از جمله هر گونه داده ای که برای ما ارائه کرده اید. همچنین می توانید درخواست کنید که ما هر گونه اطلاعات شخصی که در مورد شما نگه داریم پاک کنیم. این شامل اطلاعاتی نیست که ما مجبور به نگهداری آنها برای اهداف اداری، قانونی یا امنیتی باشیم.</p><h2>کجا داده‌های شما را ارسال می کنیم</h2><p>دیدگاه‌های بازدیدکننده ممکن است از طریق یک سرویس تشخیص جفنگ بررسی شود.</p><h2>اطلاعات تماس شما</h2><h2>اطلاعات اضافی</h2><h3>چگونه از اطلاعات شما حفاظت می کنیم</h3><h3>چه رویه های نقض اطلاعات در حال حاضر وجود دارد</h3><h3>چه چیز جدیدی از داده ها دریافت می کنیم</h3><h3>تصمیم گیری خودکار و / یا پروفایل ما با داده های کاربر انجام می شود</h3><h3>الزامات افشای قانونی صنعت</h3>","سیاست حفظ حریم خصوصی","","inherit","closed","closed","","3-revision-v1","","","2018-11-10 05:28:21","2018-11-10 01:58:21","","3","http://foolstacks.ir/?p=66","0","revision","","0");
INSERT INTO `st_posts` VALUES("31","1","2018-11-10 05:12:31","2018-11-10 01:42:31","{
    \"widget_text[6]\": {
        \"starter_content\": true,
        \"value\": {
            \"encoded_serialized_instance\": \"YTo0OntzOjU6InRpdGxlIjtzOjIyOiLZhdinINix2Kcg2KjbjNin2KjbjNivIjtzOjQ6InRleHQiO3M6MjYyOiI8c3Ryb25nPtmG2LTYp9mG24w8L3N0cm9uZz4K2K7bjNin2KjYp9mGINux27LbswrZhtuM2YjbjNmI2LHaqdiMINmG24zZiNuM2YjYsdqpINux27DbsNuw27EKCjxzdHJvbmc+2LPYp9i52Kog2qnYp9ix24w8L3N0cm9uZz4K2LTZhtio2Ycg2KrYpyDahtmH2KfYsdi02YbYqNmHOiDbuSDYtdio2K0g2KrYpyDbtSDYqNi52K8g2KfYsiDYuNmH2LEK2b7Zhtis2LTZhtio2Ycg2Ygg2KzZhdi52Yc6INux27Eg2LXYqNitINiq2Kcg27Mg2KjYudivINin2LIg2LjZh9ixIjtzOjY6ImZpbHRlciI7YjoxO3M6NjoidmlzdWFsIjtiOjE7fQ==\",
            \"title\": \"\\u0645\\u0627 \\u0631\\u0627 \\u0628\\u06cc\\u0627\\u0628\\u06cc\\u062f\",
            \"is_widget_customizer_js_value\": true,
            \"instance_hash_key\": \"950d66ac2adca4718faf92ff1e5a286c\"
        },
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 01:36:41\"
    },
    \"widget_search[3]\": {
        \"starter_content\": true,
        \"value\": {
            \"encoded_serialized_instance\": \"YToxOntzOjU6InRpdGxlIjtzOjEwOiLYrNiz2KrYrNmIIjt9\",
            \"title\": \"\\u062c\\u0633\\u062a\\u062c\\u0648\",
            \"is_widget_customizer_js_value\": true,
            \"instance_hash_key\": \"0a82e31e9c83b1307887392731344047\"
        },
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 01:36:41\"
    },
    \"widget_text[7]\": {
        \"starter_content\": true,
        \"value\": {
            \"encoded_serialized_instance\": \"YTo0OntzOjU6InRpdGxlIjtzOjI4OiLYr9ix2KjYp9ix2Ycg2KfbjNmGINiz2KfbjNiqIjtzOjQ6InRleHQiO3M6ODg6Itin24zZhtis2Kcg2YXaqdin2YYg2YXZhtin2LPYqNuMINin2LPYqiDYqNix2KfbjCDZhdi52LHZgduMINi02YXYpyDZiCDYs9in24zYquKAjNiq2KfZhi4iO3M6NjoiZmlsdGVyIjtiOjE7czo2OiJ2aXN1YWwiO2I6MTt9\",
            \"title\": \"\\u062f\\u0631\\u0628\\u0627\\u0631\\u0647 \\u0627\\u06cc\\u0646 \\u0633\\u0627\\u06cc\\u062a\",
            \"is_widget_customizer_js_value\": true,
            \"instance_hash_key\": \"7f05945c3f292bfb521c9c858db92503\"
        },
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 01:36:41\"
    },
    \"sidebars_widgets[sidebar-1]\": {
        \"starter_content\": true,
        \"value\": [
            \"text-6\",
            \"search-3\",
            \"text-7\"
        ],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 01:36:41\"
    },
    \"widget_text[8]\": {
        \"starter_content\": true,
        \"value\": {
            \"encoded_serialized_instance\": \"YTo0OntzOjU6InRpdGxlIjtzOjIyOiLZhdinINix2Kcg2KjbjNin2KjbjNivIjtzOjQ6InRleHQiO3M6MjYyOiI8c3Ryb25nPtmG2LTYp9mG24w8L3N0cm9uZz4K2K7bjNin2KjYp9mGINux27LbswrZhtuM2YjbjNmI2LHaqdiMINmG24zZiNuM2YjYsdqpINux27DbsNuw27EKCjxzdHJvbmc+2LPYp9i52Kog2qnYp9ix24w8L3N0cm9uZz4K2LTZhtio2Ycg2KrYpyDahtmH2KfYsdi02YbYqNmHOiDbuSDYtdio2K0g2KrYpyDbtSDYqNi52K8g2KfYsiDYuNmH2LEK2b7Zhtis2LTZhtio2Ycg2Ygg2KzZhdi52Yc6INux27Eg2LXYqNitINiq2Kcg27Mg2KjYudivINin2LIg2LjZh9ixIjtzOjY6ImZpbHRlciI7YjoxO3M6NjoidmlzdWFsIjtiOjE7fQ==\",
            \"title\": \"\\u0645\\u0627 \\u0631\\u0627 \\u0628\\u06cc\\u0627\\u0628\\u06cc\\u062f\",
            \"is_widget_customizer_js_value\": true,
            \"instance_hash_key\": \"950d66ac2adca4718faf92ff1e5a286c\"
        },
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 01:36:41\"
    },
    \"sidebars_widgets[sidebar-2]\": {
        \"starter_content\": true,
        \"value\": [
            \"text-8\"
        ],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 01:36:41\"
    },
    \"widget_text[9]\": {
        \"starter_content\": true,
        \"value\": {
            \"encoded_serialized_instance\": \"YTo0OntzOjU6InRpdGxlIjtzOjI4OiLYr9ix2KjYp9ix2Ycg2KfbjNmGINiz2KfbjNiqIjtzOjQ6InRleHQiO3M6ODg6Itin24zZhtis2Kcg2YXaqdin2YYg2YXZhtin2LPYqNuMINin2LPYqiDYqNix2KfbjCDZhdi52LHZgduMINi02YXYpyDZiCDYs9in24zYquKAjNiq2KfZhi4iO3M6NjoiZmlsdGVyIjtiOjE7czo2OiJ2aXN1YWwiO2I6MTt9\",
            \"title\": \"\\u062f\\u0631\\u0628\\u0627\\u0631\\u0647 \\u0627\\u06cc\\u0646 \\u0633\\u0627\\u06cc\\u062a\",
            \"is_widget_customizer_js_value\": true,
            \"instance_hash_key\": \"7f05945c3f292bfb521c9c858db92503\"
        },
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 01:36:41\"
    },
    \"widget_search[4]\": {
        \"starter_content\": true,
        \"value\": {
            \"encoded_serialized_instance\": \"YToxOntzOjU6InRpdGxlIjtzOjEwOiLYrNiz2KrYrNmIIjt9\",
            \"title\": \"\\u062c\\u0633\\u062a\\u062c\\u0648\",
            \"is_widget_customizer_js_value\": true,
            \"instance_hash_key\": \"0a82e31e9c83b1307887392731344047\"
        },
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 01:36:41\"
    },
    \"sidebars_widgets[sidebar-3]\": {
        \"starter_content\": true,
        \"value\": [
            \"text-9\",
            \"search-4\"
        ],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 01:36:41\"
    },
    \"nav_menus_created_posts\": {
        \"starter_content\": true,
        \"value\": [
            23,
            24,
            25,
            26,
            27,
            28,
            29,
            30
        ],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 01:36:41\"
    },
    \"nav_menu[-1]\": {
        \"value\": {
            \"name\": \"\\u0641\\u0647\\u0631\\u0633\\u062a \\u0628\\u0627\\u0644\\u0627\\u06cc\\u06cc\",
            \"description\": \"\",
            \"parent\": 0,
            \"auto_add\": false
        },
        \"type\": \"nav_menu\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 01:42:31\"
    },
    \"nav_menu_item[-1]\": {
        \"value\": {
            \"object_id\": 0,
            \"object\": \"\",
            \"menu_item_parent\": 0,
            \"position\": 0,
            \"type\": \"custom\",
            \"title\": \"\\u062e\\u0627\\u0646\\u0647\",
            \"url\": \"http://foolstacks.ir/\",
            \"target\": \"\",
            \"attr_title\": \"\",
            \"description\": \"\",
            \"classes\": \"\",
            \"xfn\": \"\",
            \"status\": \"publish\",
            \"original_title\": \"\",
            \"nav_menu_term_id\": -1,
            \"_invalid\": false,
            \"type_label\": \"\\u067e\\u06cc\\u0648\\u0646\\u062f \\u0633\\u0641\\u0627\\u0631\\u0634\\u06cc\"
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 01:42:31\"
    },
    \"nav_menu_item[-2]\": {
        \"value\": {
            \"object_id\": 27,
            \"object\": \"page\",
            \"menu_item_parent\": 0,
            \"position\": 1,
            \"type\": \"post_type\",
            \"title\": \"\\u062f\\u0631\\u0628\\u0627\\u0631\\u0647\",
            \"url\": \"\",
            \"target\": \"\",
            \"attr_title\": \"\",
            \"description\": \"\",
            \"classes\": \"\",
            \"xfn\": \"\",
            \"status\": \"publish\",
            \"original_title\": \"\\u062f\\u0631\\u0628\\u0627\\u0631\\u0647\",
            \"nav_menu_term_id\": -1,
            \"_invalid\": false,
            \"type_label\": \"\\u0628\\u0631\\u06af\\u0647\"
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 01:42:31\"
    },
    \"nav_menu_item[-3]\": {
        \"value\": {
            \"object_id\": 29,
            \"object\": \"page\",
            \"menu_item_parent\": 0,
            \"position\": 2,
            \"type\": \"post_type\",
            \"title\": \"\\u0628\\u0644\\u0627\\u06af\",
            \"url\": \"\",
            \"target\": \"\",
            \"attr_title\": \"\",
            \"description\": \"\",
            \"classes\": \"\",
            \"xfn\": \"\",
            \"status\": \"publish\",
            \"original_title\": \"\\u0628\\u0644\\u0627\\u06af\",
            \"nav_menu_term_id\": -1,
            \"_invalid\": false,
            \"type_label\": \"\\u0628\\u0631\\u06af\\u0647\"
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 01:42:31\"
    },
    \"nav_menu_item[-4]\": {
        \"value\": {
            \"object_id\": 28,
            \"object\": \"page\",
            \"menu_item_parent\": 0,
            \"position\": 3,
            \"type\": \"post_type\",
            \"title\": \"\\u0627\\u0631\\u062a\\u0628\\u0627\\u0637\",
            \"url\": \"\",
            \"target\": \"\",
            \"attr_title\": \"\",
            \"description\": \"\",
            \"classes\": \"\",
            \"xfn\": \"\",
            \"status\": \"publish\",
            \"original_title\": \"\\u0627\\u0631\\u062a\\u0628\\u0627\\u0637\",
            \"nav_menu_term_id\": -1,
            \"_invalid\": false,
            \"type_label\": \"\\u0628\\u0631\\u06af\\u0647\"
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 01:42:31\"
    },
    \"twentyseventeen::nav_menu_locations[top]\": {
        \"starter_content\": true,
        \"value\": -1,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 01:36:41\"
    },
    \"nav_menu[-5]\": {
        \"value\": {
            \"name\": \"\\u0641\\u0647\\u0631\\u0633\\u062a \\u0634\\u0628\\u06a9\\u0647\\u200c\\u0647\\u0627\\u06cc \\u0627\\u062c\\u062a\\u0645\\u0627\\u0639\\u06cc\",
            \"description\": \"\",
            \"parent\": 0,
            \"auto_add\": false
        },
        \"type\": \"nav_menu\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 01:42:31\"
    },
    \"nav_menu_item[-5]\": {
        \"value\": false,
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 01:37:53\"
    },
    \"nav_menu_item[-6]\": {
        \"value\": {
            \"object_id\": 0,
            \"object\": \"\",
            \"menu_item_parent\": 0,
            \"position\": 1,
            \"type\": \"custom\",
            \"title\": \"\\u0641\\u06cc\\u0633\\u0628\\u0648\\u06a9\",
            \"url\": \"https://www.facebook.com/sepidsal\",
            \"target\": \"\",
            \"attr_title\": \"\",
            \"description\": \"\",
            \"classes\": \"\",
            \"xfn\": \"\",
            \"status\": \"publish\",
            \"original_title\": \"\",
            \"nav_menu_term_id\": -5,
            \"_invalid\": false,
            \"type_label\": \"\\u067e\\u06cc\\u0648\\u0646\\u062f \\u0633\\u0641\\u0627\\u0631\\u0634\\u06cc\"
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 01:37:53\"
    },
    \"nav_menu_item[-7]\": {
        \"value\": {
            \"object_id\": 0,
            \"object\": \"\",
            \"menu_item_parent\": 0,
            \"position\": 2,
            \"type\": \"custom\",
            \"title\": \"\\u062a\\u0648\\u06cc\\u06cc\\u062a\\u0631\",
            \"url\": \"https://twitter.com/sepidsal\",
            \"target\": \"\",
            \"attr_title\": \"\",
            \"description\": \"\",
            \"classes\": \"\",
            \"xfn\": \"\",
            \"status\": \"publish\",
            \"original_title\": \"\",
            \"nav_menu_term_id\": -5,
            \"_invalid\": false,
            \"type_label\": \"\\u067e\\u06cc\\u0648\\u0646\\u062f \\u0633\\u0641\\u0627\\u0631\\u0634\\u06cc\"
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 01:37:53\"
    },
    \"nav_menu_item[-8]\": {
        \"value\": {
            \"object_id\": 0,
            \"object\": \"\",
            \"menu_item_parent\": 0,
            \"position\": 3,
            \"type\": \"custom\",
            \"title\": \"\\u0627\\u06cc\\u0646\\u0633\\u062a\\u0627\\u06af\\u0631\\u0627\\u0645\",
            \"url\": \"https://www.instagram.com/sepidsal\",
            \"target\": \"\",
            \"attr_title\": \"\",
            \"description\": \"\",
            \"classes\": \"\",
            \"xfn\": \"\",
            \"status\": \"publish\",
            \"original_title\": \"\",
            \"nav_menu_term_id\": -5,
            \"_invalid\": false,
            \"type_label\": \"\\u067e\\u06cc\\u0648\\u0646\\u062f \\u0633\\u0641\\u0627\\u0631\\u0634\\u06cc\"
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 01:37:53\"
    },
    \"nav_menu_item[-9]\": {
        \"value\": {
            \"object_id\": 0,
            \"object\": \"\",
            \"menu_item_parent\": 0,
            \"position\": 5,
            \"type\": \"custom\",
            \"title\": \"\\u0627\\u06cc\\u0645\\u06cc\\u0644\",
            \"url\": \"mailto:fullstackdiaries@gmail.com\",
            \"target\": \"\",
            \"attr_title\": \"\",
            \"description\": \"\",
            \"classes\": \"\",
            \"xfn\": \"\",
            \"status\": \"publish\",
            \"original_title\": \"\",
            \"nav_menu_term_id\": -5,
            \"_invalid\": false,
            \"type_label\": \"\\u067e\\u06cc\\u0648\\u0646\\u062f \\u0633\\u0641\\u0627\\u0631\\u0634\\u06cc\"
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 01:42:31\"
    },
    \"twentyseventeen::nav_menu_locations[social]\": {
        \"starter_content\": true,
        \"value\": -5,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 01:36:41\"
    },
    \"show_on_front\": {
        \"starter_content\": true,
        \"value\": \"page\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 01:36:41\"
    },
    \"page_on_front\": {
        \"starter_content\": true,
        \"value\": 26,
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 01:36:41\"
    },
    \"page_for_posts\": {
        \"starter_content\": true,
        \"value\": 29,
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 01:36:41\"
    },
    \"twentyseventeen::panel_1\": {
        \"starter_content\": true,
        \"value\": 30,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 01:36:41\"
    },
    \"twentyseventeen::panel_2\": {
        \"starter_content\": true,
        \"value\": 27,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 01:36:41\"
    },
    \"twentyseventeen::panel_3\": {
        \"starter_content\": true,
        \"value\": 29,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 01:36:41\"
    },
    \"twentyseventeen::panel_4\": {
        \"starter_content\": true,
        \"value\": 28,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 01:36:41\"
    },
    \"nav_menu_item[-2960679700142592000]\": {
        \"value\": {
            \"object_id\": 0,
            \"object\": \"custom\",
            \"menu_item_parent\": 0,
            \"position\": 4,
            \"type\": \"custom\",
            \"title\": \"\\u067e\\u06cc\\u0646\\u062a\\u0631\\u0633\\u062a\",
            \"url\": \"https://www.pinterest.com/sepidsal\",
            \"target\": \"\",
            \"attr_title\": \"\",
            \"description\": \"\",
            \"classes\": \"\",
            \"xfn\": \"\",
            \"status\": \"publish\",
            \"original_title\": \"\\u067e\\u06cc\\u0646\\u062a\\u0631\\u0633\\u062a\",
            \"nav_menu_term_id\": -5,
            \"_invalid\": false,
            \"type_label\": \"\\u067e\\u06cc\\u0648\\u0646\\u062f \\u0633\\u0641\\u0627\\u0631\\u0634\\u06cc\"
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 01:42:31\"
    }
}","","","trash","closed","closed","","07ee365d-3e3e-46c4-ab74-fa256f5cca18","","","2018-11-10 05:12:31","2018-11-10 01:42:31","","0","http://foolstacks.ir/?p=31","0","customize_changeset","","0");
INSERT INTO `st_posts` VALUES("57","1","2018-11-10 05:23:08","2018-11-10 01:53:08","درباره ما","درباره","","inherit","closed","closed","","27-autosave-v1","","","2018-11-10 05:23:08","2018-11-10 01:53:08","","27","http://foolstacks.ir/?p=57","0","revision","","0");
INSERT INTO `st_posts` VALUES("63","1","2018-11-10 05:27:16","2018-11-10 01:57:16","خودش آمدید!","خانه","","inherit","closed","closed","","26-revision-v1","","","2018-11-10 05:27:16","2018-11-10 01:57:16","","26","http://foolstacks.ir/?p=63","0","revision","","0");
INSERT INTO `st_posts` VALUES("32","1","2018-11-10 05:12:31","2018-11-10 01:42:31","به سایت خودتان خودش آمدید! این صفحه نخست شماست، چیزی که اکثر بازدیدکنندگان زمانی که برای اولین بار به وبسایت شما سر می‌زنند، آن را می‌بینند.","خانه","","inherit","closed","closed","","26-revision-v1","","","2018-11-10 05:12:31","2018-11-10 01:42:31","","26","http://foolstacks.ir/?p=32","0","revision","","0");
INSERT INTO `st_posts` VALUES("59","1","2018-11-10 05:24:50","2018-11-10 01:54:50","درباره ما","درباره","","inherit","closed","closed","","27-revision-v1","","","2018-11-10 05:24:50","2018-11-10 01:54:50","","27","http://foolstacks.ir/?p=59","0","revision","","0");
INSERT INTO `st_posts` VALUES("33","1","2018-11-10 05:12:31","2018-11-10 01:42:31","ممکن است شما هنرمندی باشید که تمایل دارد خودش و نمونه کارهایش را در این بخش معرفی کند یا شاید شما صاحب تجارتی باشید که می‌خواهید آن را معرفی کنید.","درباره","","inherit","closed","closed","","27-revision-v1","","","2018-11-10 05:12:31","2018-11-10 01:42:31","","27","http://foolstacks.ir/?p=33","0","revision","","0");
INSERT INTO `st_posts` VALUES("68","1","2018-11-10 05:29:05","2018-11-10 01:59:05","ارتباط","ارتباط","","inherit","closed","closed","","28-revision-v1","","","2018-11-10 05:29:05","2018-11-10 01:59:05","","28","http://foolstacks.ir/?p=68","0","revision","","0");
INSERT INTO `st_posts` VALUES("34","1","2018-11-10 05:12:31","2018-11-10 01:42:31","این یک صفحه شامل یک سری اطلاعات تماس ساده از قبیل نشانی و شماره تلفن است. همچنین می‌توانید از یک افزونه برای اضافه کردن فرم تماس استفاده کنید.","ارتباط","","inherit","closed","closed","","28-revision-v1","","","2018-11-10 05:12:31","2018-11-10 01:42:31","","28","http://foolstacks.ir/?p=34","0","revision","","0");
INSERT INTO `st_posts` VALUES("35","1","2018-11-10 05:12:31","2018-11-10 01:42:31","","بلاگ","","inherit","closed","closed","","29-revision-v1","","","2018-11-10 05:12:31","2018-11-10 01:42:31","","29","http://foolstacks.ir/?p=35","0","revision","","0");
INSERT INTO `st_posts` VALUES("65","1","2018-11-10 05:28:06","2018-11-10 01:58:06","بخش اول","یک بخش صفحه خانگی","","inherit","closed","closed","","30-revision-v1","","","2018-11-10 05:28:06","2018-11-10 01:58:06","","30","http://foolstacks.ir/?p=65","0","revision","","0");
INSERT INTO `st_posts` VALUES("36","1","2018-11-10 05:12:31","2018-11-10 01:42:31","این نمونه‌ای از یک بخش از صفحه‌ی نخست است. بخش‌های صفحه نخست می‌توانند از هر بخشی بجز خود صفحه نخست باشند، مانند برگه‌ای که آخرین نوشته‌های بلاگ شما را نمایش می‌دهد.","یک بخش صفحه خانگی","","inherit","closed","closed","","30-revision-v1","","","2018-11-10 05:12:31","2018-11-10 01:42:31","","30","http://foolstacks.ir/?p=36","0","revision","","0");
INSERT INTO `st_posts` VALUES("37","1","2018-11-10 05:12:31","2018-11-10 01:42:31","","خانه","","publish","closed","closed","","%d8%ae%d8%a7%d9%86%d9%87","","","2018-11-10 05:19:21","2018-11-10 01:49:21","","0","http://foolstacks.ir/?p=37","1","nav_menu_item","","0");
INSERT INTO `st_posts` VALUES("38","1","2018-11-10 05:12:31","2018-11-10 01:42:31"," ","","","publish","closed","closed","","38","","","2018-11-10 05:35:59","2018-11-10 02:05:59","","0","http://foolstacks.ir/?p=38","3","nav_menu_item","","0");
INSERT INTO `st_posts` VALUES("39","1","2018-11-10 05:12:31","2018-11-10 01:42:31"," ","","","publish","closed","closed","","39","","","2018-11-10 05:35:59","2018-11-10 02:05:59","","0","http://foolstacks.ir/?p=39","2","nav_menu_item","","0");
INSERT INTO `st_posts` VALUES("40","1","2018-11-10 05:12:31","2018-11-10 01:42:31"," ","","","publish","closed","closed","","40","","","2018-11-10 05:19:21","2018-11-10 01:49:21","","0","http://foolstacks.ir/?p=40","4","nav_menu_item","","0");
INSERT INTO `st_posts` VALUES("41","1","2018-11-10 05:12:31","2018-11-10 01:42:31","","فیسبوک","","publish","closed","closed","","%d9%81%db%8c%d8%b3%d8%a8%d9%88%da%a9","","","2018-11-10 05:12:31","2018-11-10 01:42:31","","0","http://foolstacks.ir/?p=41","1","nav_menu_item","","0");
INSERT INTO `st_posts` VALUES("42","1","2018-11-10 05:12:31","2018-11-10 01:42:31","","توییتر","","publish","closed","closed","","%d8%aa%d9%88%db%8c%db%8c%d8%aa%d8%b1","","","2018-11-10 05:12:31","2018-11-10 01:42:31","","0","http://foolstacks.ir/?p=42","2","nav_menu_item","","0");
INSERT INTO `st_posts` VALUES("43","1","2018-11-10 05:12:31","2018-11-10 01:42:31","","اینستاگرام","","publish","closed","closed","","%d8%a7%db%8c%d9%86%d8%b3%d8%aa%d8%a7%da%af%d8%b1%d8%a7%d9%85","","","2018-11-10 05:12:31","2018-11-10 01:42:31","","0","http://foolstacks.ir/?p=43","3","nav_menu_item","","0");
INSERT INTO `st_posts` VALUES("44","1","2018-11-10 05:12:31","2018-11-10 01:42:31","","ایمیل","","publish","closed","closed","","%d8%a7%db%8c%d9%85%db%8c%d9%84","","","2018-11-10 05:12:31","2018-11-10 01:42:31","","0","http://foolstacks.ir/?p=44","5","nav_menu_item","","0");
INSERT INTO `st_posts` VALUES("45","1","2018-11-10 05:12:31","2018-11-10 01:42:31","","پینترست","","publish","closed","closed","","%d9%be%db%8c%d9%86%d8%aa%d8%b1%d8%b3%d8%aa","","","2018-11-10 05:12:31","2018-11-10 01:42:31","","0","http://foolstacks.ir/?p=45","4","nav_menu_item","","0");
INSERT INTO `st_posts` VALUES("46","1","2018-11-10 05:15:37","2018-11-10 01:45:37","{
    \"nav_menu_item[-6471496235699804000]\": {
        \"value\": {
            \"object_id\": 0,
            \"object\": \"custom\",
            \"menu_item_parent\": 0,
            \"position\": 6,
            \"type\": \"custom\",
            \"title\": \"\\u0644\\u06cc\\u0646\\u06a9\\u062f\\u0627\\u06cc\\u0646\",
            \"url\": \"https://www.linkedin.com/in/sepideh-saljooghi-94a69a68/\",
            \"target\": \"\",
            \"attr_title\": \"\",
            \"description\": \"\",
            \"classes\": \"\",
            \"xfn\": \"\",
            \"status\": \"publish\",
            \"original_title\": \"\\u0644\\u06cc\\u0646\\u06a9\\u062f\\u0627\\u06cc\\u0646\",
            \"nav_menu_term_id\": 3,
            \"_invalid\": false,
            \"type_label\": \"\\u067e\\u06cc\\u0648\\u0646\\u062f \\u0633\\u0641\\u0627\\u0631\\u0634\\u06cc\"
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 01:44:12\"
    },
    \"nav_menu_item[-3189429963029987300]\": {
        \"value\": {
            \"object_id\": 0,
            \"object\": \"custom\",
            \"menu_item_parent\": 0,
            \"position\": 7,
            \"type\": \"custom\",
            \"title\": \"\\u06af\\u06cc\\u062a \\u0647\\u0627\\u0628\",
            \"url\": \"https://github.com/SepidSal\",
            \"target\": \"\",
            \"attr_title\": \"\",
            \"description\": \"\",
            \"classes\": \"\",
            \"xfn\": \"\",
            \"status\": \"publish\",
            \"original_title\": \"\\u06af\\u06cc\\u062a \\u0647\\u0627\\u0628\",
            \"nav_menu_term_id\": 3,
            \"_invalid\": false,
            \"type_label\": \"\\u067e\\u06cc\\u0648\\u0646\\u062f \\u0633\\u0641\\u0627\\u0631\\u0634\\u06cc\"
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 01:45:37\"
    }
}","","","trash","closed","closed","","b9932513-5039-42b3-a8c3-a5598b066da3","","","2018-11-10 05:15:37","2018-11-10 01:45:37","","0","http://foolstacks.ir/?p=46","0","customize_changeset","","0");
INSERT INTO `st_posts` VALUES("47","1","2018-11-10 05:15:37","2018-11-10 01:45:37","","لینکداین","","publish","closed","closed","","%d9%84%db%8c%d9%86%da%a9%d8%af%d8%a7%db%8c%d9%86","","","2018-11-10 05:15:37","2018-11-10 01:45:37","","0","http://foolstacks.ir/?p=47","6","nav_menu_item","","0");
INSERT INTO `st_posts` VALUES("48","1","2018-11-10 05:15:37","2018-11-10 01:45:37","","گیت هاب","","publish","closed","closed","","%da%af%db%8c%d8%aa-%d9%87%d8%a7%d8%a8","","","2018-11-10 05:15:37","2018-11-10 01:45:37","","0","http://foolstacks.ir/?p=48","7","nav_menu_item","","0");
INSERT INTO `st_posts` VALUES("49","1","2018-11-10 05:17:56","2018-11-10 01:47:56","{
    \"widget_text[8]\": {
        \"value\": {
            \"encoded_serialized_instance\": \"YTo0OntzOjU6InRpdGxlIjtzOjA6IiI7czo0OiJ0ZXh0IjtzOjUyOiI8c3Ryb25nPtmG2LTYp9mG24w8L3N0cm9uZz4NCtin24zYsdin2YYgLSDYqtmH2LHYp9mGIjtzOjY6ImZpbHRlciI7YjoxO3M6NjoidmlzdWFsIjtiOjE7fQ==\",
            \"title\": \"\",
            \"is_widget_customizer_js_value\": true,
            \"instance_hash_key\": \"ff6c119d4dd671503a74e8ba712b3830\"
        },
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 01:47:56\"
    }
}","","","trash","closed","closed","","1c89aefb-acbe-46ee-a855-fb05cdbc316d","","","2018-11-10 05:17:56","2018-11-10 01:47:56","","0","http://foolstacks.ir/?p=49","0","customize_changeset","","0");
INSERT INTO `st_posts` VALUES("50","1","2018-11-10 05:18:41","2018-11-10 01:48:41","{
    \"widget_text[9]\": {
        \"value\": {
            \"encoded_serialized_instance\": \"YTo0OntzOjU6InRpdGxlIjtzOjI4OiLYr9ix2KjYp9ix2Ycg2KfbjNmGINiz2KfbjNiqIjtzOjQ6InRleHQiO3M6NTU6Itin2LIg2q/ZiNi02Ycg2Ygg2qnZhtin2LHZh9in24wg2LLZhtiv2q/bjCDYsdmI2LLZhdix2YciO3M6NjoiZmlsdGVyIjtiOjE7czo2OiJ2aXN1YWwiO2I6MTt9\",
            \"title\": \"\\u062f\\u0631\\u0628\\u0627\\u0631\\u0647 \\u0627\\u06cc\\u0646 \\u0633\\u0627\\u06cc\\u062a\",
            \"is_widget_customizer_js_value\": true,
            \"instance_hash_key\": \"1f1014a579db323f878083e0d653d7cd\"
        },
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 01:48:41\"
    }
}","","","trash","closed","closed","","9f8654ce-7718-4091-b9b9-de607e10e146","","","2018-11-10 05:18:41","2018-11-10 01:48:41","","0","http://foolstacks.ir/?p=50","0","customize_changeset","","0");
INSERT INTO `st_posts` VALUES("51","1","2018-11-10 05:19:21","2018-11-10 01:49:21","{
    \"nav_menu_item[37]\": {
        \"value\": {
            \"object_id\": 0,
            \"object\": \"\",
            \"menu_item_parent\": 0,
            \"position\": 1,
            \"type\": \"custom\",
            \"title\": \"\\u062e\\u0627\\u0646\\u0647\",
            \"url\": \"http://foolstacks.ir/\",
            \"target\": \"\",
            \"attr_title\": \"\",
            \"description\": \"\",
            \"classes\": \"\",
            \"xfn\": \"\",
            \"status\": \"publish\",
            \"original_title\": \"\",
            \"nav_menu_term_id\": 2,
            \"_invalid\": false,
            \"type_label\": \"\\u067e\\u06cc\\u0648\\u0646\\u062f \\u0633\\u0641\\u0627\\u0631\\u0634\\u06cc\"
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 01:49:11\"
    },
    \"nav_menu_item[38]\": {
        \"value\": {
            \"object_id\": 27,
            \"object\": \"page\",
            \"menu_item_parent\": 0,
            \"position\": 2,
            \"type\": \"post_type\",
            \"title\": \"\\u062f\\u0631\\u0628\\u0627\\u0631\\u0647\",
            \"url\": \"\",
            \"target\": \"\",
            \"attr_title\": \"\",
            \"description\": \"\",
            \"classes\": \"\",
            \"xfn\": \"\",
            \"status\": \"publish\",
            \"original_title\": \"\\u062f\\u0631\\u0628\\u0627\\u0631\\u0647\",
            \"nav_menu_term_id\": 2,
            \"_invalid\": false,
            \"type_label\": \"\\u0628\\u0631\\u06af\\u0647\"
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 01:49:11\"
    },
    \"nav_menu_item[39]\": {
        \"value\": {
            \"object_id\": 29,
            \"object\": \"page\",
            \"menu_item_parent\": 0,
            \"position\": 3,
            \"type\": \"post_type\",
            \"title\": \"\\u0628\\u0644\\u0627\\u06af\",
            \"url\": \"\",
            \"target\": \"\",
            \"attr_title\": \"\",
            \"description\": \"\",
            \"classes\": \"\",
            \"xfn\": \"\",
            \"status\": \"publish\",
            \"original_title\": \"\\u0628\\u0644\\u0627\\u06af\",
            \"nav_menu_term_id\": 2,
            \"_invalid\": false,
            \"type_label\": \"\\u0628\\u0631\\u06af\\u0647\"
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 01:49:11\"
    },
    \"nav_menu_item[40]\": {
        \"value\": {
            \"object_id\": 28,
            \"object\": \"page\",
            \"menu_item_parent\": 0,
            \"position\": 4,
            \"type\": \"post_type\",
            \"title\": \"\\u0627\\u0631\\u062a\\u0628\\u0627\\u0637\",
            \"url\": \"\",
            \"target\": \"\",
            \"attr_title\": \"\",
            \"description\": \"\",
            \"classes\": \"\",
            \"xfn\": \"\",
            \"status\": \"publish\",
            \"original_title\": \"\\u0627\\u0631\\u062a\\u0628\\u0627\\u0637\",
            \"nav_menu_term_id\": 2,
            \"_invalid\": false,
            \"type_label\": \"\\u0628\\u0631\\u06af\\u0647\"
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 01:49:11\"
    }
}","","","trash","closed","closed","","978f4f43-64a8-4885-a95f-51284fbc0a5f","","","2018-11-10 05:19:21","2018-11-10 01:49:21","","0","http://foolstacks.ir/?p=51","0","customize_changeset","","0");
INSERT INTO `st_posts` VALUES("52","1","2018-11-10 05:19:52","2018-11-10 01:49:52","","s1","","inherit","open","closed","","s1","","","2018-11-10 05:19:52","2018-11-10 01:49:52","","0","http://foolstacks.ir/wp-content/uploads/2018/11/s1.png","0","attachment","image/png","0");
INSERT INTO `st_posts` VALUES("53","1","2018-11-10 05:20:11","2018-11-10 01:50:11","{
    \"blogdescription\": {
        \"value\": \"\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 01:50:11\"
    },
    \"site_icon\": {
        \"value\": 52,
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 01:50:11\"
    }
}","","","trash","closed","closed","","b89aa5f3-8ef8-4d9b-a2c0-235c8bc2894c","","","2018-11-10 05:20:11","2018-11-10 01:50:11","","0","http://foolstacks.ir/?p=53","0","customize_changeset","","0");
INSERT INTO `st_posts` VALUES("54","1","2018-11-10 05:20:25","2018-11-10 01:50:25","","fullstack","","inherit","open","closed","","images","","","2018-11-10 05:20:41","2018-11-10 01:50:41","","0","http://foolstacks.ir/wp-content/uploads/2018/11/images.png","0","attachment","image/png","0");
INSERT INTO `st_posts` VALUES("55","1","2018-11-10 05:20:44","2018-11-10 01:50:44","http://foolstacks.ir/wp-content/uploads/2018/11/cropped-images.png","cropped-images.png","","inherit","open","closed","","cropped-images-png","","","2018-11-10 05:20:44","2018-11-10 01:50:44","","0","http://foolstacks.ir/wp-content/uploads/2018/11/cropped-images.png","0","attachment","image/png","0");
INSERT INTO `st_posts` VALUES("56","1","2018-11-10 05:20:52","2018-11-10 01:50:52","{
    \"twentyseventeen::custom_logo\": {
        \"value\": 55,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 01:50:52\"
    }
}","","","trash","closed","closed","","a9467613-ceac-4af4-9348-058f612914d5","","","2018-11-10 05:20:52","2018-11-10 01:50:52","","0","http://foolstacks.ir/?p=56","0","customize_changeset","","0");
INSERT INTO `st_posts` VALUES("61","1","2018-11-10 05:26:27","2018-11-10 01:56:27","","home","","inherit","open","closed","","wallpaper-wiki-cute-girl-for-background-pic-wpc003570","","","2018-11-10 05:26:33","2018-11-10 01:56:33","","26","http://foolstacks.ir/wp-content/uploads/2018/11/wallpaper.wiki-Cute-Girl-for-Background-PIC-WPC003570.jpg","0","attachment","image/jpeg","0");
INSERT INTO `st_posts` VALUES("62","1","2018-11-10 05:26:38","2018-11-10 01:56:38","به سایت خودتان خودش آمدید! این صفحه نخست شماست، چیزی که اکثر بازدیدکنندگان زمانی که برای اولین بار به وبسایت شما سر می‌زنند، آن را می‌بینند.","خانه","","inherit","closed","closed","","26-autosave-v1","","","2018-11-10 05:26:38","2018-11-10 01:56:38","","26","http://foolstacks.ir/?p=62","0","revision","","0");
INSERT INTO `st_posts` VALUES("67","1","2018-11-10 05:28:40","2018-11-10 01:58:40","","contact","","inherit","open","closed","","d16b2da711934b95012afad351db7b509bb703614c7d7-gsbnoa-1","","","2018-11-10 05:28:49","2018-11-10 01:58:49","","28","http://foolstacks.ir/wp-content/uploads/2018/11/d16b2da711934b95012afad351db7b509bb703614c7d7-GsBNoa-1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `st_posts` VALUES("70","1","2018-11-10 05:30:19","2018-11-10 02:00:19","این یک برگه‌ی نمونه است که با یک نوشته در وبلاگ تفاوت دارد زیرا برگه‌ها در یک مکان ثابت می‌مانند و معمولاً در فهرست پیوندهای درونی سایت شما نمایش داده می‌شوند (در بیشتر پوسته‌ها). بیشتر افراد کار کردن با برگه‌ها را از یک برگه‌ی «درباره من» که آن‌ها را به خوانندگان سایت معرفی می‌کند، شروع می‌کنند. برای مثال این‌چنین می‌گویند:

<blockquote>سلام دوستان، من روزها یک کارمند اداری هستم و شب‌ها یک راننده تاکسی، این وبلاگ من است. من در اهواز زندگی می‌کنم که شهری در جنوب غربی ایران است.</blockquote>

یا چیزی شبیه این:

<blockquote>شرکت XYZ در سال ۱۳۶۵ تاسیس شد و ارائه‌دهنده محصولات صنعتی است. این شرکت ۲۰۰۰ کارگر و کارمند دارد. امیدواریم از محصولات ما راضی باشید.</blockquote>

به‌عنوان یک کاربر تازه‌ی وردپرس فارسی شما برای پاک کردن این برگه و ساختن برگه‌های تازه می‌توانید به <a href=\"http://foolstacks.ir/wp-admin/\">پیشخوان خود</a> مراجعه کنید. موفق باشید!","برگه نمونه","","inherit","closed","closed","","2-revision-v1","","","2018-11-10 05:30:19","2018-11-10 02:00:19","","2","http://foolstacks.ir/?p=70","0","revision","","0");
INSERT INTO `st_posts` VALUES("71","1","2018-11-10 05:33:08","2018-11-10 02:03:08","","myship","","inherit","open","closed","","myship","","","2018-11-10 05:33:08","2018-11-10 02:03:08","","0","http://foolstacks.ir/wp-content/uploads/2018/11/myship.jpg","0","attachment","image/jpeg","0");
INSERT INTO `st_posts` VALUES("72","1","2018-11-10 05:33:15","2018-11-10 02:03:15","","cropped-myship.jpg","","inherit","open","closed","","cropped-myship-jpg","","","2018-11-10 05:33:15","2018-11-10 02:03:15","","0","http://foolstacks.ir/wp-content/uploads/2018/11/cropped-myship.jpg","0","attachment","image/jpeg","0");
INSERT INTO `st_posts` VALUES("73","1","2018-11-10 05:33:29","2018-11-10 02:03:29","{
    \"twentyseventeen::header_image\": {
        \"value\": \"http://foolstacks.ir/wp-content/uploads/2018/11/cropped-myship.jpg\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 02:03:29\"
    },
    \"twentyseventeen::header_image_data\": {
        \"value\": {
            \"url\": \"http://foolstacks.ir/wp-content/uploads/2018/11/cropped-myship.jpg\",
            \"thumbnail_url\": \"http://foolstacks.ir/wp-content/uploads/2018/11/cropped-myship.jpg\",
            \"timestamp\": 1541815398287,
            \"attachment_id\": 72,
            \"width\": 2000,
            \"height\": 1250
        },
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 02:03:29\"
    }
}","","","trash","closed","closed","","82b0f99a-0a51-4050-9f49-e5a261783893","","","2018-11-10 05:33:29","2018-11-10 02:03:29","","0","http://foolstacks.ir/?p=73","0","customize_changeset","","0");
INSERT INTO `st_posts` VALUES("74","1","2018-11-10 05:35:59","2018-11-10 02:05:59","{
    \"nav_menu_item[38]\": {
        \"value\": {
            \"menu_item_parent\": 0,
            \"object_id\": 27,
            \"object\": \"page\",
            \"type\": \"post_type\",
            \"type_label\": \"\\u0628\\u0631\\u06af\\u0647\",
            \"url\": \"http://foolstacks.ir/?page_id=27\",
            \"title\": \"\",
            \"target\": \"\",
            \"attr_title\": \"\",
            \"description\": \"\",
            \"classes\": \"\",
            \"xfn\": \"\",
            \"nav_menu_term_id\": 2,
            \"position\": 3,
            \"status\": \"publish\",
            \"original_title\": \"\\u062f\\u0631\\u0628\\u0627\\u0631\\u0647\",
            \"_invalid\": false
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 02:05:59\"
    },
    \"nav_menu_item[39]\": {
        \"value\": {
            \"menu_item_parent\": 0,
            \"object_id\": 29,
            \"object\": \"page\",
            \"type\": \"post_type\",
            \"type_label\": \"\\u0628\\u0631\\u06af\\u0647\",
            \"url\": \"http://foolstacks.ir/?page_id=29\",
            \"title\": \"\",
            \"target\": \"\",
            \"attr_title\": \"\",
            \"description\": \"\",
            \"classes\": \"\",
            \"xfn\": \"\",
            \"nav_menu_term_id\": 2,
            \"position\": 2,
            \"status\": \"publish\",
            \"original_title\": \"\\u0628\\u0644\\u0627\\u06af\",
            \"_invalid\": false
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 02:05:59\"
    }
}","","","trash","closed","closed","","136e30b9-6460-4a5b-bdb6-2314733d2bd9","","","2018-11-10 05:35:59","2018-11-10 02:05:59","","0","http://foolstacks.ir/?p=74","0","customize_changeset","","0");
INSERT INTO `st_posts` VALUES("75","1","2018-11-10 05:38:53","2018-11-10 02:08:53","به وردپرس فارسی خوش آمدید.‌ این نخستین نوشته‌‌ی شماست. می‌توانید ویرایش یا پاکش کنید و پس از آن نوشتن را آغاز کنید!","سلام دنیا!","","inherit","closed","closed","","1-revision-v1","","","2018-11-10 05:38:53","2018-11-10 02:08:53","","1","http://foolstacks.ir/?p=75","0","revision","","0");
INSERT INTO `st_posts` VALUES("77","1","2018-11-10 05:39:34","2018-11-10 02:09:34","","ا","","inherit","open","closed","","402965393-happy-wallpapers","","","2018-11-10 05:39:40","2018-11-10 02:09:40","","1","http://foolstacks.ir/wp-content/uploads/2018/11/402965393-happy-wallpapers.jpg","0","attachment","image/jpeg","0");
INSERT INTO `st_posts` VALUES("78","1","2018-11-10 05:39:54","2018-11-10 02:09:54","","enjoy life","","inherit","open","closed","","cute-3","","","2018-11-10 05:40:07","2018-11-10 02:10:07","","1","http://foolstacks.ir/wp-content/uploads/2018/11/cute-3.jpg","0","attachment","image/jpeg","0");
INSERT INTO `st_posts` VALUES("79","1","2018-11-10 05:42:58","2018-11-10 02:12:58","{
    \"sidebars_widgets[sidebar-1]\": {
        \"value\": [
            \"search-3\",
            \"text-7\"
        ],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 02:12:58\"
    },
    \"twentyseventeen::custom_logo\": {
        \"value\": \"\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 02:12:58\"
    }
}","","","trash","closed","closed","","1bd51cdd-507f-445f-8cdd-c81eb97e26d2","","","2018-11-10 05:42:58","2018-11-10 02:12:58","","0","http://foolstacks.ir/?p=79","0","customize_changeset","","0");
INSERT INTO `st_posts` VALUES("80","1","2018-11-10 05:43:34","2018-11-10 02:13:34","{
    \"sidebars_widgets[sidebar-1]\": {
        \"value\": [
            \"search-3\"
        ],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 02:13:34\"
    }
}","","","trash","closed","closed","","78209f7a-a5cf-43c3-9a95-bad85b2e899e","","","2018-11-10 05:43:34","2018-11-10 02:13:34","","0","http://foolstacks.ir/?p=80","0","customize_changeset","","0");
INSERT INTO `st_posts` VALUES("2258","1","2018-11-13 13:20:49","0000-00-00 00:00:00","eyJmaWx0ZXIiOiJyYXciLCJtZXRhX2lkIjoiNzA2IiwicG9zdF9pZCI6IjIyNTgiLCJtZXRhX2tleSI6Im5hbWUiLCJtZXRhX3ZhbHVlIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX3RodW1ibmFpbHMiLCJ0aXRsZSI6Ik5leHRHRU4gQmFzaWMgVGh1bWJuYWlscyIsIm1vZHVsZV9pZCI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY19nYWxsZXJ5IiwiZW50aXR5X3R5cGVzIjpbImltYWdlIl0sInByZXZpZXdfaW1hZ2VfcmVscGF0aCI6IlwvbmV4dGdlbi1nYWxsZXJ5XC9wcm9kdWN0c1wvcGhvdG9jcmF0aV9uZXh0Z2VuXC9tb2R1bGVzXC9uZXh0Z2VuX2Jhc2ljX2dhbGxlcnlcL3N0YXRpY1wvdGh1bWJfcHJldmlldy5qcGciLCJkZWZhdWx0X3NvdXJjZSI6ImdhbGxlcmllcyIsInZpZXdfb3JkZXIiOjEwMDAwLCJhbGlhc2VzIjpbImJhc2ljX3RodW1ibmFpbCIsImJhc2ljX3RodW1ibmFpbHMiLCJuZXh0Z2VuX2Jhc2ljX3RodW1ibmFpbHMiXSwibmFtZSI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY190aHVtYm5haWxzIiwiaW5zdGFsbGVkX2F0X3ZlcnNpb24iOiIzLjAuMTYiLCJpZF9maWVsZCI6IklEIiwic2V0dGluZ3MiOnsib3ZlcnJpZGVfdGh1bWJuYWlsX3NldHRpbmdzIjoiMCIsInRodW1ibmFpbF93aWR0aCI6IjI0MCIsInRodW1ibmFpbF9oZWlnaHQiOiIxNjAiLCJ0aHVtYm5haWxfY3JvcCI6IjEiLCJpbWFnZXNfcGVyX3BhZ2UiOiIxNiIsIm51bWJlcl9vZl9jb2x1bW5zIjoiMCIsImFqYXhfcGFnaW5hdGlvbiI6IjEiLCJzaG93X2FsbF9pbl9saWdodGJveCI6IjAiLCJ1c2VfaW1hZ2Vicm93c2VyX2VmZmVjdCI6IjAiLCJzaG93X3NsaWRlc2hvd19saW5rIjoiMCIsInNsaWRlc2hvd19saW5rX3RleHQiOiJWaWV3IFNsaWRlc2hvdyIsImRpc3BsYXlfdmlldyI6ImRlZmF1bHQtdmlldy5waHAiLCJ0ZW1wbGF0ZSI6IiIsInVzZV9saWdodGJveF9lZmZlY3QiOnRydWUsImRpc3BsYXlfbm9faW1hZ2VzX2Vycm9yIjoxLCJkaXNhYmxlX3BhZ2luYXRpb24iOjAsInRodW1ibmFpbF9xdWFsaXR5IjoiMTAwIiwidGh1bWJuYWlsX3dhdGVybWFyayI6MCwibmdnX3RyaWdnZXJzX2Rpc3BsYXkiOiJuZXZlciIsIl9lcnJvcnMiOltdfSwiaGlkZGVuX2Zyb21fdWkiOmZhbHNlLCJoaWRkZW5fZnJvbV9pZ3ciOmZhbHNlLCJfX2RlZmF1bHRzX3NldCI6dHJ1ZX0=","NextGEN Basic Thumbnails","","draft","closed","closed","","","","","2018-11-14 12:37:24","2018-11-14 09:07:24","eyJmaWx0ZXIiOiJyYXciLCJtZXRhX2lkIjoiNzA2IiwicG9zdF9pZCI6IjIyNTgiLCJtZXRhX2tleSI6Im5hbWUiLCJtZXRhX3ZhbHVlIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX3RodW1ibmFpbHMiLCJ0aXRsZSI6Ik5leHRHRU4gQmFzaWMgVGh1bWJuYWlscyIsIm1vZHVsZV9pZCI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY19nYWxsZXJ5IiwiZW50aXR5X3R5cGVzIjpbImltYWdlIl0sInByZXZpZXdfaW1hZ2VfcmVscGF0aCI6IlwvbmV4dGdlbi1nYWxsZXJ5XC9wcm9kdWN0c1wvcGhvdG9jcmF0aV9uZXh0Z2VuXC9tb2R1bGVzXC9uZXh0Z2VuX2Jhc2ljX2dhbGxlcnlcL3N0YXRpY1wvdGh1bWJfcHJldmlldy5qcGciLCJkZWZhdWx0X3NvdXJjZSI6ImdhbGxlcmllcyIsInZpZXdfb3JkZXIiOjEwMDAwLCJhbGlhc2VzIjpbImJhc2ljX3RodW1ibmFpbCIsImJhc2ljX3RodW1ibmFpbHMiLCJuZXh0Z2VuX2Jhc2ljX3RodW1ibmFpbHMiXSwibmFtZSI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY190aHVtYm5haWxzIiwiaW5zdGFsbGVkX2F0X3ZlcnNpb24iOiIzLjAuMTYiLCJpZF9maWVsZCI6IklEIiwic2V0dGluZ3MiOnsib3ZlcnJpZGVfdGh1bWJuYWlsX3NldHRpbmdzIjoiMCIsInRodW1ibmFpbF93aWR0aCI6IjI0MCIsInRodW1ibmFpbF9oZWlnaHQiOiIxNjAiLCJ0aHVtYm5haWxfY3JvcCI6IjEiLCJpbWFnZXNfcGVyX3BhZ2UiOiIxNiIsIm51bWJlcl9vZl9jb2x1bW5zIjoiMCIsImFqYXhfcGFnaW5hdGlvbiI6IjEiLCJzaG93X2FsbF9pbl9saWdodGJveCI6IjAiLCJ1c2VfaW1hZ2Vicm93c2VyX2VmZmVjdCI6IjAiLCJzaG93X3NsaWRlc2hvd19saW5rIjoiMCIsInNsaWRlc2hvd19saW5rX3RleHQiOiJWaWV3IFNsaWRlc2hvdyIsImRpc3BsYXlfdmlldyI6ImRlZmF1bHQtdmlldy5waHAiLCJ0ZW1wbGF0ZSI6IiIsInVzZV9saWdodGJveF9lZmZlY3QiOnRydWUsImRpc3BsYXlfbm9faW1hZ2VzX2Vycm9yIjoxLCJkaXNhYmxlX3BhZ2luYXRpb24iOjAsInRodW1ibmFpbF9xdWFsaXR5IjoiMTAwIiwidGh1bWJuYWlsX3dhdGVybWFyayI6MCwibmdnX3RyaWdnZXJzX2Rpc3BsYXkiOiJuZXZlciIsIl9lcnJvcnMiOltdfSwiaGlkZGVuX2Zyb21fdWkiOmZhbHNlLCJoaWRkZW5fZnJvbV9pZ3ciOmZhbHNlLCJfX2RlZmF1bHRzX3NldCI6dHJ1ZX0=","0","http://foolstacks.ir/?post_type=display_type&#038;p=2258","0","display_type","","0");
INSERT INTO `st_posts` VALUES("83","1","2018-07-05 05:47:43","2018-07-05 05:47:43","تست 1","تست1","","publish","open","open","","%d8%aa%d8%b3%d8%aa1","","","2018-11-13 13:33:29","2018-11-13 14:33:29","","0","http://foolstacks.ir/?p=83","0","post","","0");
INSERT INTO `st_posts` VALUES("84","1","2018-11-10 05:47:43","2018-11-10 02:17:43","تست 1","تست1","","inherit","closed","closed","","83-revision-v1","","","2018-11-10 05:47:43","2018-11-10 02:17:43","","83","http://foolstacks.ir/?p=84","0","revision","","0");
INSERT INTO `st_posts` VALUES("85","1","2018-08-10 05:48:34","2018-08-10 05:48:34","تست 2","تست 2","","publish","open","open","","%d8%aa%d8%b3%d8%aa-2","","","2018-11-13 13:33:45","2018-11-13 14:33:45","","0","http://foolstacks.ir/?p=85","0","post","","0");
INSERT INTO `st_posts` VALUES("86","1","2018-11-10 05:48:34","2018-11-10 02:18:34","تست 2","تست 2","","inherit","closed","closed","","85-revision-v1","","","2018-11-10 05:48:34","2018-11-10 02:18:34","","85","http://foolstacks.ir/?p=86","0","revision","","0");
INSERT INTO `st_posts` VALUES("87","1","2018-09-17 05:49:08","2018-09-17 05:49:08","","تست 3","","publish","open","open","","%d8%aa%d8%b3%d8%aa-3","","","2018-11-13 13:33:57","2018-11-13 14:33:57","","0","http://foolstacks.ir/?p=87","0","post","","0");
INSERT INTO `st_posts` VALUES("88","1","2018-11-10 05:49:08","2018-11-10 02:19:08","","تست 3","","inherit","closed","closed","","87-revision-v1","","","2018-11-10 05:49:08","2018-11-10 02:19:08","","87","http://foolstacks.ir/?p=88","0","revision","","0");
INSERT INTO `st_posts` VALUES("89","1","2015-03-11 14:14:10","2015-03-11 14:14:10","","home_webdesign_slide1_bg","","inherit","open","open","","home_webdesign_slide1_bg","","","2015-03-11 14:14:10","2015-03-11 14:14:10","","0","http://foolstacks.ir/wp-content/uploads/2015/03/home_webdesign_slide1_bg.jpg","0","attachment","image/jpeg","0");
INSERT INTO `st_posts` VALUES("90","1","2015-03-11 15:18:52","2015-03-11 15:18:52","","home_webdesign_slider_sep","","inherit","open","open","","home_webdesign_slider_sep","","","2015-03-11 15:18:52","2015-03-11 15:18:52","","0","http://foolstacks.ir/wp-content/uploads/2015/03/home_webdesign_slider_sep.png","0","attachment","image/png","0");
INSERT INTO `st_posts` VALUES("91","1","2015-03-12 08:54:48","2015-03-12 08:54:48","","home_webdesign_newsletter_bg","","inherit","open","open","","home_webdesign_newsletter_bg","","","2015-03-12 08:54:48","2015-03-12 08:54:48","","0","http://foolstacks.ir/wp-content/uploads/2015/03/home_webdesign_newsletter_bg.jpg","0","attachment","image/jpeg","0");
INSERT INTO `st_posts` VALUES("92","1","2015-03-12 08:55:37","2015-03-12 08:55:37","","home_webdesign_new","","inherit","open","open","","home_webdesign_new","","","2015-03-12 08:55:37","2015-03-12 08:55:37","","0","http://foolstacks.ir/wp-content/uploads/2015/03/home_webdesign_new.png","0","attachment","image/png","0");
INSERT INTO `st_posts` VALUES("93","1","2015-03-12 09:52:30","2015-03-12 09:52:30","","client_11","","inherit","open","open","","client_11","","","2015-03-12 09:52:30","2015-03-12 09:52:30","","0","http://foolstacks.ir/wp-content/uploads/2015/03/client_11.png","0","attachment","image/png","0");
INSERT INTO `st_posts` VALUES("94","1","2015-03-12 09:52:30","2015-03-12 09:52:30","","client_22","","inherit","open","open","","client_22","","","2015-03-12 09:52:30","2015-03-12 09:52:30","","0","http://foolstacks.ir/wp-content/uploads/2015/03/client_22.png","0","attachment","image/png","0");
INSERT INTO `st_posts` VALUES("95","1","2015-03-12 09:52:30","2015-03-12 09:52:30","","client_33","","inherit","open","open","","client_33","","","2015-03-12 09:52:30","2015-03-12 09:52:30","","0","http://foolstacks.ir/wp-content/uploads/2015/03/client_33.png","0","attachment","image/png","0");
INSERT INTO `st_posts` VALUES("23","1","2015-03-12 09:52:30","2015-03-12 09:52:30","","client_44","","inherit","open","open","","client_44","","","2015-03-12 09:52:30","2015-03-12 09:52:30","","0","http://foolstacks.ir/wp-content/uploads/2015/03/client_44.png","0","attachment","image/png","0");
INSERT INTO `st_posts` VALUES("96","1","2015-03-12 09:57:41","2015-03-12 09:57:41","","home_webdesign_pattern1","","inherit","open","open","","home_webdesign_pattern1","","","2015-03-12 09:57:41","2015-03-12 09:57:41","","0","http://foolstacks.ir/wp-content/uploads/2015/03/home_webdesign_pattern1.png","0","attachment","image/png","0");
INSERT INTO `st_posts` VALUES("97","1","2015-03-12 10:25:39","2015-03-12 10:25:39","","home_webdesign_about_bg","","inherit","open","open","","home_webdesign_about_bg","","","2015-03-12 10:25:39","2015-03-12 10:25:39","","0","http://foolstacks.ir/wp-content/uploads/2015/03/home_webdesign_about_bg.jpg","0","attachment","image/jpeg","0");
INSERT INTO `st_posts` VALUES("98","1","2015-03-12 11:01:57","2015-03-12 11:01:57","","client_1","","inherit","open","open","","client_1","","","2015-03-12 11:01:57","2015-03-12 11:01:57","","0","http://foolstacks.ir/wp-content/uploads/2015/03/client_1.png","0","attachment","image/png","0");
INSERT INTO `st_posts` VALUES("99","1","2015-03-12 11:01:58","2015-03-12 11:01:58","","client_2","","inherit","open","open","","client_2","","","2015-03-12 11:01:58","2015-03-12 11:01:58","","0","http://foolstacks.ir/wp-content/uploads/2015/03/client_2.png","0","attachment","image/png","0");
INSERT INTO `st_posts` VALUES("100","1","2015-03-12 11:01:58","2015-03-12 11:01:58","","client_3","","inherit","open","open","","client_3","","","2015-03-12 11:01:58","2015-03-12 11:01:58","","0","http://foolstacks.ir/wp-content/uploads/2015/03/client_3.png","0","attachment","image/png","0");
INSERT INTO `st_posts` VALUES("101","1","2015-03-12 11:01:59","2015-03-12 11:01:59","","client_4","","inherit","open","open","","client_4","","","2015-03-12 11:01:59","2015-03-12 11:01:59","","0","http://foolstacks.ir/wp-content/uploads/2015/03/client_4.png","0","attachment","image/png","0");
INSERT INTO `st_posts` VALUES("102","1","2015-03-12 11:05:59","2015-03-12 11:05:59","","home_webdesign_pattern2","","inherit","open","open","","home_webdesign_pattern2","","","2015-03-12 11:05:59","2015-03-12 11:05:59","","0","http://foolstacks.ir/wp-content/uploads/2015/03/home_webdesign_pattern2.png","0","attachment","image/png","0");
INSERT INTO `st_posts` VALUES("103","1","2015-03-12 11:36:25","2015-03-12 11:36:25","","home_webdesign_ico_c","","inherit","open","open","","home_webdesign_ico_c","","","2015-03-12 11:36:25","2015-03-12 11:36:25","","0","http://foolstacks.ir/wp-content/uploads/2015/03/home_webdesign_ico_c.png","0","attachment","image/png","0");
INSERT INTO `st_posts` VALUES("104","1","2015-03-12 11:52:47","2015-03-12 11:52:47","","home_webdesign_pattern3","","inherit","open","open","","home_webdesign_pattern3","","","2015-03-12 11:52:47","2015-03-12 11:52:47","","0","http://foolstacks.ir/wp-content/uploads/2015/03/home_webdesign_pattern3.png","0","attachment","image/png","0");
INSERT INTO `st_posts` VALUES("105","1","2018-03-10 13:08:25","2018-03-10 14:08:25","Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!","Hello world!","","trash","open","open","","hello-world__trashed","","","2018-11-13 19:06:35","2018-11-13 20:06:35","","0","http://themes.muffingroup.com/be/webdesign/?p=1","0","post","","1");
INSERT INTO `st_posts` VALUES("106","1","2015-03-10 13:08:25","2015-03-10 13:08:25","","خانه","","publish","closed","closed","","%d8%b1%d9%88%d8%b2%d9%85%d8%b1%d9%87-%d9%87%d8%a7","","","2018-11-16 09:29:58","2018-11-16 05:59:58","","0","http://themes.muffingroup.com/be/webdesign/?page_id=2","0","page","","0");
INSERT INTO `st_posts` VALUES("2301","1","2018-11-13 19:05:30","2018-11-13 20:05:30","","What we offer","","inherit","closed","closed","","108-revision-v1","","","2018-11-13 19:05:30","2018-11-13 20:05:30","","108","http://foolstacks.ir/?p=2301","0","revision","","0");
INSERT INTO `st_posts` VALUES("108","1","2015-03-12 15:28:01","2015-03-12 15:28:01","","What we offer","","trash","open","open","","what-we-offer__trashed","","","2018-11-13 19:05:30","2018-11-13 20:05:30","","0","http://themes.muffingroup.com/be/webdesign/?page_id=73","0","page","","0");
INSERT INTO `st_posts` VALUES("2357","1","2018-11-14 12:32:18","0000-00-00 00:00:00","eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9","Untitled ngg_pictures","","draft","closed","closed","","mixin_nextgen_table_extras","","","2018-11-14 12:32:18","2018-11-14 09:02:18","eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9","0","http://foolstacks.ir/?p=2357","0","ngg_pictures","","0");
INSERT INTO `st_posts` VALUES("110","1","2015-03-12 15:28:50","2015-03-12 15:28:50","","Contact us","","trash","open","open","","contact-us__trashed","","","2018-11-13 19:03:36","2018-11-13 20:03:36","","0","http://themes.muffingroup.com/be/webdesign/?page_id=76","0","page","","0");
INSERT INTO `st_posts` VALUES("111","1","2015-03-12 15:29:36","2015-03-12 15:29:36","","Realisations","","trash","open","open","","realisations__trashed","","","2018-11-13 19:05:30","2018-11-13 20:05:30","","0","http://themes.muffingroup.com/be/webdesign/?page_id=78","0","page","","0");
INSERT INTO `st_posts` VALUES("2356","1","2018-11-14 12:32:18","0000-00-00 00:00:00","eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9","Untitled ngg_gallery","","draft","closed","closed","","mixin_nextgen_table_extras","","","2018-11-14 12:32:18","2018-11-14 09:02:18","eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9","0","http://foolstacks.ir/?p=2356","0","ngg_gallery","","0");
INSERT INTO `st_posts` VALUES("2256","1","2018-11-13 13:11:36","2018-11-13 09:41:36","<label> نام شما (الزامی)
    [text* your-name] </label>

<label> ایمیل شما (الزامی)
    [email* your-email] </label>

<label> شماره تماس
    [tel mobile] </label>

<label> موضوع
    [text your-subject] </label>

<label> پیام شما
    [textarea your-message] </label>

<label> افزودن فایل (کمتر از 2 مگابایت)
    [file fileUpload limit:2mb  filetypes:jpeg|png|jpg] </label>

[submit \"ارسال \"]
1
\"[your-subject]\"
[your-name] <wordpress@foolstacks.ir>
fullstackdiaries@gmail.com
از : [your-name] <[your-email]>
تلفن: [mobile]
موضوع: [your-subject]

محتوای پیام :
[your-message]

فایل: [fileUpload]
-- 
این ایمیل از فرم تماس در روزمره ها (http://foolstacks.ir) ارسال شده است.
Reply-To: [your-email]
[fileUpload]



روزمره ها \"[your-subject]\"
روزمره ها <wordpress@foolstacks.ir>
[your-email]
محتوای پیام :
[your-message]

-- 
این ایمیل از فرم تماس در روزمره ها (http://foolstacks.ir) ارسال شده است.
Reply-To: fullstackdiaries@gmail.com



از پیام شما متشکریم، پیام شما با موفقیت ارسال شد.
مشکلی در ارسال پیام شما بوجود آمده است، لطفا دوباره تلاش کنید.
یک یا چند تا از مقادیر وارد شده مشکل دارد، لطفا پس از بررسی دوباره تلاش کنید.
مشکلی در ارسال پیام شما بوجود آمده است، لطفا دوباره تلاش کنید.
شما باید با شرایط و قوانین موافقت کنید تا قادر به ارسال پیام باشید.
پر کردن این قسمت اجباری است.
مقدار وارد شده طولانی است.
مقدار وارد شده کوتاه است.
ساختار تاریخ نادرست است.
تاریخ نسبت به حداقل محدودیت زودتر است.
تاریخ نسبت به حداکثر محدودیت دیرتر است.
مشکلی در آپلود فایل شما رخ داده است.
شما اجازه ندارید از این نوع فایل آپلود کنید.
حجم فایل شما بسیار زیاد است.
مشکلی در آپلود فایل شما رخ داده است.
فرمت عدد نامعتبر است.
این مقدار کمتر از حداقل مجاز است.
این مقدار بیشتر از حداکثر مجاز است.
جواب شما به آزمون اشتباه است.
کد وارد شده صحیح نیست.
ایمیل وارد شده اشتباه است.
آدرس وارد شده اشتباه است.
شماره تلفن وارد شده اشتباه است.","فرم تماس 1","","publish","closed","closed","","%d9%81%d8%b1%d9%85-%d8%aa%d9%85%d8%a7%d8%b3-1","","","2018-11-14 11:45:54","2018-11-14 08:15:54","","0","http://foolstacks.ir/?post_type=wpcf7_contact_form&#038;p=2256","0","wpcf7_contact_form","","0");
INSERT INTO `st_posts` VALUES("2257","1","2018-11-13 13:17:45","2018-11-13 09:47:45","[contact-form-7 id=\"2256\" title=\"فرم تماس 1\"]","ارتباط","","inherit","closed","closed","","28-revision-v1","","","2018-11-13 13:17:45","2018-11-13 09:47:45","","28","http://foolstacks.ir/?p=2257","0","revision","","0");
INSERT INTO `st_posts` VALUES("2187","1","2014-04-29 12:00:53","2014-04-29 12:00:53","","Curabitur et ligula","Natoque penatibus et accumsan congue, lacus malesuada fames ac turpis semper urna. Pellentesque habitant morbi tristique id, sapien. Quisque pharetra, urna quis consectetuer adipiscing elit.","publish","closed","closed","","curabitur-et-ligula","","","2014-04-29 12:00:53","2014-04-29 12:00:53","","0","http://themes.muffingroup.com/betheme/?post_type=portfolio&#038;p=2187","0","portfolio","","0");
INSERT INTO `st_posts` VALUES("2188","1","2014-04-30 12:02:55","2014-04-30 12:02:55","","Quisque lorem tortor","Proin imperdiet urna sed eros ullamcorper, nec luctus justo feugiat. Nullam volutpat ligula","publish","closed","closed","","quisque-lorem-tortor","","","2014-04-30 12:02:55","2014-04-30 12:02:55","","0","http://themes.muffingroup.com/betheme/?post_type=portfolio&#038;p=2188","0","portfolio","","0");
INSERT INTO `st_posts` VALUES("2189","1","2014-05-01 12:07:28","2014-05-01 12:07:28","","Aliquam eratac","In fermentum nulla eget iaculis fermentum? Sed ac libero eu metus lacinia pretium. Praesent ultrices consequat neque eget scelerisque.","publish","closed","closed","","aliquam-eratac","","","2014-05-01 12:07:28","2014-05-01 12:07:28","","0","http://themes.muffingroup.com/betheme/?post_type=portfolio&#038;p=2189","0","portfolio","","0");
INSERT INTO `st_posts` VALUES("2190","1","2014-04-27 12:08:26","2014-04-27 12:08:26","","Integer aliquam purus","Sed condimentum nunc. Phasellus sit amet turpis metus nonummy enim dolor ac ligula. Sed eros. Curabitur lacinia id, lacinia dignissim. Nunc mollis. Nulla ac turpis viverra sed.","publish","closed","closed","","integer-aliquam-purus","","","2014-04-27 12:08:26","2014-04-27 12:08:26","","0","http://themes.muffingroup.com/betheme/?post_type=portfolio&#038;p=2190","0","portfolio","","0");
INSERT INTO `st_posts` VALUES("2191","1","2014-04-25 12:12:03","2014-04-25 12:12:03","","Eleifend justo vel","Duis placerat eu augue posuere condimentum. Pellentesque sollicitudin bibendum mauris ac fringilla.","publish","closed","closed","","eleifend-justo-vel","","","2014-04-25 12:12:03","2014-04-25 12:12:03","","0","http://themes.muffingroup.com/betheme/?post_type=portfolio&#038;p=2191","0","portfolio","","0");
INSERT INTO `st_posts` VALUES("2193","1","2014-04-26 12:09:23","2014-04-26 12:09:23","","Nulla imperdiet sit","Fermentum mi, quis wisi. Praesent quis turpis. Pellentesque ante. Vivamus justo.","publish","closed","closed","","nulla-imperdiet-sit","","","2014-04-26 12:09:23","2014-04-26 12:09:23","","0","http://themes.muffingroup.com/betheme/?post_type=portfolio&#038;p=2193","0","portfolio","","0");
INSERT INTO `st_posts` VALUES("2194","1","2018-11-10 05:53:10","2018-11-10 02:23:10"," ","","","publish","closed","closed","","2194","","","2018-11-14 12:14:06","2018-11-14 08:44:06","","0","http://foolstacks.ir/?p=2194","1","nav_menu_item","","0");
INSERT INTO `st_posts` VALUES("2196","1","2015-03-12 12:28:18","2015-03-12 12:28:18","","home_webdesign_footer_logo","","inherit","open","open","","home_webdesign_footer_logo","","","2015-03-12 12:28:18","2015-03-12 12:28:18","","0","http://foolstacks.ir/wp-content/uploads/2015/03/home_webdesign_footer_logo-1.png","0","attachment","image/png","0");
INSERT INTO `st_posts` VALUES("2197","1","2015-03-12 12:55:32","2015-03-12 12:55:32","","retina-webdesign","","inherit","open","open","","retina-webdesign","","","2015-03-12 12:55:32","2015-03-12 12:55:32","","0","http://foolstacks.ir/wp-content/uploads/2015/03/retina-webdesign.png","0","attachment","image/png","0");
INSERT INTO `st_posts` VALUES("2198","1","2015-03-12 12:55:32","2015-03-12 12:55:32","","webdesign","","inherit","open","open","","webdesign","","","2015-03-12 12:55:32","2015-03-12 12:55:32","","0","http://foolstacks.ir/wp-content/uploads/2015/03/webdesign.png","0","attachment","image/png","0");
INSERT INTO `st_posts` VALUES("2199","1","2015-03-12 13:30:29","2015-03-12 13:30:29","","home_webdesign_slide1_cover","","inherit","open","open","","home_webdesign_slide1_cover","","","2015-03-12 13:30:29","2015-03-12 13:30:29","","0","http://foolstacks.ir/wp-content/uploads/2015/03/home_webdesign_slide1_cover.png","0","attachment","image/png","0");
INSERT INTO `st_posts` VALUES("2200","1","2015-03-12 13:35:36","2015-03-12 13:35:36","","home_webdesign_slide1_cover2","","inherit","open","open","","home_webdesign_slide1_cover2","","","2015-03-12 13:35:36","2015-03-12 13:35:36","","0","http://foolstacks.ir/wp-content/uploads/2015/03/home_webdesign_slide1_cover2.png","0","attachment","image/png","0");
INSERT INTO `st_posts` VALUES("2201","1","2015-03-12 13:48:41","2015-03-12 13:48:41","","home_webdesign_slide3_bg","","inherit","open","open","","home_webdesign_slide3_bg","","","2015-03-12 13:48:41","2015-03-12 13:48:41","","0","http://foolstacks.ir/wp-content/uploads/2015/03/home_webdesign_slide3_bg.jpg","0","attachment","image/jpeg","0");
INSERT INTO `st_posts` VALUES("2202","1","2015-03-12 13:48:57","2015-03-12 13:48:57","","home_webdesign_slide4_bg","","inherit","open","open","","home_webdesign_slide4_bg","","","2015-03-12 13:48:57","2015-03-12 13:48:57","","0","http://foolstacks.ir/wp-content/uploads/2015/03/home_webdesign_slide4_bg.jpg","0","attachment","image/jpeg","0");
INSERT INTO `st_posts` VALUES("2203","1","2015-03-12 13:50:21","2015-03-12 13:50:21","","home_webdesign_slide3_cover","","inherit","open","open","","home_webdesign_slide3_cover","","","2015-03-12 13:50:21","2015-03-12 13:50:21","","0","http://foolstacks.ir/wp-content/uploads/2015/03/home_webdesign_slide3_cover.png","0","attachment","image/png","0");
INSERT INTO `st_posts` VALUES("2204","1","2015-03-12 13:50:38","2015-03-12 13:50:38","","home_webdesign_slide3_cover2","","inherit","open","open","","home_webdesign_slide3_cover2","","","2015-03-12 13:50:38","2015-03-12 13:50:38","","0","http://foolstacks.ir/wp-content/uploads/2015/03/home_webdesign_slide3_cover2.png","0","attachment","image/png","0");
INSERT INTO `st_posts` VALUES("2205","1","2015-03-12 14:11:56","2015-03-12 14:11:56","","home_webdesign_slide4_cover2","","inherit","open","open","","home_webdesign_slide4_cover2","","","2015-03-12 14:11:56","2015-03-12 14:11:56","","0","http://foolstacks.ir/wp-content/uploads/2015/03/home_webdesign_slide4_cover2.png","0","attachment","image/png","0");
INSERT INTO `st_posts` VALUES("2206","1","2015-03-12 14:12:07","2015-03-12 14:12:07","","home_webdesign_slide4_cover","","inherit","open","open","","home_webdesign_slide4_cover","","","2015-03-12 14:12:07","2015-03-12 14:12:07","","0","http://foolstacks.ir/wp-content/uploads/2015/03/home_webdesign_slide4_cover.png","0","attachment","image/png","0");
INSERT INTO `st_posts` VALUES("2207","1","2018-11-10 05:59:21","2018-11-10 05:59:21","","home_webdesign_slide1_bg.jpg","","inherit","closed","closed","","home-webdesign-slide1-bg-jpg","","","2018-11-10 05:59:21","2018-11-10 05:59:21","","0","http://foolstacks.ir/wp-content/uploads/revslider/webdesign/home_webdesign_slide1_bg.jpg","0","attachment","image/jpeg","0");
INSERT INTO `st_posts` VALUES("2208","1","2018-11-10 05:59:22","2018-11-10 05:59:22","","home_webdesign_slide1_cover2.png","","inherit","closed","closed","","home-webdesign-slide1-cover2-png","","","2018-11-10 05:59:22","2018-11-10 05:59:22","","0","http://foolstacks.ir/wp-content/uploads/revslider/webdesign/home_webdesign_slide1_cover2.png","0","attachment","image/png","0");
INSERT INTO `st_posts` VALUES("2209","1","2018-11-10 05:59:22","2018-11-10 05:59:22","","home_webdesign_slide1_cover.png","","inherit","closed","closed","","home-webdesign-slide1-cover-png","","","2018-11-10 05:59:22","2018-11-10 05:59:22","","0","http://foolstacks.ir/wp-content/uploads/revslider/webdesign/home_webdesign_slide1_cover.png","0","attachment","image/png","0");
INSERT INTO `st_posts` VALUES("2210","1","2018-11-10 05:59:25","2018-11-10 05:59:25","","home_webdesign_slide1_num.png","","inherit","closed","closed","","home-webdesign-slide1-num-png","","","2018-11-10 05:59:25","2018-11-10 05:59:25","","0","http://foolstacks.ir/wp-content/uploads/revslider/webdesign/home_webdesign_slide1_num.png","0","attachment","image/png","0");
INSERT INTO `st_posts` VALUES("2211","1","2018-11-10 05:59:25","2018-11-10 05:59:25","","home_webdesign_slider_sep.png","","inherit","closed","closed","","home-webdesign-slider-sep-png","","","2018-11-10 05:59:25","2018-11-10 05:59:25","","0","http://foolstacks.ir/wp-content/uploads/revslider/webdesign/home_webdesign_slider_sep.png","0","attachment","image/png","0");
INSERT INTO `st_posts` VALUES("2212","1","2018-11-10 05:59:25","2018-11-10 05:59:25","","home_webdesign_slide3_bg.jpg","","inherit","closed","closed","","home-webdesign-slide3-bg-jpg","","","2018-11-10 05:59:25","2018-11-10 05:59:25","","0","http://foolstacks.ir/wp-content/uploads/revslider/webdesign/home_webdesign_slide3_bg.jpg","0","attachment","image/jpeg","0");
INSERT INTO `st_posts` VALUES("2213","1","2018-11-10 05:59:26","2018-11-10 05:59:26","","home_webdesign_slide3_cover2.png","","inherit","closed","closed","","home-webdesign-slide3-cover2-png","","","2018-11-10 05:59:26","2018-11-10 05:59:26","","0","http://foolstacks.ir/wp-content/uploads/revslider/webdesign/home_webdesign_slide3_cover2.png","0","attachment","image/png","0");
INSERT INTO `st_posts` VALUES("2214","1","2018-11-10 05:59:26","2018-11-10 05:59:26","","home_webdesign_slide3_cover.png","","inherit","closed","closed","","home-webdesign-slide3-cover-png","","","2018-11-10 05:59:26","2018-11-10 05:59:26","","0","http://foolstacks.ir/wp-content/uploads/revslider/webdesign/home_webdesign_slide3_cover.png","0","attachment","image/png","0");
INSERT INTO `st_posts` VALUES("2215","1","2018-11-10 05:59:30","2018-11-10 05:59:30","","home_webdesign_slide2_num.png","","inherit","closed","closed","","home-webdesign-slide2-num-png","","","2018-11-10 05:59:30","2018-11-10 05:59:30","","0","http://foolstacks.ir/wp-content/uploads/revslider/webdesign/home_webdesign_slide2_num.png","0","attachment","image/png","0");
INSERT INTO `st_posts` VALUES("2216","1","2018-11-10 05:59:30","2018-11-10 05:59:30","","home_webdesign_slide4_bg.jpg","","inherit","closed","closed","","home-webdesign-slide4-bg-jpg","","","2018-11-10 05:59:30","2018-11-10 05:59:30","","0","http://foolstacks.ir/wp-content/uploads/revslider/webdesign/home_webdesign_slide4_bg.jpg","0","attachment","image/jpeg","0");
INSERT INTO `st_posts` VALUES("2217","1","2018-11-10 05:59:31","2018-11-10 05:59:31","","home_webdesign_slide4_cover2.png","","inherit","closed","closed","","home-webdesign-slide4-cover2-png","","","2018-11-10 05:59:31","2018-11-10 05:59:31","","0","http://foolstacks.ir/wp-content/uploads/revslider/webdesign/home_webdesign_slide4_cover2.png","0","attachment","image/png","0");
INSERT INTO `st_posts` VALUES("2218","1","2018-11-10 05:59:31","2018-11-10 05:59:31","","home_webdesign_slide4_cover.png","","inherit","closed","closed","","home-webdesign-slide4-cover-png","","","2018-11-10 05:59:31","2018-11-10 05:59:31","","0","http://foolstacks.ir/wp-content/uploads/revslider/webdesign/home_webdesign_slide4_cover.png","0","attachment","image/png","0");
INSERT INTO `st_posts` VALUES("2219","1","2018-11-10 05:59:34","2018-11-10 05:59:34","","home_webdesign_slide3.png","","inherit","closed","closed","","home-webdesign-slide3-png","","","2018-11-10 05:59:34","2018-11-10 05:59:34","","0","http://foolstacks.ir/wp-content/uploads/revslider/webdesign/home_webdesign_slide3.png","0","attachment","image/png","0");
INSERT INTO `st_posts` VALUES("2220","1","2018-11-10 05:59:34","2018-11-10 05:59:34","","home_webdesign_slide2_bg.jpg","","inherit","closed","closed","","home-webdesign-slide2-bg-jpg","","","2018-11-10 05:59:34","2018-11-10 05:59:34","","0","http://foolstacks.ir/wp-content/uploads/revslider/webdesign/home_webdesign_slide2_bg.jpg","0","attachment","image/jpeg","0");
INSERT INTO `st_posts` VALUES("2221","1","2018-11-10 05:59:35","2018-11-10 05:59:35","","home_webdesign_slide2_cover2.png","","inherit","closed","closed","","home-webdesign-slide2-cover2-png","","","2018-11-10 05:59:35","2018-11-10 05:59:35","","0","http://foolstacks.ir/wp-content/uploads/revslider/webdesign/home_webdesign_slide2_cover2.png","0","attachment","image/png","0");
INSERT INTO `st_posts` VALUES("2222","1","2018-11-10 05:59:35","2018-11-10 05:59:35","","home_webdesign_slide2_cover.png","","inherit","closed","closed","","home-webdesign-slide2-cover-png","","","2018-11-10 05:59:35","2018-11-10 05:59:35","","0","http://foolstacks.ir/wp-content/uploads/revslider/webdesign/home_webdesign_slide2_cover.png","0","attachment","image/png","0");
INSERT INTO `st_posts` VALUES("2223","1","2018-11-10 05:59:38","2018-11-10 05:59:38","","home_webdesign_slide4_num.png","","inherit","closed","closed","","home-webdesign-slide4-num-png","","","2018-11-10 05:59:38","2018-11-10 05:59:38","","0","http://foolstacks.ir/wp-content/uploads/revslider/webdesign/home_webdesign_slide4_num.png","0","attachment","image/png","0");
INSERT INTO `st_posts` VALUES("2224","1","2018-11-10 06:02:44","2018-11-10 02:32:44","{
    \"betheme::nav_menu_locations[main-menu]\": {
        \"value\": 0,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 02:32:44\"
    },
    \"betheme::nav_menu_locations[social-menu-bottom]\": {
        \"value\": 0,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 02:32:44\"
    }
}","","","trash","closed","closed","","8257ac53-07b0-4f44-81b4-4d7a095e87e0","","","2018-11-10 06:02:44","2018-11-10 02:32:44","","0","http://foolstacks.ir/?p=2224","0","customize_changeset","","0");
INSERT INTO `st_posts` VALUES("2225","1","2018-11-10 06:02:58","2018-11-10 02:32:58","{
    \"betheme::nav_menu_locations[main-menu]\": {
        \"value\": 2,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 02:32:58\"
    }
}","","","trash","closed","closed","","a3c54c71-5cbb-4dd2-bf12-2360aeefe34e","","","2018-11-10 06:02:58","2018-11-10 02:32:58","","0","http://foolstacks.ir/?p=2225","0","customize_changeset","","0");
INSERT INTO `st_posts` VALUES("2226","1","2018-11-10 06:03:23","2018-11-10 02:33:23","{
    \"betheme::nav_menu_locations[social-menu-bottom]\": {
        \"value\": 3,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 02:33:23\"
    }
}","","","trash","closed","closed","","eaae844b-eca0-43f1-8903-5b6a7fbe49f2","","","2018-11-10 06:03:23","2018-11-10 02:33:23","","0","http://foolstacks.ir/?p=2226","0","customize_changeset","","0");
INSERT INTO `st_posts` VALUES("2227","1","2018-11-10 06:04:16","2018-11-10 02:34:16","{
    \"betheme::nav_menu_locations[social-menu-bottom]\": {
        \"value\": 2,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 02:34:16\"
    }
}","","","trash","closed","closed","","3dd3baa1-bca4-4138-88ab-132324e24642","","","2018-11-10 06:04:16","2018-11-10 02:34:16","","0","http://foolstacks.ir/?p=2227","0","customize_changeset","","0");
INSERT INTO `st_posts` VALUES("2228","1","2018-11-10 06:04:30","2018-11-10 02:34:30","{
    \"betheme::nav_menu_locations[social-menu-bottom]\": {
        \"value\": 0,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 02:34:30\"
    }
}","","","trash","closed","closed","","d9aef906-3aca-452b-9563-95158ebacf4f","","","2018-11-10 06:04:30","2018-11-10 02:34:30","","0","http://foolstacks.ir/?p=2228","0","customize_changeset","","0");
INSERT INTO `st_posts` VALUES("2229","1","2018-11-10 06:04:48","2018-11-10 02:34:48","{
    \"betheme::nav_menu_locations[social-menu-bottom]\": {
        \"value\": 3,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 02:34:48\"
    }
}","","","trash","closed","closed","","36c57712-0bb9-4d8e-8b6f-3d4e2ccfb7ee","","","2018-11-10 06:04:48","2018-11-10 02:34:48","","0","http://foolstacks.ir/?p=2229","0","customize_changeset","","0");
INSERT INTO `st_posts` VALUES("2230","1","2018-11-10 06:06:00","2018-11-10 02:36:00","{
    \"betheme::nav_menu_locations[social-menu-bottom]\": {
        \"value\": 0,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 02:35:42\"
    }
}","","","trash","closed","closed","","e450f232-e607-4ee5-ae03-e58517521335","","","2018-11-10 06:06:00","2018-11-10 02:36:00","","0","http://foolstacks.ir/?p=2230","0","customize_changeset","","0");
INSERT INTO `st_posts` VALUES("2231","1","2018-11-10 06:07:53","2018-11-10 02:37:53","{
    \"sidebars_widgets[footer-area-1]\": {
        \"value\": [
            \"text-8\"
        ],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 02:37:53\"
    }
}","","","trash","closed","closed","","e0f628ea-0452-4348-af6a-9c167be0fb2b","","","2018-11-10 06:07:53","2018-11-10 02:37:53","","0","http://foolstacks.ir/?p=2231","0","customize_changeset","","0");
INSERT INTO `st_posts` VALUES("2232","1","2018-11-10 06:10:49","2018-11-10 02:40:49","{
    \"sidebars_widgets[footer-area-2]\": {
        \"value\": [
            \"text-10\",
            \"archives-4\"
        ],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 02:40:49\"
    },
    \"widget_archives[4]\": {
        \"value\": {
            \"encoded_serialized_instance\": \"YTozOntzOjU6InRpdGxlIjtzOjA6IiI7czo1OiJjb3VudCI7aTowO3M6ODoiZHJvcGRvd24iO2k6MTt9\",
            \"title\": \"\",
            \"is_widget_customizer_js_value\": true,
            \"instance_hash_key\": \"77f9fa39cb74bf15c2bd5b3731c2b283\"
        },
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 02:40:49\"
    }
}","","","trash","closed","closed","","e0e05ce5-75b1-4232-829f-f518a83698cf","","","2018-11-10 06:10:49","2018-11-10 02:40:49","","0","http://foolstacks.ir/?p=2232","0","customize_changeset","","0");
INSERT INTO `st_posts` VALUES("2233","1","2018-11-10 06:11:37","2018-11-10 02:41:37","{
    \"sidebars_widgets[footer-area-3]\": {
        \"value\": [
            \"rss-3\"
        ],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 02:41:31\"
    },
    \"widget_rss[3]\": {
        \"value\": [],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 02:41:31\"
    }
}","","","trash","closed","closed","","87c97181-7814-4ffb-b445-491141837980","","","2018-11-10 06:11:37","2018-11-10 02:41:37","","0","http://foolstacks.ir/?p=2233","0","customize_changeset","","0");
INSERT INTO `st_posts` VALUES("2234","1","2018-11-10 06:12:03","2018-11-10 02:42:03","{
    \"sidebars_widgets[footer-area-4]\": {
        \"value\": [
            \"recent-comments-4\"
        ],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 02:42:03\"
    },
    \"widget_recent-comments[4]\": {
        \"value\": [],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 02:42:03\"
    }
}","","","trash","closed","closed","","692dfccb-75f3-4b73-bfff-73d11ddc4506","","","2018-11-10 06:12:03","2018-11-10 02:42:03","","0","http://foolstacks.ir/?p=2234","0","customize_changeset","","0");
INSERT INTO `st_posts` VALUES("2236","1","2018-11-10 06:12:50","2018-11-10 02:42:50","{
    \"sidebars_widgets[footer-area-2]\": {
        \"value\": [
            \"text-10\"
        ],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 02:42:50\"
    }
}","","","trash","closed","closed","","a400a8de-3517-4d94-b041-0c8a7cc150ef","","","2018-11-10 06:12:50","2018-11-10 02:42:50","","0","http://foolstacks.ir/?p=2236","0","customize_changeset","","0");
INSERT INTO `st_posts` VALUES("2237","1","2018-11-10 06:13:23","2018-11-10 02:43:23","{
    \"sidebars_widgets[wp_inactive_widgets]\": {
        \"value\": [
            \"archives-2\",
            \"meta-2\",
            \"search-2\",
            \"text-2\",
            \"text-3\",
            \"text-4\",
            \"text-5\",
            \"text-6\",
            \"text-7\",
            \"categories-2\",
            \"recent-posts-2\",
            \"recent-comments-2\",
            \"search-3\",
            \"text-9\",
            \"search-4\",
            \"rss-3\"
        ],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 02:43:23\"
    },
    \"sidebars_widgets[footer-area-3]\": {
        \"value\": [
            \"archives-6\"
        ],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 02:43:23\"
    },
    \"widget_archives[6]\": {
        \"value\": [],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 02:43:23\"
    }
}","","","trash","closed","closed","","147b51ec-0df9-4cd0-a264-73adf8e9e859","","","2018-11-10 06:13:23","2018-11-10 02:43:23","","0","http://foolstacks.ir/?p=2237","0","customize_changeset","","0");
INSERT INTO `st_posts` VALUES("2238","1","2018-11-10 06:13:56","2018-11-10 02:43:56","{
    \"sidebars_widgets[wp_inactive_widgets]\": {
        \"value\": [
            \"archives-2\",
            \"meta-2\",
            \"search-2\",
            \"text-2\",
            \"text-3\",
            \"text-4\",
            \"text-5\",
            \"text-6\",
            \"text-7\",
            \"categories-2\",
            \"recent-posts-2\",
            \"recent-comments-2\",
            \"search-3\",
            \"text-9\",
            \"search-4\",
            \"rss-3\",
            \"text-8\"
        ],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 02:43:48\"
    },
    \"sidebars_widgets[footer-area-1]\": {
        \"value\": [
            \"rss-5\"
        ],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 02:43:48\"
    },
    \"widget_rss[5]\": {
        \"value\": [],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 02:43:48\"
    }
}","","","trash","closed","closed","","62315f24-1c08-4ab4-94c1-2a97ec6b883c","","","2018-11-10 06:13:56","2018-11-10 02:43:56","","0","http://foolstacks.ir/?p=2238","0","customize_changeset","","0");
INSERT INTO `st_posts` VALUES("2239","1","2018-11-10 06:15:34","2018-11-10 02:45:34","{
    \"page_on_front\": {
        \"value\": \"106\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 02:45:34\"
    }
}","","","trash","closed","closed","","22d39082-670b-4fb4-9e42-5d56a5ffc4d0","","","2018-11-10 06:15:34","2018-11-10 02:45:34","","0","http://foolstacks.ir/?p=2239","0","customize_changeset","","0");
INSERT INTO `st_posts` VALUES("2285","1","2018-11-13 17:31:51","2018-11-13 18:31:51","","What is a Blog","","inherit","open","closed","","what-is-a-blog","","","2018-11-13 17:53:48","2018-11-13 18:53:48","","27","http://foolstacks.ir/wp-content/uploads/2018/11/What-is-a-Blog.mp4","0","attachment","video/mp4","0");
INSERT INTO `st_posts` VALUES("2241","1","2018-11-10 06:37:32","2018-11-10 03:07:32","","108181-120425155J065","","inherit","open","closed","","108181-120425155j065","","","2018-11-10 06:37:32","2018-11-10 03:07:32","","85","http://foolstacks.ir/wp-content/uploads/2018/11/108181-120425155J065.jpg","0","attachment","image/jpeg","0");
INSERT INTO `st_posts` VALUES("2382","1","2018-11-17 13:49:28","0000-00-00 00:00:00","","پیش‌نویس خودکار","","auto-draft","open","open","","","","","2018-11-17 13:49:28","0000-00-00 00:00:00","","0","http://foolstacks.ir/?p=2382","0","post","","0");
INSERT INTO `st_posts` VALUES("2243","1","2018-11-10 06:38:06","2018-11-10 03:08:06","","ET-0448","","inherit","open","closed","","et-0448","","","2018-11-10 06:38:06","2018-11-10 03:08:06","","83","http://foolstacks.ir/wp-content/uploads/2018/11/1476250569285.jpg","0","attachment","image/jpeg","0");
INSERT INTO `st_posts` VALUES("2244","1","2018-11-10 07:19:15","2018-11-10 03:49:15","{
    \"sidebars_widgets[footer-area-2]\": {
        \"value\": [],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-10 03:49:15\"
    }
}","","","trash","closed","closed","","6327ba90-5a4c-4305-9b7d-4a0f3c2e0d74","","","2018-11-10 07:19:15","2018-11-10 03:49:15","","0","http://foolstacks.ir/?p=2244","0","customize_changeset","","0");
INSERT INTO `st_posts` VALUES("2245","1","2018-11-10 07:45:38","2018-11-10 04:15:38","","home_webdesign_pattern1","","inherit","open","closed","","home_webdesign_pattern1-2","","","2018-11-10 07:45:38","2018-11-10 04:15:38","","0","http://foolstacks.ir/wp-content/uploads/2018/11/home_webdesign_pattern1.png","0","attachment","image/png","0");
INSERT INTO `st_posts` VALUES("2246","1","2018-11-13 11:02:07","2018-11-13 07:32:07","","Home","","inherit","closed","closed","","106-revision-v1","","","2018-11-13 11:02:07","2018-11-13 07:32:07","","106","http://foolstacks.ir/?p=2246","0","revision","","0");
INSERT INTO `st_posts` VALUES("2247","1","2018-11-13 11:13:53","2018-11-13 07:43:53","","99we","","inherit","open","closed","","99we","","","2018-11-13 11:13:53","2018-11-13 07:43:53","","106","http://foolstacks.ir/wp-content/uploads/2018/11/99we.jpg","0","attachment","image/jpeg","0");
INSERT INTO `st_posts` VALUES("2248","1","2018-11-13 11:52:11","2018-11-13 08:22:11","","1","","inherit","open","closed","","1","","","2018-11-13 11:52:11","2018-11-13 08:22:11","","106","http://foolstacks.ir/wp-content/uploads/2018/11/1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `st_posts` VALUES("2249","1","2018-11-13 11:52:12","2018-11-13 08:22:12","","2","","inherit","open","closed","","2","","","2018-11-13 11:52:12","2018-11-13 08:22:12","","106","http://foolstacks.ir/wp-content/uploads/2018/11/2.jpg","0","attachment","image/jpeg","0");
INSERT INTO `st_posts` VALUES("2250","1","2018-11-13 11:52:13","2018-11-13 08:22:13","","3","","inherit","open","closed","","3","","","2018-11-13 11:52:13","2018-11-13 08:22:13","","106","http://foolstacks.ir/wp-content/uploads/2018/11/3.jpg","0","attachment","image/jpeg","0");
INSERT INTO `st_posts` VALUES("2251","1","2018-11-13 11:52:14","2018-11-13 08:22:14","","4","","inherit","open","closed","","4","","","2018-11-13 11:52:14","2018-11-13 08:22:14","","106","http://foolstacks.ir/wp-content/uploads/2018/11/4.jpg","0","attachment","image/jpeg","0");
INSERT INTO `st_posts` VALUES("2252","1","2018-11-13 11:52:15","2018-11-13 08:22:15","","5","","inherit","open","closed","","5","","","2018-11-13 11:52:15","2018-11-13 08:22:15","","106","http://foolstacks.ir/wp-content/uploads/2018/11/5.jpg","0","attachment","image/jpeg","0");
INSERT INTO `st_posts` VALUES("2253","1","2018-11-13 12:33:26","2018-11-13 09:03:26","","slider (2)","","inherit","open","closed","","slider-2","","","2018-11-13 12:33:26","2018-11-13 09:03:26","","0","http://foolstacks.ir/wp-content/uploads/2018/11/slider-2.jpg","0","attachment","image/jpeg","0");
INSERT INTO `st_posts` VALUES("2254","1","2018-11-13 12:52:08","2018-11-13 09:22:08","{
    \"blogname\": {
        \"value\": \"\\u0631\\u0648\\u0632\\u0645\\u0631\\u0647 \\u0647\\u0627\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-13 09:22:08\"
    }
}","","","trash","closed","closed","","a393cf10-07cb-43e0-87f1-3cd233995f82","","","2018-11-13 12:52:08","2018-11-13 09:22:08","","0","http://foolstacks.ir/?p=2254","0","customize_changeset","","0");
INSERT INTO `st_posts` VALUES("2255","1","2018-11-13 12:53:01","2018-11-13 09:23:01","{
    \"site_icon\": {
        \"value\": 52,
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-13 09:23:01\"
    }
}","","","trash","closed","closed","","70f62fd8-2717-4220-8a60-ff600de8db94","","","2018-11-13 12:53:01","2018-11-13 09:23:01","","0","http://foolstacks.ir/?p=2255","0","customize_changeset","","0");
INSERT INTO `st_posts` VALUES("2259","1","2018-11-13 13:20:49","0000-00-00 00:00:00","eyJmaWx0ZXIiOiJyYXciLCJtZXRhX2lkIjoiNzIxIiwicG9zdF9pZCI6IjIyNTkiLCJtZXRhX2tleSI6Im5hbWUiLCJtZXRhX3ZhbHVlIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX3NsaWRlc2hvdyIsInRpdGxlIjoiTmV4dEdFTiBCYXNpYyBTbGlkZXNob3ciLCJtb2R1bGVfaWQiOiJwaG90b2NyYXRpLW5leHRnZW5fYmFzaWNfZ2FsbGVyeSIsImVudGl0eV90eXBlcyI6WyJpbWFnZSJdLCJwcmV2aWV3X2ltYWdlX3JlbHBhdGgiOiJcL25leHRnZW4tZ2FsbGVyeVwvcHJvZHVjdHNcL3Bob3RvY3JhdGlfbmV4dGdlblwvbW9kdWxlc1wvbmV4dGdlbl9iYXNpY19nYWxsZXJ5XC9zdGF0aWNcL3NsaWRlc2hvd19wcmV2aWV3LmpwZyIsImRlZmF1bHRfc291cmNlIjoiZ2FsbGVyaWVzIiwidmlld19vcmRlciI6MTAwMTAsImFsaWFzZXMiOlsiYmFzaWNfc2xpZGVzaG93IiwibmV4dGdlbl9iYXNpY19zbGlkZXNob3ciXSwibmFtZSI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY19zbGlkZXNob3ciLCJpbnN0YWxsZWRfYXRfdmVyc2lvbiI6IjMuMC4xNiIsImlkX2ZpZWxkIjoiSUQiLCJzZXR0aW5ncyI6eyJnYWxsZXJ5X3dpZHRoIjoiNzUwIiwiZ2FsbGVyeV9oZWlnaHQiOiI1MDAiLCJhdXRvcGxheSI6IjEiLCJwYXVzZW9uaG92ZXIiOiIxIiwiYXJyb3dzIjoiMCIsInRyYW5zaXRpb25fc3R5bGUiOiJzbGlkZSIsImludGVydmFsIjoiMzAwMCIsInRyYW5zaXRpb25fc3BlZWQiOiIzMDAiLCJzaG93X3RodW1ibmFpbF9saW5rIjoiMSIsInRodW1ibmFpbF9saW5rX3RleHQiOiJWaWV3IFRodW1ibmFpbHMiLCJkaXNwbGF5X3ZpZXciOiJkZWZhdWx0IiwidXNlX2xpZ2h0Ym94X2VmZmVjdCI6dHJ1ZSwidGVtcGxhdGUiOiIiLCJuZ2dfdHJpZ2dlcnNfZGlzcGxheSI6Im5ldmVyIiwiX2Vycm9ycyI6W119LCJoaWRkZW5fZnJvbV91aSI6ZmFsc2UsImhpZGRlbl9mcm9tX2lndyI6ZmFsc2UsIl9fZGVmYXVsdHNfc2V0Ijp0cnVlfQ==","NextGEN Basic Slideshow","","draft","closed","closed","","","","","2018-11-14 12:37:24","2018-11-14 09:07:24","eyJmaWx0ZXIiOiJyYXciLCJtZXRhX2lkIjoiNzIxIiwicG9zdF9pZCI6IjIyNTkiLCJtZXRhX2tleSI6Im5hbWUiLCJtZXRhX3ZhbHVlIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX3NsaWRlc2hvdyIsInRpdGxlIjoiTmV4dEdFTiBCYXNpYyBTbGlkZXNob3ciLCJtb2R1bGVfaWQiOiJwaG90b2NyYXRpLW5leHRnZW5fYmFzaWNfZ2FsbGVyeSIsImVudGl0eV90eXBlcyI6WyJpbWFnZSJdLCJwcmV2aWV3X2ltYWdlX3JlbHBhdGgiOiJcL25leHRnZW4tZ2FsbGVyeVwvcHJvZHVjdHNcL3Bob3RvY3JhdGlfbmV4dGdlblwvbW9kdWxlc1wvbmV4dGdlbl9iYXNpY19nYWxsZXJ5XC9zdGF0aWNcL3NsaWRlc2hvd19wcmV2aWV3LmpwZyIsImRlZmF1bHRfc291cmNlIjoiZ2FsbGVyaWVzIiwidmlld19vcmRlciI6MTAwMTAsImFsaWFzZXMiOlsiYmFzaWNfc2xpZGVzaG93IiwibmV4dGdlbl9iYXNpY19zbGlkZXNob3ciXSwibmFtZSI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY19zbGlkZXNob3ciLCJpbnN0YWxsZWRfYXRfdmVyc2lvbiI6IjMuMC4xNiIsImlkX2ZpZWxkIjoiSUQiLCJzZXR0aW5ncyI6eyJnYWxsZXJ5X3dpZHRoIjoiNzUwIiwiZ2FsbGVyeV9oZWlnaHQiOiI1MDAiLCJhdXRvcGxheSI6IjEiLCJwYXVzZW9uaG92ZXIiOiIxIiwiYXJyb3dzIjoiMCIsInRyYW5zaXRpb25fc3R5bGUiOiJzbGlkZSIsImludGVydmFsIjoiMzAwMCIsInRyYW5zaXRpb25fc3BlZWQiOiIzMDAiLCJzaG93X3RodW1ibmFpbF9saW5rIjoiMSIsInRodW1ibmFpbF9saW5rX3RleHQiOiJWaWV3IFRodW1ibmFpbHMiLCJkaXNwbGF5X3ZpZXciOiJkZWZhdWx0IiwidXNlX2xpZ2h0Ym94X2VmZmVjdCI6dHJ1ZSwidGVtcGxhdGUiOiIiLCJuZ2dfdHJpZ2dlcnNfZGlzcGxheSI6Im5ldmVyIiwiX2Vycm9ycyI6W119LCJoaWRkZW5fZnJvbV91aSI6ZmFsc2UsImhpZGRlbl9mcm9tX2lndyI6ZmFsc2UsIl9fZGVmYXVsdHNfc2V0Ijp0cnVlfQ==","0","http://foolstacks.ir/?post_type=display_type&#038;p=2259","0","display_type","","0");
INSERT INTO `st_posts` VALUES("2260","1","2018-11-13 13:20:49","0000-00-00 00:00:00","eyJmaWx0ZXIiOiJyYXciLCJtZXRhX2lkIjoiNzM1IiwicG9zdF9pZCI6IjIyNjAiLCJtZXRhX2tleSI6Im5hbWUiLCJtZXRhX3ZhbHVlIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX2ltYWdlYnJvd3NlciIsInRpdGxlIjoiTmV4dEdFTiBCYXNpYyBJbWFnZUJyb3dzZXIiLCJlbnRpdHlfdHlwZXMiOlsiaW1hZ2UiXSwicHJldmlld19pbWFnZV9yZWxwYXRoIjoiXC9uZXh0Z2VuLWdhbGxlcnlcL3Byb2R1Y3RzXC9waG90b2NyYXRpX25leHRnZW5cL21vZHVsZXNcL25leHRnZW5fYmFzaWNfaW1hZ2Vicm93c2VyXC9zdGF0aWNcL3ByZXZpZXcuanBnIiwiZGVmYXVsdF9zb3VyY2UiOiJnYWxsZXJpZXMiLCJ2aWV3X29yZGVyIjoxMDAyMCwiYWxpYXNlcyI6WyJiYXNpY19pbWFnZWJyb3dzZXIiLCJpbWFnZWJyb3dzZXIiLCJuZXh0Z2VuX2Jhc2ljX2ltYWdlYnJvd3NlciJdLCJuYW1lIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX2ltYWdlYnJvd3NlciIsImluc3RhbGxlZF9hdF92ZXJzaW9uIjoiMy4wLjE2IiwiaWRfZmllbGQiOiJJRCIsInNldHRpbmdzIjp7ImFqYXhfcGFnaW5hdGlvbiI6IjEiLCJkaXNwbGF5X3ZpZXciOiJkZWZhdWx0LXZpZXcucGhwIiwidGVtcGxhdGUiOiIiLCJ1c2VfbGlnaHRib3hfZWZmZWN0Ijp0cnVlLCJuZ2dfdHJpZ2dlcnNfZGlzcGxheSI6Im5ldmVyIiwiX2Vycm9ycyI6W119LCJoaWRkZW5fZnJvbV91aSI6ZmFsc2UsImhpZGRlbl9mcm9tX2lndyI6ZmFsc2UsIl9fZGVmYXVsdHNfc2V0Ijp0cnVlfQ==","NextGEN Basic ImageBrowser","","draft","closed","closed","","","","","2018-11-14 12:37:24","2018-11-14 09:07:24","eyJmaWx0ZXIiOiJyYXciLCJtZXRhX2lkIjoiNzM1IiwicG9zdF9pZCI6IjIyNjAiLCJtZXRhX2tleSI6Im5hbWUiLCJtZXRhX3ZhbHVlIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX2ltYWdlYnJvd3NlciIsInRpdGxlIjoiTmV4dEdFTiBCYXNpYyBJbWFnZUJyb3dzZXIiLCJlbnRpdHlfdHlwZXMiOlsiaW1hZ2UiXSwicHJldmlld19pbWFnZV9yZWxwYXRoIjoiXC9uZXh0Z2VuLWdhbGxlcnlcL3Byb2R1Y3RzXC9waG90b2NyYXRpX25leHRnZW5cL21vZHVsZXNcL25leHRnZW5fYmFzaWNfaW1hZ2Vicm93c2VyXC9zdGF0aWNcL3ByZXZpZXcuanBnIiwiZGVmYXVsdF9zb3VyY2UiOiJnYWxsZXJpZXMiLCJ2aWV3X29yZGVyIjoxMDAyMCwiYWxpYXNlcyI6WyJiYXNpY19pbWFnZWJyb3dzZXIiLCJpbWFnZWJyb3dzZXIiLCJuZXh0Z2VuX2Jhc2ljX2ltYWdlYnJvd3NlciJdLCJuYW1lIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX2ltYWdlYnJvd3NlciIsImluc3RhbGxlZF9hdF92ZXJzaW9uIjoiMy4wLjE2IiwiaWRfZmllbGQiOiJJRCIsInNldHRpbmdzIjp7ImFqYXhfcGFnaW5hdGlvbiI6IjEiLCJkaXNwbGF5X3ZpZXciOiJkZWZhdWx0LXZpZXcucGhwIiwidGVtcGxhdGUiOiIiLCJ1c2VfbGlnaHRib3hfZWZmZWN0Ijp0cnVlLCJuZ2dfdHJpZ2dlcnNfZGlzcGxheSI6Im5ldmVyIiwiX2Vycm9ycyI6W119LCJoaWRkZW5fZnJvbV91aSI6ZmFsc2UsImhpZGRlbl9mcm9tX2lndyI6ZmFsc2UsIl9fZGVmYXVsdHNfc2V0Ijp0cnVlfQ==","0","http://foolstacks.ir/?post_type=display_type&#038;p=2260","0","display_type","","0");
INSERT INTO `st_posts` VALUES("2261","1","2018-11-13 13:20:49","0000-00-00 00:00:00","eyJmaWx0ZXIiOiJyYXciLCJtZXRhX2lkIjoiNzUxIiwicG9zdF9pZCI6IjIyNjEiLCJtZXRhX2tleSI6Im5hbWUiLCJtZXRhX3ZhbHVlIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX3NpbmdsZXBpYyIsInRpdGxlIjoiTmV4dEdFTiBCYXNpYyBTaW5nbGVQaWMiLCJlbnRpdHlfdHlwZXMiOlsiaW1hZ2UiXSwicHJldmlld19pbWFnZV9yZWxwYXRoIjoiXC9uZXh0Z2VuLWdhbGxlcnlcL3Byb2R1Y3RzXC9waG90b2NyYXRpX25leHRnZW5cL21vZHVsZXNcL25leHRnZW5fYmFzaWNfc2luZ2xlcGljXC9zdGF0aWNcL3ByZXZpZXcuZ2lmIiwiZGVmYXVsdF9zb3VyY2UiOiJnYWxsZXJpZXMiLCJ2aWV3X29yZGVyIjoxMDA2MCwiaGlkZGVuX2Zyb21fdWkiOnRydWUsImhpZGRlbl9mcm9tX2lndyI6dHJ1ZSwiYWxpYXNlcyI6WyJiYXNpY19zaW5nbGVwaWMiLCJzaW5nbGVwaWMiLCJuZXh0Z2VuX2Jhc2ljX3NpbmdsZXBpYyJdLCJuYW1lIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX3NpbmdsZXBpYyIsImluc3RhbGxlZF9hdF92ZXJzaW9uIjoiMy4wLjE2IiwiaWRfZmllbGQiOiJJRCIsInNldHRpbmdzIjp7IndpZHRoIjoiIiwiaGVpZ2h0IjoiIiwibGluayI6IiIsImxpbmtfdGFyZ2V0IjoiX2JsYW5rIiwiZmxvYXQiOiIiLCJxdWFsaXR5IjoiMTAwIiwiY3JvcCI6IjAiLCJkaXNwbGF5X3dhdGVybWFyayI6IjAiLCJkaXNwbGF5X3JlZmxlY3Rpb24iOiIwIiwidGVtcGxhdGUiOiIiLCJ1c2VfbGlnaHRib3hfZWZmZWN0Ijp0cnVlLCJtb2RlIjoiIiwibmdnX3RyaWdnZXJzX2Rpc3BsYXkiOiJuZXZlciIsIl9lcnJvcnMiOltdfSwiX19kZWZhdWx0c19zZXQiOnRydWV9","NextGEN Basic SinglePic","","draft","closed","closed","","","","","2018-11-14 12:37:24","2018-11-14 09:07:24","eyJmaWx0ZXIiOiJyYXciLCJtZXRhX2lkIjoiNzUxIiwicG9zdF9pZCI6IjIyNjEiLCJtZXRhX2tleSI6Im5hbWUiLCJtZXRhX3ZhbHVlIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX3NpbmdsZXBpYyIsInRpdGxlIjoiTmV4dEdFTiBCYXNpYyBTaW5nbGVQaWMiLCJlbnRpdHlfdHlwZXMiOlsiaW1hZ2UiXSwicHJldmlld19pbWFnZV9yZWxwYXRoIjoiXC9uZXh0Z2VuLWdhbGxlcnlcL3Byb2R1Y3RzXC9waG90b2NyYXRpX25leHRnZW5cL21vZHVsZXNcL25leHRnZW5fYmFzaWNfc2luZ2xlcGljXC9zdGF0aWNcL3ByZXZpZXcuZ2lmIiwiZGVmYXVsdF9zb3VyY2UiOiJnYWxsZXJpZXMiLCJ2aWV3X29yZGVyIjoxMDA2MCwiaGlkZGVuX2Zyb21fdWkiOnRydWUsImhpZGRlbl9mcm9tX2lndyI6dHJ1ZSwiYWxpYXNlcyI6WyJiYXNpY19zaW5nbGVwaWMiLCJzaW5nbGVwaWMiLCJuZXh0Z2VuX2Jhc2ljX3NpbmdsZXBpYyJdLCJuYW1lIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX3NpbmdsZXBpYyIsImluc3RhbGxlZF9hdF92ZXJzaW9uIjoiMy4wLjE2IiwiaWRfZmllbGQiOiJJRCIsInNldHRpbmdzIjp7IndpZHRoIjoiIiwiaGVpZ2h0IjoiIiwibGluayI6IiIsImxpbmtfdGFyZ2V0IjoiX2JsYW5rIiwiZmxvYXQiOiIiLCJxdWFsaXR5IjoiMTAwIiwiY3JvcCI6IjAiLCJkaXNwbGF5X3dhdGVybWFyayI6IjAiLCJkaXNwbGF5X3JlZmxlY3Rpb24iOiIwIiwidGVtcGxhdGUiOiIiLCJ1c2VfbGlnaHRib3hfZWZmZWN0Ijp0cnVlLCJtb2RlIjoiIiwibmdnX3RyaWdnZXJzX2Rpc3BsYXkiOiJuZXZlciIsIl9lcnJvcnMiOltdfSwiX19kZWZhdWx0c19zZXQiOnRydWV9","0","http://foolstacks.ir/?post_type=display_type&#038;p=2261","0","display_type","","0");
INSERT INTO `st_posts` VALUES("2262","1","2018-11-13 13:20:49","0000-00-00 00:00:00","eyJmaWx0ZXIiOiJyYXciLCJtZXRhX2lkIjoiNzYzIiwicG9zdF9pZCI6IjIyNjIiLCJtZXRhX2tleSI6Im5hbWUiLCJtZXRhX3ZhbHVlIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX3RhZ2Nsb3VkIiwidGl0bGUiOiJOZXh0R0VOIEJhc2ljIFRhZ0Nsb3VkIiwiZW50aXR5X3R5cGVzIjpbImltYWdlIl0sInByZXZpZXdfaW1hZ2VfcmVscGF0aCI6IlwvbmV4dGdlbi1nYWxsZXJ5XC9wcm9kdWN0c1wvcGhvdG9jcmF0aV9uZXh0Z2VuXC9tb2R1bGVzXC9uZXh0Z2VuX2Jhc2ljX3RhZ2Nsb3VkXC9zdGF0aWNcL3ByZXZpZXcuZ2lmIiwiZGVmYXVsdF9zb3VyY2UiOiJ0YWdzIiwidmlld19vcmRlciI6MTAxMDAsImFsaWFzZXMiOlsiYmFzaWNfdGFnY2xvdWQiLCJ0YWdjbG91ZCIsIm5leHRnZW5fYmFzaWNfdGFnY2xvdWQiXSwibmFtZSI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY190YWdjbG91ZCIsImluc3RhbGxlZF9hdF92ZXJzaW9uIjoiMy4wLjE2IiwiaWRfZmllbGQiOiJJRCIsInNldHRpbmdzIjp7Im51bWJlciI6IjQ1IiwiZ2FsbGVyeV9kaXNwbGF5X3R5cGUiOiJwaG90b2NyYXRpLW5leHRnZW5fYmFzaWNfdGh1bWJuYWlscyIsInVzZV9saWdodGJveF9lZmZlY3QiOnRydWUsIm5nZ190cmlnZ2Vyc19kaXNwbGF5IjoibmV2ZXIiLCJfZXJyb3JzIjpbXX0sImhpZGRlbl9mcm9tX3VpIjpmYWxzZSwiaGlkZGVuX2Zyb21faWd3IjpmYWxzZSwiX19kZWZhdWx0c19zZXQiOnRydWV9","NextGEN Basic TagCloud","","draft","closed","closed","","","","","2018-11-14 12:37:24","2018-11-14 09:07:24","eyJmaWx0ZXIiOiJyYXciLCJtZXRhX2lkIjoiNzYzIiwicG9zdF9pZCI6IjIyNjIiLCJtZXRhX2tleSI6Im5hbWUiLCJtZXRhX3ZhbHVlIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX3RhZ2Nsb3VkIiwidGl0bGUiOiJOZXh0R0VOIEJhc2ljIFRhZ0Nsb3VkIiwiZW50aXR5X3R5cGVzIjpbImltYWdlIl0sInByZXZpZXdfaW1hZ2VfcmVscGF0aCI6IlwvbmV4dGdlbi1nYWxsZXJ5XC9wcm9kdWN0c1wvcGhvdG9jcmF0aV9uZXh0Z2VuXC9tb2R1bGVzXC9uZXh0Z2VuX2Jhc2ljX3RhZ2Nsb3VkXC9zdGF0aWNcL3ByZXZpZXcuZ2lmIiwiZGVmYXVsdF9zb3VyY2UiOiJ0YWdzIiwidmlld19vcmRlciI6MTAxMDAsImFsaWFzZXMiOlsiYmFzaWNfdGFnY2xvdWQiLCJ0YWdjbG91ZCIsIm5leHRnZW5fYmFzaWNfdGFnY2xvdWQiXSwibmFtZSI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY190YWdjbG91ZCIsImluc3RhbGxlZF9hdF92ZXJzaW9uIjoiMy4wLjE2IiwiaWRfZmllbGQiOiJJRCIsInNldHRpbmdzIjp7Im51bWJlciI6IjQ1IiwiZ2FsbGVyeV9kaXNwbGF5X3R5cGUiOiJwaG90b2NyYXRpLW5leHRnZW5fYmFzaWNfdGh1bWJuYWlscyIsInVzZV9saWdodGJveF9lZmZlY3QiOnRydWUsIm5nZ190cmlnZ2Vyc19kaXNwbGF5IjoibmV2ZXIiLCJfZXJyb3JzIjpbXX0sImhpZGRlbl9mcm9tX3VpIjpmYWxzZSwiaGlkZGVuX2Zyb21faWd3IjpmYWxzZSwiX19kZWZhdWx0c19zZXQiOnRydWV9","0","http://foolstacks.ir/?post_type=display_type&#038;p=2262","0","display_type","","0");
INSERT INTO `st_posts` VALUES("2263","1","2018-11-13 13:20:49","0000-00-00 00:00:00","eyJmaWx0ZXIiOiJyYXciLCJtZXRhX2lkIjoiNzc4IiwicG9zdF9pZCI6IjIyNjMiLCJtZXRhX2tleSI6Im5hbWUiLCJtZXRhX3ZhbHVlIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX2NvbXBhY3RfYWxidW0iLCJ0aXRsZSI6Ik5leHRHRU4gQmFzaWMgQ29tcGFjdCBBbGJ1bSIsIm1vZHVsZV9pZCI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY19hbGJ1bSIsImVudGl0eV90eXBlcyI6WyJhbGJ1bSIsImdhbGxlcnkiXSwicHJldmlld19pbWFnZV9yZWxwYXRoIjoiXC9uZXh0Z2VuLWdhbGxlcnlcL3Byb2R1Y3RzXC9waG90b2NyYXRpX25leHRnZW5cL21vZHVsZXNcL25leHRnZW5fYmFzaWNfYWxidW1cL3N0YXRpY1wvY29tcGFjdF9wcmV2aWV3LmpwZyIsImRlZmF1bHRfc291cmNlIjoiYWxidW1zIiwidmlld19vcmRlciI6MTAyMDAsImFsaWFzZXMiOlsiYmFzaWNfY29tcGFjdF9hbGJ1bSIsIm5leHRnZW5fYmFzaWNfYWxidW0iLCJiYXNpY19hbGJ1bV9jb21wYWN0IiwiY29tcGFjdF9hbGJ1bSJdLCJuYW1lIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX2NvbXBhY3RfYWxidW0iLCJpbnN0YWxsZWRfYXRfdmVyc2lvbiI6IjMuMC4xNiIsImlkX2ZpZWxkIjoiSUQiLCJzZXR0aW5ncyI6eyJnYWxsZXJ5X2Rpc3BsYXlfdHlwZSI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY190aHVtYm5haWxzIiwiZ2FsbGVyaWVzX3Blcl9wYWdlIjoiMCIsImVuYWJsZV9icmVhZGNydW1icyI6IjEiLCJkaXNwbGF5X3ZpZXciOiJkZWZhdWx0LXZpZXcucGhwIiwidGVtcGxhdGUiOiIiLCJlbmFibGVfZGVzY3JpcHRpb25zIjoiMCIsIm92ZXJyaWRlX3RodW1ibmFpbF9zZXR0aW5ncyI6IjEiLCJ0aHVtYm5haWxfd2lkdGgiOiIyNDAiLCJ0aHVtYm5haWxfaGVpZ2h0IjoiMTYwIiwidGh1bWJuYWlsX2Nyb3AiOiIxIiwidXNlX2xpZ2h0Ym94X2VmZmVjdCI6dHJ1ZSwiZGlzYWJsZV9wYWdpbmF0aW9uIjowLCJvcGVuX2dhbGxlcnlfaW5fbGlnaHRib3giOjAsInRodW1ibmFpbF9xdWFsaXR5IjoxMDAsInRodW1ibmFpbF93YXRlcm1hcmsiOjAsImdhbGxlcnlfZGlzcGxheV90ZW1wbGF0ZSI6IiIsIm5nZ190cmlnZ2Vyc19kaXNwbGF5IjoibmV2ZXIiLCJfZXJyb3JzIjpbXX0sImhpZGRlbl9mcm9tX3VpIjpmYWxzZSwiaGlkZGVuX2Zyb21faWd3IjpmYWxzZSwiX19kZWZhdWx0c19zZXQiOnRydWV9","NextGEN Basic Compact Album","","draft","closed","closed","","","","","2018-11-14 12:37:24","2018-11-14 09:07:24","eyJmaWx0ZXIiOiJyYXciLCJtZXRhX2lkIjoiNzc4IiwicG9zdF9pZCI6IjIyNjMiLCJtZXRhX2tleSI6Im5hbWUiLCJtZXRhX3ZhbHVlIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX2NvbXBhY3RfYWxidW0iLCJ0aXRsZSI6Ik5leHRHRU4gQmFzaWMgQ29tcGFjdCBBbGJ1bSIsIm1vZHVsZV9pZCI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY19hbGJ1bSIsImVudGl0eV90eXBlcyI6WyJhbGJ1bSIsImdhbGxlcnkiXSwicHJldmlld19pbWFnZV9yZWxwYXRoIjoiXC9uZXh0Z2VuLWdhbGxlcnlcL3Byb2R1Y3RzXC9waG90b2NyYXRpX25leHRnZW5cL21vZHVsZXNcL25leHRnZW5fYmFzaWNfYWxidW1cL3N0YXRpY1wvY29tcGFjdF9wcmV2aWV3LmpwZyIsImRlZmF1bHRfc291cmNlIjoiYWxidW1zIiwidmlld19vcmRlciI6MTAyMDAsImFsaWFzZXMiOlsiYmFzaWNfY29tcGFjdF9hbGJ1bSIsIm5leHRnZW5fYmFzaWNfYWxidW0iLCJiYXNpY19hbGJ1bV9jb21wYWN0IiwiY29tcGFjdF9hbGJ1bSJdLCJuYW1lIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX2NvbXBhY3RfYWxidW0iLCJpbnN0YWxsZWRfYXRfdmVyc2lvbiI6IjMuMC4xNiIsImlkX2ZpZWxkIjoiSUQiLCJzZXR0aW5ncyI6eyJnYWxsZXJ5X2Rpc3BsYXlfdHlwZSI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY190aHVtYm5haWxzIiwiZ2FsbGVyaWVzX3Blcl9wYWdlIjoiMCIsImVuYWJsZV9icmVhZGNydW1icyI6IjEiLCJkaXNwbGF5X3ZpZXciOiJkZWZhdWx0LXZpZXcucGhwIiwidGVtcGxhdGUiOiIiLCJlbmFibGVfZGVzY3JpcHRpb25zIjoiMCIsIm92ZXJyaWRlX3RodW1ibmFpbF9zZXR0aW5ncyI6IjEiLCJ0aHVtYm5haWxfd2lkdGgiOiIyNDAiLCJ0aHVtYm5haWxfaGVpZ2h0IjoiMTYwIiwidGh1bWJuYWlsX2Nyb3AiOiIxIiwidXNlX2xpZ2h0Ym94X2VmZmVjdCI6dHJ1ZSwiZGlzYWJsZV9wYWdpbmF0aW9uIjowLCJvcGVuX2dhbGxlcnlfaW5fbGlnaHRib3giOjAsInRodW1ibmFpbF9xdWFsaXR5IjoxMDAsInRodW1ibmFpbF93YXRlcm1hcmsiOjAsImdhbGxlcnlfZGlzcGxheV90ZW1wbGF0ZSI6IiIsIm5nZ190cmlnZ2Vyc19kaXNwbGF5IjoibmV2ZXIiLCJfZXJyb3JzIjpbXX0sImhpZGRlbl9mcm9tX3VpIjpmYWxzZSwiaGlkZGVuX2Zyb21faWd3IjpmYWxzZSwiX19kZWZhdWx0c19zZXQiOnRydWV9","0","http://foolstacks.ir/?post_type=display_type&#038;p=2263","0","display_type","","0");
INSERT INTO `st_posts` VALUES("2264","1","2018-11-13 13:20:49","0000-00-00 00:00:00","eyJmaWx0ZXIiOiJyYXciLCJtZXRhX2lkIjoiNzkzIiwicG9zdF9pZCI6IjIyNjQiLCJtZXRhX2tleSI6Im5hbWUiLCJtZXRhX3ZhbHVlIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX2V4dGVuZGVkX2FsYnVtIiwidGl0bGUiOiJOZXh0R0VOIEJhc2ljIEV4dGVuZGVkIEFsYnVtIiwibW9kdWxlX2lkIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX2FsYnVtIiwiZW50aXR5X3R5cGVzIjpbImFsYnVtIiwiZ2FsbGVyeSJdLCJwcmV2aWV3X2ltYWdlX3JlbHBhdGgiOiJcL25leHRnZW4tZ2FsbGVyeVwvcHJvZHVjdHNcL3Bob3RvY3JhdGlfbmV4dGdlblwvbW9kdWxlc1wvbmV4dGdlbl9iYXNpY19hbGJ1bVwvc3RhdGljXC9leHRlbmRlZF9wcmV2aWV3LmpwZyIsImRlZmF1bHRfc291cmNlIjoiYWxidW1zIiwidmlld19vcmRlciI6MTAyMTAsImFsaWFzZXMiOlsiYmFzaWNfZXh0ZW5kZWRfYWxidW0iLCJuZXh0Z2VuX2Jhc2ljX2V4dGVuZGVkX2FsYnVtIiwiZXh0ZW5kZWRfYWxidW0iXSwibmFtZSI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY19leHRlbmRlZF9hbGJ1bSIsImluc3RhbGxlZF9hdF92ZXJzaW9uIjoiMy4wLjE2IiwiaWRfZmllbGQiOiJJRCIsInNldHRpbmdzIjp7ImdhbGxlcnlfZGlzcGxheV90eXBlIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX3RodW1ibmFpbHMiLCJnYWxsZXJpZXNfcGVyX3BhZ2UiOiIwIiwiZW5hYmxlX2JyZWFkY3J1bWJzIjoiMSIsImRpc3BsYXlfdmlldyI6ImRlZmF1bHQtdmlldy5waHAiLCJ0ZW1wbGF0ZSI6IiIsImVuYWJsZV9kZXNjcmlwdGlvbnMiOiIwIiwib3ZlcnJpZGVfdGh1bWJuYWlsX3NldHRpbmdzIjoiMSIsInRodW1ibmFpbF93aWR0aCI6IjMwMCIsInRodW1ibmFpbF9oZWlnaHQiOiIyMDAiLCJ0aHVtYm5haWxfY3JvcCI6IjEiLCJ1c2VfbGlnaHRib3hfZWZmZWN0Ijp0cnVlLCJkaXNhYmxlX3BhZ2luYXRpb24iOjAsIm9wZW5fZ2FsbGVyeV9pbl9saWdodGJveCI6MCwidGh1bWJuYWlsX3F1YWxpdHkiOjEwMCwidGh1bWJuYWlsX3dhdGVybWFyayI6MCwiZ2FsbGVyeV9kaXNwbGF5X3RlbXBsYXRlIjoiIiwibmdnX3RyaWdnZXJzX2Rpc3BsYXkiOiJuZXZlciIsIl9lcnJvcnMiOltdfSwiaGlkZGVuX2Zyb21fdWkiOmZhbHNlLCJoaWRkZW5fZnJvbV9pZ3ciOmZhbHNlLCJfX2RlZmF1bHRzX3NldCI6dHJ1ZX0=","NextGEN Basic Extended Album","","draft","closed","closed","","","","","2018-11-14 12:37:24","2018-11-14 09:07:24","eyJmaWx0ZXIiOiJyYXciLCJtZXRhX2lkIjoiNzkzIiwicG9zdF9pZCI6IjIyNjQiLCJtZXRhX2tleSI6Im5hbWUiLCJtZXRhX3ZhbHVlIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX2V4dGVuZGVkX2FsYnVtIiwidGl0bGUiOiJOZXh0R0VOIEJhc2ljIEV4dGVuZGVkIEFsYnVtIiwibW9kdWxlX2lkIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX2FsYnVtIiwiZW50aXR5X3R5cGVzIjpbImFsYnVtIiwiZ2FsbGVyeSJdLCJwcmV2aWV3X2ltYWdlX3JlbHBhdGgiOiJcL25leHRnZW4tZ2FsbGVyeVwvcHJvZHVjdHNcL3Bob3RvY3JhdGlfbmV4dGdlblwvbW9kdWxlc1wvbmV4dGdlbl9iYXNpY19hbGJ1bVwvc3RhdGljXC9leHRlbmRlZF9wcmV2aWV3LmpwZyIsImRlZmF1bHRfc291cmNlIjoiYWxidW1zIiwidmlld19vcmRlciI6MTAyMTAsImFsaWFzZXMiOlsiYmFzaWNfZXh0ZW5kZWRfYWxidW0iLCJuZXh0Z2VuX2Jhc2ljX2V4dGVuZGVkX2FsYnVtIiwiZXh0ZW5kZWRfYWxidW0iXSwibmFtZSI6InBob3RvY3JhdGktbmV4dGdlbl9iYXNpY19leHRlbmRlZF9hbGJ1bSIsImluc3RhbGxlZF9hdF92ZXJzaW9uIjoiMy4wLjE2IiwiaWRfZmllbGQiOiJJRCIsInNldHRpbmdzIjp7ImdhbGxlcnlfZGlzcGxheV90eXBlIjoicGhvdG9jcmF0aS1uZXh0Z2VuX2Jhc2ljX3RodW1ibmFpbHMiLCJnYWxsZXJpZXNfcGVyX3BhZ2UiOiIwIiwiZW5hYmxlX2JyZWFkY3J1bWJzIjoiMSIsImRpc3BsYXlfdmlldyI6ImRlZmF1bHQtdmlldy5waHAiLCJ0ZW1wbGF0ZSI6IiIsImVuYWJsZV9kZXNjcmlwdGlvbnMiOiIwIiwib3ZlcnJpZGVfdGh1bWJuYWlsX3NldHRpbmdzIjoiMSIsInRodW1ibmFpbF93aWR0aCI6IjMwMCIsInRodW1ibmFpbF9oZWlnaHQiOiIyMDAiLCJ0aHVtYm5haWxfY3JvcCI6IjEiLCJ1c2VfbGlnaHRib3hfZWZmZWN0Ijp0cnVlLCJkaXNhYmxlX3BhZ2luYXRpb24iOjAsIm9wZW5fZ2FsbGVyeV9pbl9saWdodGJveCI6MCwidGh1bWJuYWlsX3F1YWxpdHkiOjEwMCwidGh1bWJuYWlsX3dhdGVybWFyayI6MCwiZ2FsbGVyeV9kaXNwbGF5X3RlbXBsYXRlIjoiIiwibmdnX3RyaWdnZXJzX2Rpc3BsYXkiOiJuZXZlciIsIl9lcnJvcnMiOltdfSwiaGlkZGVuX2Zyb21fdWkiOmZhbHNlLCJoaWRkZW5fZnJvbV9pZ3ciOmZhbHNlLCJfX2RlZmF1bHRzX3NldCI6dHJ1ZX0=","0","http://foolstacks.ir/?post_type=display_type&#038;p=2264","0","display_type","","0");
INSERT INTO `st_posts` VALUES("2265","1","2018-11-13 13:37:46","2018-11-13 10:07:46","{
    \"sidebars_widgets[footer-area-2]\": {
        \"value\": [
            \"wp_statistics_widget-3\"
        ],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-13 10:07:46\"
    },
    \"widget_wp_statistics_widget[3]\": {
        \"value\": [],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-13 10:07:46\"
    }
}","","","trash","closed","closed","","86598333-d4e7-49b9-9b78-f4e9942de60d","","","2018-11-13 13:37:46","2018-11-13 10:07:46","","0","http://foolstacks.ir/?p=2265","0","customize_changeset","","0");
INSERT INTO `st_posts` VALUES("2266","1","2018-11-13 13:43:54","2018-11-13 10:13:54","{
    \"sidebars_widgets[footer-area-1]\": {
        \"value\": [],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-13 10:13:54\"
    }
}","","","trash","closed","closed","","ca692ab2-5f10-4cb7-98ca-d551235db2a4","","","2018-11-13 13:43:54","2018-11-13 10:13:54","","0","http://foolstacks.ir/?p=2266","0","customize_changeset","","0");
INSERT INTO `st_posts` VALUES("2267","1","2018-11-13 13:46:12","2018-11-13 10:16:12","{
    \"sidebars_widgets[footer-area-2]\": {
        \"value\": [],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-13 10:16:12\"
    }
}","","","trash","closed","closed","","b0d6b89b-8903-410a-b14c-b1a543d2d36c","","","2018-11-13 13:46:12","2018-11-13 10:16:12","","0","http://foolstacks.ir/?p=2267","0","customize_changeset","","0");
INSERT INTO `st_posts` VALUES("2268","1","2018-11-13 13:46:54","2018-11-13 10:16:54","{
    \"sidebars_widgets[footer-area-1]\": {
        \"value\": [
            \"wp_statistics_widget-5\"
        ],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-13 10:16:54\"
    },
    \"widget_wp_statistics_widget[5]\": {
        \"value\": [],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-13 10:16:54\"
    }
}","","","trash","closed","closed","","04ceb9e1-f4a2-4e34-a122-3a69a027a529","","","2018-11-13 13:46:54","2018-11-13 10:16:54","","0","http://foolstacks.ir/?p=2268","0","customize_changeset","","0");
INSERT INTO `st_posts` VALUES("2269","1","2018-11-13 13:53:46","2018-11-13 10:23:46","{
    \"sidebars_widgets[footer-area-2]\": {
        \"value\": [
            \"recent-posts-4\"
        ],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-13 10:23:46\"
    },
    \"widget_recent-posts[4]\": {
        \"value\": {
            \"encoded_serialized_instance\": \"YTozOntzOjU6InRpdGxlIjtzOjI2OiLZhtmI2LTYqtmHINmH2KfbjCDYqtin2LLZhyI7czo2OiJudW1iZXIiO2k6NDtzOjk6InNob3dfZGF0ZSI7YjoxO30=\",
            \"title\": \"\\u0646\\u0648\\u0634\\u062a\\u0647 \\u0647\\u0627\\u06cc \\u062a\\u0627\\u0632\\u0647\",
            \"is_widget_customizer_js_value\": true,
            \"instance_hash_key\": \"7abf51282502857999073476ebf6314f\"
        },
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-13 10:23:46\"
    }
}","","","trash","closed","closed","","df38b7a2-5ed9-418a-a093-fdfddaa685cd","","","2018-11-13 13:53:46","2018-11-13 10:23:46","","0","http://foolstacks.ir/?p=2269","0","customize_changeset","","0");
INSERT INTO `st_posts` VALUES("2270","1","2018-11-13 13:56:20","2018-11-13 10:26:20","{
    \"sidebars_widgets[footer-area-2]\": {
        \"value\": [
            \"archives-8\"
        ],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-13 10:25:59\"
    },
    \"widget_archives[8]\": {
        \"value\": {
            \"encoded_serialized_instance\": \"YTozOntzOjU6InRpdGxlIjtzOjI4OiLZhtmI2LTYqtmHINmH2KfbjCDZvtuM2LTbjNmGIjtzOjU6ImNvdW50IjtpOjA7czo4OiJkcm9wZG93biI7aTowO30=\",
            \"title\": \"\\u0646\\u0648\\u0634\\u062a\\u0647 \\u0647\\u0627\\u06cc \\u067e\\u06cc\\u0634\\u06cc\\u0646\",
            \"is_widget_customizer_js_value\": true,
            \"instance_hash_key\": \"a05a664e79b945b24978cd15ca19c299\"
        },
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-13 10:26:20\"
    }
}","","","trash","closed","closed","","b683d338-03a7-4ab2-9e87-61d831355331","","","2018-11-13 13:56:20","2018-11-13 10:26:20","","0","http://foolstacks.ir/?p=2270","0","customize_changeset","","0");
INSERT INTO `st_posts` VALUES("2271","1","2018-11-13 13:56:52","2018-11-13 10:26:52","{
    \"sidebars_widgets[wp_inactive_widgets]\": {
        \"value\": [
            \"archives-4\",
            \"text-10\",
            \"rss-5\",
            \"wp_statistics_widget-3\",
            \"archives-2\",
            \"meta-2\",
            \"search-2\",
            \"text-2\",
            \"text-3\",
            \"text-4\",
            \"text-5\",
            \"text-6\",
            \"text-7\",
            \"categories-2\",
            \"recent-posts-2\",
            \"recent-comments-2\",
            \"search-3\",
            \"text-9\",
            \"search-4\",
            \"rss-3\",
            \"text-8\",
            \"archives-6\"
        ],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-13 10:26:52\"
    },
    \"sidebars_widgets[footer-area-3]\": {
        \"value\": [
            \"recent-comments-6\"
        ],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-13 10:26:52\"
    },
    \"widget_recent-comments[6]\": {
        \"value\": [],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-13 10:26:52\"
    }
}","","","trash","closed","closed","","39ef152f-13bc-47c0-8940-ea5c9e10813b","","","2018-11-13 13:56:52","2018-11-13 10:26:52","","0","http://foolstacks.ir/?p=2271","0","customize_changeset","","0");
INSERT INTO `st_posts` VALUES("2272","1","2018-11-13 13:57:20","2018-11-13 10:27:20","{
    \"sidebars_widgets[wp_inactive_widgets]\": {
        \"value\": [
            \"archives-4\",
            \"text-10\",
            \"rss-5\",
            \"wp_statistics_widget-3\",
            \"archives-2\",
            \"meta-2\",
            \"search-2\",
            \"text-2\",
            \"text-3\",
            \"text-4\",
            \"text-5\",
            \"text-6\",
            \"text-7\",
            \"categories-2\",
            \"recent-posts-2\",
            \"recent-comments-2\",
            \"search-3\",
            \"text-9\",
            \"search-4\",
            \"rss-3\",
            \"text-8\",
            \"archives-6\",
            \"recent-comments-4\"
        ],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-13 10:27:20\"
    },
    \"sidebars_widgets[footer-area-4]\": {
        \"value\": [
            \"recent-posts-6\"
        ],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-13 10:27:20\"
    },
    \"widget_recent-posts[6]\": {
        \"value\": {
            \"encoded_serialized_instance\": \"YTozOntzOjU6InRpdGxlIjtzOjA6IiI7czo2OiJudW1iZXIiO2k6MztzOjk6InNob3dfZGF0ZSI7YjowO30=\",
            \"title\": \"\",
            \"is_widget_customizer_js_value\": true,
            \"instance_hash_key\": \"af895a6df29c0834b449fb77ddaffbf4\"
        },
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-13 10:27:20\"
    }
}","","","trash","closed","closed","","5c50ebd0-f4bd-4c35-81db-934cf0d59e3c","","","2018-11-13 13:57:20","2018-11-13 10:27:20","","0","http://foolstacks.ir/?p=2272","0","customize_changeset","","0");
INSERT INTO `st_posts` VALUES("2273","1","2018-11-13 14:03:07","2018-11-13 10:33:07","{
    \"blogname\": {
        \"value\": \"\\u0627\\u0644\\u0641\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-13 10:33:07\"
    }
}","","","trash","closed","closed","","bfaa3bf6-390b-4dd4-a152-7b87fbf905ae","","","2018-11-13 14:03:07","2018-11-13 10:33:07","","0","http://foolstacks.ir/?p=2273","0","customize_changeset","","0");
INSERT INTO `st_posts` VALUES("2274","1","2018-11-13 09:35:11","2018-11-13 10:35:11","{
    \"blogname\": {
        \"value\": \"\\u0631\\u0648\\u0632\\u0645\\u0631\\u0647 \\u0647\\u0627\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-13 10:35:11\"
    }
}","","","trash","closed","closed","","87c6ff67-9473-470a-a921-010a891f6b98","","","2018-11-13 09:35:11","2018-11-13 10:35:11","","0","http://foolstacks.ir/?p=2274","0","customize_changeset","","0");
INSERT INTO `st_posts` VALUES("2275","1","2018-11-13 13:15:36","2018-11-13 14:15:36","","1","","inherit","open","closed","","1-2","","","2018-11-13 13:15:36","2018-11-13 14:15:36","","0","http://foolstacks.ir/wp-content/uploads/2018/11/1-1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `st_posts` VALUES("2276","1","2018-11-13 13:15:41","2018-11-13 14:15:41","","2","","inherit","open","closed","","2-2","","","2018-11-13 13:15:41","2018-11-13 14:15:41","","0","http://foolstacks.ir/wp-content/uploads/2018/11/2-1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `st_posts` VALUES("2277","1","2018-11-13 13:15:44","2018-11-13 14:15:44","","3","","inherit","open","closed","","3-2","","","2018-11-13 13:15:44","2018-11-13 14:15:44","","0","http://foolstacks.ir/wp-content/uploads/2018/11/3.png","0","attachment","image/png","0");
INSERT INTO `st_posts` VALUES("2278","1","2018-11-13 13:15:49","2018-11-13 14:15:49","","4","","inherit","open","closed","","4-2","","","2018-11-13 13:15:49","2018-11-13 14:15:49","","0","http://foolstacks.ir/wp-content/uploads/2018/11/4-1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `st_posts` VALUES("2279","1","2018-11-13 13:15:53","2018-11-13 14:15:53","","5","","inherit","open","closed","","5-2","","","2018-11-13 13:15:53","2018-11-13 14:15:53","","0","http://foolstacks.ir/wp-content/uploads/2018/11/5-1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `st_posts` VALUES("2281","1","2018-11-13 13:21:10","2018-11-13 14:21:10","[contact-form-7 id=\"2256\" title=\"فرم تماس 1\"]
","ارتباط","","inherit","closed","closed","","28-revision-v1","","","2018-11-13 13:21:10","2018-11-13 14:21:10","","28","http://foolstacks.ir/?p=2281","0","revision","","0");
INSERT INTO `st_posts` VALUES("2280","1","2018-11-13 13:20:38","2018-11-13 14:20:38","[rev_slider slider2]	

[contact-form-7 id=\"2256\" title=\"فرم تماس 1\"]
","ارتباط","","inherit","closed","closed","","28-revision-v1","","","2018-11-13 13:20:38","2018-11-13 14:20:38","","28","http://foolstacks.ir/?p=2280","0","revision","","0");
INSERT INTO `st_posts` VALUES("2282","1","2018-11-13 13:21:37","2018-11-13 14:21:37","[rev_slider slider2]	","درباره","","inherit","closed","closed","","27-revision-v1","","","2018-11-13 13:21:37","2018-11-13 14:21:37","","27","http://foolstacks.ir/?p=2282","0","revision","","0");
INSERT INTO `st_posts` VALUES("2283","1","2018-11-13 13:25:08","2018-11-13 14:25:08","[rev_slider slider3]	","درباره","","inherit","closed","closed","","27-revision-v1","","","2018-11-13 13:25:08","2018-11-13 14:25:08","","27","http://foolstacks.ir/?p=2283","0","revision","","0");
INSERT INTO `st_posts` VALUES("2284","1","2018-11-13 13:32:38","2018-11-13 14:32:38","Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!","Hello world!","","inherit","closed","closed","","105-revision-v1","","","2018-11-13 13:32:38","2018-11-13 14:32:38","","105","http://foolstacks.ir/?p=2284","0","revision","","0");
INSERT INTO `st_posts` VALUES("2286","1","2018-11-13 17:54:05","2018-11-13 18:54:05","[video width=\"1280\" height=\"720\" mp4=\"http://foolstacks.ir/wp-content/uploads/2018/11/What-is-a-Blog.mp4\"][/video]

[rev_slider slider2]","درباره ما","","inherit","closed","closed","","27-revision-v1","","","2018-11-13 17:54:05","2018-11-13 18:54:05","","27","http://foolstacks.ir/?p=2286","0","revision","","0");
INSERT INTO `st_posts` VALUES("2287","1","2018-11-13 17:55:12","2018-11-13 18:55:12","[rev_slider slider2]

[video width=\"1280\" height=\"720\" mp4=\"http://foolstacks.ir/wp-content/uploads/2018/11/What-is-a-Blog.mp4\"][/video]","درباره ما","","inherit","closed","closed","","27-revision-v1","","","2018-11-13 17:55:12","2018-11-13 18:55:12","","27","http://foolstacks.ir/?p=2287","0","revision","","0");
INSERT INTO `st_posts` VALUES("2330","1","2018-11-13 22:03:55","2018-11-13 23:03:55","","","","inherit","closed","closed","","106-revision-v1","","","2018-11-13 22:03:55","2018-11-13 23:03:55","","106","http://foolstacks.ir/%about%/","0","revision","","0");
INSERT INTO `st_posts` VALUES("2288","1","2018-11-13 17:56:24","2018-11-13 18:56:24","","خانه","","inherit","closed","closed","","106-revision-v1","","","2018-11-13 17:56:24","2018-11-13 18:56:24","","106","http://foolstacks.ir/?p=2288","0","revision","","0");
INSERT INTO `st_posts` VALUES("2289","1","2018-11-13 18:13:12","2018-11-13 19:13:12","","stan-lee-marvel-comics-comicbookcom-1070074-1280x0","","inherit","open","closed","","stan-lee-marvel-comics-comicbookcom-1070074-1280x0","","","2018-11-13 18:13:12","2018-11-13 19:13:12","","0","http://foolstacks.ir/wp-content/uploads/2018/11/stan-lee-marvel-comics-comicbookcom-1070074-1280x0.jpeg","0","attachment","image/jpeg","0");
INSERT INTO `st_posts` VALUES("2290","1","2018-11-13 18:16:14","2018-11-13 19:16:14","<h1 style=\"text-align: center;\"><strong>!RIP. Stan Lee</strong></h1>","!RIP. Stan Lee","","publish","open","open","","2290","","","2018-11-13 19:21:37","2018-11-13 20:21:37","","0","http://foolstacks.ir/?p=2290","0","post","","0");
INSERT INTO `st_posts` VALUES("2291","1","2018-11-13 18:16:14","2018-11-13 19:16:14","<h1 style=\"text-align: center;\"><strong>!RIP. Stan Lee</strong></h1>","","","inherit","closed","closed","","2290-revision-v1","","","2018-11-13 18:16:14","2018-11-13 19:16:14","","2290","http://foolstacks.ir/?p=2291","0","revision","","0");
INSERT INTO `st_posts` VALUES("2292","1","2018-11-13 18:16:57","2018-11-13 19:16:57","<h1 style=\"text-align: center;\"><strong>!RIP. Stan Lee</strong></h1>","!RIP. Stan Lee","","inherit","closed","closed","","2290-revision-v1","","","2018-11-13 18:16:57","2018-11-13 19:16:57","","2290","http://foolstacks.ir/?p=2292","0","revision","","0");
INSERT INTO `st_posts` VALUES("2293","1","2018-11-13 18:46:55","2018-11-13 19:46:55","خودش آمدید!","صفحه اول","","inherit","closed","closed","","26-revision-v1","","","2018-11-13 18:46:55","2018-11-13 19:46:55","","26","http://foolstacks.ir/?p=2293","0","revision","","0");
INSERT INTO `st_posts` VALUES("2294","1","2018-11-13 18:49:51","2018-11-13 19:49:51","[contact-form-7 id=\"2256\" title=\"فرم تماس 1\"]
","ارتباط با ما","","inherit","closed","closed","","28-revision-v1","","","2018-11-13 18:49:51","2018-11-13 19:49:51","","28","http://foolstacks.ir/?p=2294","0","revision","","0");
INSERT INTO `st_posts` VALUES("2329","1","2018-11-13 21:43:52","2018-11-13 22:43:52","[rev_slider webdesign]

[video width=\"1280\" height=\"720\" mp4=\"http://foolstacks.ir/wp-content/uploads/2018/11/What-is-a-Blog.mp4\"][/video]","درباره ما","","inherit","closed","closed","","27-revision-v1","","","2018-11-13 21:43:52","2018-11-13 22:43:52","","27","http://foolstacks.ir/%about%/","0","revision","","0");
INSERT INTO `st_posts` VALUES("2295","1","2018-11-13 18:50:38","2018-11-13 19:50:38","[rev_slider webdesign]	

[video width=\"1280\" height=\"720\" mp4=\"http://foolstacks.ir/wp-content/uploads/2018/11/What-is-a-Blog.mp4\"][/video]","درباره ما","","inherit","closed","closed","","27-revision-v1","","","2018-11-13 18:50:38","2018-11-13 19:50:38","","27","http://foolstacks.ir/?p=2295","0","revision","","0");
INSERT INTO `st_posts` VALUES("2300","1","2018-11-13 19:05:30","2018-11-13 20:05:30","","Realisations","","inherit","closed","closed","","111-revision-v1","","","2018-11-13 19:05:30","2018-11-13 20:05:30","","111","http://foolstacks.ir/?p=2300","0","revision","","0");
INSERT INTO `st_posts` VALUES("2297","1","2018-11-13 19:03:36","2018-11-13 20:03:36","","Contact us","","inherit","closed","closed","","110-revision-v1","","","2018-11-13 19:03:36","2018-11-13 20:03:36","","110","http://foolstacks.ir/?p=2297","0","revision","","0");
INSERT INTO `st_posts` VALUES("2298","1","2018-11-13 19:04:20","2018-11-13 20:04:20","","Realisations","","inherit","closed","closed","","111-autosave-v1","","","2018-11-13 19:04:20","2018-11-13 20:04:20","","111","http://foolstacks.ir/?p=2298","0","revision","","0");
INSERT INTO `st_posts` VALUES("2299","1","2018-11-13 19:04:26","2018-11-13 20:04:26","","What we offer","","inherit","closed","closed","","108-autosave-v1","","","2018-11-13 19:04:26","2018-11-13 20:04:26","","108","http://foolstacks.ir/?p=2299","0","revision","","0");
INSERT INTO `st_posts` VALUES("2302","1","2018-11-13 19:08:59","2018-11-13 20:08:59","","hw","","inherit","open","closed","","hw","","","2018-11-13 19:08:59","2018-11-13 20:08:59","","1","http://foolstacks.ir/wp-content/uploads/2018/06/hw.jpeg","0","attachment","image/jpeg","0");
INSERT INTO `st_posts` VALUES("2303","1","2018-11-13 19:10:51","2018-11-13 20:10:51","<img class=\"size-medium wp-image-2302 aligncenter\" src=\"http://foolstacks.ir/wp-content/uploads/2018/06/hw-300x87.jpeg\" alt=\"\" width=\"300\" height=\"87\">
<h2 style=\"text-align: center;\"><strong>سلام دنیا!</strong></h2>","سلام دنیا!","","inherit","closed","closed","","1-revision-v1","","","2018-11-13 19:10:51","2018-11-13 20:10:51","","1","http://foolstacks.ir/?p=2303","0","revision","","0");
INSERT INTO `st_posts` VALUES("2304","1","2018-11-13 19:16:22","2018-11-13 20:16:22","","Marvel","","inherit","open","closed","","marvel","","","2018-11-13 19:16:22","2018-11-13 20:16:22","","2290","http://foolstacks.ir/wp-content/uploads/2018/11/Marvel.jpg","0","attachment","image/jpeg","0");
INSERT INTO `st_posts` VALUES("2305","1","2018-11-13 19:20:44","2018-11-13 20:20:44","{
    \"widget_archives[8]\": {
        \"value\": {
            \"encoded_serialized_instance\": \"YTozOntzOjU6InRpdGxlIjtzOjI4OiLZhtmI2LTYqtmHINmH2KfbjCDZvtuM2LTbjNmGIjtzOjU6ImNvdW50IjtpOjA7czo4OiJkcm9wZG93biI7aTowO30=\",
            \"title\": \"\\u0646\\u0648\\u0634\\u062a\\u0647 \\u0647\\u0627\\u06cc \\u067e\\u06cc\\u0634\\u06cc\\u0646\",
            \"is_widget_customizer_js_value\": true,
            \"instance_hash_key\": \"a05a664e79b945b24978cd15ca19c299\"
        },
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-13 20:20:35\"
    },
    \"widget_recent-posts[6]\": {
        \"value\": {
            \"encoded_serialized_instance\": \"YTozOntzOjU6InRpdGxlIjtzOjA6IiI7czo2OiJudW1iZXIiO2k6NDtzOjk6InNob3dfZGF0ZSI7YjowO30=\",
            \"title\": \"\",
            \"is_widget_customizer_js_value\": true,
            \"instance_hash_key\": \"5b28cb42052777024dcd82b93c956e50\"
        },
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-13 20:20:44\"
    }
}","","","trash","closed","closed","","3e9c10f5-b790-48ae-a95b-49c1bb2d0771","","","2018-11-13 19:20:44","2018-11-13 20:20:44","","0","http://foolstacks.ir/?p=2305","0","customize_changeset","","0");
INSERT INTO `st_posts` VALUES("2306","1","2018-11-13 19:26:29","2018-11-13 20:26:29","","Web-Design-Blog-Image","","inherit","open","closed","","web-design-blog-image","","","2018-11-13 19:26:29","2018-11-13 20:26:29","","0","http://foolstacks.ir/wp-content/uploads/2018/11/Web-Design-Blog-Image.jpg","0","attachment","image/jpeg","0");
INSERT INTO `st_posts` VALUES("2307","1","2018-11-13 20:23:11","2018-11-13 21:23:11","","blog","","inherit","open","closed","","blog","","","2018-11-13 20:36:41","2018-11-13 21:36:41","","2315","http://foolstacks.ir/wp-content/uploads/2018/11/blog.png","0","attachment","image/png","0");
INSERT INTO `st_posts` VALUES("2308","1","2018-11-13 20:23:15","2018-11-13 21:23:15","","brand","","inherit","open","closed","","brand","","","2018-11-13 20:38:35","2018-11-13 21:38:35","","2317","http://foolstacks.ir/wp-content/uploads/2018/11/brand.png","0","attachment","image/png","0");
INSERT INTO `st_posts` VALUES("2309","1","2018-11-13 20:23:18","2018-11-13 21:23:18","","portal","","inherit","open","closed","","portal","","","2018-11-13 20:48:59","2018-11-13 21:48:59","","2313","http://foolstacks.ir/wp-content/uploads/2018/11/portal.png","0","attachment","image/png","0");
INSERT INTO `st_posts` VALUES("2311","1","2018-11-13 20:23:23","2018-11-13 21:23:23","","wp","","inherit","open","closed","","wp","","","2018-11-13 20:40:12","2018-11-13 21:40:12","","2319","http://foolstacks.ir/wp-content/uploads/2018/11/wp.jpg","0","attachment","image/jpeg","0");
INSERT INTO `st_posts` VALUES("2312","1","2018-11-13 20:29:11","2018-11-13 21:29:11","","store","","inherit","open","closed","","store-2","","","2018-11-13 20:29:11","2018-11-13 21:29:11","","106","http://foolstacks.ir/wp-content/uploads/2018/11/store-1.png","0","attachment","image/png","0");
INSERT INTO `st_posts` VALUES("2313","1","2018-11-13 20:31:05","2018-11-13 21:31:05","<img class=\"alignnone size-medium wp-image-2309\" src=\"http://foolstacks.ir/wp-content/uploads/2018/11/portal-300x235.png\" alt=\"\" width=\"300\" height=\"235\">","پرتال سازمانی","","publish","closed","closed","","%d9%be%d8%b1%d8%aa%d8%a7%d9%84-%d8%b3%d8%a7%d8%b2%d9%85%d8%a7%d9%86%db%8c","","","2018-11-13 20:49:33","2018-11-13 21:49:33","","0","http://foolstacks.ir/?page_id=2313","0","page","","0");
INSERT INTO `st_posts` VALUES("2314","1","2018-11-13 20:31:05","2018-11-13 21:31:05","","پرتال سازمانی","","inherit","closed","closed","","2313-revision-v1","","","2018-11-13 20:31:05","2018-11-13 21:31:05","","2313","http://foolstacks.ir/?p=2314","0","revision","","0");
INSERT INTO `st_posts` VALUES("2315","1","2018-11-13 20:36:57","2018-11-13 21:36:57","<img class=\"alignnone size-medium wp-image-2307\" src=\"http://foolstacks.ir/wp-content/uploads/2018/11/blog-300x236.png\" alt=\"\" width=\"300\" height=\"236\">","بلاگ نویسی","","publish","closed","closed","","%d8%a8%d9%84%d8%a7%da%af-2","","","2018-11-13 20:48:19","2018-11-13 21:48:19","","0","http://foolstacks.ir/?page_id=2315","0","page","","0");
INSERT INTO `st_posts` VALUES("2316","1","2018-11-13 20:36:57","2018-11-13 21:36:57","<img src=\"http://foolstacks.ir/wp-content/uploads/2018/11/blog-300x236.png\" alt=\"\" width=\"300\" height=\"236\" class=\"alignnone size-medium wp-image-2307\" />","بلاگ","","inherit","closed","closed","","2315-revision-v1","","","2018-11-13 20:36:57","2018-11-13 21:36:57","","2315","http://foolstacks.ir/?p=2316","0","revision","","0");
INSERT INTO `st_posts` VALUES("2317","1","2018-11-13 20:38:43","2018-11-13 21:38:43","<img class=\"alignnone size-medium wp-image-2308\" src=\"http://foolstacks.ir/wp-content/uploads/2018/11/brand-300x191.png\" alt=\"\" width=\"300\" height=\"191\">","برندسازی","","publish","closed","closed","","%d8%a8%d8%b1%d9%86%d8%af%d8%b3%d8%a7%d8%b2%db%8c","","","2018-11-13 20:43:30","2018-11-13 21:43:30","","0","http://foolstacks.ir/?page_id=2317","0","page","","0");
INSERT INTO `st_posts` VALUES("2318","1","2018-11-13 20:38:43","2018-11-13 21:38:43","<img src=\"http://foolstacks.ir/wp-content/uploads/2018/11/brand-300x191.png\" alt=\"\" width=\"300\" height=\"191\" class=\"alignnone size-medium wp-image-2308\" />","برندسازی","","inherit","closed","closed","","2317-revision-v1","","","2018-11-13 20:38:43","2018-11-13 21:38:43","","2317","http://foolstacks.ir/?p=2318","0","revision","","0");
INSERT INTO `st_posts` VALUES("2319","1","2018-11-13 20:40:12","2018-11-13 21:40:12","<img src=\"http://foolstacks.ir/wp-content/uploads/2018/11/wp-300x172.jpg\" alt=\"\" width=\"300\" height=\"172\" class=\"alignnone size-medium wp-image-2311\" />","وردپرس","","publish","closed","closed","","%d9%88%d8%b1%d8%af%d9%be%d8%b1%d8%b3","","","2018-11-13 20:41:09","2018-11-13 21:41:09","","0","http://foolstacks.ir/?page_id=2319","0","page","","0");
INSERT INTO `st_posts` VALUES("2320","1","2018-11-13 20:40:12","2018-11-13 21:40:12","","وردپرس","","inherit","closed","closed","","2319-revision-v1","","","2018-11-13 20:40:12","2018-11-13 21:40:12","","2319","http://foolstacks.ir/?p=2320","0","revision","","0");
INSERT INTO `st_posts` VALUES("2321","1","2018-11-13 20:41:09","2018-11-13 21:41:09","<img src=\"http://foolstacks.ir/wp-content/uploads/2018/11/wp-300x172.jpg\" alt=\"\" width=\"300\" height=\"172\" class=\"alignnone size-medium wp-image-2311\" />","وردپرس","","inherit","closed","closed","","2319-revision-v1","","","2018-11-13 20:41:09","2018-11-13 21:41:09","","2319","http://foolstacks.ir/?p=2321","0","revision","","0");
INSERT INTO `st_posts` VALUES("2322","1","2018-11-13 20:43:30","2018-11-13 21:43:30","<img class=\"alignnone size-medium wp-image-2308\" src=\"http://foolstacks.ir/wp-content/uploads/2018/11/brand-300x191.png\" alt=\"\" width=\"300\" height=\"191\">","برندسازی","","inherit","closed","closed","","2317-revision-v1","","","2018-11-13 20:43:30","2018-11-13 21:43:30","","2317","http://foolstacks.ir/?p=2322","0","revision","","0");
INSERT INTO `st_posts` VALUES("2323","1","2018-11-13 20:44:40","2018-11-13 21:44:40","<img class=\"alignnone size-medium wp-image-2312\" src=\"http://foolstacks.ir/wp-content/uploads/2018/11/store-1-300x187.png\" alt=\"\" width=\"300\" height=\"187\">","فروشگاه اینترنتی","","publish","closed","closed","","%d9%81%d8%b1%d9%88%d8%b4%da%af%d8%a7%d9%87","","","2018-11-13 20:47:25","2018-11-13 21:47:25","","0","http://foolstacks.ir/?page_id=2323","0","page","","0");
INSERT INTO `st_posts` VALUES("2324","1","2018-11-13 20:44:40","2018-11-13 21:44:40","","فروشگاه","","inherit","closed","closed","","2323-revision-v1","","","2018-11-13 20:44:40","2018-11-13 21:44:40","","2323","http://foolstacks.ir/?p=2324","0","revision","","0");
INSERT INTO `st_posts` VALUES("2325","1","2018-11-13 20:45:23","2018-11-13 21:45:23","<img class=\"alignnone size-medium wp-image-2312\" src=\"http://foolstacks.ir/wp-content/uploads/2018/11/store-1-300x187.png\" alt=\"\" width=\"300\" height=\"187\">","فروشگاه","","inherit","closed","closed","","2323-revision-v1","","","2018-11-13 20:45:23","2018-11-13 21:45:23","","2323","http://foolstacks.ir/?p=2325","0","revision","","0");
INSERT INTO `st_posts` VALUES("2326","1","2018-11-13 20:47:25","2018-11-13 21:47:25","<img class=\"alignnone size-medium wp-image-2312\" src=\"http://foolstacks.ir/wp-content/uploads/2018/11/store-1-300x187.png\" alt=\"\" width=\"300\" height=\"187\">","فروشگاه اینترنتی","","inherit","closed","closed","","2323-revision-v1","","","2018-11-13 20:47:25","2018-11-13 21:47:25","","2323","http://foolstacks.ir/?p=2326","0","revision","","0");
INSERT INTO `st_posts` VALUES("2327","1","2018-11-13 20:48:19","2018-11-13 21:48:19","<img class=\"alignnone size-medium wp-image-2307\" src=\"http://foolstacks.ir/wp-content/uploads/2018/11/blog-300x236.png\" alt=\"\" width=\"300\" height=\"236\">","بلاگ نویسی","","inherit","closed","closed","","2315-revision-v1","","","2018-11-13 20:48:19","2018-11-13 21:48:19","","2315","http://foolstacks.ir/?p=2327","0","revision","","0");
INSERT INTO `st_posts` VALUES("2328","1","2018-11-13 20:49:33","2018-11-13 21:49:33","<img class=\"alignnone size-medium wp-image-2309\" src=\"http://foolstacks.ir/wp-content/uploads/2018/11/portal-300x235.png\" alt=\"\" width=\"300\" height=\"235\">","پرتال سازمانی","","inherit","closed","closed","","2313-revision-v1","","","2018-11-13 20:49:33","2018-11-13 21:49:33","","2313","http://foolstacks.ir/?p=2328","0","revision","","0");
INSERT INTO `st_posts` VALUES("2331","1","2018-11-13 22:05:45","2018-11-13 23:05:45","{
    \"blogname\": {
        \"value\": \"\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-13 23:05:45\"
    }
}","","","trash","closed","closed","","9aed82b2-8928-44e2-8c0d-e30dc9c09ef8","","","2018-11-13 22:05:45","2018-11-13 23:05:45","","0","http://foolstacks.ir/%about%/","0","customize_changeset","","0");
INSERT INTO `st_posts` VALUES("2332","1","2018-11-13 22:06:54","2018-11-13 23:06:54","{
    \"blogname\": {
        \"value\": \"\\u0631\\u0648\\u0632\\u0645\\u0631\\u0647 \\u0647\\u0627\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-13 23:06:54\"
    }
}","","","trash","closed","closed","","56dfb023-616c-4612-9ee1-d1141c2c7ca7","","","2018-11-13 22:06:54","2018-11-13 23:06:54","","0","http://foolstacks.ir/%about%/","0","customize_changeset","","0");
INSERT INTO `st_posts` VALUES("2333","1","2018-11-13 22:10:10","2018-11-13 23:10:10","","","","trash","closed","closed","","%d8%ae%d8%a7%d9%86%d9%87__trashed-2","","","2018-11-13 22:19:28","2018-11-13 23:19:28","","0","http://foolstacks.ir/?page_id=2333","0","page","","0");
INSERT INTO `st_posts` VALUES("2334","1","2018-11-13 22:10:10","2018-11-13 23:10:10","{
    \"page_on_front\": {
        \"value\": \"2333\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-13 23:10:10\"
    },
    \"nav_menus_created_posts\": {
        \"value\": [
            2333
        ],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-13 23:10:10\"
    }
}","","","trash","closed","closed","","15f03124-8b0f-4da3-b7e2-2db334789757","","","2018-11-13 22:10:10","2018-11-13 23:10:10","","0","http://foolstacks.ir/%about%/","0","customize_changeset","","0");
INSERT INTO `st_posts` VALUES("2335","1","2018-11-13 22:10:10","2018-11-13 23:10:10","","خانه","","inherit","closed","closed","","2333-revision-v1","","","2018-11-13 22:10:10","2018-11-13 23:10:10","","2333","http://foolstacks.ir/%about%/","0","revision","","0");
INSERT INTO `st_posts` VALUES("2336","1","2018-11-13 22:10:53","2018-11-13 23:10:53","{
    \"page_on_front\": {
        \"value\": \"106\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-13 23:10:53\"
    }
}","","","trash","closed","closed","","3b846766-6da8-48c7-9c46-cc1425d8987d","","","2018-11-13 22:10:53","2018-11-13 23:10:53","","0","http://foolstacks.ir/%about%/","0","customize_changeset","","0");
INSERT INTO `st_posts` VALUES("2337","1","2018-11-13 22:11:11","2018-11-13 23:11:11","{
    \"blogname\": {
        \"value\": \"\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-13 23:11:11\"
    }
}","","","trash","closed","closed","","f3730e2f-0404-4049-9fcc-96dfc8a69df5","","","2018-11-13 22:11:11","2018-11-13 23:11:11","","0","http://foolstacks.ir/%about%/","0","customize_changeset","","0");
INSERT INTO `st_posts` VALUES("2338","1","2018-11-13 22:13:28","2018-11-13 23:13:28","","","","inherit","closed","closed","","2333-revision-v1","","","2018-11-13 22:13:28","2018-11-13 23:13:28","","2333","http://foolstacks.ir/%about%/","0","revision","","0");
INSERT INTO `st_posts` VALUES("2339","1","2018-11-13 22:14:14","2018-11-13 23:14:14","{
    \"blogname\": {
        \"value\": \"\\u0631\\u0648\\u0632\\u0645\\u0631\\u0647 \\u0647\\u0627\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-13 23:14:14\"
    }
}","","","trash","closed","closed","","4301ba78-4760-4683-9cd5-403decda1ee7","","","2018-11-13 22:14:14","2018-11-13 23:14:14","","0","http://foolstacks.ir/%about%/","0","customize_changeset","","0");
INSERT INTO `st_posts` VALUES("2340","1","2018-11-13 22:14:42","2018-11-13 23:14:42","{
    \"page_on_front\": {
        \"value\": \"0\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-13 23:14:42\"
    }
}","","","trash","closed","closed","","fde9cb18-7961-4481-9bb2-9962a5817049","","","2018-11-13 22:14:42","2018-11-13 23:14:42","","0","http://foolstacks.ir/%about%/","0","customize_changeset","","0");
INSERT INTO `st_posts` VALUES("2341","1","2018-11-13 22:15:16","2018-11-13 23:15:16","{
    \"page_on_front\": {
        \"value\": \"106\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-13 23:15:16\"
    }
}","","","trash","closed","closed","","e4431335-8ce1-4e0e-991c-c0e7642b64b5","","","2018-11-13 22:15:16","2018-11-13 23:15:16","","0","http://foolstacks.ir/%about%/","0","customize_changeset","","0");
INSERT INTO `st_posts` VALUES("2342","1","2018-11-13 22:17:18","2018-11-13 23:17:18","","خانه","","trash","closed","closed","","%d8%ae%d8%a7%d9%86%d9%87-2__trashed","","","2018-11-13 22:19:02","2018-11-13 23:19:02","","0","http://foolstacks.ir/?page_id=2342","0","page","","0");
INSERT INTO `st_posts` VALUES("2343","1","2018-11-13 22:17:18","2018-11-13 23:17:18","{
    \"page_on_front\": {
        \"value\": \"2342\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-13 23:17:06\"
    },
    \"nav_menus_created_posts\": {
        \"value\": [
            2342
        ],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-13 23:17:06\"
    }
}","","","trash","closed","closed","","c2ba882a-6d44-4eb1-8757-a96bc1ff6886","","","2018-11-13 22:17:18","2018-11-13 23:17:18","","0","http://foolstacks.ir/?p=2343","0","customize_changeset","","0");
INSERT INTO `st_posts` VALUES("2344","1","2018-11-13 22:17:18","2018-11-13 23:17:18","","خانه","","inherit","closed","closed","","2342-revision-v1","","","2018-11-13 22:17:18","2018-11-13 23:17:18","","2342","http://foolstacks.ir/%about%/","0","revision","","0");
INSERT INTO `st_posts` VALUES("2345","1","2018-11-13 22:18:14","2018-11-13 23:18:14","","خانه","","inherit","closed","closed","","2342-autosave-v1","","","2018-11-13 22:18:14","2018-11-13 23:18:14","","2342","http://foolstacks.ir/%about%/","0","revision","","0");
INSERT INTO `st_posts` VALUES("2346","1","2018-11-13 22:20:05","2018-11-13 23:20:05","","خانه","","inherit","closed","closed","","106-revision-v1","","","2018-11-13 22:20:05","2018-11-13 23:20:05","","106","http://foolstacks.ir/%about%/","0","revision","","0");
INSERT INTO `st_posts` VALUES("2347","1","2018-11-13 22:20:43","2018-11-13 23:20:43","{
    \"show_on_front\": {
        \"value\": \"page\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-13 23:20:43\"
    },
    \"page_on_front\": {
        \"value\": \"106\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2018-11-13 23:20:43\"
    }
}","","","trash","closed","closed","","623989b6-958b-48ce-b700-f9668bd179a6","","","2018-11-13 22:20:43","2018-11-13 23:20:43","","0","http://foolstacks.ir/%about%/","0","customize_changeset","","0");
INSERT INTO `st_posts` VALUES("2348","1","2018-11-14 11:47:13","2018-11-14 08:17:13","&lt;iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d18329.307377441437!2d51.366665957120915!3d35.6968338514745!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3f8e00491ff3dcd9%3A0xf0b3697c567024bc!2sTehran%2C+Tehran+Province%2C+Iran!5e0!3m2!1sen!2s!4v1542183334626\" width=\"600\" height=\"450\" frameborder=\"0\" style=\"border:0\" allowfullscreen&gt;&lt;/iframe&gt;

[contact-form-7 id=\"2256\" title=\"فرم تماس 1\"]","ارتباط با ما","","inherit","closed","closed","","28-revision-v1","","","2018-11-14 11:47:13","2018-11-14 08:17:13","","28","http://foolstacks.ir/28-revision-v1/","0","revision","","0");
INSERT INTO `st_posts` VALUES("2349","1","2018-11-14 11:48:06","2018-11-14 08:18:06","
<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d18329.307377441437!2d51.366665957120915!3d35.6968338514745!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3f8e00491ff3dcd9%3A0xf0b3697c567024bc!2sTehran%2C+Tehran+Province%2C+Iran!5e0!3m2!1sen!2s!4v1542183334626\" width=\"600\" height=\"450\" frameborder=\"0\" style=\"border:0\" allowfullscreen></iframe>

[contact-form-7 id=\"2256\" title=\"فرم تماس 1\"]","ارتباط با ما","","inherit","closed","closed","","28-revision-v1","","","2018-11-14 11:48:06","2018-11-14 08:18:06","","28","http://foolstacks.ir/28-revision-v1/","0","revision","","0");
INSERT INTO `st_posts` VALUES("2350","1","2018-11-14 12:11:26","2018-11-14 08:41:26","[ngg src=\"galleries\" display=\"basic_thumbnail\"]","گالری","","publish","closed","closed","","%da%af%d8%a7%d9%84%d8%b1%db%8c","","","2018-11-14 12:35:16","2018-11-14 09:05:16","","0","http://foolstacks.ir/?page_id=2350","0","page","","0");
INSERT INTO `st_posts` VALUES("2351","1","2018-11-14 12:11:26","2018-11-14 08:41:26","","گالری","","inherit","closed","closed","","2350-revision-v1","","","2018-11-14 12:11:26","2018-11-14 08:41:26","","2350","http://foolstacks.ir/2350-revision-v1/","0","revision","","0");
INSERT INTO `st_posts` VALUES("2352","1","2018-11-14 12:13:36","2018-11-14 08:43:36"," ","","","publish","closed","closed","","2352","","","2018-11-14 12:14:06","2018-11-14 08:44:06","","0","http://foolstacks.ir/?p=2352","3","nav_menu_item","","0");
INSERT INTO `st_posts` VALUES("2353","1","2018-11-14 12:13:36","2018-11-14 08:43:36"," ","","","publish","closed","closed","","2353","","","2018-11-14 12:14:06","2018-11-14 08:44:06","","0","http://foolstacks.ir/?p=2353","2","nav_menu_item","","0");
INSERT INTO `st_posts` VALUES("2354","1","2018-11-14 12:13:36","2018-11-14 08:43:36"," ","","","publish","closed","closed","","2354","","","2018-11-14 12:14:06","2018-11-14 08:44:06","","0","http://foolstacks.ir/?p=2354","4","nav_menu_item","","0");
INSERT INTO `st_posts` VALUES("2358","1","2018-11-14 12:32:20","0000-00-00 00:00:00","eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9","Untitled ngg_pictures","","draft","closed","closed","","mixin_nextgen_table_extras","","","2018-11-14 12:32:20","2018-11-14 09:02:20","eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9","0","http://foolstacks.ir/?p=2358","0","ngg_pictures","","0");
INSERT INTO `st_posts` VALUES("2359","1","2018-11-14 12:32:21","0000-00-00 00:00:00","eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9","Untitled ngg_pictures","","draft","closed","closed","","mixin_nextgen_table_extras","","","2018-11-14 12:32:21","2018-11-14 09:02:21","eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9","0","http://foolstacks.ir/?p=2359","0","ngg_pictures","","0");
INSERT INTO `st_posts` VALUES("2355","1","2018-11-14 12:13:36","2018-11-14 08:43:36"," ","","","publish","closed","closed","","2355","","","2018-11-14 12:14:06","2018-11-14 08:44:06","","0","http://foolstacks.ir/?p=2355","5","nav_menu_item","","0");
INSERT INTO `st_posts` VALUES("2360","1","2018-11-14 12:32:23","0000-00-00 00:00:00","eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9","Untitled ngg_pictures","","draft","closed","closed","","mixin_nextgen_table_extras","","","2018-11-14 12:32:23","2018-11-14 09:02:23","eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9","0","http://foolstacks.ir/?p=2360","0","ngg_pictures","","0");
INSERT INTO `st_posts` VALUES("2361","1","2018-11-14 12:32:24","0000-00-00 00:00:00","eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9","Untitled ngg_pictures","","draft","closed","closed","","mixin_nextgen_table_extras","","","2018-11-14 12:32:24","2018-11-14 09:02:24","eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9","0","http://foolstacks.ir/?p=2361","0","ngg_pictures","","0");
INSERT INTO `st_posts` VALUES("2362","1","2018-11-14 12:32:26","0000-00-00 00:00:00","eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9","Untitled ngg_pictures","","draft","closed","closed","","mixin_nextgen_table_extras","","","2018-11-14 12:32:26","2018-11-14 09:02:26","eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9","0","http://foolstacks.ir/?p=2362","0","ngg_pictures","","0");
INSERT INTO `st_posts` VALUES("2363","1","2018-11-14 12:32:28","0000-00-00 00:00:00","eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9","Untitled ngg_pictures","","draft","closed","closed","","mixin_nextgen_table_extras","","","2018-11-14 12:32:28","2018-11-14 09:02:28","eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9","0","http://foolstacks.ir/?p=2363","0","ngg_pictures","","0");
INSERT INTO `st_posts` VALUES("2364","1","2018-11-14 12:32:29","0000-00-00 00:00:00","eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9","Untitled ngg_pictures","","draft","closed","closed","","mixin_nextgen_table_extras","","","2018-11-14 12:32:29","2018-11-14 09:02:29","eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9","0","http://foolstacks.ir/?p=2364","0","ngg_pictures","","0");
INSERT INTO `st_posts` VALUES("2365","1","2018-11-14 12:32:31","0000-00-00 00:00:00","eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9","Untitled ngg_pictures","","draft","closed","closed","","mixin_nextgen_table_extras","","","2018-11-14 12:32:31","2018-11-14 09:02:31","eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9","0","http://foolstacks.ir/?p=2365","0","ngg_pictures","","0");
INSERT INTO `st_posts` VALUES("2366","1","2018-11-14 12:32:32","0000-00-00 00:00:00","eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9","Untitled ngg_pictures","","draft","closed","closed","","mixin_nextgen_table_extras","","","2018-11-14 12:32:32","2018-11-14 09:02:32","eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9","0","http://foolstacks.ir/?p=2366","0","ngg_pictures","","0");
INSERT INTO `st_posts` VALUES("2367","1","2018-11-14 12:32:33","0000-00-00 00:00:00","eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9","Untitled ngg_pictures","","draft","closed","closed","","mixin_nextgen_table_extras","","","2018-11-14 12:32:33","2018-11-14 09:02:33","eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9","0","http://foolstacks.ir/?p=2367","0","ngg_pictures","","0");
INSERT INTO `st_posts` VALUES("2368","1","2018-11-14 12:34:40","0000-00-00 00:00:00","eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9","Untitled ngg_gallery","","draft","closed","closed","","mixin_nextgen_table_extras","","","2018-11-14 12:34:40","2018-11-14 09:04:40","eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9","0","http://foolstacks.ir/?p=2368","0","ngg_gallery","","0");
INSERT INTO `st_posts` VALUES("2369","1","2018-11-14 12:34:40","0000-00-00 00:00:00","eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9","Untitled ngg_pictures","","draft","closed","closed","","mixin_nextgen_table_extras","","","2018-11-14 12:34:40","2018-11-14 09:04:40","eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9","0","http://foolstacks.ir/?p=2369","0","ngg_pictures","","0");
INSERT INTO `st_posts` VALUES("2370","1","2018-11-14 12:34:41","0000-00-00 00:00:00","eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9","Untitled ngg_pictures","","draft","closed","closed","","mixin_nextgen_table_extras","","","2018-11-14 12:34:41","2018-11-14 09:04:41","eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9","0","http://foolstacks.ir/?p=2370","0","ngg_pictures","","0");
INSERT INTO `st_posts` VALUES("2371","1","2018-11-14 12:34:43","0000-00-00 00:00:00","eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9","Untitled ngg_pictures","","draft","closed","closed","","mixin_nextgen_table_extras","","","2018-11-14 12:34:43","2018-11-14 09:04:43","eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9","0","http://foolstacks.ir/?p=2371","0","ngg_pictures","","0");
INSERT INTO `st_posts` VALUES("2372","1","2018-11-14 12:34:45","0000-00-00 00:00:00","eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9","Untitled ngg_pictures","","draft","closed","closed","","mixin_nextgen_table_extras","","","2018-11-14 12:34:45","2018-11-14 09:04:45","eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9","0","http://foolstacks.ir/?p=2372","0","ngg_pictures","","0");
INSERT INTO `st_posts` VALUES("2373","1","2018-11-14 12:34:47","0000-00-00 00:00:00","eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9","Untitled ngg_pictures","","draft","closed","closed","","mixin_nextgen_table_extras","","","2018-11-14 12:34:47","2018-11-14 09:04:47","eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9","0","http://foolstacks.ir/?p=2373","0","ngg_pictures","","0");
INSERT INTO `st_posts` VALUES("2374","1","2018-11-14 12:34:48","0000-00-00 00:00:00","eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9","Untitled ngg_pictures","","draft","closed","closed","","mixin_nextgen_table_extras","","","2018-11-14 12:34:48","2018-11-14 09:04:48","eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9","0","http://foolstacks.ir/?p=2374","0","ngg_pictures","","0");
INSERT INTO `st_posts` VALUES("2375","1","2018-11-14 12:34:50","0000-00-00 00:00:00","eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9","Untitled ngg_pictures","","draft","closed","closed","","mixin_nextgen_table_extras","","","2018-11-14 12:34:50","2018-11-14 09:04:50","eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9","0","http://foolstacks.ir/?p=2375","0","ngg_pictures","","0");
INSERT INTO `st_posts` VALUES("2376","1","2018-11-14 12:34:52","0000-00-00 00:00:00","eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9","Untitled ngg_pictures","","draft","closed","closed","","mixin_nextgen_table_extras","","","2018-11-14 12:34:52","2018-11-14 09:04:52","eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9","0","http://foolstacks.ir/?p=2376","0","ngg_pictures","","0");
INSERT INTO `st_posts` VALUES("2377","1","2018-11-14 12:34:55","0000-00-00 00:00:00","eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9","Untitled ngg_pictures","","draft","closed","closed","","mixin_nextgen_table_extras","","","2018-11-14 12:34:55","2018-11-14 09:04:55","eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9","0","http://foolstacks.ir/?p=2377","0","ngg_pictures","","0");
INSERT INTO `st_posts` VALUES("2378","1","2018-11-14 12:34:56","0000-00-00 00:00:00","eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9","Untitled ngg_pictures","","draft","closed","closed","","mixin_nextgen_table_extras","","","2018-11-14 12:34:56","2018-11-14 09:04:56","eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9","0","http://foolstacks.ir/?p=2378","0","ngg_pictures","","0");
INSERT INTO `st_posts` VALUES("2379","1","2018-11-14 12:35:00","0000-00-00 00:00:00","eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9","Untitled ngg_pictures","","draft","closed","closed","","mixin_nextgen_table_extras","","","2018-11-14 12:35:00","2018-11-14 09:05:00","eyJpZF9maWVsZCI6IklEIiwiX19kZWZhdWx0c19zZXQiOnRydWV9","0","http://foolstacks.ir/?p=2379","0","ngg_pictures","","0");
INSERT INTO `st_posts` VALUES("2380","1","2018-11-14 12:35:16","2018-11-14 09:05:16","[ngg src=\"galleries\" display=\"basic_thumbnail\"]","گالری","","inherit","closed","closed","","2350-revision-v1","","","2018-11-14 12:35:16","2018-11-14 09:05:16","","2350","http://foolstacks.ir/2350-revision-v1/","0","revision","","0");
INSERT INTO `st_posts` VALUES("2381","1","2018-11-16 09:29:03","2018-11-16 05:59:03","","خانه","","inherit","closed","closed","","106-autosave-v1","","","2018-11-16 09:29:03","2018-11-16 05:59:03","","106","http://foolstacks.ir/106-autosave-v1/","0","revision","","0");


DROP TABLE IF EXISTS `st_revslider_css`;

CREATE TABLE `st_revslider_css` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `handle` text NOT NULL,
  `settings` text,
  `hover` text,
  `params` text NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=50 DEFAULT CHARSET=latin1;

INSERT INTO `st_revslider_css` VALUES("1",".tp-caption.medium_grey","","","{\"position\":\"absolute\",\"color\":\"#fff\",\"text-shadow\":\"0px 2px 5px rgba(0, 0, 0, 0.5)\",\"font-weight\":\"700\",\"font-size\":\"20px\",\"line-height\":\"20px\",\"font-family\":\"Arial\",\"padding\":\"2px 4px\",\"margin\":\"0px\",\"border-width\":\"0px\",\"border-style\":\"none\",\"background-color\":\"#888\",\"white-space\":\"nowrap\"}");
INSERT INTO `st_revslider_css` VALUES("2",".tp-caption.small_text","","","{\"position\":\"absolute\",\"color\":\"#fff\",\"text-shadow\":\"0px 2px 5px rgba(0, 0, 0, 0.5)\",\"font-weight\":\"700\",\"font-size\":\"14px\",\"line-height\":\"20px\",\"font-family\":\"Arial\",\"margin\":\"0px\",\"border-width\":\"0px\",\"border-style\":\"none\",\"white-space\":\"nowrap\"}");
INSERT INTO `st_revslider_css` VALUES("3",".tp-caption.medium_text","","","{\"position\":\"absolute\",\"color\":\"#fff\",\"text-shadow\":\"0px 2px 5px rgba(0, 0, 0, 0.5)\",\"font-weight\":\"700\",\"font-size\":\"20px\",\"line-height\":\"20px\",\"font-family\":\"Arial\",\"margin\":\"0px\",\"border-width\":\"0px\",\"border-style\":\"none\",\"white-space\":\"nowrap\"}");
INSERT INTO `st_revslider_css` VALUES("4",".tp-caption.large_text","","","{\"position\":\"absolute\",\"color\":\"#fff\",\"text-shadow\":\"0px 2px 5px rgba(0, 0, 0, 0.5)\",\"font-weight\":\"700\",\"font-size\":\"40px\",\"line-height\":\"40px\",\"font-family\":\"Arial\",\"margin\":\"0px\",\"border-width\":\"0px\",\"border-style\":\"none\",\"white-space\":\"nowrap\"}");
INSERT INTO `st_revslider_css` VALUES("5",".tp-caption.very_large_text","","","{\"position\":\"absolute\",\"color\":\"#fff\",\"text-shadow\":\"0px 2px 5px rgba(0, 0, 0, 0.5)\",\"font-weight\":\"700\",\"font-size\":\"60px\",\"line-height\":\"60px\",\"font-family\":\"Arial\",\"margin\":\"0px\",\"border-width\":\"0px\",\"border-style\":\"none\",\"white-space\":\"nowrap\",\"letter-spacing\":\"-2px\"}");
INSERT INTO `st_revslider_css` VALUES("6",".tp-caption.very_big_white","","","{\"position\":\"absolute\",\"color\":\"#fff\",\"text-shadow\":\"none\",\"font-weight\":\"800\",\"font-size\":\"60px\",\"line-height\":\"60px\",\"font-family\":\"Arial\",\"margin\":\"0px\",\"border-width\":\"0px\",\"border-style\":\"none\",\"white-space\":\"nowrap\",\"padding\":\"0px 4px\",\"padding-top\":\"1px\",\"background-color\":\"#000\"}");
INSERT INTO `st_revslider_css` VALUES("7",".tp-caption.very_big_black","","","{\"position\":\"absolute\",\"color\":\"#000\",\"text-shadow\":\"none\",\"font-weight\":\"700\",\"font-size\":\"60px\",\"line-height\":\"60px\",\"font-family\":\"Arial\",\"margin\":\"0px\",\"border-width\":\"0px\",\"border-style\":\"none\",\"white-space\":\"nowrap\",\"padding\":\"0px 4px\",\"padding-top\":\"1px\",\"background-color\":\"#fff\"}");
INSERT INTO `st_revslider_css` VALUES("8",".tp-caption.modern_medium_fat","","","{\"position\":\"absolute\",\"color\":\"#000\",\"text-shadow\":\"none\",\"font-weight\":\"800\",\"font-size\":\"24px\",\"line-height\":\"20px\",\"font-family\":\"\\\"Open Sans\\\", sans-serif\",\"margin\":\"0px\",\"border-width\":\"0px\",\"border-style\":\"none\",\"white-space\":\"nowrap\"}");
INSERT INTO `st_revslider_css` VALUES("9",".tp-caption.modern_medium_fat_white","","","{\"position\":\"absolute\",\"color\":\"#fff\",\"text-shadow\":\"none\",\"font-weight\":\"800\",\"font-size\":\"24px\",\"line-height\":\"20px\",\"font-family\":\"\\\"Open Sans\\\", sans-serif\",\"margin\":\"0px\",\"border-width\":\"0px\",\"border-style\":\"none\",\"white-space\":\"nowrap\"}");
INSERT INTO `st_revslider_css` VALUES("10",".tp-caption.modern_medium_light","","","{\"position\":\"absolute\",\"color\":\"#000\",\"text-shadow\":\"none\",\"font-weight\":\"300\",\"font-size\":\"24px\",\"line-height\":\"20px\",\"font-family\":\"\\\"Open Sans\\\", sans-serif\",\"margin\":\"0px\",\"border-width\":\"0px\",\"border-style\":\"none\",\"white-space\":\"nowrap\"}");
INSERT INTO `st_revslider_css` VALUES("11",".tp-caption.modern_big_bluebg","","","{\"position\":\"absolute\",\"color\":\"#fff\",\"text-shadow\":\"none\",\"font-weight\":\"800\",\"font-size\":\"30px\",\"line-height\":\"36px\",\"font-family\":\"\\\"Open Sans\\\", sans-serif\",\"padding\":\"3px 10px\",\"margin\":\"0px\",\"border-width\":\"0px\",\"border-style\":\"none\",\"background-color\":\"#4e5b6c\",\"letter-spacing\":\"0\"}");
INSERT INTO `st_revslider_css` VALUES("12",".tp-caption.modern_big_redbg","","","{\"position\":\"absolute\",\"color\":\"#fff\",\"text-shadow\":\"none\",\"font-weight\":\"300\",\"font-size\":\"30px\",\"line-height\":\"36px\",\"font-family\":\"\\\"Open Sans\\\", sans-serif\",\"padding\":\"3px 10px\",\"padding-top\":\"1px\",\"margin\":\"0px\",\"border-width\":\"0px\",\"border-style\":\"none\",\"background-color\":\"#de543e\",\"letter-spacing\":\"0\"}");
INSERT INTO `st_revslider_css` VALUES("13",".tp-caption.modern_small_text_dark","","","{\"position\":\"absolute\",\"color\":\"#555\",\"text-shadow\":\"none\",\"font-size\":\"14px\",\"line-height\":\"22px\",\"font-family\":\"Arial\",\"margin\":\"0px\",\"border-width\":\"0px\",\"border-style\":\"none\",\"white-space\":\"nowrap\"}");
INSERT INTO `st_revslider_css` VALUES("14",".tp-caption.boxshadow","","","{\"-moz-box-shadow\":\"0px 0px 20px rgba(0, 0, 0, 0.5)\",\"-webkit-box-shadow\":\"0px 0px 20px rgba(0, 0, 0, 0.5)\",\"box-shadow\":\"0px 0px 20px rgba(0, 0, 0, 0.5)\"}");
INSERT INTO `st_revslider_css` VALUES("15",".tp-caption.black","","","{\"color\":\"#000\",\"text-shadow\":\"none\"}");
INSERT INTO `st_revslider_css` VALUES("16",".tp-caption.noshadow","","","{\"text-shadow\":\"none\"}");
INSERT INTO `st_revslider_css` VALUES("17",".tp-caption.thinheadline_dark","","","{\"position\":\"absolute\",\"color\":\"rgba(0,0,0,0.85)\",\"text-shadow\":\"none\",\"font-weight\":\"300\",\"font-size\":\"30px\",\"line-height\":\"30px\",\"font-family\":\"\\\"Open Sans\\\"\",\"background-color\":\"transparent\"}");
INSERT INTO `st_revslider_css` VALUES("18",".tp-caption.thintext_dark","","","{\"position\":\"absolute\",\"color\":\"rgba(0,0,0,0.85)\",\"text-shadow\":\"none\",\"font-weight\":\"300\",\"font-size\":\"16px\",\"line-height\":\"26px\",\"font-family\":\"\\\"Open Sans\\\"\",\"background-color\":\"transparent\"}");
INSERT INTO `st_revslider_css` VALUES("19",".tp-caption.largeblackbg","","","{\"position\":\"absolute\",\"color\":\"#fff\",\"text-shadow\":\"none\",\"font-weight\":\"300\",\"font-size\":\"50px\",\"line-height\":\"70px\",\"font-family\":\"\\\"Open Sans\\\"\",\"background-color\":\"#000\",\"padding\":\"0px 20px\",\"-webkit-border-radius\":\"0px\",\"-moz-border-radius\":\"0px\",\"border-radius\":\"0px\"}");
INSERT INTO `st_revslider_css` VALUES("20",".tp-caption.largepinkbg","","","{\"position\":\"absolute\",\"color\":\"#fff\",\"text-shadow\":\"none\",\"font-weight\":\"300\",\"font-size\":\"50px\",\"line-height\":\"70px\",\"font-family\":\"\\\"Open Sans\\\"\",\"background-color\":\"#db4360\",\"padding\":\"0px 20px\",\"-webkit-border-radius\":\"0px\",\"-moz-border-radius\":\"0px\",\"border-radius\":\"0px\"}");
INSERT INTO `st_revslider_css` VALUES("21",".tp-caption.largewhitebg","","","{\"position\":\"absolute\",\"color\":\"#000\",\"text-shadow\":\"none\",\"font-weight\":\"300\",\"font-size\":\"50px\",\"line-height\":\"70px\",\"font-family\":\"\\\"Open Sans\\\"\",\"background-color\":\"#fff\",\"padding\":\"0px 20px\",\"-webkit-border-radius\":\"0px\",\"-moz-border-radius\":\"0px\",\"border-radius\":\"0px\"}");
INSERT INTO `st_revslider_css` VALUES("22",".tp-caption.largegreenbg","","","{\"position\":\"absolute\",\"color\":\"#fff\",\"text-shadow\":\"none\",\"font-weight\":\"300\",\"font-size\":\"50px\",\"line-height\":\"70px\",\"font-family\":\"\\\"Open Sans\\\"\",\"background-color\":\"#67ae73\",\"padding\":\"0px 20px\",\"-webkit-border-radius\":\"0px\",\"-moz-border-radius\":\"0px\",\"border-radius\":\"0px\"}");
INSERT INTO `st_revslider_css` VALUES("23",".tp-caption.excerpt","","","{\"font-size\":\"36px\",\"line-height\":\"36px\",\"font-weight\":\"700\",\"font-family\":\"Arial\",\"color\":\"#ffffff\",\"text-decoration\":\"none\",\"background-color\":\"rgba(0, 0, 0, 1)\",\"text-shadow\":\"none\",\"margin\":\"0px\",\"letter-spacing\":\"-1.5px\",\"padding\":\"1px 4px 0px 4px\",\"width\":\"150px\",\"white-space\":\"normal !important\",\"height\":\"auto\",\"border-width\":\"0px\",\"border-color\":\"rgb(255, 255, 255)\",\"border-style\":\"none\"}");
INSERT INTO `st_revslider_css` VALUES("24",".tp-caption.large_bold_grey","","","{\"font-size\":\"60px\",\"line-height\":\"60px\",\"font-weight\":\"800\",\"font-family\":\"\\\"Open Sans\\\"\",\"color\":\"rgb(102, 102, 102)\",\"text-decoration\":\"none\",\"background-color\":\"transparent\",\"text-shadow\":\"none\",\"margin\":\"0px\",\"padding\":\"1px 4px 0px\",\"border-width\":\"0px\",\"border-color\":\"rgb(255, 214, 88)\",\"border-style\":\"none\"}");
INSERT INTO `st_revslider_css` VALUES("25",".tp-caption.medium_thin_grey","","","{\"font-size\":\"34px\",\"line-height\":\"30px\",\"font-weight\":\"300\",\"font-family\":\"\\\"Open Sans\\\"\",\"color\":\"rgb(102, 102, 102)\",\"text-decoration\":\"none\",\"background-color\":\"transparent\",\"padding\":\"1px 4px 0px\",\"text-shadow\":\"none\",\"margin\":\"0px\",\"border-width\":\"0px\",\"border-color\":\"rgb(255, 214, 88)\",\"border-style\":\"none\"}");
INSERT INTO `st_revslider_css` VALUES("26",".tp-caption.small_thin_grey","","","{\"font-size\":\"18px\",\"line-height\":\"26px\",\"font-weight\":\"300\",\"font-family\":\"\\\"Open Sans\\\"\",\"color\":\"rgb(117, 117, 117)\",\"text-decoration\":\"none\",\"background-color\":\"transparent\",\"padding\":\"1px 4px 0px\",\"text-shadow\":\"none\",\"margin\":\"0px\",\"border-width\":\"0px\",\"border-color\":\"rgb(255, 214, 88)\",\"border-style\":\"none\"}");
INSERT INTO `st_revslider_css` VALUES("27",".tp-caption.lightgrey_divider","","","{\"text-decoration\":\"none\",\"background-color\":\"rgba(235, 235, 235, 1)\",\"width\":\"370px\",\"height\":\"3px\",\"background-position\":\"initial initial\",\"background-repeat\":\"initial initial\",\"border-width\":\"0px\",\"border-color\":\"rgb(34, 34, 34)\",\"border-style\":\"none\"}");
INSERT INTO `st_revslider_css` VALUES("28",".tp-caption.large_bold_darkblue","","","{\"font-size\":\"58px\",\"line-height\":\"60px\",\"font-weight\":\"800\",\"font-family\":\"\\\"Open Sans\\\"\",\"color\":\"rgb(52, 73, 94)\",\"text-decoration\":\"none\",\"background-color\":\"transparent\",\"border-width\":\"0px\",\"border-color\":\"rgb(255, 214, 88)\",\"border-style\":\"none\"}");
INSERT INTO `st_revslider_css` VALUES("29",".tp-caption.medium_bg_darkblue","","","{\"font-size\":\"20px\",\"line-height\":\"20px\",\"font-weight\":\"800\",\"font-family\":\"\\\"Open Sans\\\"\",\"color\":\"rgb(255, 255, 255)\",\"text-decoration\":\"none\",\"background-color\":\"rgb(52, 73, 94)\",\"padding\":\"10px\",\"border-width\":\"0px\",\"border-color\":\"rgb(255, 214, 88)\",\"border-style\":\"none\"}");
INSERT INTO `st_revslider_css` VALUES("30",".tp-caption.medium_bold_red","","","{\"font-size\":\"24px\",\"line-height\":\"30px\",\"font-weight\":\"800\",\"font-family\":\"\\\"Open Sans\\\"\",\"color\":\"rgb(227, 58, 12)\",\"text-decoration\":\"none\",\"background-color\":\"transparent\",\"padding\":\"0px\",\"border-width\":\"0px\",\"border-color\":\"rgb(255, 214, 88)\",\"border-style\":\"none\"}");
INSERT INTO `st_revslider_css` VALUES("31",".tp-caption.medium_light_red","","","{\"font-size\":\"21px\",\"line-height\":\"26px\",\"font-weight\":\"300\",\"font-family\":\"\\\"Open Sans\\\"\",\"color\":\"rgb(227, 58, 12)\",\"text-decoration\":\"none\",\"background-color\":\"transparent\",\"padding\":\"0px\",\"border-width\":\"0px\",\"border-color\":\"rgb(255, 214, 88)\",\"border-style\":\"none\"}");
INSERT INTO `st_revslider_css` VALUES("32",".tp-caption.medium_bg_red","","","{\"font-size\":\"20px\",\"line-height\":\"20px\",\"font-weight\":\"800\",\"font-family\":\"\\\"Open Sans\\\"\",\"color\":\"rgb(255, 255, 255)\",\"text-decoration\":\"none\",\"background-color\":\"rgb(227, 58, 12)\",\"padding\":\"10px\",\"border-width\":\"0px\",\"border-color\":\"rgb(255, 214, 88)\",\"border-style\":\"none\"}");
INSERT INTO `st_revslider_css` VALUES("33",".tp-caption.medium_bold_orange","","","{\"font-size\":\"24px\",\"line-height\":\"30px\",\"font-weight\":\"800\",\"font-family\":\"\\\"Open Sans\\\"\",\"color\":\"rgb(243, 156, 18)\",\"text-decoration\":\"none\",\"background-color\":\"transparent\",\"border-width\":\"0px\",\"border-color\":\"rgb(255, 214, 88)\",\"border-style\":\"none\"}");
INSERT INTO `st_revslider_css` VALUES("34",".tp-caption.medium_bg_orange","","","{\"font-size\":\"20px\",\"line-height\":\"20px\",\"font-weight\":\"800\",\"font-family\":\"\\\"Open Sans\\\"\",\"color\":\"rgb(255, 255, 255)\",\"text-decoration\":\"none\",\"background-color\":\"rgb(243, 156, 18)\",\"padding\":\"10px\",\"border-width\":\"0px\",\"border-color\":\"rgb(255, 214, 88)\",\"border-style\":\"none\"}");
INSERT INTO `st_revslider_css` VALUES("35",".tp-caption.grassfloor","","","{\"text-decoration\":\"none\",\"background-color\":\"rgba(160, 179, 151, 1)\",\"width\":\"4000px\",\"height\":\"150px\",\"border-width\":\"0px\",\"border-color\":\"rgb(34, 34, 34)\",\"border-style\":\"none\"}");
INSERT INTO `st_revslider_css` VALUES("36",".tp-caption.large_bold_white","","","{\"font-size\":\"58px\",\"line-height\":\"60px\",\"font-weight\":\"800\",\"font-family\":\"\\\"Open Sans\\\"\",\"color\":\"rgb(255, 255, 255)\",\"text-decoration\":\"none\",\"background-color\":\"transparent\",\"border-width\":\"0px\",\"border-color\":\"rgb(255, 214, 88)\",\"border-style\":\"none\"}");
INSERT INTO `st_revslider_css` VALUES("37",".tp-caption.medium_light_white","","","{\"font-size\":\"30px\",\"line-height\":\"36px\",\"font-weight\":\"300\",\"font-family\":\"\\\"Open Sans\\\"\",\"color\":\"rgb(255, 255, 255)\",\"text-decoration\":\"none\",\"background-color\":\"transparent\",\"padding\":\"0px\",\"border-width\":\"0px\",\"border-color\":\"rgb(255, 214, 88)\",\"border-style\":\"none\"}");
INSERT INTO `st_revslider_css` VALUES("38",".tp-caption.mediumlarge_light_white","","","{\"font-size\":\"34px\",\"line-height\":\"40px\",\"font-weight\":\"300\",\"font-family\":\"\\\"Open Sans\\\"\",\"color\":\"rgb(255, 255, 255)\",\"text-decoration\":\"none\",\"background-color\":\"transparent\",\"padding\":\"0px\",\"border-width\":\"0px\",\"border-color\":\"rgb(255, 214, 88)\",\"border-style\":\"none\"}");
INSERT INTO `st_revslider_css` VALUES("39",".tp-caption.mediumlarge_light_white_center","","","{\"font-size\":\"34px\",\"line-height\":\"40px\",\"font-weight\":\"300\",\"font-family\":\"\\\"Open Sans\\\"\",\"color\":\"#ffffff\",\"text-decoration\":\"none\",\"background-color\":\"transparent\",\"padding\":\"0px 0px 0px 0px\",\"text-align\":\"center\",\"border-width\":\"0px\",\"border-color\":\"rgb(255, 214, 88)\",\"border-style\":\"none\"}");
INSERT INTO `st_revslider_css` VALUES("40",".tp-caption.medium_bg_asbestos","","","{\"font-size\":\"20px\",\"line-height\":\"20px\",\"font-weight\":\"800\",\"font-family\":\"\\\"Open Sans\\\"\",\"color\":\"rgb(255, 255, 255)\",\"text-decoration\":\"none\",\"background-color\":\"rgb(127, 140, 141)\",\"padding\":\"10px\",\"border-width\":\"0px\",\"border-color\":\"rgb(255, 214, 88)\",\"border-style\":\"none\"}");
INSERT INTO `st_revslider_css` VALUES("41",".tp-caption.medium_light_black","","","{\"font-size\":\"30px\",\"line-height\":\"36px\",\"font-weight\":\"300\",\"font-family\":\"\\\"Open Sans\\\"\",\"color\":\"rgb(0, 0, 0)\",\"text-decoration\":\"none\",\"background-color\":\"transparent\",\"padding\":\"0px\",\"border-width\":\"0px\",\"border-color\":\"rgb(255, 214, 88)\",\"border-style\":\"none\"}");
INSERT INTO `st_revslider_css` VALUES("42",".tp-caption.large_bold_black","","","{\"font-size\":\"58px\",\"line-height\":\"60px\",\"font-weight\":\"800\",\"font-family\":\"\\\"Open Sans\\\"\",\"color\":\"rgb(0, 0, 0)\",\"text-decoration\":\"none\",\"background-color\":\"transparent\",\"border-width\":\"0px\",\"border-color\":\"rgb(255, 214, 88)\",\"border-style\":\"none\"}");
INSERT INTO `st_revslider_css` VALUES("43",".tp-caption.mediumlarge_light_darkblue","","","{\"font-size\":\"34px\",\"line-height\":\"40px\",\"font-weight\":\"300\",\"font-family\":\"\\\"Open Sans\\\"\",\"color\":\"rgb(52, 73, 94)\",\"text-decoration\":\"none\",\"background-color\":\"transparent\",\"padding\":\"0px\",\"border-width\":\"0px\",\"border-color\":\"rgb(255, 214, 88)\",\"border-style\":\"none\"}");
INSERT INTO `st_revslider_css` VALUES("44",".tp-caption.small_light_white","","","{\"font-size\":\"17px\",\"line-height\":\"28px\",\"font-weight\":\"300\",\"font-family\":\"\\\"Open Sans\\\"\",\"color\":\"rgb(255, 255, 255)\",\"text-decoration\":\"none\",\"background-color\":\"transparent\",\"padding\":\"0px\",\"border-width\":\"0px\",\"border-color\":\"rgb(255, 214, 88)\",\"border-style\":\"none\"}");
INSERT INTO `st_revslider_css` VALUES("45",".tp-caption.roundedimage","","","{\"border-width\":\"0px\",\"border-color\":\"rgb(34, 34, 34)\",\"border-style\":\"none\"}");
INSERT INTO `st_revslider_css` VALUES("46",".tp-caption.large_bg_black","","","{\"font-size\":\"40px\",\"line-height\":\"40px\",\"font-weight\":\"800\",\"font-family\":\"\\\"Open Sans\\\"\",\"color\":\"rgb(255, 255, 255)\",\"text-decoration\":\"none\",\"background-color\":\"rgb(0, 0, 0)\",\"padding\":\"10px 20px 15px\",\"border-width\":\"0px\",\"border-color\":\"rgb(255, 214, 88)\",\"border-style\":\"none\"}");
INSERT INTO `st_revslider_css` VALUES("47",".tp-caption.mediumwhitebg","","","{\"font-size\":\"30px\",\"line-height\":\"30px\",\"font-weight\":\"300\",\"font-family\":\"\\\"Open Sans\\\"\",\"color\":\"rgb(0, 0, 0)\",\"text-decoration\":\"none\",\"background-color\":\"rgb(255, 255, 255)\",\"padding\":\"5px 15px 10px\",\"text-shadow\":\"none\",\"border-width\":\"0px\",\"border-color\":\"rgb(0, 0, 0)\",\"border-style\":\"none\"}");
INSERT INTO `st_revslider_css` VALUES("48",".tp-caption.mfnrswebdesignlargelight","","","{\"color\":\"#ffffff\",\"text-shadow\":\"none\",\"font-size\":\"46px\",\"line-height\":\"46px\",\"font-weight\":\"700\",\"background-color\":\"transparent\",\"text-decoration\":\"none\",\"font-family\":\"Alegreya sans, sans-serif\",\"border-width\":\"0px\",\"border-color\":\"rgb(0, 0, 0)\",\"border-style\":\"none\"}");
INSERT INTO `st_revslider_css` VALUES("49",".tp-caption.mfnrswebdesignsmalllight","","","{\"color\":\"#ffffff\",\"text-shadow\":\"none\",\"font-size\":\"16px\",\"line-height\":\"23px\",\"font-weight\":\"300\",\"background-color\":\"transparent\",\"text-decoration\":\"none\",\"font-family\":\"Alegreya sans, sans-serif\",\"border-width\":\"0px\",\"border-color\":\"rgb(0, 0, 0)\",\"border-style\":\"none\"}");


DROP TABLE IF EXISTS `st_revslider_layer_animations`;

CREATE TABLE `st_revslider_layer_animations` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `handle` text NOT NULL,
  `params` text NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `st_revslider_layer_animations` VALUES("1","Short from Right 2","{\"movex\":\"2000\",\"movey\":\"0\",\"movez\":\"0\",\"rotationx\":\"0\",\"rotationy\":\"0\",\"rotationz\":\"0\",\"scalex\":\"100\",\"scaley\":\"100\",\"skewx\":\"0\",\"skewy\":\"0\",\"captionopacity\":\"0\",\"captionperspective\":\"600\",\"originx\":\"50\",\"originy\":\"50\"}");
INSERT INTO `st_revslider_layer_animations` VALUES("2","Short from Left 2","{\"movex\":\"-2000\",\"movey\":\"0\",\"movez\":\"0\",\"rotationx\":\"0\",\"rotationy\":\"0\",\"rotationz\":\"0\",\"scalex\":\"100\",\"scaley\":\"100\",\"skewx\":\"0\",\"skewy\":\"0\",\"captionopacity\":\"0\",\"captionperspective\":\"600\",\"originx\":\"50\",\"originy\":\"50\"}");


DROP TABLE IF EXISTS `st_revslider_settings`;

CREATE TABLE `st_revslider_settings` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `general` text NOT NULL,
  `params` text NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `st_revslider_settings` VALUES("1","a:0:{}","");


DROP TABLE IF EXISTS `st_revslider_sliders`;

CREATE TABLE `st_revslider_sliders` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `title` tinytext NOT NULL,
  `alias` tinytext,
  `params` text NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `st_revslider_sliders` VALUES("1","Home Webdesign","webdesign","{\"title\":\"Home Webdesign\",\"alias\":\"webdesign\",\"shortcode\":\"[rev_slider webdesign]\",\"source_type\":\"gallery\",\"post_types\":\"post\",\"post_category\":\"\",\"post_sortby\":\"ID\",\"posts_sort_direction\":\"DESC\",\"max_slider_posts\":\"30\",\"excerpt_limit\":\"55\",\"slider_template_id\":\"\",\"posts_list\":\"\",\"slider_type\":\"fullwidth\",\"fullscreen_offset_container\":\"\",\"fullscreen_offset_size\":\"\",\"fullscreen_min_height\":\"\",\"full_screen_align_force\":\"on\",\"auto_height\":\"off\",\"force_full_width\":\"on\",\"min_height\":\"0\",\"width\":\"1176\",\"height\":\"900\",\"responsitive_w1\":\"940\",\"responsitive_sw1\":\"770\",\"responsitive_w2\":\"780\",\"responsitive_sw2\":\"500\",\"responsitive_w3\":\"510\",\"responsitive_sw3\":\"310\",\"responsitive_w4\":\"0\",\"responsitive_sw4\":\"0\",\"responsitive_w5\":\"0\",\"responsitive_sw5\":\"0\",\"responsitive_w6\":\"0\",\"responsitive_sw6\":\"0\",\"delay\":\"5000\",\"shuffle\":\"off\",\"lazy_load\":\"off\",\"use_wpml\":\"off\",\"enable_static_layers\":\"off\",\"next_slide_on_window_focus\":\"off\",\"start_js_after_delay\":0,\"stop_slider\":\"off\",\"stop_after_loops\":0,\"stop_at_slide\":2,\"show_timerbar\":\"hide\",\"loop_slide\":\"loop\",\"position\":\"center\",\"margin_top\":0,\"margin_bottom\":0,\"margin_left\":0,\"margin_right\":0,\"shadow_type\":\"0\",\"padding\":0,\"background_color\":\"\",\"background_dotted_overlay\":\"none\",\"show_background_image\":\"false\",\"background_image\":\"http:\\/\\/foolstacks.ir\\/wp-content\\/\",\"bg_fit\":\"cover\",\"bg_repeat\":\"no-repeat\",\"bg_position\":\"center top\",\"stop_on_hover\":\"off\",\"keyboard_navigation\":\"off\",\"navigation_style\":\"round\",\"navigaion_type\":\"bullet\",\"navigation_arrows\":\"none\",\"navigaion_always_on\":\"false\",\"hide_thumbs\":200,\"navigaion_align_hor\":\"center\",\"navigaion_align_vert\":\"bottom\",\"navigaion_offset_hor\":\"0\",\"navigaion_offset_vert\":20,\"leftarrow_align_hor\":\"left\",\"leftarrow_align_vert\":\"center\",\"leftarrow_offset_hor\":20,\"leftarrow_offset_vert\":0,\"rightarrow_align_hor\":\"right\",\"rightarrow_align_vert\":\"center\",\"rightarrow_offset_hor\":20,\"rightarrow_offset_vert\":0,\"thumb_width\":100,\"thumb_height\":50,\"thumb_amount\":5,\"use_spinner\":\"0\",\"spinner_color\":\"#FFFFFF\",\"use_parallax\":\"off\",\"disable_parallax_mobile\":\"off\",\"parallax_type\":\"mouse\",\"parallax_bg_freeze\":\"off\",\"parallax_level_1\":\"5\",\"parallax_level_2\":\"10\",\"parallax_level_3\":\"15\",\"parallax_level_4\":\"20\",\"parallax_level_5\":\"25\",\"parallax_level_6\":\"30\",\"parallax_level_7\":\"35\",\"parallax_level_8\":\"40\",\"parallax_level_9\":\"45\",\"parallax_level_10\":\"50\",\"touchenabled\":\"on\",\"swipe_velocity\":75,\"swipe_min_touches\":1,\"drag_block_vertical\":\"false\",\"disable_on_mobile\":\"off\",\"disable_kenburns_on_mobile\":\"off\",\"hide_slider_under\":0,\"hide_defined_layers_under\":0,\"hide_all_layers_under\":0,\"hide_arrows_on_mobile\":\"off\",\"hide_bullets_on_mobile\":\"off\",\"hide_thumbs_on_mobile\":\"off\",\"hide_thumbs_under_resolution\":0,\"hide_thumbs_delay_mobile\":1500,\"start_with_slide\":\"1\",\"first_transition_active\":\"false\",\"first_transition_type\":\"fade\",\"first_transition_duration\":300,\"first_transition_slot_amount\":7,\"simplify_ie8_ios4\":\"off\",\"show_alternative_type\":\"off\",\"show_alternate_image\":\"\",\"reset_transitions\":\"\",\"reset_transition_duration\":0,\"0\":\"Execute settings on all slides\",\"jquery_noconflict\":\"on\",\"js_to_body\":\"false\",\"output_type\":\"none\",\"custom_css\":\"\",\"custom_javascript\":\"\",\"template\":\"false\"}");
INSERT INTO `st_revslider_sliders` VALUES("3","About","slider2","{\"title\":\"About\",\"alias\":\"slider2\",\"shortcode\":\"[rev_slider slider2]\",\"source_type\":\"gallery\",\"post_types\":\"post\",\"post_category\":\"\",\"post_sortby\":\"ID\",\"posts_sort_direction\":\"DESC\",\"max_slider_posts\":\"30\",\"excerpt_limit\":\"55\",\"slider_template_id\":\"\",\"posts_list\":\"\",\"slider_type\":\"fullwidth\",\"fullscreen_offset_container\":\"\",\"fullscreen_offset_size\":\"\",\"fullscreen_min_height\":\"\",\"full_screen_align_force\":\"on\",\"auto_height\":\"off\",\"force_full_width\":\"on\",\"min_height\":\"0\",\"width\":\"1176\",\"height\":\"900\",\"responsitive_w1\":\"940\",\"responsitive_sw1\":\"770\",\"responsitive_w2\":\"780\",\"responsitive_sw2\":\"500\",\"responsitive_w3\":\"510\",\"responsitive_sw3\":\"310\",\"responsitive_w4\":\"0\",\"responsitive_sw4\":\"0\",\"responsitive_w5\":\"0\",\"responsitive_sw5\":\"0\",\"responsitive_w6\":\"0\",\"responsitive_sw6\":\"0\",\"delay\":\"5000\",\"shuffle\":\"off\",\"lazy_load\":\"off\",\"use_wpml\":\"off\",\"enable_static_layers\":\"off\",\"next_slide_on_window_focus\":\"off\",\"start_js_after_delay\":0,\"stop_slider\":\"off\",\"stop_after_loops\":0,\"stop_at_slide\":2,\"show_timerbar\":\"hide\",\"loop_slide\":\"loop\",\"position\":\"center\",\"margin_top\":0,\"margin_bottom\":0,\"margin_left\":0,\"margin_right\":0,\"shadow_type\":\"0\",\"padding\":0,\"background_color\":\"\",\"background_dotted_overlay\":\"none\",\"show_background_image\":\"false\",\"background_image\":\"http:\\/\\/foolstacks.ir\\/wp-content\\/\",\"bg_fit\":\"cover\",\"bg_repeat\":\"no-repeat\",\"bg_position\":\"center top\",\"stop_on_hover\":\"off\",\"keyboard_navigation\":\"off\",\"navigation_style\":\"round\",\"navigaion_type\":\"bullet\",\"navigation_arrows\":\"none\",\"navigaion_always_on\":\"false\",\"hide_thumbs\":200,\"navigaion_align_hor\":\"center\",\"navigaion_align_vert\":\"bottom\",\"navigaion_offset_hor\":\"0\",\"navigaion_offset_vert\":20,\"leftarrow_align_hor\":\"left\",\"leftarrow_align_vert\":\"center\",\"leftarrow_offset_hor\":20,\"leftarrow_offset_vert\":0,\"rightarrow_align_hor\":\"right\",\"rightarrow_align_vert\":\"center\",\"rightarrow_offset_hor\":20,\"rightarrow_offset_vert\":0,\"thumb_width\":100,\"thumb_height\":50,\"thumb_amount\":5,\"use_spinner\":\"0\",\"spinner_color\":\"#FFFFFF\",\"use_parallax\":\"off\",\"disable_parallax_mobile\":\"off\",\"parallax_type\":\"mouse\",\"parallax_bg_freeze\":\"off\",\"parallax_level_1\":\"5\",\"parallax_level_2\":\"10\",\"parallax_level_3\":\"15\",\"parallax_level_4\":\"20\",\"parallax_level_5\":\"25\",\"parallax_level_6\":\"30\",\"parallax_level_7\":\"35\",\"parallax_level_8\":\"40\",\"parallax_level_9\":\"45\",\"parallax_level_10\":\"50\",\"touchenabled\":\"on\",\"swipe_velocity\":75,\"swipe_min_touches\":1,\"drag_block_vertical\":\"false\",\"disable_on_mobile\":\"off\",\"disable_kenburns_on_mobile\":\"off\",\"hide_slider_under\":0,\"hide_defined_layers_under\":0,\"hide_all_layers_under\":0,\"hide_arrows_on_mobile\":\"off\",\"hide_bullets_on_mobile\":\"off\",\"hide_thumbs_on_mobile\":\"off\",\"hide_thumbs_under_resolution\":0,\"hide_thumbs_delay_mobile\":1500,\"start_with_slide\":\"1\",\"first_transition_active\":\"false\",\"first_transition_type\":\"fade\",\"first_transition_duration\":300,\"first_transition_slot_amount\":7,\"simplify_ie8_ios4\":\"off\",\"show_alternative_type\":\"off\",\"show_alternate_image\":\"\",\"reset_transitions\":\"\",\"reset_transition_duration\":0,\"0\":\"Execute settings on all slides\",\"jquery_noconflict\":\"on\",\"js_to_body\":\"false\",\"output_type\":\"none\",\"custom_css\":\"\",\"custom_javascript\":\"\",\"template\":\"false\"}");


DROP TABLE IF EXISTS `st_revslider_slides`;

CREATE TABLE `st_revslider_slides` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `slider_id` int(9) NOT NULL,
  `slide_order` int(11) NOT NULL,
  `params` text NOT NULL,
  `layers` text NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

INSERT INTO `st_revslider_slides` VALUES("1","1","4","{\"background_type\":\"image\",\"image\":\"http:\\/\\/foolstacks.ir\\/wp-content\\/uploads\\/2018\\/11\\/cute-3.jpg\",\"image_id\":\"78\",\"title\":\"Slide\",\"state\":\"published\",\"date_from\":\"\",\"date_to\":\"\",\"slide_transition\":\"fade\",\"0\":\"Remove\",\"slot_amount\":7,\"transition_rotation\":0,\"transition_duration\":300,\"delay\":\"\",\"save_performance\":\"off\",\"enable_link\":\"false\",\"link_type\":\"regular\",\"link\":\"\",\"link_open_in\":\"same\",\"slide_link\":\"nothing\",\"link_pos\":\"front\",\"slide_thumb\":\"\",\"class_attr\":\"\",\"id_attr\":\"\",\"attr_attr\":\"\",\"data_attr\":\"\",\"slide_bg_color\":\"#E7E7E7\",\"slide_bg_external\":\"\",\"bg_fit\":\"cover\",\"bg_fit_x\":\"100\",\"bg_fit_y\":\"100\",\"bg_repeat\":\"no-repeat\",\"bg_position\":\"center center\",\"bg_position_x\":\"0\",\"bg_position_y\":\"0\",\"bg_end_position_x\":\"0\",\"bg_end_position_y\":\"0\",\"bg_end_position\":\"center top\",\"kenburn_effect\":\"off\",\"kb_start_fit\":\"100\",\"kb_end_fit\":\"100\",\"kb_duration\":\"9000\",\"kb_easing\":\"Linear.easeNone\",\"0\":\"Remove\"}","[{\"style\":\"\",\"text\":\"Image 8\",\"type\":\"image\",\"image_url\":\"http:\\/\\/foolstacks.ir\\/wp-content\\/uploads\\/revslider\\/webdesign\\/home_webdesign_slide1_cover2.png\",\"left\":-50,\"top\":-50,\"loop_animation\":\"none\",\"loop_easing\":\"Power3.easeInOut\",\"loop_speed\":\"2\",\"loop_startdeg\":\"-20\",\"loop_enddeg\":\"20\",\"loop_xorigin\":\"50\",\"loop_yorigin\":\"50\",\"loop_xstart\":\"0\",\"loop_xend\":\"0\",\"loop_ystart\":\"0\",\"loop_yend\":\"0\",\"loop_zoomstart\":\"1\",\"loop_zoomend\":\"1\",\"loop_angle\":\"0\",\"loop_radius\":\"10\",\"animation\":\"customin-2\",\"easing\":\"Power3.easeInOut\",\"split\":\"none\",\"endsplit\":\"none\",\"splitdelay\":\"10\",\"endsplitdelay\":\"10\",\"2d_origin_x\":\"50\",\"2d_origin_y\":\"50\",\"parallax_level\":\"-\",\"whitespace\":\"nowrap\",\"speed\":1500,\"align_hor\":\"right\",\"align_vert\":\"top\",\"hiddenunder\":false,\"resizeme\":true,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"time\":300,\"endtime\":\"8700\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"width\":335,\"height\":402,\"serial\":\"0\",\"endTimeFinal\":8700,\"endSpeedFinal\":300,\"realEndTime\":9000,\"timeLast\":6900,\"endWithSlide\":true,\"max_height\":\"auto\",\"max_width\":\"auto\",\"2d_rotation\":\"\",\"alt\":\"\",\"scaleX\":\"\",\"scaleY\":\"\",\"scaleProportional\":false,\"attrID\":\"\",\"attrClasses\":\"\",\"attrTitle\":\"\",\"attrRel\":\"\",\"link_id\":\"\",\"link_class\":\"\",\"link_title\":\"\",\"link_rel\":\"\",\"static_start\":\"1\",\"static_end\":\"1\"},{\"style\":\"\",\"text\":\"Background\",\"type\":\"image\",\"image_url\":\"http:\\/\\/foolstacks.ir\\/wp-content\\/uploads\\/revslider\\/webdesign\\/home_webdesign_slide1_cover.png\",\"left\":-10,\"top\":-10,\"loop_animation\":\"none\",\"loop_easing\":\"Power3.easeInOut\",\"loop_speed\":\"2\",\"loop_startdeg\":\"-20\",\"loop_enddeg\":\"20\",\"loop_xorigin\":\"50\",\"loop_yorigin\":\"50\",\"loop_xstart\":\"0\",\"loop_xend\":\"0\",\"loop_ystart\":\"0\",\"loop_yend\":\"0\",\"loop_zoomstart\":\"1\",\"loop_zoomend\":\"1\",\"loop_angle\":\"0\",\"loop_radius\":\"10\",\"animation\":\"customin-2\",\"easing\":\"Power3.easeInOut\",\"split\":\"none\",\"endsplit\":\"none\",\"splitdelay\":\"10\",\"endsplitdelay\":\"10\",\"2d_origin_x\":\"50\",\"2d_origin_y\":\"50\",\"parallax_level\":\"-\",\"whitespace\":\"nowrap\",\"speed\":1300,\"align_hor\":\"left\",\"align_vert\":\"top\",\"hiddenunder\":false,\"resizeme\":true,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"time\":500,\"endtime\":\"8700\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"width\":1719,\"height\":1600,\"serial\":\"1\",\"endTimeFinal\":8700,\"endSpeedFinal\":300,\"realEndTime\":9000,\"timeLast\":8500,\"endWithSlide\":true,\"max_height\":\"auto\",\"max_width\":\"auto\",\"2d_rotation\":\"\",\"alt\":\"\",\"scaleX\":\"\",\"scaleY\":\"\",\"scaleProportional\":false,\"attrID\":\"\",\"attrClasses\":\"\",\"attrTitle\":\"\",\"attrRel\":\"\",\"link_id\":\"\",\"link_class\":\"\",\"link_title\":\"\",\"link_rel\":\"\",\"static_start\":\"1\",\"static_end\":\"1\"},{\"style\":\"\",\"text\":\"Background\",\"type\":\"image\",\"image_url\":\"http:\\/\\/foolstacks.ir\\/wp-content\\/uploads\\/revslider\\/webdesign\\/home_webdesign_slide1_cover.png\",\"left\":-300,\"top\":-10,\"loop_animation\":\"none\",\"loop_easing\":\"Power3.easeInOut\",\"loop_speed\":\"2\",\"loop_startdeg\":\"-20\",\"loop_enddeg\":\"20\",\"loop_xorigin\":\"50\",\"loop_yorigin\":\"50\",\"loop_xstart\":\"0\",\"loop_xend\":\"0\",\"loop_ystart\":\"0\",\"loop_yend\":\"0\",\"loop_zoomstart\":\"1\",\"loop_zoomend\":\"1\",\"loop_angle\":\"0\",\"loop_radius\":\"10\",\"animation\":\"customin-2\",\"easing\":\"Power3.easeInOut\",\"split\":\"none\",\"endsplit\":\"none\",\"splitdelay\":\"10\",\"endsplitdelay\":\"10\",\"2d_origin_x\":\"50\",\"2d_origin_y\":\"50\",\"parallax_level\":\"-\",\"whitespace\":\"nowrap\",\"speed\":1300,\"align_hor\":\"left\",\"align_vert\":\"top\",\"hiddenunder\":false,\"resizeme\":true,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"time\":800,\"endtime\":\"8700\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"width\":1719,\"height\":1600,\"serial\":\"2\",\"endTimeFinal\":8700,\"endSpeedFinal\":300,\"realEndTime\":9000,\"timeLast\":8500,\"endWithSlide\":true,\"max_height\":\"auto\",\"max_width\":\"auto\",\"2d_rotation\":\"\",\"alt\":\"\",\"scaleX\":\"\",\"scaleY\":\"\",\"scaleProportional\":false,\"attrID\":\"\",\"attrClasses\":\"\",\"attrTitle\":\"\",\"attrRel\":\"\",\"link_id\":\"\",\"link_class\":\"\",\"link_title\":\"\",\"link_rel\":\"\",\"static_start\":\"1\",\"static_end\":\"1\"},{\"style\":\"\",\"text\":\"Number\",\"type\":\"image\",\"image_url\":\"http:\\/\\/foolstacks.ir\\/wp-content\\/uploads\\/revslider\\/webdesign\\/home_webdesign_slide4_num.png\",\"left\":140,\"top\":-90,\"loop_animation\":\"none\",\"loop_easing\":\"Power3.easeInOut\",\"loop_speed\":\"2\",\"loop_startdeg\":\"-20\",\"loop_enddeg\":\"20\",\"loop_xorigin\":\"50\",\"loop_yorigin\":\"50\",\"loop_xstart\":\"0\",\"loop_xend\":\"0\",\"loop_ystart\":\"0\",\"loop_yend\":\"0\",\"loop_zoomstart\":\"1\",\"loop_zoomend\":\"1\",\"loop_angle\":\"0\",\"loop_radius\":\"10\",\"animation\":\"sft\",\"easing\":\"Power3.easeInOut\",\"split\":\"none\",\"endsplit\":\"none\",\"splitdelay\":\"10\",\"endsplitdelay\":\"10\",\"2d_origin_x\":\"50\",\"2d_origin_y\":\"50\",\"parallax_level\":\"-\",\"whitespace\":\"nowrap\",\"speed\":1000,\"align_hor\":\"left\",\"align_vert\":\"middle\",\"hiddenunder\":false,\"resizeme\":true,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"time\":1400,\"endtime\":\"8700\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"width\":111,\"height\":72,\"serial\":\"3\",\"endTimeFinal\":8700,\"endSpeedFinal\":300,\"realEndTime\":9000,\"timeLast\":8500,\"endWithSlide\":true,\"max_height\":\"auto\",\"max_width\":\"auto\",\"2d_rotation\":\"\",\"alt\":\"\",\"scaleX\":\"\",\"scaleY\":\"\",\"scaleProportional\":false,\"attrID\":\"\",\"attrClasses\":\"\",\"attrTitle\":\"\",\"attrRel\":\"\",\"link_id\":\"\",\"link_class\":\"\",\"link_title\":\"\",\"link_rel\":\"\",\"static_end\":\"2\",\"static_start\":\"1\"},{\"text\":\"Enjoy Music\",\"type\":\"text\",\"left\":140,\"top\":9,\"loop_animation\":\"none\",\"loop_easing\":\"Power3.easeInOut\",\"loop_speed\":\"2\",\"loop_startdeg\":\"-20\",\"loop_enddeg\":\"20\",\"loop_xorigin\":\"50\",\"loop_yorigin\":\"50\",\"loop_xstart\":\"0\",\"loop_xend\":\"0\",\"loop_ystart\":\"0\",\"loop_yend\":\"0\",\"loop_zoomstart\":\"1\",\"loop_zoomend\":\"1\",\"loop_angle\":\"0\",\"loop_radius\":\"10\",\"animation\":\"sfl\",\"easing\":\"Power3.easeInOut\",\"split\":\"none\",\"endsplit\":\"none\",\"splitdelay\":\"10\",\"endsplitdelay\":\"10\",\"2d_origin_x\":\"50\",\"2d_origin_y\":\"50\",\"parallax_level\":\"-\",\"whitespace\":\"nowrap\",\"speed\":1000,\"align_hor\":\"left\",\"align_vert\":\"middle\",\"hiddenunder\":false,\"resizeme\":true,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"style\":\"mfnrswebdesignlargelight\",\"time\":1500,\"endtime\":\"8700\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"width\":261,\"height\":46,\"serial\":\"4\",\"endTimeFinal\":8700,\"endSpeedFinal\":300,\"realEndTime\":9000,\"timeLast\":8700,\"endWithSlide\":true,\"max_height\":\"auto\",\"max_width\":\"auto\",\"2d_rotation\":\"0\",\"alt\":\"\",\"scaleX\":\"\",\"scaleY\":\"\",\"scaleProportional\":false,\"attrID\":\"\",\"attrClasses\":\"\",\"attrTitle\":\"\",\"attrRel\":\"\",\"link_id\":\"\",\"link_class\":\"\",\"link_title\":\"\",\"link_rel\":\"\",\"static_end\":\"2\",\"static_start\":\"1\"},{\"style\":\"\",\"text\":\"Sep\",\"type\":\"image\",\"image_url\":\"http:\\/\\/foolstacks.ir\\/wp-content\\/uploads\\/revslider\\/webdesign\\/home_webdesign_slider_sep.png\",\"left\":140,\"top\":70,\"loop_animation\":\"none\",\"loop_easing\":\"Power3.easeInOut\",\"loop_speed\":\"2\",\"loop_startdeg\":\"-20\",\"loop_enddeg\":\"20\",\"loop_xorigin\":\"50\",\"loop_yorigin\":\"50\",\"loop_xstart\":\"0\",\"loop_xend\":\"0\",\"loop_ystart\":\"0\",\"loop_yend\":\"0\",\"loop_zoomstart\":\"1\",\"loop_zoomend\":\"1\",\"loop_angle\":\"0\",\"loop_radius\":\"10\",\"animation\":\"sfl\",\"easing\":\"Power3.easeInOut\",\"split\":\"none\",\"endsplit\":\"none\",\"splitdelay\":\"10\",\"endsplitdelay\":\"10\",\"2d_origin_x\":\"50\",\"2d_origin_y\":\"50\",\"parallax_level\":\"-\",\"whitespace\":\"nowrap\",\"speed\":1000,\"align_hor\":\"left\",\"align_vert\":\"middle\",\"hiddenunder\":false,\"resizeme\":true,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"time\":1700,\"endtime\":\"8700\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"width\":83,\"height\":5,\"serial\":\"5\",\"endTimeFinal\":8700,\"endSpeedFinal\":300,\"realEndTime\":9000,\"timeLast\":8700,\"endWithSlide\":true,\"max_height\":\"auto\",\"max_width\":\"auto\",\"2d_rotation\":\"\",\"alt\":\"\",\"scaleX\":\"\",\"scaleY\":\"\",\"scaleProportional\":false,\"attrID\":\"\",\"attrClasses\":\"\",\"attrTitle\":\"\",\"attrRel\":\"\",\"link_id\":\"\",\"link_class\":\"\",\"link_title\":\"\",\"link_rel\":\"\",\"static_end\":\"1\",\"static_start\":\"1\"},{\"text\":\"\",\"type\":\"text\",\"left\":140,\"top\":169,\"loop_animation\":\"none\",\"loop_easing\":\"Power3.easeInOut\",\"loop_speed\":\"2\",\"loop_startdeg\":\"-20\",\"loop_enddeg\":\"20\",\"loop_xorigin\":\"50\",\"loop_yorigin\":\"50\",\"loop_xstart\":\"0\",\"loop_xend\":\"0\",\"loop_ystart\":\"0\",\"loop_yend\":\"0\",\"loop_zoomstart\":\"1\",\"loop_zoomend\":\"1\",\"loop_angle\":\"0\",\"loop_radius\":\"10\",\"animation\":\"sfl\",\"easing\":\"Power3.easeInOut\",\"split\":\"none\",\"endsplit\":\"none\",\"splitdelay\":\"10\",\"endsplitdelay\":\"10\",\"2d_origin_x\":\"50\",\"2d_origin_y\":\"50\",\"parallax_level\":\"-\",\"whitespace\":\"nowrap\",\"speed\":1000,\"align_hor\":\"left\",\"align_vert\":\"middle\",\"hiddenunder\":false,\"resizeme\":true,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"style\":\"mfnrswebdesignsmalllight\",\"time\":1900,\"endtime\":\"8700\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"width\":418,\"height\":65,\"serial\":\"6\",\"endTimeFinal\":8700,\"endSpeedFinal\":300,\"realEndTime\":9000,\"timeLast\":8700,\"endWithSlide\":true,\"max_height\":\"auto\",\"max_width\":\"auto\",\"2d_rotation\":\"\",\"alt\":\"\",\"scaleX\":\"\",\"scaleY\":\"\",\"scaleProportional\":false,\"attrID\":\"\",\"attrClasses\":\"\",\"attrTitle\":\"\",\"attrRel\":\"\",\"link_id\":\"\",\"link_class\":\"\",\"link_title\":\"\",\"link_rel\":\"\",\"static_end\":\"2\",\"static_start\":\"1\"},{\"text\":\"[button title=\\\"See the project\\\" icon=\\\"icon-code\\\" icon_position=\\\"right\\\" link=\\\"#\\\"  color=\\\"#fff\\\" font_color=\\\"#fff\\\" large=\\\"1\\\"]\",\"type\":\"text\",\"left\":140,\"top\":310,\"loop_animation\":\"none\",\"loop_easing\":\"Power3.easeInOut\",\"loop_speed\":\"2\",\"loop_startdeg\":\"-20\",\"loop_enddeg\":\"20\",\"loop_xorigin\":\"50\",\"loop_yorigin\":\"50\",\"loop_xstart\":\"0\",\"loop_xend\":\"0\",\"loop_ystart\":\"0\",\"loop_yend\":\"0\",\"loop_zoomstart\":\"1\",\"loop_zoomend\":\"1\",\"loop_angle\":\"0\",\"loop_radius\":\"10\",\"animation\":\"sfl\",\"easing\":\"Power3.easeInOut\",\"split\":\"none\",\"endsplit\":\"none\",\"splitdelay\":\"10\",\"endsplitdelay\":\"10\",\"2d_origin_x\":\"50\",\"2d_origin_y\":\"50\",\"parallax_level\":\"-\",\"whitespace\":\"nowrap\",\"speed\":1000,\"align_hor\":\"left\",\"align_vert\":\"middle\",\"hiddenunder\":false,\"resizeme\":true,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"style\":\"\",\"time\":2100,\"endtime\":\"8700\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"width\":707,\"height\":13,\"serial\":\"7\",\"endTimeFinal\":8700,\"endSpeedFinal\":300,\"realEndTime\":9000,\"timeLast\":8500,\"endWithSlide\":true,\"max_height\":\"auto\",\"max_width\":\"auto\",\"2d_rotation\":\"\",\"alt\":\"\",\"scaleX\":\"\",\"scaleY\":\"\",\"scaleProportional\":false,\"attrID\":\"\",\"attrClasses\":\"\",\"attrTitle\":\"\",\"attrRel\":\"\",\"link_id\":\"\",\"link_class\":\"\",\"link_title\":\"\",\"link_rel\":\"\",\"static_end\":\"1\",\"static_start\":\"1\"}]");
INSERT INTO `st_revslider_slides` VALUES("2","1","1","{\"background_type\":\"image\",\"image\":\"http:\\/\\/foolstacks.ir\\/wp-content\\/uploads\\/2018\\/11\\/wallpaper.wiki-Cute-Girl-for-Background-PIC-WPC003570.jpg\",\"image_id\":\"61\",\"title\":\"Slide\",\"state\":\"published\",\"date_from\":\"\",\"date_to\":\"\",\"slide_transition\":\"fade\",\"0\":\"Remove\",\"slot_amount\":7,\"transition_rotation\":0,\"transition_duration\":300,\"delay\":\"\",\"save_performance\":\"off\",\"enable_link\":\"false\",\"link_type\":\"regular\",\"link\":\"\",\"link_open_in\":\"same\",\"slide_link\":\"nothing\",\"link_pos\":\"front\",\"slide_thumb\":\"\",\"class_attr\":\"\",\"id_attr\":\"\",\"attr_attr\":\"\",\"data_attr\":\"\",\"slide_bg_color\":\"#E7E7E7\",\"slide_bg_external\":\"\",\"bg_fit\":\"cover\",\"bg_fit_x\":\"100\",\"bg_fit_y\":\"100\",\"bg_repeat\":\"no-repeat\",\"bg_position\":\"center center\",\"bg_position_x\":\"0\",\"bg_position_y\":\"0\",\"bg_end_position_x\":\"0\",\"bg_end_position_y\":\"0\",\"bg_end_position\":\"center top\",\"kenburn_effect\":\"off\",\"kb_start_fit\":\"100\",\"kb_end_fit\":\"100\",\"kb_duration\":\"9000\",\"kb_easing\":\"Linear.easeNone\",\"0\":\"Remove\"}","[{\"style\":\"\",\"text\":\"Image 8\",\"type\":\"image\",\"image_url\":\"http:\\/\\/foolstacks.ir\\/wp-content\\/uploads\\/revslider\\/webdesign\\/home_webdesign_slide3_cover2.png\",\"left\":-50,\"top\":-50,\"loop_animation\":\"none\",\"loop_easing\":\"Power3.easeInOut\",\"loop_speed\":\"2\",\"loop_startdeg\":\"-20\",\"loop_enddeg\":\"20\",\"loop_xorigin\":\"50\",\"loop_yorigin\":\"50\",\"loop_xstart\":\"0\",\"loop_xend\":\"0\",\"loop_ystart\":\"0\",\"loop_yend\":\"0\",\"loop_zoomstart\":\"1\",\"loop_zoomend\":\"1\",\"loop_angle\":\"0\",\"loop_radius\":\"10\",\"animation\":\"customin-2\",\"easing\":\"Power3.easeInOut\",\"split\":\"none\",\"endsplit\":\"none\",\"splitdelay\":\"10\",\"endsplitdelay\":\"10\",\"2d_origin_x\":\"50\",\"2d_origin_y\":\"50\",\"parallax_level\":\"-\",\"whitespace\":\"nowrap\",\"speed\":1500,\"align_hor\":\"right\",\"align_vert\":\"top\",\"hiddenunder\":false,\"resizeme\":true,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"time\":300,\"endtime\":\"8700\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"width\":335,\"height\":402,\"serial\":\"0\",\"endTimeFinal\":8700,\"endSpeedFinal\":300,\"realEndTime\":9000,\"timeLast\":6900,\"endWithSlide\":true,\"max_height\":\"auto\",\"max_width\":\"auto\",\"2d_rotation\":\"\",\"alt\":\"\",\"scaleX\":\"\",\"scaleY\":\"\",\"scaleProportional\":false,\"attrID\":\"\",\"attrClasses\":\"\",\"attrTitle\":\"\",\"attrRel\":\"\",\"link_id\":\"\",\"link_class\":\"\",\"link_title\":\"\",\"link_rel\":\"\",\"static_start\":\"1\",\"static_end\":\"2\"},{\"style\":\"\",\"text\":\"Background\",\"type\":\"image\",\"image_url\":\"http:\\/\\/foolstacks.ir\\/wp-content\\/uploads\\/revslider\\/webdesign\\/home_webdesign_slide3_cover.png\",\"left\":-10,\"top\":-10,\"loop_animation\":\"none\",\"loop_easing\":\"Power3.easeInOut\",\"loop_speed\":\"2\",\"loop_startdeg\":\"-20\",\"loop_enddeg\":\"20\",\"loop_xorigin\":\"50\",\"loop_yorigin\":\"50\",\"loop_xstart\":\"0\",\"loop_xend\":\"0\",\"loop_ystart\":\"0\",\"loop_yend\":\"0\",\"loop_zoomstart\":\"1\",\"loop_zoomend\":\"1\",\"loop_angle\":\"0\",\"loop_radius\":\"10\",\"animation\":\"customin-2\",\"easing\":\"Power3.easeInOut\",\"split\":\"none\",\"endsplit\":\"none\",\"splitdelay\":\"10\",\"endsplitdelay\":\"10\",\"2d_origin_x\":\"50\",\"2d_origin_y\":\"50\",\"parallax_level\":\"-\",\"whitespace\":\"nowrap\",\"speed\":1300,\"align_hor\":\"left\",\"align_vert\":\"top\",\"hiddenunder\":false,\"resizeme\":true,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"time\":500,\"endtime\":\"8700\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"width\":1719,\"height\":1600,\"serial\":\"1\",\"endTimeFinal\":1200,\"endSpeedFinal\":300,\"realEndTime\":5000,\"timeLast\":1200,\"endWithSlide\":true,\"max_height\":\"auto\",\"max_width\":\"auto\",\"2d_rotation\":\"\",\"alt\":\"\",\"scaleX\":\"\",\"scaleY\":\"\",\"scaleProportional\":false,\"attrID\":\"\",\"attrClasses\":\"\",\"attrTitle\":\"\",\"attrRel\":\"\",\"link_id\":\"\",\"link_class\":\"\",\"link_title\":\"\",\"link_rel\":\"\",\"static_start\":\"1\",\"static_end\":\"2\"},{\"style\":\"\",\"text\":\"Background\",\"type\":\"image\",\"image_url\":\"http:\\/\\/foolstacks.ir\\/wp-content\\/uploads\\/revslider\\/webdesign\\/home_webdesign_slide3_cover.png\",\"left\":-300,\"top\":-10,\"loop_animation\":\"none\",\"loop_easing\":\"Power3.easeInOut\",\"loop_speed\":\"2\",\"loop_startdeg\":\"-20\",\"loop_enddeg\":\"20\",\"loop_xorigin\":\"50\",\"loop_yorigin\":\"50\",\"loop_xstart\":\"0\",\"loop_xend\":\"0\",\"loop_ystart\":\"0\",\"loop_yend\":\"0\",\"loop_zoomstart\":\"1\",\"loop_zoomend\":\"1\",\"loop_angle\":\"0\",\"loop_radius\":\"10\",\"animation\":\"customin-2\",\"easing\":\"Power3.easeInOut\",\"split\":\"none\",\"endsplit\":\"none\",\"splitdelay\":\"10\",\"endsplitdelay\":\"10\",\"2d_origin_x\":\"50\",\"2d_origin_y\":\"50\",\"parallax_level\":\"-\",\"whitespace\":\"nowrap\",\"speed\":1300,\"align_hor\":\"left\",\"align_vert\":\"top\",\"hiddenunder\":false,\"resizeme\":true,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"time\":800,\"endtime\":\"8700\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"width\":1719,\"height\":1600,\"serial\":\"2\",\"endTimeFinal\":1500,\"endSpeedFinal\":300,\"realEndTime\":5000,\"timeLast\":1500,\"endWithSlide\":true,\"max_height\":\"auto\",\"max_width\":\"auto\",\"2d_rotation\":\"\",\"alt\":\"\",\"scaleX\":\"\",\"scaleY\":\"\",\"scaleProportional\":false,\"attrID\":\"\",\"attrClasses\":\"\",\"attrTitle\":\"\",\"attrRel\":\"\",\"link_id\":\"\",\"link_class\":\"\",\"link_title\":\"\",\"link_rel\":\"\",\"static_start\":\"1\",\"static_end\":\"2\"},{\"style\":\"\",\"text\":\"Number\",\"type\":\"image\",\"image_url\":\"http:\\/\\/foolstacks.ir\\/wp-content\\/uploads\\/revslider\\/webdesign\\/home_webdesign_slide1_num.png\",\"left\":132,\"top\":-90,\"loop_animation\":\"none\",\"loop_easing\":\"Power3.easeInOut\",\"loop_speed\":\"2\",\"loop_startdeg\":\"-20\",\"loop_enddeg\":\"20\",\"loop_xorigin\":\"50\",\"loop_yorigin\":\"50\",\"loop_xstart\":\"0\",\"loop_xend\":\"0\",\"loop_ystart\":\"0\",\"loop_yend\":\"0\",\"loop_zoomstart\":\"1\",\"loop_zoomend\":\"1\",\"loop_angle\":\"0\",\"loop_radius\":\"10\",\"animation\":\"sft\",\"easing\":\"Power3.easeInOut\",\"split\":\"none\",\"endsplit\":\"none\",\"splitdelay\":\"10\",\"endsplitdelay\":\"10\",\"2d_origin_x\":\"50\",\"2d_origin_y\":\"50\",\"parallax_level\":\"-\",\"whitespace\":\"nowrap\",\"speed\":1000,\"align_hor\":\"left\",\"align_vert\":\"middle\",\"hiddenunder\":false,\"resizeme\":true,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"time\":1400,\"endtime\":\"8700\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"width\":82,\"height\":73,\"serial\":\"3\",\"endTimeFinal\":8700,\"endSpeedFinal\":300,\"realEndTime\":9000,\"timeLast\":8500,\"endWithSlide\":true,\"max_height\":\"auto\",\"max_width\":\"auto\",\"2d_rotation\":\"\",\"alt\":\"01\",\"scaleX\":\"\",\"scaleY\":\"\",\"scaleProportional\":false,\"attrID\":\"\",\"attrClasses\":\"\",\"attrTitle\":\"\",\"attrRel\":\"\",\"link_id\":\"\",\"link_class\":\"\",\"link_title\":\"\",\"link_rel\":\"\",\"static_end\":\"2\",\"static_start\":\"1\"},{\"text\":\"Enjoy Time\",\"type\":\"text\",\"left\":140,\"top\":10,\"loop_animation\":\"none\",\"loop_easing\":\"Power3.easeInOut\",\"loop_speed\":\"2\",\"loop_startdeg\":\"-20\",\"loop_enddeg\":\"20\",\"loop_xorigin\":\"50\",\"loop_yorigin\":\"50\",\"loop_xstart\":\"0\",\"loop_xend\":\"0\",\"loop_ystart\":\"0\",\"loop_yend\":\"0\",\"loop_zoomstart\":\"1\",\"loop_zoomend\":\"1\",\"loop_angle\":\"0\",\"loop_radius\":\"10\",\"animation\":\"sfl\",\"easing\":\"Power3.easeInOut\",\"split\":\"none\",\"endsplit\":\"none\",\"splitdelay\":\"10\",\"endsplitdelay\":\"10\",\"2d_origin_x\":\"50\",\"2d_origin_y\":\"50\",\"parallax_level\":\"-\",\"whitespace\":\"nowrap\",\"speed\":1000,\"align_hor\":\"left\",\"align_vert\":\"middle\",\"hiddenunder\":false,\"resizeme\":true,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"style\":\"mfnrswebdesignlargelight\",\"time\":1500,\"endtime\":\"8700\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"width\":63,\"height\":13,\"serial\":\"4\",\"endTimeFinal\":8700,\"endSpeedFinal\":300,\"realEndTime\":9000,\"timeLast\":8700,\"endWithSlide\":true,\"max_height\":\"auto\",\"max_width\":\"auto\",\"2d_rotation\":\"\",\"alt\":\"\",\"scaleX\":\"\",\"scaleY\":\"\",\"scaleProportional\":false,\"attrID\":\"\",\"attrClasses\":\"\",\"attrTitle\":\"\",\"attrRel\":\"\",\"link_id\":\"\",\"link_class\":\"\",\"link_title\":\"\",\"link_rel\":\"\",\"static_end\":\"2\",\"static_start\":\"1\"},{\"style\":\"\",\"text\":\"Sep\",\"type\":\"image\",\"image_url\":\"http:\\/\\/foolstacks.ir\\/wp-content\\/uploads\\/revslider\\/webdesign\\/home_webdesign_slider_sep.png\",\"left\":140,\"top\":70,\"loop_animation\":\"none\",\"loop_easing\":\"Power3.easeInOut\",\"loop_speed\":\"2\",\"loop_startdeg\":\"-20\",\"loop_enddeg\":\"20\",\"loop_xorigin\":\"50\",\"loop_yorigin\":\"50\",\"loop_xstart\":\"0\",\"loop_xend\":\"0\",\"loop_ystart\":\"0\",\"loop_yend\":\"0\",\"loop_zoomstart\":\"1\",\"loop_zoomend\":\"1\",\"loop_angle\":\"0\",\"loop_radius\":\"10\",\"animation\":\"sfl\",\"easing\":\"Power3.easeInOut\",\"split\":\"none\",\"endsplit\":\"none\",\"splitdelay\":\"10\",\"endsplitdelay\":\"10\",\"2d_origin_x\":\"50\",\"2d_origin_y\":\"50\",\"parallax_level\":\"-\",\"whitespace\":\"nowrap\",\"speed\":1000,\"align_hor\":\"left\",\"align_vert\":\"middle\",\"hiddenunder\":false,\"resizeme\":true,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"time\":1700,\"endtime\":\"8700\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"width\":83,\"height\":5,\"serial\":\"5\",\"endTimeFinal\":8700,\"endSpeedFinal\":300,\"realEndTime\":9000,\"timeLast\":8700,\"endWithSlide\":true,\"max_height\":\"auto\",\"max_width\":\"auto\",\"2d_rotation\":\"\",\"alt\":\"\",\"scaleX\":\"\",\"scaleY\":\"\",\"scaleProportional\":false,\"attrID\":\"\",\"attrClasses\":\"\",\"attrTitle\":\"\",\"attrRel\":\"\",\"link_id\":\"\",\"link_class\":\"\",\"link_title\":\"\",\"link_rel\":\"\",\"static_end\":\"1\",\"static_start\":\"1\"},{\"text\":\"\",\"type\":\"text\",\"left\":140,\"top\":169,\"loop_animation\":\"none\",\"loop_easing\":\"Power3.easeInOut\",\"loop_speed\":\"2\",\"loop_startdeg\":\"-20\",\"loop_enddeg\":\"20\",\"loop_xorigin\":\"50\",\"loop_yorigin\":\"50\",\"loop_xstart\":\"0\",\"loop_xend\":\"0\",\"loop_ystart\":\"0\",\"loop_yend\":\"0\",\"loop_zoomstart\":\"1\",\"loop_zoomend\":\"1\",\"loop_angle\":\"0\",\"loop_radius\":\"10\",\"animation\":\"sfl\",\"easing\":\"Power3.easeInOut\",\"split\":\"none\",\"endsplit\":\"none\",\"splitdelay\":\"10\",\"endsplitdelay\":\"10\",\"2d_origin_x\":\"50\",\"2d_origin_y\":\"50\",\"parallax_level\":\"-\",\"whitespace\":\"nowrap\",\"speed\":1000,\"align_hor\":\"left\",\"align_vert\":\"middle\",\"hiddenunder\":false,\"resizeme\":true,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"style\":\"mfnrswebdesignsmalllight\",\"time\":1900,\"endtime\":\"8700\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"width\":418,\"height\":65,\"serial\":\"6\",\"endTimeFinal\":8700,\"endSpeedFinal\":300,\"realEndTime\":9000,\"timeLast\":8700,\"endWithSlide\":true,\"max_height\":\"auto\",\"max_width\":\"auto\",\"2d_rotation\":\"\",\"alt\":\"\",\"scaleX\":\"\",\"scaleY\":\"\",\"scaleProportional\":false,\"attrID\":\"\",\"attrClasses\":\"\",\"attrTitle\":\"\",\"attrRel\":\"\",\"link_id\":\"\",\"link_class\":\"\",\"link_title\":\"\",\"link_rel\":\"\",\"static_end\":\"2\",\"static_start\":\"1\"},{\"text\":\"[button title=\\\"See the project\\\" icon=\\\"icon-code\\\" icon_position=\\\"right\\\" link=\\\"#\\\"  color=\\\"#fff\\\" font_color=\\\"#fff\\\" large=\\\"1\\\"]\",\"type\":\"text\",\"left\":140,\"top\":310,\"loop_animation\":\"none\",\"loop_easing\":\"Power3.easeInOut\",\"loop_speed\":\"2\",\"loop_startdeg\":\"-20\",\"loop_enddeg\":\"20\",\"loop_xorigin\":\"50\",\"loop_yorigin\":\"50\",\"loop_xstart\":\"0\",\"loop_xend\":\"0\",\"loop_ystart\":\"0\",\"loop_yend\":\"0\",\"loop_zoomstart\":\"1\",\"loop_zoomend\":\"1\",\"loop_angle\":\"0\",\"loop_radius\":\"10\",\"animation\":\"sfl\",\"easing\":\"Power3.easeInOut\",\"split\":\"none\",\"endsplit\":\"none\",\"splitdelay\":\"10\",\"endsplitdelay\":\"10\",\"2d_origin_x\":\"50\",\"2d_origin_y\":\"50\",\"parallax_level\":\"-\",\"whitespace\":\"nowrap\",\"speed\":1000,\"align_hor\":\"left\",\"align_vert\":\"middle\",\"hiddenunder\":false,\"resizeme\":true,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"style\":\"\",\"time\":2100,\"endtime\":\"8700\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"width\":707,\"height\":13,\"serial\":\"7\",\"endTimeFinal\":8700,\"endSpeedFinal\":300,\"realEndTime\":9000,\"timeLast\":8500,\"endWithSlide\":true,\"max_height\":\"auto\",\"max_width\":\"auto\",\"2d_rotation\":\"\",\"alt\":\"\",\"scaleX\":\"\",\"scaleY\":\"\",\"scaleProportional\":false,\"attrID\":\"\",\"attrClasses\":\"\",\"attrTitle\":\"\",\"attrRel\":\"\",\"link_id\":\"\",\"link_class\":\"\",\"link_title\":\"\",\"link_rel\":\"\",\"static_end\":\"1\",\"static_start\":\"1\"}]");
INSERT INTO `st_revslider_slides` VALUES("3","1","2","{\"background_type\":\"image\",\"image\":\"http:\\/\\/foolstacks.ir\\/wp-content\\/uploads\\/2018\\/11\\/Girl-Reading-Book-Wallpaper.jpg\",\"image_id\":\"60\",\"title\":\"Slide\",\"state\":\"published\",\"date_from\":\"\",\"date_to\":\"\",\"slide_transition\":\"fade\",\"0\":\"Remove\",\"slot_amount\":7,\"transition_rotation\":0,\"transition_duration\":300,\"delay\":\"\",\"save_performance\":\"off\",\"enable_link\":\"false\",\"link_type\":\"regular\",\"link\":\"\",\"link_open_in\":\"same\",\"slide_link\":\"nothing\",\"link_pos\":\"front\",\"slide_thumb\":\"\",\"class_attr\":\"\",\"id_attr\":\"\",\"attr_attr\":\"\",\"data_attr\":\"\",\"slide_bg_color\":\"#E7E7E7\",\"slide_bg_external\":\"\",\"bg_fit\":\"cover\",\"bg_fit_x\":\"100\",\"bg_fit_y\":\"100\",\"bg_repeat\":\"no-repeat\",\"bg_position\":\"center center\",\"bg_position_x\":\"0\",\"bg_position_y\":\"0\",\"bg_end_position_x\":\"0\",\"bg_end_position_y\":\"0\",\"bg_end_position\":\"center top\",\"kenburn_effect\":\"off\",\"kb_start_fit\":\"100\",\"kb_end_fit\":\"100\",\"kb_duration\":\"9000\",\"kb_easing\":\"Linear.easeNone\",\"0\":\"Remove\"}","[{\"style\":\"\",\"text\":\"Image 8\",\"type\":\"image\",\"image_url\":\"http:\\/\\/foolstacks.ir\\/wp-content\\/uploads\\/revslider\\/webdesign\\/home_webdesign_slide4_cover2.png\",\"left\":-50,\"top\":-50,\"loop_animation\":\"none\",\"loop_easing\":\"Power3.easeInOut\",\"loop_speed\":\"2\",\"loop_startdeg\":\"-20\",\"loop_enddeg\":\"20\",\"loop_xorigin\":\"50\",\"loop_yorigin\":\"50\",\"loop_xstart\":\"0\",\"loop_xend\":\"0\",\"loop_ystart\":\"0\",\"loop_yend\":\"0\",\"loop_zoomstart\":\"1\",\"loop_zoomend\":\"1\",\"loop_angle\":\"0\",\"loop_radius\":\"10\",\"animation\":\"customin-2\",\"easing\":\"Power3.easeInOut\",\"split\":\"none\",\"endsplit\":\"none\",\"splitdelay\":\"10\",\"endsplitdelay\":\"10\",\"2d_origin_x\":\"50\",\"2d_origin_y\":\"50\",\"parallax_level\":\"-\",\"whitespace\":\"nowrap\",\"speed\":1500,\"align_hor\":\"right\",\"align_vert\":\"top\",\"hiddenunder\":false,\"resizeme\":true,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"time\":300,\"endtime\":\"8700\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"width\":335,\"height\":402,\"serial\":\"0\",\"endTimeFinal\":8700,\"endSpeedFinal\":300,\"realEndTime\":9000,\"timeLast\":6900,\"endWithSlide\":true,\"max_height\":\"auto\",\"max_width\":\"auto\",\"2d_rotation\":\"\",\"alt\":\"\",\"scaleX\":\"\",\"scaleY\":\"\",\"scaleProportional\":false,\"attrID\":\"\",\"attrClasses\":\"\",\"attrTitle\":\"\",\"attrRel\":\"\",\"link_id\":\"\",\"link_class\":\"\",\"link_title\":\"\",\"link_rel\":\"\",\"static_start\":\"1\",\"static_end\":\"2\"},{\"style\":\"\",\"text\":\"Background\",\"type\":\"image\",\"image_url\":\"http:\\/\\/foolstacks.ir\\/wp-content\\/uploads\\/revslider\\/webdesign\\/home_webdesign_slide4_cover.png\",\"left\":-10,\"top\":-10,\"loop_animation\":\"none\",\"loop_easing\":\"Power3.easeInOut\",\"loop_speed\":\"2\",\"loop_startdeg\":\"-20\",\"loop_enddeg\":\"20\",\"loop_xorigin\":\"50\",\"loop_yorigin\":\"50\",\"loop_xstart\":\"0\",\"loop_xend\":\"0\",\"loop_ystart\":\"0\",\"loop_yend\":\"0\",\"loop_zoomstart\":\"1\",\"loop_zoomend\":\"1\",\"loop_angle\":\"0\",\"loop_radius\":\"10\",\"animation\":\"customin-2\",\"easing\":\"Power3.easeInOut\",\"split\":\"none\",\"endsplit\":\"none\",\"splitdelay\":\"10\",\"endsplitdelay\":\"10\",\"2d_origin_x\":\"50\",\"2d_origin_y\":\"50\",\"parallax_level\":\"-\",\"whitespace\":\"nowrap\",\"speed\":1300,\"align_hor\":\"left\",\"align_vert\":\"top\",\"hiddenunder\":false,\"resizeme\":true,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"time\":500,\"endtime\":\"8700\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"width\":1719,\"height\":1600,\"serial\":\"1\",\"endTimeFinal\":8700,\"endSpeedFinal\":300,\"realEndTime\":9000,\"timeLast\":8500,\"endWithSlide\":true,\"max_height\":\"auto\",\"max_width\":\"auto\",\"2d_rotation\":\"\",\"alt\":\"\",\"scaleX\":\"\",\"scaleY\":\"\",\"scaleProportional\":false,\"attrID\":\"\",\"attrClasses\":\"\",\"attrTitle\":\"\",\"attrRel\":\"\",\"link_id\":\"\",\"link_class\":\"\",\"link_title\":\"\",\"link_rel\":\"\",\"static_start\":\"1\",\"static_end\":\"2\"},{\"style\":\"\",\"text\":\"Background\",\"type\":\"image\",\"image_url\":\"http:\\/\\/foolstacks.ir\\/wp-content\\/uploads\\/revslider\\/webdesign\\/home_webdesign_slide4_cover.png\",\"left\":-300,\"top\":-10,\"loop_animation\":\"none\",\"loop_easing\":\"Power3.easeInOut\",\"loop_speed\":\"2\",\"loop_startdeg\":\"-20\",\"loop_enddeg\":\"20\",\"loop_xorigin\":\"50\",\"loop_yorigin\":\"50\",\"loop_xstart\":\"0\",\"loop_xend\":\"0\",\"loop_ystart\":\"0\",\"loop_yend\":\"0\",\"loop_zoomstart\":\"1\",\"loop_zoomend\":\"1\",\"loop_angle\":\"0\",\"loop_radius\":\"10\",\"animation\":\"customin-2\",\"easing\":\"Power3.easeInOut\",\"split\":\"none\",\"endsplit\":\"none\",\"splitdelay\":\"10\",\"endsplitdelay\":\"10\",\"2d_origin_x\":\"50\",\"2d_origin_y\":\"50\",\"parallax_level\":\"-\",\"whitespace\":\"nowrap\",\"speed\":1300,\"align_hor\":\"left\",\"align_vert\":\"top\",\"hiddenunder\":false,\"resizeme\":true,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"time\":800,\"endtime\":\"8700\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"width\":1719,\"height\":1600,\"serial\":\"2\",\"endTimeFinal\":8700,\"endSpeedFinal\":300,\"realEndTime\":9000,\"timeLast\":8500,\"endWithSlide\":true,\"max_height\":\"auto\",\"max_width\":\"auto\",\"2d_rotation\":\"\",\"alt\":\"\",\"scaleX\":\"\",\"scaleY\":\"\",\"scaleProportional\":false,\"attrID\":\"\",\"attrClasses\":\"\",\"attrTitle\":\"\",\"attrRel\":\"\",\"link_id\":\"\",\"link_class\":\"\",\"link_title\":\"\",\"link_rel\":\"\",\"static_start\":\"1\",\"static_end\":\"2\"},{\"style\":\"\",\"text\":\"Number\",\"type\":\"image\",\"image_url\":\"http:\\/\\/foolstacks.ir\\/wp-content\\/uploads\\/revslider\\/webdesign\\/home_webdesign_slide2_num.png\",\"left\":140,\"top\":-90,\"loop_animation\":\"none\",\"loop_easing\":\"Power3.easeInOut\",\"loop_speed\":\"2\",\"loop_startdeg\":\"-20\",\"loop_enddeg\":\"20\",\"loop_xorigin\":\"50\",\"loop_yorigin\":\"50\",\"loop_xstart\":\"0\",\"loop_xend\":\"0\",\"loop_ystart\":\"0\",\"loop_yend\":\"0\",\"loop_zoomstart\":\"1\",\"loop_zoomend\":\"1\",\"loop_angle\":\"0\",\"loop_radius\":\"10\",\"animation\":\"sft\",\"easing\":\"Power3.easeInOut\",\"split\":\"none\",\"endsplit\":\"none\",\"splitdelay\":\"10\",\"endsplitdelay\":\"10\",\"2d_origin_x\":\"50\",\"2d_origin_y\":\"50\",\"parallax_level\":\"-\",\"whitespace\":\"nowrap\",\"speed\":1000,\"align_hor\":\"left\",\"align_vert\":\"middle\",\"hiddenunder\":false,\"resizeme\":true,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"time\":1400,\"endtime\":\"8700\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"width\":114,\"height\":72,\"serial\":\"3\",\"endTimeFinal\":8700,\"endSpeedFinal\":300,\"realEndTime\":9000,\"timeLast\":8500,\"endWithSlide\":true,\"max_height\":\"auto\",\"max_width\":\"auto\",\"2d_rotation\":\"\",\"alt\":\"\",\"scaleX\":\"\",\"scaleY\":\"\",\"scaleProportional\":false,\"attrID\":\"\",\"attrClasses\":\"\",\"attrTitle\":\"\",\"attrRel\":\"\",\"link_id\":\"\",\"link_class\":\"\",\"link_title\":\"\",\"link_rel\":\"\",\"static_end\":\"2\",\"static_start\":\"1\"},{\"text\":\"Enjoy Life\",\"type\":\"text\",\"left\":140,\"top\":10,\"loop_animation\":\"none\",\"loop_easing\":\"Power3.easeInOut\",\"loop_speed\":\"2\",\"loop_startdeg\":\"-20\",\"loop_enddeg\":\"20\",\"loop_xorigin\":\"50\",\"loop_yorigin\":\"50\",\"loop_xstart\":\"0\",\"loop_xend\":\"0\",\"loop_ystart\":\"0\",\"loop_yend\":\"0\",\"loop_zoomstart\":\"1\",\"loop_zoomend\":\"1\",\"loop_angle\":\"0\",\"loop_radius\":\"10\",\"animation\":\"sfl\",\"easing\":\"Power3.easeInOut\",\"split\":\"none\",\"endsplit\":\"none\",\"splitdelay\":\"10\",\"endsplitdelay\":\"10\",\"2d_origin_x\":\"50\",\"2d_origin_y\":\"50\",\"parallax_level\":\"-\",\"whitespace\":\"nowrap\",\"speed\":1000,\"align_hor\":\"left\",\"align_vert\":\"middle\",\"hiddenunder\":false,\"resizeme\":true,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"style\":\"mfnrswebdesignlargelight\",\"time\":1500,\"endtime\":\"8700\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"width\":63,\"height\":13,\"serial\":\"4\",\"endTimeFinal\":8700,\"endSpeedFinal\":300,\"realEndTime\":9000,\"timeLast\":8700,\"endWithSlide\":true,\"max_height\":\"auto\",\"max_width\":\"auto\",\"2d_rotation\":\"\",\"alt\":\"\",\"scaleX\":\"\",\"scaleY\":\"\",\"scaleProportional\":false,\"attrID\":\"\",\"attrClasses\":\"\",\"attrTitle\":\"\",\"attrRel\":\"\",\"link_id\":\"\",\"link_class\":\"\",\"link_title\":\"\",\"link_rel\":\"\",\"static_end\":\"2\",\"static_start\":\"1\"},{\"style\":\"\",\"text\":\"Sep\",\"type\":\"image\",\"image_url\":\"http:\\/\\/foolstacks.ir\\/wp-content\\/uploads\\/revslider\\/webdesign\\/home_webdesign_slider_sep.png\",\"left\":140,\"top\":70,\"loop_animation\":\"none\",\"loop_easing\":\"Power3.easeInOut\",\"loop_speed\":\"2\",\"loop_startdeg\":\"-20\",\"loop_enddeg\":\"20\",\"loop_xorigin\":\"50\",\"loop_yorigin\":\"50\",\"loop_xstart\":\"0\",\"loop_xend\":\"0\",\"loop_ystart\":\"0\",\"loop_yend\":\"0\",\"loop_zoomstart\":\"1\",\"loop_zoomend\":\"1\",\"loop_angle\":\"0\",\"loop_radius\":\"10\",\"animation\":\"sfl\",\"easing\":\"Power3.easeInOut\",\"split\":\"none\",\"endsplit\":\"none\",\"splitdelay\":\"10\",\"endsplitdelay\":\"10\",\"2d_origin_x\":\"50\",\"2d_origin_y\":\"50\",\"parallax_level\":\"-\",\"whitespace\":\"nowrap\",\"speed\":1000,\"align_hor\":\"left\",\"align_vert\":\"middle\",\"hiddenunder\":false,\"resizeme\":true,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"time\":1700,\"endtime\":\"8700\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"width\":83,\"height\":5,\"serial\":\"5\",\"endTimeFinal\":8700,\"endSpeedFinal\":300,\"realEndTime\":9000,\"timeLast\":8700,\"endWithSlide\":true,\"max_height\":\"auto\",\"max_width\":\"auto\",\"2d_rotation\":\"\",\"alt\":\"\",\"scaleX\":\"\",\"scaleY\":\"\",\"scaleProportional\":false,\"attrID\":\"\",\"attrClasses\":\"\",\"attrTitle\":\"\",\"attrRel\":\"\",\"link_id\":\"\",\"link_class\":\"\",\"link_title\":\"\",\"link_rel\":\"\",\"static_end\":\"1\",\"static_start\":\"1\"},{\"text\":\"\",\"type\":\"text\",\"left\":140,\"top\":169,\"loop_animation\":\"none\",\"loop_easing\":\"Power3.easeInOut\",\"loop_speed\":\"2\",\"loop_startdeg\":\"-20\",\"loop_enddeg\":\"20\",\"loop_xorigin\":\"50\",\"loop_yorigin\":\"50\",\"loop_xstart\":\"0\",\"loop_xend\":\"0\",\"loop_ystart\":\"0\",\"loop_yend\":\"0\",\"loop_zoomstart\":\"1\",\"loop_zoomend\":\"1\",\"loop_angle\":\"0\",\"loop_radius\":\"10\",\"animation\":\"sfl\",\"easing\":\"Power3.easeInOut\",\"split\":\"none\",\"endsplit\":\"none\",\"splitdelay\":\"10\",\"endsplitdelay\":\"10\",\"2d_origin_x\":\"50\",\"2d_origin_y\":\"50\",\"parallax_level\":\"-\",\"whitespace\":\"nowrap\",\"speed\":1000,\"align_hor\":\"left\",\"align_vert\":\"middle\",\"hiddenunder\":false,\"resizeme\":true,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"style\":\"mfnrswebdesignsmalllight\",\"time\":1900,\"endtime\":\"8700\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"width\":418,\"height\":65,\"serial\":\"6\",\"endTimeFinal\":8700,\"endSpeedFinal\":300,\"realEndTime\":9000,\"timeLast\":8700,\"endWithSlide\":true,\"max_height\":\"auto\",\"max_width\":\"auto\",\"2d_rotation\":\"\",\"alt\":\"\",\"scaleX\":\"\",\"scaleY\":\"\",\"scaleProportional\":false,\"attrID\":\"\",\"attrClasses\":\"\",\"attrTitle\":\"\",\"attrRel\":\"\",\"link_id\":\"\",\"link_class\":\"\",\"link_title\":\"\",\"link_rel\":\"\",\"static_end\":\"2\",\"static_start\":\"1\"},{\"text\":\"[button title=\\\"See the project\\\" icon=\\\"icon-code\\\" icon_position=\\\"right\\\" link=\\\"#\\\"  color=\\\"#fff\\\" font_color=\\\"#fff\\\" large=\\\"1\\\"]\",\"type\":\"text\",\"left\":140,\"top\":310,\"loop_animation\":\"none\",\"loop_easing\":\"Power3.easeInOut\",\"loop_speed\":\"2\",\"loop_startdeg\":\"-20\",\"loop_enddeg\":\"20\",\"loop_xorigin\":\"50\",\"loop_yorigin\":\"50\",\"loop_xstart\":\"0\",\"loop_xend\":\"0\",\"loop_ystart\":\"0\",\"loop_yend\":\"0\",\"loop_zoomstart\":\"1\",\"loop_zoomend\":\"1\",\"loop_angle\":\"0\",\"loop_radius\":\"10\",\"animation\":\"sfl\",\"easing\":\"Power3.easeInOut\",\"split\":\"none\",\"endsplit\":\"none\",\"splitdelay\":\"10\",\"endsplitdelay\":\"10\",\"2d_origin_x\":\"50\",\"2d_origin_y\":\"50\",\"parallax_level\":\"-\",\"whitespace\":\"nowrap\",\"speed\":1000,\"align_hor\":\"left\",\"align_vert\":\"middle\",\"hiddenunder\":false,\"resizeme\":true,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"style\":\"\",\"time\":2100,\"endtime\":\"8700\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"width\":707,\"height\":13,\"serial\":\"7\",\"endTimeFinal\":8700,\"endSpeedFinal\":300,\"realEndTime\":9000,\"timeLast\":8500,\"endWithSlide\":true,\"max_height\":\"auto\",\"max_width\":\"auto\",\"2d_rotation\":\"\",\"alt\":\"\",\"scaleX\":\"\",\"scaleY\":\"\",\"scaleProportional\":false,\"attrID\":\"\",\"attrClasses\":\"\",\"attrTitle\":\"\",\"attrRel\":\"\",\"link_id\":\"\",\"link_class\":\"\",\"link_title\":\"\",\"link_rel\":\"\",\"static_end\":\"1\",\"static_start\":\"1\"}]");
INSERT INTO `st_revslider_slides` VALUES("4","1","3","{\"background_type\":\"image\",\"image\":\"http:\\/\\/foolstacks.ir\\/wp-content\\/uploads\\/2018\\/11\\/slider-2.jpg\",\"image_id\":\"2253\",\"title\":\"Slide\",\"state\":\"published\",\"date_from\":\"\",\"date_to\":\"\",\"slide_transition\":\"fade\",\"0\":\"Remove\",\"slot_amount\":7,\"transition_rotation\":0,\"transition_duration\":300,\"delay\":\"\",\"save_performance\":\"off\",\"enable_link\":\"false\",\"link_type\":\"regular\",\"link\":\"\",\"link_open_in\":\"same\",\"slide_link\":\"nothing\",\"link_pos\":\"front\",\"slide_thumb\":\"\",\"class_attr\":\"\",\"id_attr\":\"\",\"attr_attr\":\"\",\"data_attr\":\"\",\"slide_bg_color\":\"#E7E7E7\",\"slide_bg_external\":\"\",\"bg_fit\":\"cover\",\"bg_fit_x\":\"100\",\"bg_fit_y\":\"100\",\"bg_repeat\":\"no-repeat\",\"bg_position\":\"center center\",\"bg_position_x\":\"0\",\"bg_position_y\":\"0\",\"bg_end_position_x\":\"0\",\"bg_end_position_y\":\"0\",\"bg_end_position\":\"center top\",\"kenburn_effect\":\"off\",\"kb_start_fit\":\"100\",\"kb_end_fit\":\"100\",\"kb_duration\":\"9000\",\"kb_easing\":\"Linear.easeNone\",\"0\":\"Remove\"}","[{\"style\":\"\",\"text\":\"Image 8\",\"type\":\"image\",\"image_url\":\"http:\\/\\/foolstacks.ir\\/wp-content\\/uploads\\/revslider\\/webdesign\\/home_webdesign_slide2_cover2.png\",\"left\":-50,\"top\":-50,\"loop_animation\":\"none\",\"loop_easing\":\"Power3.easeInOut\",\"loop_speed\":\"2\",\"loop_startdeg\":\"-20\",\"loop_enddeg\":\"20\",\"loop_xorigin\":\"50\",\"loop_yorigin\":\"50\",\"loop_xstart\":\"0\",\"loop_xend\":\"0\",\"loop_ystart\":\"0\",\"loop_yend\":\"0\",\"loop_zoomstart\":\"1\",\"loop_zoomend\":\"1\",\"loop_angle\":\"0\",\"loop_radius\":\"10\",\"animation\":\"customin-2\",\"easing\":\"Power3.easeInOut\",\"split\":\"none\",\"endsplit\":\"none\",\"splitdelay\":\"10\",\"endsplitdelay\":\"10\",\"2d_origin_x\":\"50\",\"2d_origin_y\":\"50\",\"parallax_level\":\"-\",\"whitespace\":\"nowrap\",\"speed\":1500,\"align_hor\":\"right\",\"align_vert\":\"top\",\"hiddenunder\":false,\"resizeme\":true,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"time\":300,\"endtime\":\"8700\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"width\":335,\"height\":402,\"serial\":\"0\",\"endTimeFinal\":8700,\"endSpeedFinal\":300,\"realEndTime\":9000,\"timeLast\":6900,\"endWithSlide\":true,\"max_height\":\"auto\",\"max_width\":\"auto\",\"2d_rotation\":\"\",\"alt\":\"\",\"scaleX\":\"\",\"scaleY\":\"\",\"scaleProportional\":false,\"attrID\":\"\",\"attrClasses\":\"\",\"attrTitle\":\"\",\"attrRel\":\"\",\"link_id\":\"\",\"link_class\":\"\",\"link_title\":\"\",\"link_rel\":\"\",\"static_start\":\"1\",\"static_end\":\"2\"},{\"style\":\"\",\"text\":\"Background\",\"type\":\"image\",\"image_url\":\"http:\\/\\/foolstacks.ir\\/wp-content\\/uploads\\/revslider\\/webdesign\\/home_webdesign_slide2_cover.png\",\"left\":-10,\"top\":-10,\"loop_animation\":\"none\",\"loop_easing\":\"Power3.easeInOut\",\"loop_speed\":\"2\",\"loop_startdeg\":\"-20\",\"loop_enddeg\":\"20\",\"loop_xorigin\":\"50\",\"loop_yorigin\":\"50\",\"loop_xstart\":\"0\",\"loop_xend\":\"0\",\"loop_ystart\":\"0\",\"loop_yend\":\"0\",\"loop_zoomstart\":\"1\",\"loop_zoomend\":\"1\",\"loop_angle\":\"0\",\"loop_radius\":\"10\",\"animation\":\"customin-2\",\"easing\":\"Power3.easeInOut\",\"split\":\"none\",\"endsplit\":\"none\",\"splitdelay\":\"10\",\"endsplitdelay\":\"10\",\"2d_origin_x\":\"50\",\"2d_origin_y\":\"50\",\"parallax_level\":\"-\",\"whitespace\":\"nowrap\",\"speed\":1300,\"align_hor\":\"left\",\"align_vert\":\"top\",\"hiddenunder\":false,\"resizeme\":true,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"time\":500,\"endtime\":\"8700\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"width\":1719,\"height\":1600,\"serial\":\"1\",\"endTimeFinal\":8700,\"endSpeedFinal\":300,\"realEndTime\":9000,\"timeLast\":8500,\"endWithSlide\":true,\"max_height\":\"auto\",\"max_width\":\"auto\",\"2d_rotation\":\"\",\"alt\":\"\",\"scaleX\":\"\",\"scaleY\":\"\",\"scaleProportional\":false,\"attrID\":\"\",\"attrClasses\":\"\",\"attrTitle\":\"\",\"attrRel\":\"\",\"link_id\":\"\",\"link_class\":\"\",\"link_title\":\"\",\"link_rel\":\"\",\"static_start\":\"1\",\"static_end\":\"2\"},{\"style\":\"\",\"text\":\"Background\",\"type\":\"image\",\"image_url\":\"http:\\/\\/foolstacks.ir\\/wp-content\\/uploads\\/revslider\\/webdesign\\/home_webdesign_slide2_cover.png\",\"left\":-300,\"top\":-10,\"loop_animation\":\"none\",\"loop_easing\":\"Power3.easeInOut\",\"loop_speed\":\"2\",\"loop_startdeg\":\"-20\",\"loop_enddeg\":\"20\",\"loop_xorigin\":\"50\",\"loop_yorigin\":\"50\",\"loop_xstart\":\"0\",\"loop_xend\":\"0\",\"loop_ystart\":\"0\",\"loop_yend\":\"0\",\"loop_zoomstart\":\"1\",\"loop_zoomend\":\"1\",\"loop_angle\":\"0\",\"loop_radius\":\"10\",\"animation\":\"customin-2\",\"easing\":\"Power3.easeInOut\",\"split\":\"none\",\"endsplit\":\"none\",\"splitdelay\":\"10\",\"endsplitdelay\":\"10\",\"2d_origin_x\":\"50\",\"2d_origin_y\":\"50\",\"parallax_level\":\"-\",\"whitespace\":\"nowrap\",\"speed\":1300,\"align_hor\":\"left\",\"align_vert\":\"top\",\"hiddenunder\":false,\"resizeme\":true,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"time\":800,\"endtime\":\"8700\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"width\":1719,\"height\":1600,\"serial\":\"2\",\"endTimeFinal\":8700,\"endSpeedFinal\":300,\"realEndTime\":9000,\"timeLast\":8500,\"endWithSlide\":true,\"max_height\":\"auto\",\"max_width\":\"auto\",\"2d_rotation\":\"\",\"alt\":\"\",\"scaleX\":\"\",\"scaleY\":\"\",\"scaleProportional\":false,\"attrID\":\"\",\"attrClasses\":\"\",\"attrTitle\":\"\",\"attrRel\":\"\",\"link_id\":\"\",\"link_class\":\"\",\"link_title\":\"\",\"link_rel\":\"\",\"static_start\":\"1\",\"static_end\":\"2\"},{\"style\":\"\",\"text\":\"Number\",\"type\":\"image\",\"image_url\":\"http:\\/\\/foolstacks.ir\\/wp-content\\/uploads\\/revslider\\/webdesign\\/home_webdesign_slide3.png\",\"left\":140,\"top\":-90,\"loop_animation\":\"none\",\"loop_easing\":\"Power3.easeInOut\",\"loop_speed\":\"2\",\"loop_startdeg\":\"-20\",\"loop_enddeg\":\"20\",\"loop_xorigin\":\"50\",\"loop_yorigin\":\"50\",\"loop_xstart\":\"0\",\"loop_xend\":\"0\",\"loop_ystart\":\"0\",\"loop_yend\":\"0\",\"loop_zoomstart\":\"1\",\"loop_zoomend\":\"1\",\"loop_angle\":\"0\",\"loop_radius\":\"10\",\"animation\":\"sft\",\"easing\":\"Power3.easeInOut\",\"split\":\"none\",\"endsplit\":\"none\",\"splitdelay\":\"10\",\"endsplitdelay\":\"10\",\"2d_origin_x\":\"50\",\"2d_origin_y\":\"50\",\"parallax_level\":\"-\",\"whitespace\":\"nowrap\",\"speed\":1000,\"align_hor\":\"left\",\"align_vert\":\"middle\",\"hiddenunder\":false,\"resizeme\":true,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"time\":1400,\"endtime\":\"8700\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"width\":101,\"height\":72,\"serial\":\"3\",\"endTimeFinal\":8700,\"endSpeedFinal\":300,\"realEndTime\":9000,\"timeLast\":8500,\"endWithSlide\":true,\"max_height\":\"auto\",\"max_width\":\"auto\",\"2d_rotation\":\"\",\"alt\":\"\",\"scaleX\":\"\",\"scaleY\":\"\",\"scaleProportional\":false,\"attrID\":\"\",\"attrClasses\":\"\",\"attrTitle\":\"\",\"attrRel\":\"\",\"link_id\":\"\",\"link_class\":\"\",\"link_title\":\"\",\"link_rel\":\"\",\"static_end\":\"2\",\"static_start\":\"1\"},{\"text\":\"Enjoy Home\",\"type\":\"text\",\"left\":140,\"top\":10,\"loop_animation\":\"none\",\"loop_easing\":\"Power3.easeInOut\",\"loop_speed\":\"2\",\"loop_startdeg\":\"-20\",\"loop_enddeg\":\"20\",\"loop_xorigin\":\"50\",\"loop_yorigin\":\"50\",\"loop_xstart\":\"0\",\"loop_xend\":\"0\",\"loop_ystart\":\"0\",\"loop_yend\":\"0\",\"loop_zoomstart\":\"1\",\"loop_zoomend\":\"1\",\"loop_angle\":\"0\",\"loop_radius\":\"10\",\"animation\":\"sfl\",\"easing\":\"Power3.easeInOut\",\"split\":\"none\",\"endsplit\":\"none\",\"splitdelay\":\"10\",\"endsplitdelay\":\"10\",\"2d_origin_x\":\"50\",\"2d_origin_y\":\"50\",\"parallax_level\":\"-\",\"whitespace\":\"nowrap\",\"speed\":1000,\"align_hor\":\"left\",\"align_vert\":\"middle\",\"hiddenunder\":false,\"resizeme\":true,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"style\":\"mfnrswebdesignlargelight\",\"time\":1500,\"endtime\":\"8700\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"width\":63,\"height\":13,\"serial\":\"4\",\"endTimeFinal\":8700,\"endSpeedFinal\":300,\"realEndTime\":9000,\"timeLast\":8700,\"endWithSlide\":true,\"max_height\":\"auto\",\"max_width\":\"auto\",\"2d_rotation\":\"\",\"alt\":\"\",\"scaleX\":\"\",\"scaleY\":\"\",\"scaleProportional\":false,\"attrID\":\"\",\"attrClasses\":\"\",\"attrTitle\":\"\",\"attrRel\":\"\",\"link_id\":\"\",\"link_class\":\"\",\"link_title\":\"\",\"link_rel\":\"\",\"static_end\":\"2\",\"static_start\":\"1\"},{\"style\":\"\",\"text\":\"Sep\",\"type\":\"image\",\"image_url\":\"http:\\/\\/foolstacks.ir\\/wp-content\\/uploads\\/revslider\\/webdesign\\/home_webdesign_slider_sep.png\",\"left\":140,\"top\":70,\"loop_animation\":\"none\",\"loop_easing\":\"Power3.easeInOut\",\"loop_speed\":\"2\",\"loop_startdeg\":\"-20\",\"loop_enddeg\":\"20\",\"loop_xorigin\":\"50\",\"loop_yorigin\":\"50\",\"loop_xstart\":\"0\",\"loop_xend\":\"0\",\"loop_ystart\":\"0\",\"loop_yend\":\"0\",\"loop_zoomstart\":\"1\",\"loop_zoomend\":\"1\",\"loop_angle\":\"0\",\"loop_radius\":\"10\",\"animation\":\"sfl\",\"easing\":\"Power3.easeInOut\",\"split\":\"none\",\"endsplit\":\"none\",\"splitdelay\":\"10\",\"endsplitdelay\":\"10\",\"2d_origin_x\":\"50\",\"2d_origin_y\":\"50\",\"parallax_level\":\"-\",\"whitespace\":\"nowrap\",\"speed\":1000,\"align_hor\":\"left\",\"align_vert\":\"middle\",\"hiddenunder\":false,\"resizeme\":true,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"time\":1700,\"endtime\":\"8700\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"width\":83,\"height\":5,\"serial\":\"5\",\"endTimeFinal\":8700,\"endSpeedFinal\":300,\"realEndTime\":9000,\"timeLast\":8700,\"endWithSlide\":true,\"max_height\":\"auto\",\"max_width\":\"auto\",\"2d_rotation\":\"\",\"alt\":\"\",\"scaleX\":\"\",\"scaleY\":\"\",\"scaleProportional\":false,\"attrID\":\"\",\"attrClasses\":\"\",\"attrTitle\":\"\",\"attrRel\":\"\",\"link_id\":\"\",\"link_class\":\"\",\"link_title\":\"\",\"link_rel\":\"\",\"static_end\":\"1\",\"static_start\":\"1\"},{\"text\":\"\",\"type\":\"text\",\"left\":140,\"top\":169,\"loop_animation\":\"none\",\"loop_easing\":\"Power3.easeInOut\",\"loop_speed\":\"2\",\"loop_startdeg\":\"-20\",\"loop_enddeg\":\"20\",\"loop_xorigin\":\"50\",\"loop_yorigin\":\"50\",\"loop_xstart\":\"0\",\"loop_xend\":\"0\",\"loop_ystart\":\"0\",\"loop_yend\":\"0\",\"loop_zoomstart\":\"1\",\"loop_zoomend\":\"1\",\"loop_angle\":\"0\",\"loop_radius\":\"10\",\"animation\":\"sfl\",\"easing\":\"Power3.easeInOut\",\"split\":\"none\",\"endsplit\":\"none\",\"splitdelay\":\"10\",\"endsplitdelay\":\"10\",\"2d_origin_x\":\"50\",\"2d_origin_y\":\"50\",\"parallax_level\":\"-\",\"whitespace\":\"nowrap\",\"speed\":1000,\"align_hor\":\"left\",\"align_vert\":\"middle\",\"hiddenunder\":false,\"resizeme\":true,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"style\":\"mfnrswebdesignsmalllight\",\"time\":1900,\"endtime\":\"8700\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"width\":418,\"height\":65,\"serial\":\"6\",\"endTimeFinal\":8700,\"endSpeedFinal\":300,\"realEndTime\":9000,\"timeLast\":8700,\"endWithSlide\":true,\"max_height\":\"auto\",\"max_width\":\"auto\",\"2d_rotation\":\"\",\"alt\":\"\",\"scaleX\":\"\",\"scaleY\":\"\",\"scaleProportional\":false,\"attrID\":\"\",\"attrClasses\":\"\",\"attrTitle\":\"\",\"attrRel\":\"\",\"link_id\":\"\",\"link_class\":\"\",\"link_title\":\"\",\"link_rel\":\"\",\"static_end\":\"2\",\"static_start\":\"1\"},{\"text\":\"[button title=\\\"See the project\\\" icon=\\\"icon-code\\\" icon_position=\\\"right\\\" link=\\\"#\\\"  color=\\\"#fff\\\" font_color=\\\"#fff\\\" large=\\\"1\\\"]\",\"type\":\"text\",\"left\":140,\"top\":310,\"loop_animation\":\"none\",\"loop_easing\":\"Power3.easeInOut\",\"loop_speed\":\"2\",\"loop_startdeg\":\"-20\",\"loop_enddeg\":\"20\",\"loop_xorigin\":\"50\",\"loop_yorigin\":\"50\",\"loop_xstart\":\"0\",\"loop_xend\":\"0\",\"loop_ystart\":\"0\",\"loop_yend\":\"0\",\"loop_zoomstart\":\"1\",\"loop_zoomend\":\"1\",\"loop_angle\":\"0\",\"loop_radius\":\"10\",\"animation\":\"sfl\",\"easing\":\"Power3.easeInOut\",\"split\":\"none\",\"endsplit\":\"none\",\"splitdelay\":\"10\",\"endsplitdelay\":\"10\",\"2d_origin_x\":\"50\",\"2d_origin_y\":\"50\",\"parallax_level\":\"-\",\"whitespace\":\"nowrap\",\"speed\":1000,\"align_hor\":\"left\",\"align_vert\":\"middle\",\"hiddenunder\":false,\"resizeme\":true,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"style\":\"\",\"time\":2100,\"endtime\":\"8700\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"width\":707,\"height\":13,\"serial\":\"7\",\"endTimeFinal\":8700,\"endSpeedFinal\":300,\"realEndTime\":9000,\"timeLast\":8500,\"endWithSlide\":true,\"max_height\":\"auto\",\"max_width\":\"auto\",\"2d_rotation\":\"\",\"alt\":\"\",\"scaleX\":\"\",\"scaleY\":\"\",\"scaleProportional\":false,\"attrID\":\"\",\"attrClasses\":\"\",\"attrTitle\":\"\",\"attrRel\":\"\",\"link_id\":\"\",\"link_class\":\"\",\"link_title\":\"\",\"link_rel\":\"\",\"static_end\":\"1\",\"static_start\":\"1\"}]");
INSERT INTO `st_revslider_slides` VALUES("10","3","4","{\"background_type\":\"image\",\"image\":\"http:\\/\\/foolstacks.ir\\/wp-content\\/uploads\\/2018\\/11\\/5-1.jpg\",\"image_id\":\"2279\",\"title\":\"Slide\",\"state\":\"published\",\"date_from\":\"\",\"date_to\":\"\",\"slide_transition\":\"random-selected,random-static,random-premium,random,fade\",\"0\":\"Remove\",\"slot_amount\":7,\"transition_rotation\":0,\"transition_duration\":300,\"delay\":\"\",\"save_performance\":\"off\",\"enable_link\":\"false\",\"link_type\":\"regular\",\"link\":\"\",\"link_open_in\":\"same\",\"slide_link\":\"nothing\",\"link_pos\":\"front\",\"slide_thumb\":\"\",\"class_attr\":\"\",\"id_attr\":\"\",\"attr_attr\":\"\",\"data_attr\":\"\",\"slide_bg_color\":\"#E7E7E7\",\"slide_bg_external\":\"\",\"bg_fit\":\"cover\",\"bg_fit_x\":\"100\",\"bg_fit_y\":\"100\",\"bg_repeat\":\"no-repeat\",\"bg_position\":\"center center\",\"bg_position_x\":\"0\",\"bg_position_y\":\"0\",\"bg_end_position_x\":\"0\",\"bg_end_position_y\":\"0\",\"bg_end_position\":\"center top\",\"kenburn_effect\":\"off\",\"kb_start_fit\":\"100\",\"kb_end_fit\":\"100\",\"kb_duration\":\"9000\",\"kb_easing\":\"Linear.easeNone\",\"0\":\"Remove\"}","[{\"style\":\"\",\"text\":\"Background\",\"type\":\"image\",\"image_url\":\"http:\\/\\/foolstacks.ir\\/wp-content\\/uploads\\/revslider\\/webdesign\\/home_webdesign_slide1_cover.png\",\"left\":198,\"top\":-4,\"loop_animation\":\"none\",\"loop_easing\":\"Power3.easeInOut\",\"loop_speed\":\"2\",\"loop_startdeg\":\"-20\",\"loop_enddeg\":\"20\",\"loop_xorigin\":\"50\",\"loop_yorigin\":\"50\",\"loop_xstart\":\"0\",\"loop_xend\":\"0\",\"loop_ystart\":\"0\",\"loop_yend\":\"0\",\"loop_zoomstart\":\"1\",\"loop_zoomend\":\"1\",\"loop_angle\":\"0\",\"loop_radius\":\"10\",\"animation\":\"customin-2\",\"easing\":\"Power3.easeInOut\",\"split\":\"none\",\"endsplit\":\"none\",\"splitdelay\":\"10\",\"endsplitdelay\":\"10\",\"2d_origin_x\":\"50\",\"2d_origin_y\":\"50\",\"parallax_level\":\"-\",\"whitespace\":\"nowrap\",\"speed\":1300,\"align_hor\":\"left\",\"align_vert\":\"top\",\"hiddenunder\":false,\"resizeme\":true,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"time\":500,\"endtime\":\"8700\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"width\":1719,\"height\":1600,\"serial\":\"1\",\"endTimeFinal\":8700,\"endSpeedFinal\":300,\"realEndTime\":9000,\"timeLast\":8500,\"endWithSlide\":true,\"max_height\":\"auto\",\"max_width\":\"auto\",\"2d_rotation\":\"\",\"alt\":\"\",\"scaleX\":\"\",\"scaleY\":\"\",\"scaleProportional\":false,\"attrID\":\"\",\"attrClasses\":\"\",\"attrTitle\":\"\",\"attrRel\":\"\",\"link_id\":\"\",\"link_class\":\"\",\"link_title\":\"\",\"link_rel\":\"\",\"static_start\":\"1\",\"static_end\":\"2\"},{\"style\":\"\",\"text\":\"Background\",\"type\":\"image\",\"image_url\":\"http:\\/\\/foolstacks.ir\\/wp-content\\/uploads\\/revslider\\/webdesign\\/home_webdesign_slide1_cover.png\",\"left\":2,\"top\":-8,\"loop_animation\":\"none\",\"loop_easing\":\"Power3.easeInOut\",\"loop_speed\":\"2\",\"loop_startdeg\":\"-20\",\"loop_enddeg\":\"20\",\"loop_xorigin\":\"50\",\"loop_yorigin\":\"50\",\"loop_xstart\":\"0\",\"loop_xend\":\"0\",\"loop_ystart\":\"0\",\"loop_yend\":\"0\",\"loop_zoomstart\":\"1\",\"loop_zoomend\":\"1\",\"loop_angle\":\"0\",\"loop_radius\":\"10\",\"animation\":\"customin-2\",\"easing\":\"Power3.easeInOut\",\"split\":\"none\",\"endsplit\":\"none\",\"splitdelay\":\"10\",\"endsplitdelay\":\"10\",\"2d_origin_x\":\"50\",\"2d_origin_y\":\"50\",\"parallax_level\":\"-\",\"whitespace\":\"nowrap\",\"speed\":1300,\"align_hor\":\"left\",\"align_vert\":\"top\",\"hiddenunder\":false,\"resizeme\":true,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"time\":800,\"endtime\":\"8700\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"width\":1719,\"height\":1600,\"serial\":\"2\",\"endTimeFinal\":8700,\"endSpeedFinal\":300,\"realEndTime\":9000,\"timeLast\":8500,\"endWithSlide\":true,\"max_height\":\"auto\",\"max_width\":\"auto\",\"2d_rotation\":\"\",\"alt\":\"\",\"scaleX\":\"\",\"scaleY\":\"\",\"scaleProportional\":false,\"attrID\":\"\",\"attrClasses\":\"\",\"attrTitle\":\"\",\"attrRel\":\"\",\"link_id\":\"\",\"link_class\":\"\",\"link_title\":\"\",\"link_rel\":\"\",\"static_start\":\"1\",\"static_end\":\"1\"},{\"text\":\"\\u0628\\u0627 \\u06a9\\u0645\\u062a\\u0631\\u06cc\\u0646 \\u0647\\u0632\\u06cc\\u0646\\u0647\",\"type\":\"text\",\"left\":140,\"top\":9,\"loop_animation\":\"none\",\"loop_easing\":\"Power3.easeInOut\",\"loop_speed\":\"2\",\"loop_startdeg\":\"-20\",\"loop_enddeg\":\"20\",\"loop_xorigin\":\"50\",\"loop_yorigin\":\"50\",\"loop_xstart\":\"0\",\"loop_xend\":\"0\",\"loop_ystart\":\"0\",\"loop_yend\":\"0\",\"loop_zoomstart\":\"1\",\"loop_zoomend\":\"1\",\"loop_angle\":\"0\",\"loop_radius\":\"10\",\"animation\":\"sfl\",\"easing\":\"Power3.easeInOut\",\"split\":\"none\",\"endsplit\":\"none\",\"splitdelay\":\"10\",\"endsplitdelay\":\"10\",\"2d_origin_x\":\"50\",\"2d_origin_y\":\"50\",\"parallax_level\":\"-\",\"whitespace\":\"nowrap\",\"speed\":1000,\"align_hor\":\"left\",\"align_vert\":\"middle\",\"hiddenunder\":false,\"resizeme\":true,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"style\":\"mfnrswebdesignlargelight\",\"time\":1500,\"endtime\":\"8700\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"width\":261,\"height\":46,\"serial\":\"4\",\"endTimeFinal\":8700,\"endSpeedFinal\":300,\"realEndTime\":9000,\"timeLast\":8700,\"endWithSlide\":true,\"max_height\":\"auto\",\"max_width\":\"auto\",\"2d_rotation\":\"0\",\"alt\":\"\",\"scaleX\":\"\",\"scaleY\":\"\",\"scaleProportional\":false,\"attrID\":\"\",\"attrClasses\":\"\",\"attrTitle\":\"\",\"attrRel\":\"\",\"link_id\":\"\",\"link_class\":\"\",\"link_title\":\"\",\"link_rel\":\"\",\"static_end\":\"2\",\"static_start\":\"1\"}]");
INSERT INTO `st_revslider_slides` VALUES("11","3","1","{\"background_type\":\"image\",\"image\":\"http:\\/\\/foolstacks.ir\\/wp-content\\/uploads\\/2018\\/11\\/2-1.jpg\",\"image_id\":\"2276\",\"title\":\"Slide\",\"state\":\"published\",\"date_from\":\"\",\"date_to\":\"\",\"slide_transition\":\"random-selected,random-static,random-premium,random\",\"0\":\"Remove\",\"slot_amount\":7,\"transition_rotation\":0,\"transition_duration\":300,\"delay\":\"\",\"save_performance\":\"off\",\"enable_link\":\"false\",\"link_type\":\"regular\",\"link\":\"\",\"link_open_in\":\"same\",\"slide_link\":\"nothing\",\"link_pos\":\"front\",\"slide_thumb\":\"\",\"class_attr\":\"\",\"id_attr\":\"\",\"attr_attr\":\"\",\"data_attr\":\"\",\"slide_bg_color\":\"#E7E7E7\",\"slide_bg_external\":\"\",\"bg_fit\":\"cover\",\"bg_fit_x\":\"100\",\"bg_fit_y\":\"100\",\"bg_repeat\":\"no-repeat\",\"bg_position\":\"center center\",\"bg_position_x\":\"0\",\"bg_position_y\":\"0\",\"bg_end_position_x\":\"0\",\"bg_end_position_y\":\"0\",\"bg_end_position\":\"center top\",\"kenburn_effect\":\"off\",\"kb_start_fit\":\"100\",\"kb_end_fit\":\"100\",\"kb_duration\":\"9000\",\"kb_easing\":\"Linear.easeNone\",\"0\":\"Remove\"}","[{\"style\":\"\",\"text\":\"Background\",\"type\":\"image\",\"image_url\":\"http:\\/\\/foolstacks.ir\\/wp-content\\/uploads\\/revslider\\/webdesign\\/home_webdesign_slide3_cover.png\",\"left\":243,\"top\":-1,\"loop_animation\":\"none\",\"loop_easing\":\"Power3.easeInOut\",\"loop_speed\":\"2\",\"loop_startdeg\":\"-20\",\"loop_enddeg\":\"20\",\"loop_xorigin\":\"50\",\"loop_yorigin\":\"50\",\"loop_xstart\":\"0\",\"loop_xend\":\"0\",\"loop_ystart\":\"0\",\"loop_yend\":\"0\",\"loop_zoomstart\":\"1\",\"loop_zoomend\":\"1\",\"loop_angle\":\"0\",\"loop_radius\":\"10\",\"animation\":\"customin-2\",\"easing\":\"Power3.easeInOut\",\"split\":\"none\",\"endsplit\":\"none\",\"splitdelay\":\"10\",\"endsplitdelay\":\"10\",\"2d_origin_x\":\"50\",\"2d_origin_y\":\"50\",\"parallax_level\":\"-\",\"whitespace\":\"nowrap\",\"speed\":1300,\"align_hor\":\"left\",\"align_vert\":\"top\",\"hiddenunder\":false,\"resizeme\":true,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"time\":500,\"endtime\":\"8700\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"width\":1719,\"height\":1600,\"serial\":\"1\",\"endTimeFinal\":1200,\"endSpeedFinal\":300,\"realEndTime\":5000,\"timeLast\":1200,\"endWithSlide\":true,\"max_height\":\"auto\",\"max_width\":\"auto\",\"2d_rotation\":\"\",\"alt\":\"\",\"scaleX\":\"\",\"scaleY\":\"\",\"scaleProportional\":false,\"attrID\":\"\",\"attrClasses\":\"\",\"attrTitle\":\"\",\"attrRel\":\"\",\"link_id\":\"\",\"link_class\":\"\",\"link_title\":\"\",\"link_rel\":\"\",\"static_start\":\"1\",\"static_end\":\"2\"},{\"style\":\"\",\"text\":\"Background\",\"type\":\"image\",\"image_url\":\"http:\\/\\/foolstacks.ir\\/wp-content\\/uploads\\/revslider\\/webdesign\\/home_webdesign_slide3_cover.png\",\"left\":-46,\"top\":8,\"loop_animation\":\"none\",\"loop_easing\":\"Power3.easeInOut\",\"loop_speed\":\"2\",\"loop_startdeg\":\"-20\",\"loop_enddeg\":\"20\",\"loop_xorigin\":\"50\",\"loop_yorigin\":\"50\",\"loop_xstart\":\"0\",\"loop_xend\":\"0\",\"loop_ystart\":\"0\",\"loop_yend\":\"0\",\"loop_zoomstart\":\"1\",\"loop_zoomend\":\"1\",\"loop_angle\":\"0\",\"loop_radius\":\"10\",\"animation\":\"customin-2\",\"easing\":\"Power3.easeInOut\",\"split\":\"none\",\"endsplit\":\"none\",\"splitdelay\":\"10\",\"endsplitdelay\":\"10\",\"2d_origin_x\":\"50\",\"2d_origin_y\":\"50\",\"parallax_level\":\"-\",\"whitespace\":\"nowrap\",\"speed\":1300,\"align_hor\":\"left\",\"align_vert\":\"top\",\"hiddenunder\":false,\"resizeme\":true,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"time\":800,\"endtime\":\"8700\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"width\":1719,\"height\":1600,\"serial\":\"2\",\"endTimeFinal\":1500,\"endSpeedFinal\":300,\"realEndTime\":5000,\"timeLast\":1500,\"endWithSlide\":true,\"max_height\":\"auto\",\"max_width\":\"auto\",\"2d_rotation\":\"\",\"alt\":\"\",\"scaleX\":\"\",\"scaleY\":\"\",\"scaleProportional\":false,\"attrID\":\"\",\"attrClasses\":\"\",\"attrTitle\":\"\",\"attrRel\":\"\",\"link_id\":\"\",\"link_class\":\"\",\"link_title\":\"\",\"link_rel\":\"\",\"static_start\":\"1\",\"static_end\":\"2\"},{\"text\":\"\\u0637\\u0631\\u0627\\u062d\\u06cc \\u0633\\u0627\\u06cc\\u062a \\u062e\\u0648\\u062f \\u0631\\u0627 \\u0628\\u0647 \\u0645\\u0627 \\u0628\\u0633\\u067e\\u0627\\u0631\\u06cc\\u062f\",\"type\":\"text\",\"left\":140,\"top\":10,\"loop_animation\":\"none\",\"loop_easing\":\"Power3.easeInOut\",\"loop_speed\":\"2\",\"loop_startdeg\":\"-20\",\"loop_enddeg\":\"20\",\"loop_xorigin\":\"50\",\"loop_yorigin\":\"50\",\"loop_xstart\":\"0\",\"loop_xend\":\"0\",\"loop_ystart\":\"0\",\"loop_yend\":\"0\",\"loop_zoomstart\":\"1\",\"loop_zoomend\":\"1\",\"loop_angle\":\"0\",\"loop_radius\":\"10\",\"animation\":\"sfl\",\"easing\":\"Power3.easeInOut\",\"split\":\"none\",\"endsplit\":\"none\",\"splitdelay\":\"10\",\"endsplitdelay\":\"10\",\"2d_origin_x\":\"50\",\"2d_origin_y\":\"50\",\"parallax_level\":\"-\",\"whitespace\":\"nowrap\",\"speed\":1000,\"align_hor\":\"left\",\"align_vert\":\"middle\",\"hiddenunder\":false,\"resizeme\":true,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"style\":\"mfnrswebdesignlargelight\",\"time\":1500,\"endtime\":\"8700\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"width\":63,\"height\":13,\"serial\":\"4\",\"endTimeFinal\":8700,\"endSpeedFinal\":300,\"realEndTime\":9000,\"timeLast\":8700,\"endWithSlide\":true,\"max_height\":\"auto\",\"max_width\":\"auto\",\"2d_rotation\":\"\",\"alt\":\"\",\"scaleX\":\"\",\"scaleY\":\"\",\"scaleProportional\":false,\"attrID\":\"\",\"attrClasses\":\"\",\"attrTitle\":\"\",\"attrRel\":\"\",\"link_id\":\"\",\"link_class\":\"\",\"link_title\":\"\",\"link_rel\":\"\",\"static_end\":\"2\",\"static_start\":\"1\"},{\"text\":\"\",\"type\":\"text\",\"left\":140,\"top\":169,\"loop_animation\":\"none\",\"loop_easing\":\"Power3.easeInOut\",\"loop_speed\":\"2\",\"loop_startdeg\":\"-20\",\"loop_enddeg\":\"20\",\"loop_xorigin\":\"50\",\"loop_yorigin\":\"50\",\"loop_xstart\":\"0\",\"loop_xend\":\"0\",\"loop_ystart\":\"0\",\"loop_yend\":\"0\",\"loop_zoomstart\":\"1\",\"loop_zoomend\":\"1\",\"loop_angle\":\"0\",\"loop_radius\":\"10\",\"animation\":\"sfl\",\"easing\":\"Power3.easeInOut\",\"split\":\"none\",\"endsplit\":\"none\",\"splitdelay\":\"10\",\"endsplitdelay\":\"10\",\"2d_origin_x\":\"50\",\"2d_origin_y\":\"50\",\"parallax_level\":\"-\",\"whitespace\":\"nowrap\",\"speed\":1000,\"align_hor\":\"left\",\"align_vert\":\"middle\",\"hiddenunder\":false,\"resizeme\":true,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"style\":\"mfnrswebdesignsmalllight\",\"time\":1900,\"endtime\":\"8700\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"width\":418,\"height\":65,\"serial\":\"6\",\"endTimeFinal\":8700,\"endSpeedFinal\":300,\"realEndTime\":9000,\"timeLast\":8700,\"endWithSlide\":true,\"max_height\":\"auto\",\"max_width\":\"auto\",\"2d_rotation\":\"\",\"alt\":\"\",\"scaleX\":\"\",\"scaleY\":\"\",\"scaleProportional\":false,\"attrID\":\"\",\"attrClasses\":\"\",\"attrTitle\":\"\",\"attrRel\":\"\",\"link_id\":\"\",\"link_class\":\"\",\"link_title\":\"\",\"link_rel\":\"\",\"static_end\":\"2\",\"static_start\":\"1\"}]");
INSERT INTO `st_revslider_slides` VALUES("14","3","2","{\"background_type\":\"image\",\"image\":\"http:\\/\\/foolstacks.ir\\/wp-content\\/uploads\\/2018\\/11\\/3.png\",\"image_id\":\"2277\",\"title\":\"Slide\",\"state\":\"published\",\"date_from\":\"\",\"date_to\":\"\",\"slide_transition\":\"random-selected,random-static,random-premium,random,fade\",\"0\":\"Remove\",\"slot_amount\":7,\"transition_rotation\":0,\"transition_duration\":300,\"delay\":\"\",\"save_performance\":\"off\",\"enable_link\":\"false\",\"link_type\":\"regular\",\"link\":\"\",\"link_open_in\":\"same\",\"slide_link\":\"nothing\",\"link_pos\":\"front\",\"slide_thumb\":\"\",\"class_attr\":\"\",\"id_attr\":\"\",\"attr_attr\":\"\",\"data_attr\":\"\",\"slide_bg_color\":\"#E7E7E7\",\"slide_bg_external\":\"\",\"bg_fit\":\"cover\",\"bg_fit_x\":\"100\",\"bg_fit_y\":\"100\",\"bg_repeat\":\"no-repeat\",\"bg_position\":\"center center\",\"bg_position_x\":\"0\",\"bg_position_y\":\"0\",\"bg_end_position_x\":\"0\",\"bg_end_position_y\":\"0\",\"bg_end_position\":\"center top\",\"kenburn_effect\":\"off\",\"kb_start_fit\":\"100\",\"kb_end_fit\":\"100\",\"kb_duration\":\"9000\",\"kb_easing\":\"Linear.easeNone\",\"0\":\"Remove\"}","[{\"style\":\"\",\"text\":\"Background\",\"type\":\"image\",\"image_url\":\"http:\\/\\/foolstacks.ir\\/wp-content\\/uploads\\/revslider\\/webdesign\\/home_webdesign_slide4_cover.png\",\"left\":220,\"top\":-23,\"loop_animation\":\"none\",\"loop_easing\":\"Power3.easeInOut\",\"loop_speed\":\"2\",\"loop_startdeg\":\"-20\",\"loop_enddeg\":\"20\",\"loop_xorigin\":\"50\",\"loop_yorigin\":\"50\",\"loop_xstart\":\"0\",\"loop_xend\":\"0\",\"loop_ystart\":\"0\",\"loop_yend\":\"0\",\"loop_zoomstart\":\"1\",\"loop_zoomend\":\"1\",\"loop_angle\":\"0\",\"loop_radius\":\"10\",\"animation\":\"customin-2\",\"easing\":\"Power3.easeInOut\",\"split\":\"none\",\"endsplit\":\"none\",\"splitdelay\":\"10\",\"endsplitdelay\":\"10\",\"2d_origin_x\":\"50\",\"2d_origin_y\":\"50\",\"parallax_level\":\"-\",\"whitespace\":\"nowrap\",\"speed\":1300,\"align_hor\":\"left\",\"align_vert\":\"top\",\"hiddenunder\":false,\"resizeme\":true,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"time\":500,\"endtime\":\"8700\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"width\":1719,\"height\":1600,\"serial\":\"1\",\"endTimeFinal\":8700,\"endSpeedFinal\":300,\"realEndTime\":9000,\"timeLast\":8500,\"endWithSlide\":true,\"max_height\":\"auto\",\"max_width\":\"auto\",\"2d_rotation\":\"\",\"alt\":\"\",\"scaleX\":\"\",\"scaleY\":\"\",\"scaleProportional\":false,\"attrID\":\"\",\"attrClasses\":\"\",\"attrTitle\":\"\",\"attrRel\":\"\",\"link_id\":\"\",\"link_class\":\"\",\"link_title\":\"\",\"link_rel\":\"\",\"static_start\":\"1\",\"static_end\":\"2\"},{\"style\":\"\",\"text\":\"Background\",\"type\":\"image\",\"image_url\":\"http:\\/\\/foolstacks.ir\\/wp-content\\/uploads\\/revslider\\/webdesign\\/home_webdesign_slide4_cover.png\",\"left\":-110,\"top\":-40,\"loop_animation\":\"none\",\"loop_easing\":\"Power3.easeInOut\",\"loop_speed\":\"2\",\"loop_startdeg\":\"-20\",\"loop_enddeg\":\"20\",\"loop_xorigin\":\"50\",\"loop_yorigin\":\"50\",\"loop_xstart\":\"0\",\"loop_xend\":\"0\",\"loop_ystart\":\"0\",\"loop_yend\":\"0\",\"loop_zoomstart\":\"1\",\"loop_zoomend\":\"1\",\"loop_angle\":\"0\",\"loop_radius\":\"10\",\"animation\":\"customin-2\",\"easing\":\"Power3.easeInOut\",\"split\":\"none\",\"endsplit\":\"none\",\"splitdelay\":\"10\",\"endsplitdelay\":\"10\",\"2d_origin_x\":\"50\",\"2d_origin_y\":\"50\",\"parallax_level\":\"-\",\"whitespace\":\"nowrap\",\"speed\":1300,\"align_hor\":\"left\",\"align_vert\":\"top\",\"hiddenunder\":false,\"resizeme\":true,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"time\":800,\"endtime\":\"8700\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"width\":1719,\"height\":1600,\"serial\":\"2\",\"endTimeFinal\":8700,\"endSpeedFinal\":300,\"realEndTime\":9000,\"timeLast\":8500,\"endWithSlide\":true,\"max_height\":\"auto\",\"max_width\":\"auto\",\"2d_rotation\":\"\",\"alt\":\"\",\"scaleX\":\"\",\"scaleY\":\"\",\"scaleProportional\":false,\"attrID\":\"\",\"attrClasses\":\"\",\"attrTitle\":\"\",\"attrRel\":\"\",\"link_id\":\"\",\"link_class\":\"\",\"link_title\":\"\",\"link_rel\":\"\",\"static_start\":\"1\",\"static_end\":\"2\"},{\"text\":\"\\u0645\\u0637\\u0627\\u0628\\u0642 \\u0628\\u0627 \\u0646\\u06cc\\u0627\\u0632\\u0647\\u0627 \\u0648 \\u0627\\u0647\\u062f\\u0627\\u0641 \\u0634\\u0645\\u0627\",\"type\":\"text\",\"left\":140,\"top\":10,\"loop_animation\":\"none\",\"loop_easing\":\"Power3.easeInOut\",\"loop_speed\":\"2\",\"loop_startdeg\":\"-20\",\"loop_enddeg\":\"20\",\"loop_xorigin\":\"50\",\"loop_yorigin\":\"50\",\"loop_xstart\":\"0\",\"loop_xend\":\"0\",\"loop_ystart\":\"0\",\"loop_yend\":\"0\",\"loop_zoomstart\":\"1\",\"loop_zoomend\":\"1\",\"loop_angle\":\"0\",\"loop_radius\":\"10\",\"animation\":\"sfl\",\"easing\":\"Power3.easeInOut\",\"split\":\"none\",\"endsplit\":\"none\",\"splitdelay\":\"10\",\"endsplitdelay\":\"10\",\"2d_origin_x\":\"50\",\"2d_origin_y\":\"50\",\"parallax_level\":\"-\",\"whitespace\":\"nowrap\",\"speed\":1000,\"align_hor\":\"left\",\"align_vert\":\"middle\",\"hiddenunder\":false,\"resizeme\":true,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"style\":\"mfnrswebdesignlargelight\",\"time\":1500,\"endtime\":\"8700\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"width\":63,\"height\":13,\"serial\":\"4\",\"endTimeFinal\":8700,\"endSpeedFinal\":300,\"realEndTime\":9000,\"timeLast\":8700,\"endWithSlide\":true,\"max_height\":\"auto\",\"max_width\":\"auto\",\"2d_rotation\":\"\",\"alt\":\"\",\"scaleX\":\"\",\"scaleY\":\"\",\"scaleProportional\":false,\"attrID\":\"\",\"attrClasses\":\"\",\"attrTitle\":\"\",\"attrRel\":\"\",\"link_id\":\"\",\"link_class\":\"\",\"link_title\":\"\",\"link_rel\":\"\",\"static_end\":\"2\",\"static_start\":\"1\"}]");
INSERT INTO `st_revslider_slides` VALUES("13","3","3","{\"background_type\":\"image\",\"image\":\"http:\\/\\/foolstacks.ir\\/wp-content\\/uploads\\/2018\\/11\\/1-1.jpg\",\"image_id\":\"2275\",\"title\":\"Slide\",\"state\":\"published\",\"date_from\":\"\",\"date_to\":\"\",\"slide_transition\":\"random-selected,random-static,random-premium,random,fade\",\"0\":\"Remove\",\"slot_amount\":7,\"transition_rotation\":0,\"transition_duration\":300,\"delay\":\"\",\"save_performance\":\"off\",\"enable_link\":\"false\",\"link_type\":\"regular\",\"link\":\"\",\"link_open_in\":\"same\",\"slide_link\":\"nothing\",\"link_pos\":\"front\",\"slide_thumb\":\"\",\"class_attr\":\"\",\"id_attr\":\"\",\"attr_attr\":\"\",\"data_attr\":\"\",\"slide_bg_color\":\"#E7E7E7\",\"slide_bg_external\":\"\",\"bg_fit\":\"cover\",\"bg_fit_x\":\"100\",\"bg_fit_y\":\"100\",\"bg_repeat\":\"no-repeat\",\"bg_position\":\"center center\",\"bg_position_x\":\"0\",\"bg_position_y\":\"0\",\"bg_end_position_x\":\"0\",\"bg_end_position_y\":\"0\",\"bg_end_position\":\"center top\",\"kenburn_effect\":\"off\",\"kb_start_fit\":\"100\",\"kb_end_fit\":\"100\",\"kb_duration\":\"9000\",\"kb_easing\":\"Linear.easeNone\",\"0\":\"Remove\"}","[{\"style\":\"\",\"text\":\"Background\",\"type\":\"image\",\"image_url\":\"http:\\/\\/foolstacks.ir\\/wp-content\\/uploads\\/revslider\\/webdesign\\/home_webdesign_slide2_cover.png\",\"left\":217,\"top\":-16,\"loop_animation\":\"none\",\"loop_easing\":\"Power3.easeInOut\",\"loop_speed\":\"2\",\"loop_startdeg\":\"-20\",\"loop_enddeg\":\"20\",\"loop_xorigin\":\"50\",\"loop_yorigin\":\"50\",\"loop_xstart\":\"0\",\"loop_xend\":\"0\",\"loop_ystart\":\"0\",\"loop_yend\":\"0\",\"loop_zoomstart\":\"1\",\"loop_zoomend\":\"1\",\"loop_angle\":\"0\",\"loop_radius\":\"10\",\"animation\":\"customin-2\",\"easing\":\"Power3.easeInOut\",\"split\":\"none\",\"endsplit\":\"none\",\"splitdelay\":\"10\",\"endsplitdelay\":\"10\",\"2d_origin_x\":\"50\",\"2d_origin_y\":\"50\",\"parallax_level\":\"-\",\"whitespace\":\"nowrap\",\"speed\":1300,\"align_hor\":\"left\",\"align_vert\":\"top\",\"hiddenunder\":false,\"resizeme\":true,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"time\":500,\"endtime\":\"8700\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"width\":1719,\"height\":1600,\"serial\":\"1\",\"endTimeFinal\":8700,\"endSpeedFinal\":300,\"realEndTime\":9000,\"timeLast\":8500,\"endWithSlide\":true,\"max_height\":\"auto\",\"max_width\":\"auto\",\"2d_rotation\":\"\",\"alt\":\"\",\"scaleX\":\"\",\"scaleY\":\"\",\"scaleProportional\":false,\"attrID\":\"\",\"attrClasses\":\"\",\"attrTitle\":\"\",\"attrRel\":\"\",\"link_id\":\"\",\"link_class\":\"\",\"link_title\":\"\",\"link_rel\":\"\",\"static_start\":\"1\",\"static_end\":\"2\"},{\"style\":\"\",\"text\":\"Background\",\"type\":\"image\",\"image_url\":\"http:\\/\\/foolstacks.ir\\/wp-content\\/uploads\\/revslider\\/webdesign\\/home_webdesign_slide2_cover.png\",\"left\":-4,\"top\":-6,\"loop_animation\":\"none\",\"loop_easing\":\"Power3.easeInOut\",\"loop_speed\":\"2\",\"loop_startdeg\":\"-20\",\"loop_enddeg\":\"20\",\"loop_xorigin\":\"50\",\"loop_yorigin\":\"50\",\"loop_xstart\":\"0\",\"loop_xend\":\"0\",\"loop_ystart\":\"0\",\"loop_yend\":\"0\",\"loop_zoomstart\":\"1\",\"loop_zoomend\":\"1\",\"loop_angle\":\"0\",\"loop_radius\":\"10\",\"animation\":\"customin-2\",\"easing\":\"Power3.easeInOut\",\"split\":\"none\",\"endsplit\":\"none\",\"splitdelay\":\"10\",\"endsplitdelay\":\"10\",\"2d_origin_x\":\"50\",\"2d_origin_y\":\"50\",\"parallax_level\":\"-\",\"whitespace\":\"nowrap\",\"speed\":1300,\"align_hor\":\"left\",\"align_vert\":\"top\",\"hiddenunder\":false,\"resizeme\":true,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"time\":800,\"endtime\":\"8700\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"width\":1719,\"height\":1600,\"serial\":\"2\",\"endTimeFinal\":8700,\"endSpeedFinal\":300,\"realEndTime\":9000,\"timeLast\":8500,\"endWithSlide\":true,\"max_height\":\"auto\",\"max_width\":\"auto\",\"2d_rotation\":\"\",\"alt\":\"\",\"scaleX\":\"\",\"scaleY\":\"\",\"scaleProportional\":false,\"attrID\":\"\",\"attrClasses\":\"\",\"attrTitle\":\"\",\"attrRel\":\"\",\"link_id\":\"\",\"link_class\":\"\",\"link_title\":\"\",\"link_rel\":\"\",\"static_start\":\"1\",\"static_end\":\"2\"},{\"text\":\"\\u062f\\u0631 \\u06a9\\u0648\\u062a\\u0627\\u0647\\u062a\\u0631\\u06cc\\u0646 \\u0632\\u0645\\u0627\\u0646\",\"type\":\"text\",\"left\":140,\"top\":10,\"loop_animation\":\"none\",\"loop_easing\":\"Power3.easeInOut\",\"loop_speed\":\"2\",\"loop_startdeg\":\"-20\",\"loop_enddeg\":\"20\",\"loop_xorigin\":\"50\",\"loop_yorigin\":\"50\",\"loop_xstart\":\"0\",\"loop_xend\":\"0\",\"loop_ystart\":\"0\",\"loop_yend\":\"0\",\"loop_zoomstart\":\"1\",\"loop_zoomend\":\"1\",\"loop_angle\":\"0\",\"loop_radius\":\"10\",\"animation\":\"sfl\",\"easing\":\"Power3.easeInOut\",\"split\":\"none\",\"endsplit\":\"none\",\"splitdelay\":\"10\",\"endsplitdelay\":\"10\",\"2d_origin_x\":\"50\",\"2d_origin_y\":\"50\",\"parallax_level\":\"-\",\"whitespace\":\"nowrap\",\"speed\":1000,\"align_hor\":\"left\",\"align_vert\":\"middle\",\"hiddenunder\":false,\"resizeme\":true,\"link\":\"\",\"link_open_in\":\"same\",\"link_slide\":\"nothing\",\"scrollunder_offset\":\"\",\"style\":\"mfnrswebdesignlargelight\",\"time\":1500,\"endtime\":\"8700\",\"endspeed\":300,\"endanimation\":\"auto\",\"endeasing\":\"nothing\",\"corner_left\":\"nothing\",\"corner_right\":\"nothing\",\"width\":63,\"height\":13,\"serial\":\"4\",\"endTimeFinal\":8700,\"endSpeedFinal\":300,\"realEndTime\":9000,\"timeLast\":8700,\"endWithSlide\":true,\"max_height\":\"auto\",\"max_width\":\"auto\",\"2d_rotation\":\"\",\"alt\":\"\",\"scaleX\":\"\",\"scaleY\":\"\",\"scaleProportional\":false,\"attrID\":\"\",\"attrClasses\":\"\",\"attrTitle\":\"\",\"attrRel\":\"\",\"link_id\":\"\",\"link_class\":\"\",\"link_title\":\"\",\"link_rel\":\"\",\"static_end\":\"2\",\"static_start\":\"1\"}]");


DROP TABLE IF EXISTS `st_revslider_static_slides`;

CREATE TABLE `st_revslider_static_slides` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `slider_id` int(9) NOT NULL,
  `params` text NOT NULL,
  `layers` text NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `st_statistics_exclusions`;

CREATE TABLE `st_statistics_exclusions` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `count` bigint(20) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `date` (`date`),
  KEY `reason` (`reason`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `st_statistics_historical`;

CREATE TABLE `st_statistics_historical` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `category` varchar(25) NOT NULL,
  `page_id` bigint(20) NOT NULL,
  `uri` varchar(255) NOT NULL,
  `value` bigint(20) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `page_id` (`page_id`),
  UNIQUE KEY `uri` (`uri`),
  KEY `category` (`category`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `st_statistics_pages`;

CREATE TABLE `st_statistics_pages` (
  `uri` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `count` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  UNIQUE KEY `date_2` (`date`,`uri`),
  KEY `url` (`uri`),
  KEY `date` (`date`),
  KEY `id` (`id`),
  KEY `uri` (`uri`,`count`,`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `st_statistics_pages` VALUES("/","2018-11-13","37","106");
INSERT INTO `st_statistics_pages` VALUES("/?wc-ajax=get_refreshed_fragments","2018-11-13","10","106");
INSERT INTO `st_statistics_pages` VALUES("/?page_id=27","2018-11-13","7","27");
INSERT INTO `st_statistics_pages` VALUES("/?page_id=28","2018-11-13","2","28");
INSERT INTO `st_statistics_pages` VALUES("/?p=2290","2018-11-13","1","2290");
INSERT INTO `st_statistics_pages` VALUES("/?p=1","2018-11-13","2","1");
INSERT INTO `st_statistics_pages` VALUES("/?page_id=2315","2018-11-13","1","2315");
INSERT INTO `st_statistics_pages` VALUES("/%d8%a8%d9%84%d8%a7%da%af-2/","2018-11-13","1","2315");
INSERT INTO `st_statistics_pages` VALUES("/?page_id=2313","2018-11-13","1","2313");
INSERT INTO `st_statistics_pages` VALUES("/%d9%be%d8%b1%d8%aa%d8%a7%d9%84-%d8%b3%d8%a7%d8%b2%d9%85%d8%a7%d9%86%db%8c/","2018-11-13","1","2313");
INSERT INTO `st_statistics_pages` VALUES("/?page_id=2323","2018-11-13","1","2323");
INSERT INTO `st_statistics_pages` VALUES("/%d9%81%d8%b1%d9%88%d8%b4%da%af%d8%a7%d9%87/","2018-11-13","1","2323");
INSERT INTO `st_statistics_pages` VALUES("/?page_id=2319","2018-11-13","1","2319");
INSERT INTO `st_statistics_pages` VALUES("/%d9%88%d8%b1%d8%af%d9%be%d8%b1%d8%b3/","2018-11-13","1","2319");
INSERT INTO `st_statistics_pages` VALUES("/?page_id=2317","2018-11-13","1","2317");
INSERT INTO `st_statistics_pages` VALUES("/%d8%a8%d8%b1%d9%86%d8%af%d8%b3%d8%a7%d8%b2%db%8c/","2018-11-13","1","2317");
INSERT INTO `st_statistics_pages` VALUES("/%D8%AF%D8%B1%D8%A8%D8%A7%D8%B1%D9%87/","2018-11-13","2","27");
INSERT INTO `st_statistics_pages` VALUES("/%d8%a7%d8%b1%d8%aa%d8%a8%d8%a7%d8%b7/","2018-11-13","1","28");
INSERT INTO `st_statistics_pages` VALUES("/%about%/","2018-11-13","1","106");
INSERT INTO `st_statistics_pages` VALUES("/","2018-11-14","51","106");
INSERT INTO `st_statistics_pages` VALUES("/?wc-ajax=get_refreshed_fragments","2018-11-14","34","106");
INSERT INTO `st_statistics_pages` VALUES("/%d8%af%d8%b1%d8%a8%d8%a7%d8%b1%d9%87/","2018-11-14","6","27");
INSERT INTO `st_statistics_pages` VALUES("/?p=1","2018-11-14","2","1");
INSERT INTO `st_statistics_pages` VALUES("/?p=2290","2018-11-14","3","2290");
INSERT INTO `st_statistics_pages` VALUES("/?page_id=2319","2018-11-14","1","2319");
INSERT INTO `st_statistics_pages` VALUES("/%d9%88%d8%b1%d8%af%d9%be%d8%b1%d8%b3/","2018-11-14","1","2319");
INSERT INTO `st_statistics_pages` VALUES("/%about%/","2018-11-14","2","106");
INSERT INTO `st_statistics_pages` VALUES("/%d8%a7%d8%b1%d8%aa%d8%a8%d8%a7%d8%b7/","2018-11-14","4","28");
INSERT INTO `st_statistics_pages` VALUES("/?page_id=2313","2018-11-14","1","2313");
INSERT INTO `st_statistics_pages` VALUES("/%d9%be%d8%b1%d8%aa%d8%a7%d9%84-%d8%b3%d8%a7%d8%b2%d9%85%d8%a7%d9%86%db%8c/","2018-11-14","1","2313");
INSERT INTO `st_statistics_pages` VALUES("/?page_id=2315","2018-11-14","1","2315");
INSERT INTO `st_statistics_pages` VALUES("/%d8%a8%d9%84%d8%a7%da%af-2/","2018-11-14","1","2315");
INSERT INTO `st_statistics_pages` VALUES("/2290/","2018-11-14","2","2290");
INSERT INTO `st_statistics_pages` VALUES("/%d8%b3%d9%84%d8%a7%d9%85-%d8%af%d9%86%db%8c%d8%a7/","2018-11-14","1","1");
INSERT INTO `st_statistics_pages` VALUES("/%d8%aa%d8%b3%d8%aa1/","2018-11-14","1","83");
INSERT INTO `st_statistics_pages` VALUES("/%d8%aa%d8%b3%d8%aa-2/","2018-11-14","1","85");
INSERT INTO `st_statistics_pages` VALUES("/%d8%aa%d8%b3%d8%aa-3/","2018-11-14","1","87");
INSERT INTO `st_statistics_pages` VALUES("/%da%af%d8%a7%d9%84%d8%b1%db%8c/","2018-11-14","1","2350");
INSERT INTO `st_statistics_pages` VALUES("//%da%af%d8%a7%d9%84%d8%b1%db%8c/","2018-11-14","1","2350");
INSERT INTO `st_statistics_pages` VALUES("/","2018-11-15","3","106");
INSERT INTO `st_statistics_pages` VALUES("/","2018-11-16","6","106");
INSERT INTO `st_statistics_pages` VALUES("/%da%af%d8%a7%d9%84%d8%b1%db%8c/","2018-11-16","1","2350");
INSERT INTO `st_statistics_pages` VALUES("/%d8%a7%d8%b1%d8%aa%d8%a8%d8%a7%d8%b7/","2018-11-16","1","28");
INSERT INTO `st_statistics_pages` VALUES("/%d8%af%d8%b1%d8%a8%d8%a7%d8%b1%d9%87/","2018-11-16","1","27");
INSERT INTO `st_statistics_pages` VALUES("/","2018-11-17","1","106");
INSERT INTO `st_statistics_pages` VALUES("/%d8%b1%d9%81%d8%b9-%d8%ae%d8%b7%d8%a7%db%8c-%d8%b1%d8%a7%d9%87-%d8%a7%d9%86%d8%af%d8%a7%d8%b2%db%8c-%d8%aa%d8%a7%d9%85%da%a9%d8%aa-%d9%87%d9%86%da%af%d8%a7%d9%85-%d8%a7%d8%aa%d8%b5%d8%a7%d9%84-%d8%a8/","2018-11-17","1","2383");
INSERT INTO `st_statistics_pages` VALUES("/","2018-11-18","3","106");
INSERT INTO `st_statistics_pages` VALUES("/","2018-11-19","1","106");
INSERT INTO `st_statistics_pages` VALUES("/%d8%b1%d9%81%d8%b9-%d8%ae%d8%b7%d8%a7%db%8c-%d8%b1%d8%a7%d9%87-%d8%a7%d9%86%d8%af%d8%a7%d8%b2%db%8c-%d8%aa%d8%a7%d9%85%da%a9%d8%aa-%d9%87%d9%86%da%af%d8%a7%d9%85-%d8%a7%d8%aa%d8%b5%d8%a7%d9%84-%d8%a8/","2018-11-19","1","2383");


DROP TABLE IF EXISTS `st_statistics_search`;

CREATE TABLE `st_statistics_search` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `last_counter` date NOT NULL,
  `engine` varchar(64) NOT NULL,
  `host` varchar(255) DEFAULT NULL,
  `words` varchar(255) DEFAULT NULL,
  `visitor` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `last_counter` (`last_counter`),
  KEY `engine` (`engine`),
  KEY `host` (`host`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `st_statistics_useronline`;

CREATE TABLE `st_statistics_useronline` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(60) NOT NULL,
  `created` int(11) DEFAULT NULL,
  `timestamp` int(10) NOT NULL,
  `date` datetime NOT NULL,
  `referred` text NOT NULL,
  `agent` varchar(255) NOT NULL,
  `platform` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `location` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=92 DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `st_statistics_visit`;

CREATE TABLE `st_statistics_visit` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `last_visit` datetime NOT NULL,
  `last_counter` date NOT NULL,
  `visit` int(10) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `unique_date` (`last_counter`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

INSERT INTO `st_statistics_visit` VALUES("1","2018-11-13 13:26:28","2018-11-13","351");
INSERT INTO `st_statistics_visit` VALUES("2","2018-11-14 12:47:00","2018-11-14","1168");
INSERT INTO `st_statistics_visit` VALUES("3","2018-11-15 04:57:34","2018-11-15","10");
INSERT INTO `st_statistics_visit` VALUES("4","2018-11-16 10:55:02","2018-11-16","31");
INSERT INTO `st_statistics_visit` VALUES("5","0000-00-00 00:00:00","2018-11-17","6");
INSERT INTO `st_statistics_visit` VALUES("6","2018-11-18 10:13:11","2018-11-18","8");
INSERT INTO `st_statistics_visit` VALUES("7","2018-11-19 12:42:02","2018-11-19","6");
INSERT INTO `st_statistics_visit` VALUES("8","0000-00-00 00:00:00","2018-11-20","0");
INSERT INTO `st_statistics_visit` VALUES("9","0000-00-00 00:00:00","2018-11-21","0");


DROP TABLE IF EXISTS `st_statistics_visitor`;

CREATE TABLE `st_statistics_visitor` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `last_counter` date NOT NULL,
  `referred` text NOT NULL,
  `agent` varchar(255) NOT NULL,
  `platform` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `UAString` varchar(255) DEFAULT NULL,
  `ip` varchar(60) NOT NULL,
  `location` varchar(10) DEFAULT NULL,
  `hits` int(11) DEFAULT NULL,
  `honeypot` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `date_ip_agent` (`last_counter`,`ip`,`agent`(75),`platform`(75),`version`(75)),
  KEY `agent` (`agent`),
  KEY `platform` (`platform`),
  KEY `version` (`version`),
  KEY `location` (`location`)
) ENGINE=MyISAM AUTO_INCREMENT=52 DEFAULT CHARSET=utf8;

INSERT INTO `st_statistics_visitor` VALUES("1","2018-11-13","http://foolstacks.ir/wp-admin/plugin-install.php?s=wp+statistic&tab=search&type=term","Chrome","Windows","70.0.3538.77","","5.112.106.225","000","","");
INSERT INTO `st_statistics_visitor` VALUES("2","2018-11-13","http://foolstacks.ir","MSIE","Windows","11.0","","185.239.173.205","GB","3","0");
INSERT INTO `st_statistics_visitor` VALUES("3","2018-11-13","http://foolstacks.ir","MSIE","Windows","11.0","","5.112.106.225","IR","4","0");
INSERT INTO `st_statistics_visitor` VALUES("4","2018-11-13","http://foolstacks.ir","Chrome","Android","70.0.3538.80","","5.112.106.225","IR","13","0");
INSERT INTO `st_statistics_visitor` VALUES("5","2018-11-13","http://foolstacks.ir","نا معلوم","نا معلوم","نا معلوم","","13.210.188.208","AU","1","0");
INSERT INTO `st_statistics_visitor` VALUES("6","2018-11-13","http://foolstacks.ir","MSIE","Windows","11.0","","109.202.101.49","NL","6","0");
INSERT INTO `st_statistics_visitor` VALUES("7","2018-11-13","http://foolstacks.ir","Chrome","Android","70.0.3538.80","","192.95.47.194","CA","10","0");
INSERT INTO `st_statistics_visitor` VALUES("8","2018-11-13","http://foolstacks.ir/","Chrome","Android","70.0.3538.80","","109.202.101.49","NL","170","0");
INSERT INTO `st_statistics_visitor` VALUES("9","2018-11-13","http://foolstacks.ir","SamsungBrowser","Android","7.4","","5.112.15.223","IR","49","0");
INSERT INTO `st_statistics_visitor` VALUES("10","2018-11-13","http://foolstacks.ir/?page_id=28","MSIE","Windows","11.0","","91.251.46.50","IR","87","0");
INSERT INTO `st_statistics_visitor` VALUES("11","2018-11-13","http://foolstacks.ir","Chrome","Windows","70.0.3538.77","","91.251.46.50","IR","7","0");
INSERT INTO `st_statistics_visitor` VALUES("12","2018-11-14","http://foolstacks.ir","Chrome","Windows","70.0.3538.77","","91.251.46.50","IR","14","0");
INSERT INTO `st_statistics_visitor` VALUES("13","2018-11-14","http://foolstacks.ir","Microsoft","نا معلوم","نا معلوم","","198.48.181.170","CA","1","0");
INSERT INTO `st_statistics_visitor` VALUES("14","2018-11-14","http://foolstacks.ir","MSIE","Windows","7.0","","198.48.181.170","CA","1","0");
INSERT INTO `st_statistics_visitor` VALUES("15","2018-11-14","http://foolstacks.ir","Chrome","Windows","70.0.3538.77","","198.48.181.170","CA","4","0");
INSERT INTO `st_statistics_visitor` VALUES("16","2018-11-14","http://foolstacks.ir","MSIE","Windows","11.0","","91.251.46.50","IR","7","0");
INSERT INTO `st_statistics_visitor` VALUES("17","2018-11-14","http://foolstacks.ir","Chrome","Android","70.0.3538.80","","91.251.46.50","IR","97","0");
INSERT INTO `st_statistics_visitor` VALUES("18","2018-11-14","http://foolstacks.ir","weborama-fetcher","نا معلوم","نا معلوم","","34.241.209.24","IE","5","0");
INSERT INTO `st_statistics_visitor` VALUES("19","2018-11-14","http://foolstacks.ir/%d8%a8%d9%84%d8%a7%da%af/","Chrome","Android","70.0.3538.80","","91.251.11.14","IR","108","0");
INSERT INTO `st_statistics_visitor` VALUES("20","2018-11-14","http://foolstacks.ir","Chrome","Android","70.0.3538.80","","185.180.15.230","CZ","78","0");
INSERT INTO `st_statistics_visitor` VALUES("21","2018-11-14","http://foolstacks.ir","Chrome","Windows","70.0.3538.102","","91.251.11.14","IR","19","0");
INSERT INTO `st_statistics_visitor` VALUES("22","2018-11-14","http://foolstacks.ir","MSIE","Windows","11.0","","91.251.11.14","IR","15","0");
INSERT INTO `st_statistics_visitor` VALUES("23","2018-11-14","http://foolstacks.ir","Firefox","Windows","63.0","","185.239.173.206","GB","8","0");
INSERT INTO `st_statistics_visitor` VALUES("24","2018-11-14","http://foolstacks.ir","Chrome","Windows","70.0.3538.102","","185.239.173.206","GB","17","0");
INSERT INTO `st_statistics_visitor` VALUES("25","2018-11-14","http://foolstacks.ir","MSIE","Windows","11.0","","185.239.173.206","GB","7","0");
INSERT INTO `st_statistics_visitor` VALUES("26","2018-11-14","http://foolstacks.ir","Chrome","Android","70.0.3538.80","","109.202.101.49","NL","72","0");
INSERT INTO `st_statistics_visitor` VALUES("27","2018-11-14","android-app://org.telegram.messenger","Chrome","Android","70.0.3538.80","","109.202.101.35","NL","99","0");
INSERT INTO `st_statistics_visitor` VALUES("28","2018-11-14","http://foolstacks.ir","Chrome","Android","70.0.3538.80","","109.202.101.50","NL","73","0");
INSERT INTO `st_statistics_visitor` VALUES("29","2018-11-14","android-app://org.telegram.messenger","Chrome","Android","69.0.3497.100","","83.123.13.186","IR","69","0");
INSERT INTO `st_statistics_visitor` VALUES("30","2018-11-14","http://foolstacks.ir/wp-content/themes/betheme/css/base.css?ver=8.8","Firefox","Windows","63.0","","5.112.250.213","IR","57","0");
INSERT INTO `st_statistics_visitor` VALUES("31","2018-11-14","https://foolstacks.ir","Safari","iPhone","12.0","","31.56.188.130","IR","15","0");
INSERT INTO `st_statistics_visitor` VALUES("32","2018-11-14","android-app://org.telegram.messenger","Chrome","Android","70.0.3538.80","","37.59.65.0","GB","42","0");
INSERT INTO `st_statistics_visitor` VALUES("33","2018-11-14","http://foolstacks.ir","MSIE","Windows","11.0","","5.112.250.213","IR","39","0");
INSERT INTO `st_statistics_visitor` VALUES("34","2018-11-14","http://foolstacks.ir","Chrome","Windows","70.0.3538.102","","5.112.250.213","IR","1","0");
INSERT INTO `st_statistics_visitor` VALUES("35","2018-11-14","android-app://org.telegram.messenger","Chrome","Android","70.0.3538.80","","178.63.238.135","DE","30","0");
INSERT INTO `st_statistics_visitor` VALUES("36","2018-11-14","android-app://org.telegram.messenger","Chrome","Android","55.0.2883.91","","2605:3e80:800::2628","FR","29","0");
INSERT INTO `st_statistics_visitor` VALUES("37","2018-11-14","http://foolstacks.ir/","Chrome","Android","55.0.2883.91","","192.119.167.21","US","16","0");
INSERT INTO `st_statistics_visitor` VALUES("38","2018-11-14","http://foolstacks.ir","Chrome","Windows","70.0.3538.102","","5.113.56.201","IR","2","0");
INSERT INTO `st_statistics_visitor` VALUES("39","2018-11-14","http://foolstacks.ir","Chrome","Android","70.0.3538.80","","89.165.30.10","IR","2","0");
INSERT INTO `st_statistics_visitor` VALUES("40","2018-11-14","http://foolstacks.ir","Chrome","Android","70.0.3538.80","","5.113.100.66","IR","180","0");
INSERT INTO `st_statistics_visitor` VALUES("41","2018-11-14","http://foolstacks.ir","SamsungBrowser","Android","7.4","","142.93.188.191","US","30","0");
INSERT INTO `st_statistics_visitor` VALUES("42","2018-11-14","android-app://ir.hotgram.mobile.android","Chrome","Android","70.0.3538.80","","5.112.15.223","IR","30","0");
INSERT INTO `st_statistics_visitor` VALUES("43","2018-11-15","http://foolstacks.ir","Firefox","Windows","54.0","","54.244.175.196","US","1","0");
INSERT INTO `st_statistics_visitor` VALUES("44","2018-11-15","http://foolstacks.ir","Chrome","Windows","10.0","","5.113.225.207","IR","1","0");
INSERT INTO `st_statistics_visitor` VALUES("45","2018-11-15","http://foolstacks.ir","Edge","Windows","10.0","","40.77.170.249","US","8","0");
INSERT INTO `st_statistics_visitor` VALUES("46","2018-11-16","http://foolstacks.ir","Chrome","Windows","10.0","","86.55.170.217","IR","16","0");
INSERT INTO `st_statistics_visitor` VALUES("47","2018-11-16","http://foolstacks.ir","Internet Explorer","Windows","10.0","","86.55.170.217","IR","15","0");
INSERT INTO `st_statistics_visitor` VALUES("48","2018-11-17","http://foolstacks.ir","Chrome","Windows","10.0","","5.112.217.133","IR","6","0");
INSERT INTO `st_statistics_visitor` VALUES("49","2018-11-18","http://foolstacks.ir","Chrome","Windows","10.0","","31.2.206.232","IR","7","0");
INSERT INTO `st_statistics_visitor` VALUES("50","2018-11-18","http://foolstacks.ir","Chrome","Windows","10.0","","89.198.67.213","IR","1","0");
INSERT INTO `st_statistics_visitor` VALUES("51","2018-11-19","http://foolstacks.ir","Chrome","Windows","10.0","","5.114.76.250","IR","6","0");


DROP TABLE IF EXISTS `st_term_relationships`;

CREATE TABLE `st_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `st_term_relationships` VALUES("105","18","0");
INSERT INTO `st_term_relationships` VALUES("37","2","0");
INSERT INTO `st_term_relationships` VALUES("38","2","0");
INSERT INTO `st_term_relationships` VALUES("39","2","0");
INSERT INTO `st_term_relationships` VALUES("40","2","0");
INSERT INTO `st_term_relationships` VALUES("41","3","0");
INSERT INTO `st_term_relationships` VALUES("42","3","0");
INSERT INTO `st_term_relationships` VALUES("43","3","0");
INSERT INTO `st_term_relationships` VALUES("44","3","0");
INSERT INTO `st_term_relationships` VALUES("45","3","0");
INSERT INTO `st_term_relationships` VALUES("47","3","0");
INSERT INTO `st_term_relationships` VALUES("48","3","0");
INSERT INTO `st_term_relationships` VALUES("2383","42","0");
INSERT INTO `st_term_relationships` VALUES("83","13","0");
INSERT INTO `st_term_relationships` VALUES("87","6","0");
INSERT INTO `st_term_relationships` VALUES("87","11","0");
INSERT INTO `st_term_relationships` VALUES("85","5","0");
INSERT INTO `st_term_relationships` VALUES("83","8","0");
INSERT INTO `st_term_relationships` VALUES("85","10","0");
INSERT INTO `st_term_relationships` VALUES("1","17","0");
INSERT INTO `st_term_relationships` VALUES("2383","40","0");
INSERT INTO `st_term_relationships` VALUES("2383","41","0");
INSERT INTO `st_term_relationships` VALUES("2187","20","0");
INSERT INTO `st_term_relationships` VALUES("2187","21","0");
INSERT INTO `st_term_relationships` VALUES("2188","19","0");
INSERT INTO `st_term_relationships` VALUES("2189","19","0");
INSERT INTO `st_term_relationships` VALUES("2189","20","0");
INSERT INTO `st_term_relationships` VALUES("2190","19","0");
INSERT INTO `st_term_relationships` VALUES("2190","20","0");
INSERT INTO `st_term_relationships` VALUES("2191","19","0");
INSERT INTO `st_term_relationships` VALUES("2191","20","0");
INSERT INTO `st_term_relationships` VALUES("2191","21","0");
INSERT INTO `st_term_relationships` VALUES("2193","20","0");
INSERT INTO `st_term_relationships` VALUES("2194","22","0");
INSERT INTO `st_term_relationships` VALUES("2290","37","0");
INSERT INTO `st_term_relationships` VALUES("2290","38","0");
INSERT INTO `st_term_relationships` VALUES("2290","39","0");
INSERT INTO `st_term_relationships` VALUES("2353","22","0");
INSERT INTO `st_term_relationships` VALUES("2352","22","0");
INSERT INTO `st_term_relationships` VALUES("2354","22","0");
INSERT INTO `st_term_relationships` VALUES("2355","22","0");
INSERT INTO `st_term_relationships` VALUES("2383","43","0");


DROP TABLE IF EXISTS `st_term_taxonomy`;

CREATE TABLE `st_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=MyISAM AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `st_term_taxonomy` VALUES("1","1","category","","0","0");
INSERT INTO `st_term_taxonomy` VALUES("2","2","nav_menu","","0","4");
INSERT INTO `st_term_taxonomy` VALUES("3","3","nav_menu","","0","7");
INSERT INTO `st_term_taxonomy` VALUES("4","4","category","","0","0");
INSERT INTO `st_term_taxonomy` VALUES("5","5","category","","0","1");
INSERT INTO `st_term_taxonomy` VALUES("6","6","category","","0","1");
INSERT INTO `st_term_taxonomy` VALUES("7","7","category","","0","0");
INSERT INTO `st_term_taxonomy` VALUES("8","8","category","","0","1");
INSERT INTO `st_term_taxonomy` VALUES("9","9","category","","0","0");
INSERT INTO `st_term_taxonomy` VALUES("10","10","post_tag","","0","1");
INSERT INTO `st_term_taxonomy` VALUES("11","11","post_tag","","0","1");
INSERT INTO `st_term_taxonomy` VALUES("12","12","post_tag","","0","0");
INSERT INTO `st_term_taxonomy` VALUES("13","13","post_tag","","0","1");
INSERT INTO `st_term_taxonomy` VALUES("14","14","post_tag","","0","0");
INSERT INTO `st_term_taxonomy` VALUES("15","15","post_tag","","0","0");
INSERT INTO `st_term_taxonomy` VALUES("16","16","post_tag","","0","0");
INSERT INTO `st_term_taxonomy` VALUES("18","18","category","","0","0");
INSERT INTO `st_term_taxonomy` VALUES("17","17","category","","0","1");
INSERT INTO `st_term_taxonomy` VALUES("19","19","portfolio-types","","0","4");
INSERT INTO `st_term_taxonomy` VALUES("20","20","portfolio-types","","0","5");
INSERT INTO `st_term_taxonomy` VALUES("21","21","portfolio-types","","0","2");
INSERT INTO `st_term_taxonomy` VALUES("22","22","nav_menu","","0","5");
INSERT INTO `st_term_taxonomy` VALUES("37","37","category","","0","1");
INSERT INTO `st_term_taxonomy` VALUES("23","23","product_type","","0","0");
INSERT INTO `st_term_taxonomy` VALUES("24","24","product_type","","0","0");
INSERT INTO `st_term_taxonomy` VALUES("25","25","product_type","","0","0");
INSERT INTO `st_term_taxonomy` VALUES("26","26","product_type","","0","0");
INSERT INTO `st_term_taxonomy` VALUES("27","27","product_visibility","","0","0");
INSERT INTO `st_term_taxonomy` VALUES("28","28","product_visibility","","0","0");
INSERT INTO `st_term_taxonomy` VALUES("29","29","product_visibility","","0","0");
INSERT INTO `st_term_taxonomy` VALUES("30","30","product_visibility","","0","0");
INSERT INTO `st_term_taxonomy` VALUES("31","31","product_visibility","","0","0");
INSERT INTO `st_term_taxonomy` VALUES("32","32","product_visibility","","0","0");
INSERT INTO `st_term_taxonomy` VALUES("33","33","product_visibility","","0","0");
INSERT INTO `st_term_taxonomy` VALUES("34","34","product_visibility","","0","0");
INSERT INTO `st_term_taxonomy` VALUES("35","35","product_visibility","","0","0");
INSERT INTO `st_term_taxonomy` VALUES("36","36","product_cat","","0","0");
INSERT INTO `st_term_taxonomy` VALUES("38","38","post_tag","","0","1");
INSERT INTO `st_term_taxonomy` VALUES("39","39","post_tag","","0","1");
INSERT INTO `st_term_taxonomy` VALUES("40","40","category","","0","1");
INSERT INTO `st_term_taxonomy` VALUES("41","41","post_tag","","0","1");
INSERT INTO `st_term_taxonomy` VALUES("42","42","post_tag","","0","1");
INSERT INTO `st_term_taxonomy` VALUES("43","43","post_tag","","0","1");


DROP TABLE IF EXISTS `st_termmeta`;

CREATE TABLE `st_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `st_terms`;

CREATE TABLE `st_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=MyISAM AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `st_terms` VALUES("1","دسته‌بندی نشده","%d8%af%d8%b3%d8%aa%d9%87%e2%80%8c%d8%a8%d9%86%d8%af%db%8c-%d9%86%d8%b4%d8%af%d9%87","0");
INSERT INTO `st_terms` VALUES("2","فهرست بالایی","%d9%81%d9%87%d8%b1%d8%b3%d8%aa-%d8%a8%d8%a7%d9%84%d8%a7%db%8c%db%8c","0");
INSERT INTO `st_terms` VALUES("3","فهرست شبکه‌های اجتماعی","%d9%81%d9%87%d8%b1%d8%b3%d8%aa-%d8%b4%d8%a8%da%a9%d9%87%e2%80%8c%d9%87%d8%a7%db%8c-%d8%a7%d8%ac%d8%aa%d9%85%d8%a7%d8%b9%db%8c","0");
INSERT INTO `st_terms` VALUES("4","علمی","%d8%b9%d9%84%d9%85%db%8c","0");
INSERT INTO `st_terms` VALUES("5","تاریخی","%d8%aa%d8%a7%d8%b1%db%8c%d8%ae%db%8c","0");
INSERT INTO `st_terms` VALUES("6","فرهنگی","%d9%81%d8%b1%d9%87%d9%86%da%af%db%8c","0");
INSERT INTO `st_terms` VALUES("7","هنری","%d9%87%d9%86%d8%b1%db%8c","0");
INSERT INTO `st_terms` VALUES("8","ورزشی","%d9%88%d8%b1%d8%b2%d8%b4%db%8c","0");
INSERT INTO `st_terms` VALUES("9","فناوری","%d9%81%d9%86%d8%a7%d9%88%d8%b1%db%8c","0");
INSERT INTO `st_terms` VALUES("10","ایران","%d8%a7%db%8c%d8%b1%d8%a7%d9%86","0");
INSERT INTO `st_terms` VALUES("11","کرمان","%da%a9%d8%b1%d9%85%d8%a7%d9%86","0");
INSERT INTO `st_terms` VALUES("12","بافت","%d8%a8%d8%a7%d9%81%d8%aa","0");
INSERT INTO `st_terms` VALUES("13","شطرنج","%d8%b4%d8%b7%d8%b1%d9%86%d8%ac","0");
INSERT INTO `st_terms` VALUES("14","لینوکس","%d9%84%db%8c%d9%86%d9%88%da%a9%d8%b3","0");
INSERT INTO `st_terms` VALUES("15","گیت هاب","%da%af%db%8c%d8%aa-%d9%87%d8%a7%d8%a8","0");
INSERT INTO `st_terms` VALUES("16","سیستم عامل","%d8%b3%db%8c%d8%b3%d8%aa%d9%85-%d8%b9%d8%a7%d9%85%d9%84","0");
INSERT INTO `st_terms` VALUES("17","عمومی","%d8%b9%d9%85%d9%88%d9%85%db%8c","0");
INSERT INTO `st_terms` VALUES("18","Uncategorized","uncategorized","0");
INSERT INTO `st_terms` VALUES("19","Photos","photos","0");
INSERT INTO `st_terms` VALUES("20","Video","video","0");
INSERT INTO `st_terms` VALUES("21","Webdesign","webdesign","0");
INSERT INTO `st_terms` VALUES("22","Main Menu","main-menu","0");
INSERT INTO `st_terms` VALUES("23","simple","simple","0");
INSERT INTO `st_terms` VALUES("24","grouped","grouped","0");
INSERT INTO `st_terms` VALUES("25","variable","variable","0");
INSERT INTO `st_terms` VALUES("26","external","external","0");
INSERT INTO `st_terms` VALUES("27","exclude-from-search","exclude-from-search","0");
INSERT INTO `st_terms` VALUES("28","exclude-from-catalog","exclude-from-catalog","0");
INSERT INTO `st_terms` VALUES("29","featured","featured","0");
INSERT INTO `st_terms` VALUES("30","outofstock","outofstock","0");
INSERT INTO `st_terms` VALUES("31","rated-1","rated-1","0");
INSERT INTO `st_terms` VALUES("32","rated-2","rated-2","0");
INSERT INTO `st_terms` VALUES("33","rated-3","rated-3","0");
INSERT INTO `st_terms` VALUES("34","rated-4","rated-4","0");
INSERT INTO `st_terms` VALUES("35","rated-5","rated-5","0");
INSERT INTO `st_terms` VALUES("36","Uncategorized","uncategorized","0");
INSERT INTO `st_terms` VALUES("37","سرگرمی","%d8%b3%d8%b1%da%af%d8%b1%d9%85%db%8c","0");
INSERT INTO `st_terms` VALUES("38","marvel","marvel","0");
INSERT INTO `st_terms` VALUES("39","Stan lee","stan-lee","0");
INSERT INTO `st_terms` VALUES("40","برنامه نویسی","%d8%a8%d8%b1%d9%86%d8%a7%d9%85%d9%87-%d9%86%d9%88%db%8c%d8%b3%db%8c","0");
INSERT INTO `st_terms` VALUES("41","جاوا","%d8%ac%d8%a7%d9%88%d8%a7","0");
INSERT INTO `st_terms` VALUES("42","تامکت","%d8%aa%d8%a7%d9%85%da%a9%d8%aa","0");
INSERT INTO `st_terms` VALUES("43","اکلیپس","%d8%a7%da%a9%d9%84%db%8c%d9%be%d8%b3","0");


DROP TABLE IF EXISTS `st_usermeta`;

CREATE TABLE `st_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM AUTO_INCREMENT=98 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `st_usermeta` VALUES("1","1","nickname","سپیده");
INSERT INTO `st_usermeta` VALUES("2","1","first_name","");
INSERT INTO `st_usermeta` VALUES("3","1","last_name","");
INSERT INTO `st_usermeta` VALUES("4","1","description","");
INSERT INTO `st_usermeta` VALUES("5","1","rich_editing","true");
INSERT INTO `st_usermeta` VALUES("6","1","syntax_highlighting","true");
INSERT INTO `st_usermeta` VALUES("7","1","comment_shortcuts","false");
INSERT INTO `st_usermeta` VALUES("8","1","admin_color","fresh");
INSERT INTO `st_usermeta` VALUES("9","1","use_ssl","0");
INSERT INTO `st_usermeta` VALUES("10","1","show_admin_bar_front","true");
INSERT INTO `st_usermeta` VALUES("11","1","locale","");
INSERT INTO `st_usermeta` VALUES("12","1","st_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `st_usermeta` VALUES("13","1","st_user_level","10");
INSERT INTO `st_usermeta` VALUES("14","1","dismissed_wp_pointers","wp496_privacy,vc_pointers_backend_editor");
INSERT INTO `st_usermeta` VALUES("15","1","show_welcome_panel","1");
INSERT INTO `st_usermeta` VALUES("16","1","session_tokens","a:5:{s:64:\"ba3ee42c962e40e7b11514df08d318314cb57f1d71eb04674e3379e0f04be8af\";a:4:{s:10:\"expiration\";i:1542473685;s:2:\"ip\";s:13:\"5.113.225.207\";s:2:\"ua\";s:115:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36\";s:5:\"login\";i:1542300885;}s:64:\"da7dee96366900fffc09f5737a4427dc5b7424448cc7b68bdfce2679bb2b6177\";a:4:{s:10:\"expiration\";i:1542519750;s:2:\"ip\";s:13:\"86.55.170.217\";s:2:\"ua\";s:115:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36\";s:5:\"login\";i:1542346950;}s:64:\"f09339960e7d14018dfbd2b641e58796c7f316a88a49184460e72593e6cd5b42\";a:4:{s:10:\"expiration\";i:1542523638;s:2:\"ip\";s:13:\"86.55.170.217\";s:2:\"ua\";s:115:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36\";s:5:\"login\";i:1542350838;}s:64:\"684fc53635d13fdd7be14c8998012bd308c50e0c8c1578660ec510b6233663bc\";a:4:{s:10:\"expiration\";i:1542525335;s:2:\"ip\";s:13:\"86.55.170.217\";s:2:\"ua\";s:115:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36\";s:5:\"login\";i:1542352535;}s:64:\"3cb96aded8df18b312a469be694e8ad3f0a920dbcaa24e9f861cdf41af3d8e02\";a:4:{s:10:\"expiration\";i:1542622762;s:2:\"ip\";s:13:\"5.112.217.133\";s:2:\"ua\";s:115:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36\";s:5:\"login\";i:1542449962;}}");
INSERT INTO `st_usermeta` VALUES("17","1","st_user-settings","libraryContent=browse&editor=tinymce&mfold=o");
INSERT INTO `st_usermeta` VALUES("18","1","st_user-settings-time","1542450333");
INSERT INTO `st_usermeta` VALUES("19","1","st_dashboard_quick_press_last_post_id","2382");
INSERT INTO `st_usermeta` VALUES("20","1","community-events-location","a:1:{s:2:\"ip\";s:11:\"5.112.217.0\";}");
INSERT INTO `st_usermeta` VALUES("21","1","managenav-menuscolumnshidden","a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}");
INSERT INTO `st_usermeta` VALUES("22","1","metaboxhidden_nav-menus","a:2:{i:0;s:12:\"add-post_tag\";i:1;s:15:\"add-post_format\";}");
INSERT INTO `st_usermeta` VALUES("23","1","tgmpa_dismissed_notice","1");
INSERT INTO `st_usermeta` VALUES("88","1","wpseo-has-mailchimp-signup","1");
INSERT INTO `st_usermeta` VALUES("90","1","wpseo-remove-upsell-notice","1");
INSERT INTO `st_usermeta` VALUES("25","1","_woocommerce_persistent_cart_1","a:1:{s:4:\"cart\";a:0:{}}");
INSERT INTO `st_usermeta` VALUES("26","1","wc_last_active","1542412800");
INSERT INTO `st_usermeta` VALUES("27","1","wp_statistics","a:2:{s:13:\"dashboard_set\";s:6:\"12.4.3\";s:10:\"editor_set\";s:6:\"12.4.3\";}");
INSERT INTO `st_usermeta` VALUES("28","1","metaboxhidden_dashboard","a:12:{i:0;s:29:\"wp-statistics-browsers-widget\";i:1;s:30:\"wp-statistics-countries-widget\";i:2;s:28:\"wp-statistics-hitsmap-widget\";i:3;s:25:\"wp-statistics-hits-widget\";i:4;s:26:\"wp-statistics-pages-widget\";i:5;s:27:\"wp-statistics-recent-widget\";i:6;s:30:\"wp-statistics-referring-widget\";i:7;s:27:\"wp-statistics-search-widget\";i:8;s:28:\"wp-statistics-summary-widget\";i:9;s:26:\"wp-statistics-words-widget\";i:10;s:33:\"wp-statistics-top-visitors-widget\";i:11;s:37:\"wp-statistics-searched-phrases-widget\";}");
INSERT INTO `st_usermeta` VALUES("30","1","last_login_time","2018-11-17 13:49:22");
INSERT INTO `st_usermeta` VALUES("34","1","metaboxhidden_post","a:1:{i:0;s:29:\"wp_statistics_editor_meta_box\";}");
INSERT INTO `st_usermeta` VALUES("35","1","metaboxhidden_page","a:1:{i:0;s:29:\"wp_statistics_editor_meta_box\";}");
INSERT INTO `st_usermeta` VALUES("36","1","_yoast_wpseo_profile_updated","1542152354");
INSERT INTO `st_usermeta` VALUES("39","1","nav_menu_recently_edited","22");
INSERT INTO `st_usermeta` VALUES("41","1","wpseo_title","");
INSERT INTO `st_usermeta` VALUES("42","1","wpseo_metadesc","");
INSERT INTO `st_usermeta` VALUES("43","1","wpseo_noindex_author","");
INSERT INTO `st_usermeta` VALUES("44","1","wpseo_content_analysis_disable","");
INSERT INTO `st_usermeta` VALUES("45","1","wpseo_keyword_analysis_disable","");
INSERT INTO `st_usermeta` VALUES("46","1","billing_first_name","");
INSERT INTO `st_usermeta` VALUES("47","1","billing_last_name","");
INSERT INTO `st_usermeta` VALUES("48","1","billing_company","");
INSERT INTO `st_usermeta` VALUES("49","1","billing_address_1","");
INSERT INTO `st_usermeta` VALUES("50","1","billing_address_2","");
INSERT INTO `st_usermeta` VALUES("51","1","billing_city","");
INSERT INTO `st_usermeta` VALUES("52","1","billing_postcode","");
INSERT INTO `st_usermeta` VALUES("53","1","billing_country","");
INSERT INTO `st_usermeta` VALUES("54","1","billing_state","");
INSERT INTO `st_usermeta` VALUES("55","1","billing_phone","");
INSERT INTO `st_usermeta` VALUES("56","1","billing_email","fullstackdiaries@gmail.com");
INSERT INTO `st_usermeta` VALUES("57","1","shipping_first_name","");
INSERT INTO `st_usermeta` VALUES("58","1","shipping_last_name","");
INSERT INTO `st_usermeta` VALUES("59","1","shipping_company","");
INSERT INTO `st_usermeta` VALUES("60","1","shipping_address_1","");
INSERT INTO `st_usermeta` VALUES("61","1","shipping_address_2","");
INSERT INTO `st_usermeta` VALUES("62","1","shipping_city","");
INSERT INTO `st_usermeta` VALUES("63","1","shipping_postcode","");
INSERT INTO `st_usermeta` VALUES("64","1","shipping_country","");
INSERT INTO `st_usermeta` VALUES("65","1","shipping_state","");
INSERT INTO `st_usermeta` VALUES("66","1","googleplus","");
INSERT INTO `st_usermeta` VALUES("67","1","twitter","");
INSERT INTO `st_usermeta` VALUES("68","1","facebook","");
INSERT INTO `st_usermeta` VALUES("69","1","last_update","1542152354");
INSERT INTO `st_usermeta` VALUES("91","1","st_yoast_notifications","a:2:{i:0;a:2:{s:7:\"message\";s:455:\"Yoast SEO and WooCommerce can work together a lot better by adding a helper plugin. Please install Yoast WooCommerce SEO to make your life better. <a href=\"https://yoa.st/1o0?php_version=5.6.38&platform=wordpress&platform_version=4.9.8&software=free&software_version=9.1&role=administrator&days_active=17852\" aria-label=\"اطلاعات بیشتر درباره Yoast WooCommerce SEO\" target=\"_blank\" rel=\"noopener noreferrer\">اطلاعات بیشتر</a>.\";s:7:\"options\";a:9:{s:4:\"type\";s:7:\"warning\";s:2:\"id\";s:44:\"wpseo-suggested-plugin-yoast-woocommerce-seo\";s:5:\"nonce\";N;s:8:\"priority\";d:0.5;s:9:\"data_json\";a:0:{}s:13:\"dismissal_key\";N;s:12:\"capabilities\";a:1:{i:0;s:15:\"install_plugins\";}s:16:\"capability_check\";s:3:\"all\";s:14:\"yoast_branding\";b:0;}}i:1;a:2:{s:7:\"message\";s:251:\"خطاهای خزیدن (Crawl) را از دست ندهید: <a href=\"http://foolstacks.ir/wp-admin/admin.php?page=wpseo_search_console&tab=settings\">با میز فرمان جستجوی گوگل در اینجا ارتباط برقرار کنید
</a>.\";s:7:\"options\";a:9:{s:4:\"type\";s:7:\"warning\";s:2:\"id\";s:17:\"wpseo-dismiss-gsc\";s:5:\"nonce\";N;s:8:\"priority\";d:0.5;s:9:\"data_json\";a:0:{}s:13:\"dismissal_key\";N;s:12:\"capabilities\";s:20:\"wpseo_manage_options\";s:16:\"capability_check\";s:3:\"all\";s:14:\"yoast_branding\";b:0;}}}");
INSERT INTO `st_usermeta` VALUES("92","1","st_wpseo-dismiss-gsc","seen");
INSERT INTO `st_usermeta` VALUES("93","1","st_wpseo-suggested-plugin-yoast-woocommerce-seo","seen");


DROP TABLE IF EXISTS `st_users`;

CREATE TABLE `st_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `st_users` VALUES("1","foolstacks","$P$BnctAwnPhfSHbdPC7DOhCo1opRgvv5/","foolstacks","fullstackdiaries@gmail.com","","2018-11-10 01:28:36","","0","سپیده");


DROP TABLE IF EXISTS `st_wc_download_log`;

CREATE TABLE `st_wc_download_log` (
  `download_log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` datetime NOT NULL,
  `permission_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `user_ip_address` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`download_log_id`),
  KEY `permission_id` (`permission_id`),
  KEY `timestamp` (`timestamp`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `st_wc_webhooks`;

CREATE TABLE `st_wc_webhooks` (
  `webhook_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `delivery_url` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `topic` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `api_version` smallint(4) NOT NULL,
  `failure_count` smallint(10) NOT NULL DEFAULT '0',
  `pending_delivery` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`webhook_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `st_woocommerce_api_keys`;

CREATE TABLE `st_woocommerce_api_keys` (
  `key_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `description` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permissions` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `consumer_key` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `consumer_secret` char(43) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nonces` longtext COLLATE utf8mb4_unicode_ci,
  `truncated_key` char(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_access` datetime DEFAULT NULL,
  PRIMARY KEY (`key_id`),
  KEY `consumer_key` (`consumer_key`),
  KEY `consumer_secret` (`consumer_secret`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `st_woocommerce_attribute_taxonomies`;

CREATE TABLE `st_woocommerce_attribute_taxonomies` (
  `attribute_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `attribute_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attribute_label` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attribute_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attribute_orderby` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attribute_public` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`attribute_id`),
  KEY `attribute_name` (`attribute_name`(20))
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `st_woocommerce_downloadable_product_permissions`;

CREATE TABLE `st_woocommerce_downloadable_product_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `download_id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `order_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `order_key` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_email` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `downloads_remaining` varchar(9) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `access_granted` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access_expires` datetime DEFAULT NULL,
  `download_count` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`permission_id`),
  KEY `download_order_key_product` (`product_id`,`order_id`,`order_key`(16),`download_id`),
  KEY `download_order_product` (`download_id`,`order_id`,`product_id`),
  KEY `order_id` (`order_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `st_woocommerce_log`;

CREATE TABLE `st_woocommerce_log` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` datetime NOT NULL,
  `level` smallint(4) NOT NULL,
  `source` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `context` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`log_id`),
  KEY `level` (`level`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `st_woocommerce_order_itemmeta`;

CREATE TABLE `st_woocommerce_order_itemmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_item_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `order_item_id` (`order_item_id`),
  KEY `meta_key` (`meta_key`(32))
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `st_woocommerce_order_items`;

CREATE TABLE `st_woocommerce_order_items` (
  `order_item_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_item_name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_item_type` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `order_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`order_item_id`),
  KEY `order_id` (`order_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `st_woocommerce_payment_tokenmeta`;

CREATE TABLE `st_woocommerce_payment_tokenmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `payment_token_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `payment_token_id` (`payment_token_id`),
  KEY `meta_key` (`meta_key`(32))
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `st_woocommerce_payment_tokens`;

CREATE TABLE `st_woocommerce_payment_tokens` (
  `token_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `gateway_id` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `type` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`token_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `st_woocommerce_sessions`;

CREATE TABLE `st_woocommerce_sessions` (
  `session_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `session_key` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_expiry` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`session_id`),
  UNIQUE KEY `session_key` (`session_key`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `st_woocommerce_shipping_zone_locations`;

CREATE TABLE `st_woocommerce_shipping_zone_locations` (
  `location_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `zone_id` bigint(20) unsigned NOT NULL,
  `location_code` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location_type` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `location_id` (`location_id`),
  KEY `location_type_code` (`location_type`(10),`location_code`(20))
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `st_woocommerce_shipping_zone_methods`;

CREATE TABLE `st_woocommerce_shipping_zone_methods` (
  `zone_id` bigint(20) unsigned NOT NULL,
  `instance_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `method_id` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `method_order` bigint(20) unsigned NOT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`instance_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `st_woocommerce_shipping_zones`;

CREATE TABLE `st_woocommerce_shipping_zones` (
  `zone_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `zone_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `zone_order` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`zone_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `st_woocommerce_tax_rate_locations`;

CREATE TABLE `st_woocommerce_tax_rate_locations` (
  `location_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `location_code` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tax_rate_id` bigint(20) unsigned NOT NULL,
  `location_type` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `tax_rate_id` (`tax_rate_id`),
  KEY `location_type_code` (`location_type`(10),`location_code`(20))
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `st_woocommerce_tax_rates`;

CREATE TABLE `st_woocommerce_tax_rates` (
  `tax_rate_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tax_rate_country` varchar(2) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tax_rate_state` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tax_rate` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tax_rate_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tax_rate_priority` bigint(20) unsigned NOT NULL,
  `tax_rate_compound` int(1) NOT NULL DEFAULT '0',
  `tax_rate_shipping` int(1) NOT NULL DEFAULT '1',
  `tax_rate_order` bigint(20) unsigned NOT NULL,
  `tax_rate_class` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`tax_rate_id`),
  KEY `tax_rate_country` (`tax_rate_country`),
  KEY `tax_rate_state` (`tax_rate_state`(2)),
  KEY `tax_rate_class` (`tax_rate_class`(10)),
  KEY `tax_rate_priority` (`tax_rate_priority`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `st_yoast_seo_links`;

CREATE TABLE `st_yoast_seo_links` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_id` bigint(20) unsigned NOT NULL,
  `target_post_id` bigint(20) unsigned NOT NULL,
  `type` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `link_direction` (`post_id`,`type`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `st_yoast_seo_links` VALUES("17","http://foolstacks.ir/wp-content/uploads/2018/11/What-is-a-Blog.mp4","27","0","internal");
INSERT INTO `st_yoast_seo_links` VALUES("16","#","27","0","internal");
INSERT INTO `st_yoast_seo_links` VALUES("15","#","27","0","internal");
INSERT INTO `st_yoast_seo_links` VALUES("13","#","27","0","internal");
INSERT INTO `st_yoast_seo_links` VALUES("14","#","27","0","internal");


DROP TABLE IF EXISTS `st_yoast_seo_meta`;

CREATE TABLE `st_yoast_seo_meta` (
  `object_id` bigint(20) unsigned NOT NULL,
  `internal_link_count` int(10) unsigned DEFAULT NULL,
  `incoming_link_count` int(10) unsigned DEFAULT NULL,
  UNIQUE KEY `object_id` (`object_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `st_yoast_seo_meta` VALUES("28","0","0");
INSERT INTO `st_yoast_seo_meta` VALUES("27","5","0");
INSERT INTO `st_yoast_seo_meta` VALUES("1","0","0");
INSERT INTO `st_yoast_seo_meta` VALUES("105","0","0");
INSERT INTO `st_yoast_seo_meta` VALUES("2240","0","0");
INSERT INTO `st_yoast_seo_meta` VALUES("83","0","0");
INSERT INTO `st_yoast_seo_meta` VALUES("85","0","0");
INSERT INTO `st_yoast_seo_meta` VALUES("87","0","0");
INSERT INTO `st_yoast_seo_meta` VALUES("106","0","0");
INSERT INTO `st_yoast_seo_meta` VALUES("2290","0","0");
INSERT INTO `st_yoast_seo_meta` VALUES("26","0","0");
INSERT INTO `st_yoast_seo_meta` VALUES("2296","0","0");
INSERT INTO `st_yoast_seo_meta` VALUES("2195","0","0");
INSERT INTO `st_yoast_seo_meta` VALUES("107","0","0");
INSERT INTO `st_yoast_seo_meta` VALUES("2313","0","0");
INSERT INTO `st_yoast_seo_meta` VALUES("2315","0","0");
INSERT INTO `st_yoast_seo_meta` VALUES("2317","0","0");
INSERT INTO `st_yoast_seo_meta` VALUES("2319","0","0");
INSERT INTO `st_yoast_seo_meta` VALUES("2323","0","0");
INSERT INTO `st_yoast_seo_meta` VALUES("2310","0","0");
INSERT INTO `st_yoast_seo_meta` VALUES("29","0","0");
INSERT INTO `st_yoast_seo_meta` VALUES("2333","0","0");
INSERT INTO `st_yoast_seo_meta` VALUES("2342","0","0");
INSERT INTO `st_yoast_seo_meta` VALUES("2350","0","0");
INSERT INTO `st_yoast_seo_meta` VALUES("109","0","0");
INSERT INTO `st_yoast_seo_meta` VALUES("112","0","0");
INSERT INTO `st_yoast_seo_meta` VALUES("113","0","0");
INSERT INTO `st_yoast_seo_meta` VALUES("5","0","0");
INSERT INTO `st_yoast_seo_meta` VALUES("6","0","0");
INSERT INTO `st_yoast_seo_meta` VALUES("7","0","0");
INSERT INTO `st_yoast_seo_meta` VALUES("14","0","0");
INSERT INTO `st_yoast_seo_meta` VALUES("15","0","0");
INSERT INTO `st_yoast_seo_meta` VALUES("16","0","0");
INSERT INTO `st_yoast_seo_meta` VALUES("8","0","0");
INSERT INTO `st_yoast_seo_meta` VALUES("9","0","0");
INSERT INTO `st_yoast_seo_meta` VALUES("10","0","0");
INSERT INTO `st_yoast_seo_meta` VALUES("11","0","0");
INSERT INTO `st_yoast_seo_meta` VALUES("12","0","0");
INSERT INTO `st_yoast_seo_meta` VALUES("13","0","0");
INSERT INTO `st_yoast_seo_meta` VALUES("22","0","0");
INSERT INTO `st_yoast_seo_meta` VALUES("17","0","0");
INSERT INTO `st_yoast_seo_meta` VALUES("18","0","0");
INSERT INTO `st_yoast_seo_meta` VALUES("19","0","0");
INSERT INTO `st_yoast_seo_meta` VALUES("20","0","0");
INSERT INTO `st_yoast_seo_meta` VALUES("21","0","0");
INSERT INTO `st_yoast_seo_meta` VALUES("2235","0","0");
INSERT INTO `st_yoast_seo_meta` VALUES("69","0","0");
INSERT INTO `st_yoast_seo_meta` VALUES("4","0","0");
INSERT INTO `st_yoast_seo_meta` VALUES("2242","0","0");
INSERT INTO `st_yoast_seo_meta` VALUES("2383","0","0");


